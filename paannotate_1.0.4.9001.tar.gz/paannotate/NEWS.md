# paannotate 1.0.4.9001

Data-free reviewer derivative. Analytical R files are unchanged.

# paannotate 1.0.4

- Updated package documentation and namespace declarations.
- Encoded existing figure text explicitly for portable source checks.

# paannotate 1.0.3

- Keep decimal-suffixed PAO1 genes in multi-project target scans when the
  input counts contain them. Whiteley's released count matrix lacks PA0714.1;
  individual Whiteley targets absent from the release now fail clearly.
- Add `pa_load_p2c_cohort()` and `pa_run_p2c_cohort()` for Whiteley-style
  target correlation meta-analysis across custom Paper2Counts cohorts.
- Resolve gene symbols from supplied assembly catalogs and report exact
  shared-gene coverage without imputing missing loci.

# paannotate 1.0.2

- Widen exported PNG/PDF heatmaps and wrap long titles so figure headings remain visible.
- Allow CSV-based reports without installing the optional `readxl` spreadsheet importer.

# paannotate 1.0.1

- Preserve assembly gene symbols and product descriptions when an analysis uses
  a frozen pathway-membership file alongside `gene_catalog`.
- Accept audited same-species strain references and documented manual reference
  overrides in organism-aware annotation retrieval.

# paannotate 1.0.0

- Added assembly-validated, organism/strain-aware KEGG and GO retrieval through
  `fetch_organism_annotations()`.
- Added direct GFF3 alias and UniProt/RefSeq accession bridging while preserving
  assembly-native locus tags as primary identifiers.
- Added provider/mapping evidence audits and fail-closed ambiguity handling.
- `pa_run_custom()` now accepts organism context, gene catalogs, and identifier
  crosswalks; PAO1 behavior remains available as the legacy default.

# paannotate 0.9.0

- Added `pao1_extended`, now the default identifier policy for
  `pa_run_custom()` and `pa_targets()`. Canonical locus tags and distinct
  decimal-suffixed historical subloci such as `PA0195.1` are retained without
  merging or relabeling.
- Added `gene_identifier_audit.csv`, which records each identifier's class,
  six-character historical anchor, annotation eligibility, and relationship
  evidence. A shared prefix is not treated as proof of homology and annotations
  are not inherited from the unsuffixed locus.

# paannotate 0.8.0

- Added `pa_run_custom()` as the beginner-facing entry point for one custom
  dataset. It automatically dispatches to target correlation, a two-condition
  edgeR/limma comparison, or enrichment of precomputed gene results.
- Custom reports deliberately omit meta-analysis concepts such as I2,
  cross-cutoff persistence, project replication, and leave-one-project-out
  stability; their gene tables use ordinary rho or log2-fold-change effects.
- Custom input accepts matrices, conventional or transposed tables, long-form
  expression, CSV/TSV/TXT, Excel, optional metadata, and precomputed
  edgeR/limma/DESeq2-style results, with an auditable input-type decision.
- Single-dataset ranked enrichment uses every evaluable gene and continues
  independently when no genes pass the FDR/effect cutoff needed for ORA.
- Canonical GO, KEGG, PseudoCAP, supplied, and custom database terms are now
  the default. Paannotate's manually curated umbrellas and iron collections
  are calculated and displayed only with `curated=TRUE`.
- Added a purpose-built single-dataset workbook, plain-language README,
  canonical enrichment folder, effect heatmaps, ranked dotplots, checkpoints,
  and direct compatibility with `pa_focus_pathways()`.

# paannotate 0.7.0

- Added `pa_check_whiteley_metadata_target()` to preview any two-level
  Whiteley metadata comparison and show sample coding, group counts, eligible
  BioProjects, confounding checks, and readiness at every requested cutoff.
- Added `pa_scan_whiteley_metadata()` and `pa_run_whiteley_metadata()` to test
  every gene against conditions such as M9 versus SCFM within BioProjects,
  combine the replicated effects, run the ordinary enrichment workflow, and
  produce the standard workbook and heatmaps.
- Metadata-target output reports both point-biserial association and the
  positive-minus-reference normalized log2-CPM difference, with complete
  project and sample audits. One-sided projects are documented but never used
  to estimate a condition effect.
- `pa_run_scan_config()` now accepts a `metadata_target` section, with a
  packaged `whiteley_metadata_target_config.yml` template.
- `pa_metadata_coverage()` now writes a level-by-level table showing how many
  samples and BioProjects support every documented metadata value.
- Heatmap clustering now tolerates structurally missing cells: all-empty rows
  and columns are removed and only an unsafe clustering axis is disabled,
  rather than losing an otherwise readable heatmap.

# paannotate 0.6.0

- Added `pa_metadata_coverage()` to quantify sample-, field-, and
  BioProject-level metadata gaps and create a result-independent project
  review priority list.
- Added `pa_build_accession_graph()` and `pa_fetch_whiteley_metadata()` to
  connect analysis samples to BioSample, BioProject, SRA, GEO, and PubMed
  accessions and cache machine-readable public records with a complete fetch
  manifest.
- Added `pa_export_metadata_queue()`, `pa_validate_metadata()`, and
  `pa_merge_metadata_overlay()` for project-oriented Excel review, protected
  identifiers, controlled-value checks, explicit evidence, versioned merges,
  and a cell-level change audit.
- Added versioned medium, treatment, and strain dictionaries. Standardized
  values participate in Whiteley filters while original wording is preserved.
- `pa_load_whiteley()`, `pa_check_whiteley_cohort()`,
  `pa_scan_whiteley()`, and `pa_run_whiteley()` now accept
  `metadata_overlay`; applying it never rebuilds the expression cache, and
  reports save the changes that affected the run.
- All `pa_focus_pathways()` dotplots now use a substantially wider,
  label-aware canvas and left margin so long ontology labels are not clipped.

# paannotate 0.5.4

- Added `pa_focus_pathways()` for making pathway-specific tables, heatmaps,
  ranked-enrichment dot plots, ORA dot plots, membership tables, and
  leading-edge gene views from a completed scan without rerunning the analysis.
- Focus searches accept exact IDs/names, literal keywords, regular expressions,
  named pathway collections, curated themes, and beginner-friendly presets such
  as `"iron"`, `"secretion"`, and `"biofilm"`.
- Focused views retain the enrichment analysis's original family and global FDR
  values rather than recalculating significance after pathway selection. Every
  report contains match, configuration, and plot-status audits.
- New enrichment objects retain exact pathway membership so focused reports can
  list every pathway member. Older saved reports remain supported using their
  observed ORA-overlap and ranked leading-edge genes.

# paannotate 0.5.3

- Ranked pathways for which fgsea returns non-finite P-values, FDRs, or NES
  values are now retained as explicitly non-evaluable audit rows and excluded
  from FDR correction, summaries, and plots. Valid pathway results continue
  without requiring users to tune fgsea arguments.
- Fixed the late report-stage crash caused by missing enrichment scores in
  heatmap matrix construction. Every heatmap is now failure-isolated and a
  `heatmap_status.csv` records created, empty, skipped, and failed panels.
- Multi-target scans now residualize each project's candidate-gene matrix once
  and reuse it across targets. Reports with multiple targets also receive
  combined heatmaps and automatic per-target heatmap folders.

# paannotate 0.5.2

- Fixed enrichment when no persistent genes pass a requested sample cutoff.
  ORA now returns an empty table for that cutoff instead of raising a
  zero-row data-frame assignment error, while full-ranked exact-term and
  curated-theme enrichment continue independently.
- Mixed-cutoff enrichment now tolerates cutoffs with no selected genes without
  discarding ORA results from cutoffs that do have selected genes.

# paannotate 0.5.1

- Added a versioned Whiteley medium-family dictionary. The friendly `media`
  filter now resolves `LB`, `lysogeny broth`, `Luria-Bertani broth`, and LB
  formulations to the canonical `LB` family, and resolves M9 formulations to
  `M9`, while preserving `medium_base`, `medium_full`, and `medium_raw`.
- Added `medium_family`, mapping status, rule, description, and dictionary
  version to cohort metadata and sample-selection audits.
- Deliberately leaves ambiguous `LBN medium` outside the LB family unless a
  user requests LBN explicitly. Existing prepared caches are upgraded in
  place without rebuilding the expression matrix.

# paannotate 0.5.0

- `pa_run_whiteley()` and `pa_scan_whiteley()` now use the complete Whiteley
  release by default: 7,301 count profiles aggregated to 5,932
  project-specific BioSamples. Count QC transparently removes 111 zero-signal
  profiles, leaving 5,821 analyzable samples across 470 project groups.
- Added `use_curated_414 = TRUE` as an exact compatibility preset for the
  frozen 414-sample/46-BioProject cohort.
- Added friendly strain, medium, context, engineered-sample, and BioProject
  filters; arbitrary include/exclude metadata filters; formula/function-based
  custom selection; configurable text matching; and explicit missing-metadata
  behavior.
- Added `pa_check_whiteley_cohort()` for a metadata-only preview before a long
  scan. Every report now includes sample-level selection decisions, filtering
  counts, and project sizes before and after filtering.
- The full release joins `all_metadata.csv` to the count data and uses the
  curated PAO1 condition atlas as a structured metadata overlay where
  available. Runs without metadata are retained as visibly `UNASSIGNED`.
- Project-level correlations are now vectorized, making the substantially
  larger default cohort practical without changing the correlation statistic.

# paannotate 0.4.1

- Added a frozen Whiteley PAO1 profile covering 414 curated BioSamples, 523
  technical runs, and 46 BioProjects. BioProject and study-arm fields are now
  internal resources rather than required user uploads.
- Added `pa_load_whiteley()`, `pa_scan_whiteley()`, and `pa_run_whiteley()` so a
  user can provide only an arbitrary gene/signature, analysis thresholds, and
  an output directory.
- Matched the reference 46-project workflow's technical-run aggregation,
  within-project edgeR TMM/log-CPM normalization, candidate-gene CPM/MAD
  filters, target detection/variability/coherence rules, and intercept-only
  handling for single-arm projects.
- Added a target-only YAML template and configuration mode, while preserving
  explicit expression/metadata inputs for custom compendia.

# paannotate 0.4.0

- Added arbitrary individual-gene and multi-gene signature definitions with
  project-specific standardized scoring and explicit target-coverage audits.
- Added within-project Spearman/Pearson scanning, optional formula-based
  covariate residualization, Fisher-z DerSimonian-Laird meta-analysis, full
  hypothesis-family BH correction, I2, directional agreement, fixed/random
  sensitivity, and leave-one-project-out stability.
- Added user-configurable project sample cutoffs, pairwise sample minima,
  residual degrees of freedom, FDR, rho, I2, project-count, and persistence
  rules.
- Added strict direction-specific ORA plus full-ranked fgsea/CAMERA-PR from the
  scan result, exact GO/KEGG/PseudoCAP term retention, retested curated umbrella
  gene sets, and dedicated iron-focused outputs.
- Added reader-oriented Excel reports, complete compressed audit tables, and
  PNG/PDF heatmaps for genes, exact pathways, umbrella themes, and iron systems.
- Added `pa_run_scan()` and a portable YAML interface through
  `pa_run_scan_config()`.

# paannotate 0.3.0

- Added `pa_read()` and `pa_check_input()` for audited input normalization,
  column aliases, and genes-in-columns/transposed layouts.
- Added `pa_combine()` for checked gene-ID joins between separate expression
  and statistics files.
- Added PseudoCAP/Pseudomonas Genome Database import, including gene length,
  products, pathways, and functional classes when present.
- Added Whiteley Lab count/TPM and metadata import with source provenance and
  per-gene compendium summaries.
- Added goseq-backed selection-bias-aware enrichment for gene length, mean
  expression, or a custom numeric bias.
- Added full-ranked CAMERA-PR, CAMERA, and fgsea workflows. CAMERA modes account
  for inter-gene correlation; full CAMERA can estimate correlation from
  normalized expression.
- Added `pa_help()`, `pa_check_setup()`, and the beginner `pa_run()` workflow.
- Preserved the `analyze_pa_csv()` interface and legacy Fisher enrichment
  outputs.
