# paannotate 1.0.4.9001 reviewer source candidate

This derivative preserves the standalone 1.0.4 R implementation and excludes
bundled extdata. Follow the accompanying reviewer package instructions for the
offline user-supplied count workflow. The built-in Whiteley presets, packaged
metadata dictionaries and default curated themes require separately authorized
resources. Supply your own membership data and, if needed, a themes table.
The maintainer email in DESCRIPTION is an upstream placeholder.

The MIT declaration and LICENSE file are inherited from standalone 1.0.4.
Institutional approval of the exact external package remains pending.
