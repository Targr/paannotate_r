# Pathway membership is frozen with the analysis; display subsets never refit tests.
.p2c_member_membership <- function(enrichment) {
  if(is.null(enrichment))return(data.frame())
  parts<-list(enrichment$exact$membership,enrichment$themes$membership)
  parts<-Filter(function(x)is.data.frame(x)&&nrow(x)>0,parts)
  if(!length(parts))return(data.frame())
  unique(do.call(rbind,lapply(parts,function(x)x[c('database','ontology','set_id','set_name','gene_id')])))
}
.p2c_member_index <- function(scan,enrichment,individual=NULL){
  m<-.p2c_member_membership(enrichment)
  pathways<-if(nrow(m))lapply(split(m,paste(m$database,m$ontology,m$set_id,sep='::')),function(x)list(id=paste(x$database[1],x$ontology[1],x$set_id[1],sep='::'),name=x$set_name[1],database=x$database[1],members=as.list(unique(x$gene_id)))) else list()
  membership<-scan$targets$membership
  requested<-unique(membership$gene_id)
  single<-scan$targets$targets$target[scan$targets$targets$requested_members==1]
  available_genes<-unique(membership$gene_id[membership$target%in%single])
  targets<-lapply(unique(membership$target),function(t)list(id=t,label=if(t%in%single)membership$gene_id[match(t,membership$target)] else t,type=if(t%in%single)'individual' else 'signature'))
  if(!is.null(individual))for(t in setdiff(requested,available_genes))targets[[length(targets)+1L]]<-list(id=t,label=t,type='individual')
  list(pathways=unname(pathways),targets=targets,requested_individual_genes=as.list(requested),
       individual_available=!is.null(individual)||all(requested%in%available_genes),
       modes=as.list(unique(scan$meta_analysis$analysis_mode)),cutoffs=as.list(scan$config$min_samples_per_project),
       studies=as.list(unique(scan$project_correlations$project_id)))
}
.p2c_write_member_index <- function(scan,enrichment,directory,individual=NULL){
  jsonlite::write_json(.p2c_member_index(scan,enrichment,individual),file.path(directory,'Pathway_index.json'),auto_unbox=TRUE,na='null',digits=NA)
}
.p2c_member_source <- function(scan,enrichment,request,individual=NULL){
  m<-.p2c_member_membership(enrichment)
  key<-paste(m$database,m$ontology,m$set_id,sep='::');term<-m[key==request$pathway,,drop=FALSE]
  if(!nrow(term))stop('Choose a pathway from this saved analysis.')
  ids<-unique(as.character(term$gene_id));mode<-request$mode;cutoff<-as.integer(request$cutoff)
  if(!mode%in%unique(scan$meta_analysis$analysis_mode)||!cutoff%in%scan$config$min_samples_per_project)stop('Choose an available analysis mode and sample cutoff.')
  index<-.p2c_member_index(scan,enrichment,individual)
  targets<-index$targets
  wanted<-unlist(request$targets,use.names=FALSE)
  if(!length(wanted))wanted<-vapply(targets,`[[`,character(1),'id')
  if(any(!wanted%in%vapply(targets,`[[`,character(1),'id')))stop('Individual targets need their own saved correlation calculation.')
  meta<-is.null(request$study)||!nzchar(request$study)
  datasets<-list(scan);if(!is.null(individual))datasets[[2]]<-individual
  results<-lapply(seq_along(datasets),function(i){
    x<-if(meta)datasets[[i]]$meta_analysis else datasets[[i]]$project_correlations
    x<-x[x$analysis_mode==mode,,drop=FALSE]
    if(meta)x<-x[x$cutoff==cutoff,,drop=FALSE] else {
      x<-x[x$project_id==request$study & x$biological_samples>=cutoff,,drop=FALSE]
      # Adjust across the complete saved study/mode gene-target family, before subsetting.
      x$meta_fdr<-NA_real_;ok<-is.finite(x$pvalue);x$meta_fdr[ok]<-stats::p.adjust(x$pvalue[ok],'BH')
    }
    if(i>1)x<-x[!x$target%in%unique(scan$targets$membership$target),,drop=FALSE]
    x
  })
  # Different checkpoints can carry different annotation columns.
  columns<-Reduce(union,lapply(results,names));results<-lapply(results,function(x){for(k in setdiff(columns,names(x)))x[[k]]<-NA;x[columns]})
  d<-do.call(rbind,results)
  shape<-c(length(ids),length(wanted));blank<-function()matrix(NA_real_,shape[1],shape[2]);v<-q<-p<-n<-k<-lo<-hi<-hetero<-blank();status<-matrix('Not estimable under the saved filters/model',shape[1],shape[2])
  quantified<-scan$gene_input_summary$gene_id
  for(i in seq_along(ids))for(j in seq_along(wanted)){
    definition<-index$targets[[match(wanted[j],vapply(index$targets,`[[`,character(1),'id'))]]
    if(definition$type=='individual'&&identical(ids[i],definition$label)){status[i,j]<-'Self-correlation excluded';next}
    x<-d[d$gene_id==ids[i]&d$target==wanted[j],,drop=FALSE]
    if(nrow(x)>1)stop('Ambiguous saved correlation cells.')
    if(!nrow(x)){if(definition$type=='individual'&&!definition$label%in%quantified)status[i,j]<-'Target not quantified in this dataset' else if(!ids[i]%in%quantified)status[i,j]<-'Not quantified in this dataset';next}
    value<-if(meta)x$meta_rho else x$rho
    if(!length(value)||!is.finite(value)){status[i,j]<-'Insufficient usable studies or samples';next}
    v[i,j]<-value;q[i,j]<-x$meta_fdr;p[i,j]<-x$pvalue
    if(meta){n[i,j]<-x$contributing_samples;k[i,j]<-x$contributing_projects;lo[i,j]<-x$ci_low;hi[i,j]<-x$ci_high;hetero[i,j]<-x$i2_percent}else{n[i,j]<-x$pairwise_samples;k[i,j]<-1}
    status[i,j]<-'Available'
  }
  labels<-ids
  annotations<-enrichment$gene_annotations
  if(is.data.frame(annotations)&&'gene_id'%in%names(annotations)){
    field<-intersect(c('gene_symbol','gene_name','gene_names'),names(annotations))
    if(length(field)){a<-as.character(annotations[[field[1]]][match(ids,annotations$gene_id)]);ok<-!is.na(a)&nzchar(a)&a!=ids;labels[ok]<-paste0(a[ok],' (',ids[ok],')')}
  }
  rows<-function(x)lapply(seq_len(nrow(x)),function(i)as.list(x[i,]))
  list(schema=2,kind='genes',pathway_members=TRUE,pathway_id=request$pathway,pathway_name=term$set_name[1],
       title=paste0(term$set_name[1],' \u2014 member correlations'),statistic=if(meta)'Meta-analysis correlation (rho)' else 'Within-study correlation (rho)',
       full_results=TRUE,default_top_n=length(ids),default_row_selection='original',row_ids=as.list(ids),row_labels=as.list(labels),
       column_ids=as.list(wanted),column_labels=lapply(wanted,function(t)index$targets[[match(t,vapply(index$targets,`[[`,character(1),'id'))]]$label),values=rows(v),adjusted_p=rows(q),pvalues=rows(p),sample_counts=rows(n),study_counts=rows(k),ci_low=rows(lo),ci_high=rows(hi),heterogeneity=rows(hetero),cell_status=rows(status),
       analysis_mode=mode,sample_cutoff=cutoff,study=request$study,
       significance_definition=if(meta)'Original BH meta_fdr across all gene-target tests within each source calculation, cutoff and analysis mode. Signature and supplemental individual-target families remain separate.' else 'BH across the complete saved gene-target family for this study and analysis mode, before pathway selection. Signature and supplemental families remain separate.',
       missing='Unavailable genes, filtered effects and self-correlations are missing, never zero.',limit=1)
}
