.scan_empty_enrichment <- function() {
  data.frame(
    cutoff = integer(), target = character(), direction = character(),
    database = character(), ontology = character(), set_id = character(),
    set_name = character(), method = character(), pvalue = numeric(),
    family_fdr = numeric(), global_fdr = numeric(), overlap_count = integer(),
    strict_support = logical(), stringsAsFactors = FALSE
  )
}

.scan_gene_annotations <- function(source) {
  candidates <- if (is.list(source) && !is.data.frame(source)) {
    Filter(is.data.frame, list(source$uniprot_by_locus, source$pseudocap_by_locus,
                              source$kegg_by_locus))
  } else if (is.data.frame(source)) list(source) else list()
  rows <- list()
  counter <- 0L
  for (table in candidates) {
    gene_column <- intersect(c("gene_id", "pao1_locus", "locus_tag", "locus"),
                             names(table))[1]
    if (is.na(gene_column) || !length(gene_column)) next
    gene_name_columns <- intersect(
      c("gene_names", "gene_name", "pseudocap_gene_name", "uniprot_gene_names", "symbol"),
      names(table)
    )
    protein_columns <- intersect(
      c("protein_name", "pseudocap_product", "uniprot_protein_name",
        "gene_description", "product", "description"), names(table)
    )
    if (!length(gene_name_columns) && !length(protein_columns)) next
    coalesce <- function(columns) {
      if (!length(columns)) return(rep("", nrow(table)))
      values <- rep("", nrow(table))
      for (column in columns) {
        candidate <- trimws(as.character(table[[column]]))
        use <- !nzchar(values) & !is.na(candidate) & nzchar(candidate) & candidate != "-"
        values[use] <- candidate[use]
      }
      values
    }
    counter <- counter + 1L
    rows[[counter]] <- data.frame(
      # Annotation providers already resolve aliases to the assembly-native
      # primary identifier. Preserve it; do not re-filter generic locus tags as PAO1.
      gene_id = .scan_clean_id(table[[gene_column]], "as_is"),
      gene_names = coalesce(gene_name_columns), protein_name = coalesce(protein_columns),
      stringsAsFactors = FALSE
    )
  }
  if (!length(rows)) return(data.frame(
    gene_id = character(), gene_names = character(), protein_name = character(),
    stringsAsFactors = FALSE
  ))
  combined <- do.call(rbind, rows)
  combined <- combined[!is.na(combined$gene_id), , drop = FALSE]
  groups <- split(seq_len(nrow(combined)), combined$gene_id)
  result <- do.call(rbind, lapply(names(groups), function(gene) {
    idx <- groups[[gene]]
    collapse <- function(x) {
      x <- unique(trimws(as.character(x[!is.na(x) & nzchar(trimws(as.character(x)))])))
      paste(x, collapse = "; ")
    }
    data.frame(gene_id = gene, gene_names = collapse(combined$gene_names[idx]),
               protein_name = collapse(combined$protein_name[idx]),
               stringsAsFactors = FALSE)
  }))
  rownames(result) <- NULL
  result
}

.scan_group_bh <- function(data, p_col, group_cols) {
  data$family_fdr <- NA_real_
  if (!nrow(data)) return(data)
  adjust_valid <- function(p) {
    adjusted <- rep(NA_real_, length(p))
    valid <- is.finite(p) & p >= 0 & p <= 1
    if (any(valid)) adjusted[valid] <- stats::p.adjust(p[valid], method = "BH")
    adjusted
  }
  key <- do.call(paste, c(data[group_cols], sep = "\r"))
  for (value in unique(key)) {
    idx <- which(key == value)
    p <- suppressWarnings(as.numeric(data[[p_col]][idx]))
    data$family_fdr[idx] <- adjust_valid(p)
  }
  p <- suppressWarnings(as.numeric(data[[p_col]]))
  data$global_fdr <- adjust_valid(p)
  data
}

.scan_selection_table <- function(scan, cutoff, view) {
  if (view == "persistent") {
    x <- scan$relationships[scan$relationships$cutoff == cutoff &
                              scan$relationships$persistent %in% TRUE, , drop = FALSE]
    return(data.frame(
      target = x$target, gene_id = x$gene_id,
      direction = x$persistent_direction, effect = x$selected_rho,
      fdr = x$selected_fdr, evidence_class = x$persistent_class,
      stringsAsFactors = FALSE
    ))
  }
  x <- scan$meta_analysis[scan$meta_analysis$cutoff == cutoff &
                            scan$meta_analysis$analysis_mode == view &
                            scan$meta_analysis$evidence_class %in%
                              c("Core tracker", "Supported tracker"), , drop = FALSE]
  data.frame(
    target = x$target, gene_id = x$gene_id, direction = x$direction,
    effect = x$meta_rho, fdr = x$meta_fdr,
    evidence_class = x$evidence_class, stringsAsFactors = FALSE
  )
}

.scan_rank_mode <- function(scan, target, cutoff, view) {
  if (view %in% c("total", "adjusted")) return(view)
  adjusted <- scan$meta_analysis$cutoff == cutoff &
    scan$meta_analysis$target == target &
    scan$meta_analysis$analysis_mode == "adjusted" &
    scan$meta_analysis$evaluable_in_meta_analysis %in% TRUE
  if (any(adjusted)) "adjusted" else "total"
}

.scan_ora <- function(selection, membership, universe, cutoff, minimum_overlap,
                      minimum_size, maximum_size) {
  if (!nrow(selection)) return(.scan_empty_enrichment())
  term_columns <- c("database", "ontology", "set_id", "set_name")
  term_key <- do.call(paste, c(membership[term_columns], sep = "\r"))
  term_rows <- split(seq_len(nrow(membership)), term_key)
  results <- list()
  counter <- 0L
  for (target in unique(selection$target)) {
    for (direction in c("Positive", "Negative")) {
      chosen <- unique(selection$gene_id[selection$target == target &
                                           selection$direction == direction])
      if (!length(chosen)) next
      for (idx in term_rows) {
        term <- membership[idx[1], term_columns, drop = FALSE]
        annotated_universe <- unique(intersect(
          universe,
          membership$gene_id[membership$database == term$database &
                               membership$ontology == term$ontology]
        ))
        set_genes <- unique(intersect(membership$gene_id[idx], annotated_universe))
        selected_genes <- unique(intersect(chosen, annotated_universe))
        N <- length(annotated_universe)
        M <- length(set_genes)
        n <- length(selected_genes)
        overlap <- intersect(selected_genes, set_genes)
        k <- length(overlap)
        if (N < 1L || n < 1L || M < minimum_size || M > maximum_size) next
        pvalue <- stats::phyper(k - 1, M, N - M, n, lower.tail = FALSE)
        odds <- suppressWarnings(stats::fisher.test(
          matrix(c(k, n - k, M - k, N - M - n + k), nrow = 2),
          alternative = "greater"
        )$estimate)
        counter <- counter + 1L
        results[[counter]] <- data.frame(
          cutoff = cutoff, target = target, direction = direction,
          database = term$database, ontology = term$ontology,
          set_id = term$set_id, set_name = term$set_name, method = "ora",
          pvalue = pvalue, selected_count = n, background_count = N,
          set_size = M, overlap_count = k,
          expected_overlap = n * M / N,
          fold_enrichment = if (n * M > 0) k * N / (n * M) else NA_real_,
          odds_ratio = unname(odds), overlap_genes = paste(sort(overlap), collapse = "; "),
          stringsAsFactors = FALSE
        )
      }
    }
  }
  result <- if (length(results)) do.call(rbind, results) else .scan_empty_enrichment()
  if (!nrow(result)) return(result)
  result <- .scan_group_bh(
    result, "pvalue", c("cutoff", "target", "direction", "database", "ontology")
  )
  result$strict_support <- result$family_fdr <= 0.05 &
    result$global_fdr <= 0.05 & result$overlap_count >= minimum_overlap
  result[order(result$cutoff, result$target, result$direction,
               result$global_fdr, -result$overlap_count), , drop = FALSE]
}

.scan_ranked <- function(scan, membership, cutoff, view, methods,
                         minimum_overlap, minimum_size, maximum_size,
                         inter_gene_cor, ...) {
  methods <- setdiff(methods, "ora")
  if (!length(methods)) return(.scan_empty_enrichment())
  results <- list()
  counter <- 0L
  for (target in unique(scan$meta_analysis$target)) {
    mode <- .scan_rank_mode(scan, target, cutoff, view)
    ranked <- scan$meta_analysis[
      scan$meta_analysis$cutoff == cutoff & scan$meta_analysis$target == target &
        scan$meta_analysis$analysis_mode == mode &
        is.finite(scan$meta_analysis$z_statistic),
      c("gene_id", "z_statistic"), drop = FALSE
    ]
    if (nrow(ranked) < 2L) next
    names(ranked)[2] <- "statistic"
    for (method in methods) {
      needed <- if (method == "fgsea") "fgsea" else if (method == "camera_pr") "limma" else NA
      if (is.na(needed) || !requireNamespace(needed, quietly = TRUE)) {
        warning("Skipping ranked method '", method, "': optional package '",
                needed, "' is unavailable.", call. = FALSE)
        next
      }
      fit <- tryCatch(
        pa_enrich_ranked(
          ranked, membership, method = method, gene_id_col = "gene_id",
          statistic_col = "statistic", inter_gene_cor = inter_gene_cor,
          minimum_size = minimum_size, maximum_size = maximum_size, ...
        ),
        error = function(e) {
          warning("Ranked enrichment failed for ", target, " (", method,
                  "): ", conditionMessage(e), call. = FALSE)
          NULL
        }
      )
      if (is.null(fit) || !nrow(fit$results)) next
      x <- fit$results
      pvalue <- suppressWarnings(as.numeric(
        if ("pval" %in% names(x)) x$pval else x$PValue
      ))
      method_fdr <- suppressWarnings(as.numeric(
        if ("padj" %in% names(x)) x$padj else x$FDR
      ))
      effect <- suppressWarnings(as.numeric(if ("NES" %in% names(x)) x$NES else
        ifelse(tolower(as.character(x$Direction)) == "up", 1, -1)
      ))
      evaluable <- is.finite(pvalue) & pvalue >= 0 & pvalue <= 1 &
        is.finite(method_fdr) & method_fdr >= 0 & method_fdr <= 1 &
        is.finite(effect)
      direction <- rep(NA_character_, length(effect))
      direction[evaluable] <- ifelse(effect[evaluable] >= 0, "Positive", "Negative")
      exclusion_reason <- rep("", length(effect))
      exclusion_reason[!evaluable] <- vapply(which(!evaluable), function(i) {
        missing <- character()
        if (!is.finite(pvalue[i]) || pvalue[i] < 0 || pvalue[i] > 1) {
          missing <- c(missing, "p-value")
        }
        if (!is.finite(method_fdr[i]) || method_fdr[i] < 0 || method_fdr[i] > 1) {
          missing <- c(missing, "method FDR")
        }
        if (!is.finite(effect[i])) missing <- c(missing, "enrichment score")
        paste0(method, " returned a non-finite or invalid ", paste(missing, collapse = ", "))
      }, character(1))
      overlap_count <- if ("leadingEdge" %in% names(x)) {
        vapply(x$leadingEdge, length, integer(1))
      } else if ("NGenes" %in% names(x)) as.integer(x$NGenes) else NA_integer_
      leading <- if ("leadingEdge" %in% names(x)) {
        vapply(x$leadingEdge, function(z) paste(z, collapse = "; "), character(1))
      } else rep("", nrow(x))
      counter <- counter + 1L
      results[[counter]] <- data.frame(
        cutoff = cutoff, target = target, direction = direction,
        database = x$database, ontology = x$ontology,
        set_id = x$set_id, set_name = x$set_name, method = method,
        rank_mode = mode, pvalue = pvalue,
        method_fdr = method_fdr, enrichment_score = effect,
        evaluable = evaluable, exclusion_reason = exclusion_reason,
        set_size = if ("size" %in% names(x)) as.integer(x$size) else
          if ("NGenes" %in% names(x)) as.integer(x$NGenes) else NA_integer_,
        overlap_count = overlap_count, leading_edge_genes = leading,
        stringsAsFactors = FALSE
      )
    }
  }
  result <- if (length(results)) do.call(rbind, results) else .scan_empty_enrichment()
  if (!nrow(result)) return(result)
  result <- .scan_group_bh(result, "pvalue", c("cutoff", "target", "method"))
  result$evaluable <- result$evaluable %in% TRUE &
    is.finite(result$family_fdr) & is.finite(result$global_fdr)
  result$strict_support <- result$evaluable &
    result$family_fdr <= 0.05 & result$global_fdr <= 0.05 &
    (is.na(result$overlap_count) | result$overlap_count >= minimum_overlap)
  result[order(result$cutoff, result$target, result$global_fdr,
               -abs(result$enrichment_score)), , drop = FALSE]
}

.scan_term_summary <- function(ora, ranked) {
  keys <- c("cutoff", "target", "direction", "database", "ontology", "set_id", "set_name")
  pieces <- list()
  if (nrow(ora)) {
    x <- ora
    x$ora_strict <- x$strict_support
    x$ora_best_fdr <- pmin(x$family_fdr, x$global_fdr, na.rm = TRUE)
    x <- x[c(keys, "ora_strict", "ora_best_fdr", "overlap_count", "overlap_genes")]
    names(x)[names(x) == "overlap_count"] <- "ora_overlap_count"
    pieces$ora <- x
  }
  if (nrow(ranked)) {
    if ("evaluable" %in% names(ranked)) {
      ranked <- ranked[ranked$evaluable %in% TRUE, , drop = FALSE]
    } else {
      ranked <- ranked[
        is.finite(ranked$pvalue) & is.finite(ranked$enrichment_score) &
          ranked$direction %in% c("Positive", "Negative"),
        , drop = FALSE
      ]
    }
  }
  if (nrow(ranked)) {
    split_rows <- split(seq_len(nrow(ranked)), do.call(paste, c(ranked[keys], sep = "\r")))
    x <- do.call(rbind, lapply(split_rows, function(idx) {
      z <- ranked[idx, , drop = FALSE]
      best <- idx[which.min(ranked$global_fdr[idx])]
      data.frame(
        ranked[keys][best, , drop = FALSE],
        ranked_strict = any(z$strict_support %in% TRUE),
        ranked_best_fdr = min(z$global_fdr, na.rm = TRUE),
        ranked_methods = paste(sort(unique(z$method)), collapse = "; "),
        ranked_score = ranked$enrichment_score[best], stringsAsFactors = FALSE
      )
    }))
    pieces$ranked <- x
  }
  if (!length(pieces)) return(data.frame())
  result <- if (length(pieces) == 2L) merge(
    pieces$ora, pieces$ranked, by = keys, all = TRUE, sort = FALSE
  ) else pieces[[1]]
  if (!"ora_strict" %in% names(result)) result$ora_strict <- FALSE
  if (!"ranked_strict" %in% names(result)) result$ranked_strict <- FALSE
  result$ora_strict[is.na(result$ora_strict)] <- FALSE
  result$ranked_strict[is.na(result$ranked_strict)] <- FALSE
  result$evidence_tier <- ifelse(
    result$ora_strict & result$ranked_strict, "Core consensus",
    ifelse(result$ranked_strict, "Ranked supported",
           ifelse(result$ora_strict, "ORA supported", "Exploratory"))
  )
  order_tier <- match(result$evidence_tier,
                      c("Core consensus", "Ranked supported", "ORA supported", "Exploratory"))
  result[order(order_tier, result$cutoff, result$target, result$direction,
               result$set_name), , drop = FALSE]
}

.scan_read_themes <- function(themes = NULL) {
  if (is.data.frame(themes)) return(themes)
  if (is.null(themes)) {
    themes <- system.file("extdata", "curated_pao1_themes.csv", package = "paannotate")
    if (!nzchar(themes)) {
      local <- file.path("inst", "extdata", "curated_pao1_themes.csv")
      if (file.exists(local)) themes <- local
    }
  }
  if (!is.character(themes) || length(themes) != 1L || !file.exists(themes)) {
    stop("Curated theme table is unavailable. Supply themes= with a CSV or data frame.",
         call. = FALSE)
  }
  utils::read.csv(themes, stringsAsFactors = FALSE, check.names = FALSE)
}

.scan_theme_membership <- function(membership, themes) {
  required <- c("priority", "curated_theme", "keyword_rule", "focus")
  if (length(setdiff(required, names(themes)))) {
    stop("Theme table must contain: ", paste(required, collapse = ", "), call. = FALSE)
  }
  themes <- themes[order(as.numeric(themes$priority)), , drop = FALSE]
  terms <- unique(membership[c("database", "ontology", "set_id", "set_name")])
  searchable <- tolower(paste(terms$set_id, terms$set_name, terms$ontology,
                              terms$database, sep = " | "))
  matched <- lapply(searchable, function(text) {
    which(vapply(themes$keyword_rule, function(rule) {
      isTRUE(grepl(rule, text, ignore.case = TRUE, perl = TRUE))
    }, logical(1)))
  })
  terms$matching_theme_count <- lengths(matched)
  terms$all_matching_themes <- vapply(matched, function(idx) {
    paste(themes$curated_theme[idx], collapse = "; ")
  }, character(1))
  terms$curated_theme <- vapply(matched, function(idx) {
    if (length(idx)) themes$curated_theme[idx[1]] else "Unassigned"
  }, character(1))
  terms$focus <- vapply(matched, function(idx) {
    if (length(idx)) themes$focus[idx[1]] else "unassigned"
  }, character(1))
  terms$ambiguous <- terms$matching_theme_count > 1L
  key <- do.call(paste, c(terms[c("database", "ontology", "set_id", "set_name")], sep = "\r"))
  membership_key <- do.call(paste, c(membership[c("database", "ontology", "set_id", "set_name")],
                                     sep = "\r"))
  mapped <- terms[match(membership_key, key), , drop = FALSE]
  keep <- mapped$curated_theme != "Unassigned"
  theme_membership <- data.frame(
    gene_id = membership$gene_id[keep], database = "CURATED",
    ontology = "umbrella_theme",
    set_id = paste0("THEME_", .scan_slug(mapped$curated_theme[keep])),
    set_name = mapped$curated_theme[keep], stringsAsFactors = FALSE
  )
  theme_membership <- unique(theme_membership)
  list(mapping = terms, membership = theme_membership, themes = themes)
}

.scan_iron_subset <- function(summary, mapping = NULL) {
  if (!nrow(summary)) return(summary)
  pattern <- paste(
    "iron|ferric|ferrous|siderophore|pyoverdine|pyochelin|heme|hemin|hemophore|",
    "iron[- ]sulfur|fe[- ]?s|\\bfur\\b|prrf|tonb-dependent", sep = ""
  )
  keep <- grepl(pattern, paste(summary$set_id, summary$set_name, summary$ontology),
                ignore.case = TRUE, perl = TRUE)
  summary[keep, , drop = FALSE]
}

#' Enrich target-correlated genes for canonical pathways
#'
#' Runs direction-specific over-representation analysis and full-ranked gene-set
#' analysis from a [pa_scan_targets()] result. It preserves exact GO/KEGG/etc.
#' terms by default. With `curated=TRUE`, it additionally rebuilds paannotate's
#' umbrella sets from actual gene membership and produces an iron-focused
#' subset. If a cutoff has no selected genes, ORA is returned empty for that
#' cutoff while full-ranked enrichment continues whenever finite ranking
#' statistics are available.
#'
#' @param scan A `pa_target_scan` object or report `pa_target_scan.rds` path.
#' @param membership A paannotate annotation object, membership CSV/TSV/XLSX/RDS
#'   path, or five-column table (`gene_id`, `database`, `ontology`, `set_id`,
#'   `set_name`).
#' @param methods Any of `"ora"`, `"fgsea"`, and `"camera_pr"`.
#' @param cutoff One or more previously analyzed sample cutoffs; default is the
#'   strictest (largest) cutoff.
#' @param view `"persistent"`, `"total"`, or `"adjusted"` evidence.
#' @param term_fdr,global_fdr Required within-family and global FDR.
#' @param minimum_overlap,minimum_size,maximum_size Gene-set filters.
#' @param curated Build and test paannotate's manually curated umbrella terms.
#'   The default is `FALSE`, so canonical database terms appear first and alone.
#' @param themes Curated-theme CSV/data frame, or `NULL` for the packaged PAO1
#'   dictionary; used only when `curated=TRUE`.
#' @param inter_gene_cor CAMERA-PR correlation assumption.
#' @param study_enrichment Compute separately labeled individual-study enrichment
#'   automatically when pooled estimates are unavailable, always, or never.
#' @param ... Passed to ranked enrichment (for example `nPermSimple`).
#' @return A `pa_scan_enrichment` object containing exact results plus optional
#'   curated and iron results, full mappings, and audit information.
#' @export
pa_enrich_scan <- function(
    scan, membership, methods = c("ora", "fgsea"), cutoff = NULL,
    view = c("persistent", "total", "adjusted"), term_fdr = 0.05,
    global_fdr = 0.05, minimum_overlap = 5, minimum_size = 5,
    maximum_size = 500, curated = FALSE, themes = NULL,
    inter_gene_cor = 0.01, study_enrichment = c('auto','always','none'), ...) {
  if (is.character(scan) && length(scan) == 1L &&
      tolower(tools::file_ext(scan)) == "rds") scan <- readRDS(path.expand(scan))
  if (!inherits(scan, "pa_target_scan")) stop("scan must be a pa_target_scan object.",
                                               call. = FALSE)
  view <- match.arg(view)
  study_enrichment <- match.arg(study_enrichment)
  methods <- unique(match.arg(methods, c("ora", "fgsea", "camera_pr"),
                              several.ok = TRUE))
  if (is.character(membership) && length(membership) == 1L) {
    membership <- .scan_read_membership(membership)
  }
  annotation_source <- membership
  gene_annotations <- .scan_gene_annotations(annotation_source)
  membership <- .as_membership(membership)
  available_cutoffs <- sort(unique(scan$meta_analysis$cutoff))
  if (is.null(cutoff)) cutoff <- max(available_cutoffs)
  cutoff <- sort(unique(as.integer(cutoff)))
  if (length(setdiff(cutoff, available_cutoffs))) {
    stop("Requested cutoff was not analyzed by pa_scan_targets().", call. = FALSE)
  }
  universe <- unique(scan$candidate_genes)
  selection <- do.call(rbind, lapply(cutoff, function(value) {
    x <- .scan_selection_table(scan, value, view)
    # A cutoff can legitimately have no selected genes. Assign a vector with
    # the same length as the table so the empty ORA branch does not prevent the
    # independent full-ranked analysis from running.
    x$cutoff <- rep.int(as.integer(value), nrow(x))
    x
  }))
  selected_cutoffs <- unique(selection$cutoff)
  empty_selection_cutoffs <- setdiff(cutoff, selected_cutoffs)
  if (length(empty_selection_cutoffs) && "ora" %in% methods) {
    warning(
      "No genes were selected for ORA at cutoff(s): ",
      paste(empty_selection_cutoffs, collapse = ", "),
      ". ORA tables will be empty for those cutoffs; ranked enrichment ",
      "will continue when ranked statistics are available.",
      call. = FALSE
    )
  }
  exact_ora <- do.call(rbind, lapply(cutoff, function(value) {
    if (!"ora" %in% methods) return(.scan_empty_enrichment())
    .scan_ora(selection[selection$cutoff == value, , drop = FALSE], membership,
              universe, value, minimum_overlap, minimum_size, maximum_size)
  }))
  ranked_engine_warnings <- character()
  capture_ranked_warnings <- function(code) {
    withCallingHandlers(
      code,
      warning = function(condition) {
        message <- conditionMessage(condition)
        numerical <- grepl(
          "P-values were not calculated properly|P-values are less than",
          message, ignore.case = TRUE
        )
        if (numerical) {
          ranked_engine_warnings <<- unique(c(ranked_engine_warnings, message))
          invokeRestart("muffleWarning")
        }
      }
    )
  }
  exact_ranked <- capture_ranked_warnings(do.call(rbind, lapply(cutoff, function(value) {
    .scan_ranked(scan, membership, value, view, methods, minimum_overlap,
                 minimum_size, maximum_size, inter_gene_cor, ...)
  })))
  if (nrow(exact_ora)) {
    exact_ora$strict_support <- exact_ora$family_fdr <= term_fdr &
      exact_ora$global_fdr <= global_fdr & exact_ora$overlap_count >= minimum_overlap
  }
  if (nrow(exact_ranked)) {
    exact_ranked$strict_support <- exact_ranked$evaluable %in% TRUE &
      exact_ranked$family_fdr <= term_fdr &
      exact_ranked$global_fdr <= global_fdr &
      (is.na(exact_ranked$overlap_count) | exact_ranked$overlap_count >= minimum_overlap)
  }
  exact_summary <- .scan_term_summary(exact_ora, exact_ranked)
  if (isTRUE(curated)) {
    theme <- .scan_theme_membership(membership, .scan_read_themes(themes))
    theme_ora <- do.call(rbind, lapply(cutoff, function(value) {
      if (!"ora" %in% methods || !nrow(theme$membership)) return(.scan_empty_enrichment())
      .scan_ora(selection[selection$cutoff == value, , drop = FALSE], theme$membership,
                universe, value, minimum_overlap, minimum_size, maximum_size)
    }))
    theme_ranked <- capture_ranked_warnings(do.call(rbind, lapply(cutoff, function(value) {
      if (!nrow(theme$membership)) return(.scan_empty_enrichment())
      .scan_ranked(scan, theme$membership, value, view, methods, minimum_overlap,
                   minimum_size, maximum_size, inter_gene_cor, ...)
    })))
    if (nrow(theme_ora)) {
      theme_ora$strict_support <- theme_ora$family_fdr <= term_fdr &
        theme_ora$global_fdr <= global_fdr & theme_ora$overlap_count >= minimum_overlap
    }
    if (nrow(theme_ranked)) {
      theme_ranked$strict_support <- theme_ranked$evaluable %in% TRUE &
        theme_ranked$family_fdr <= term_fdr &
        theme_ranked$global_fdr <= global_fdr &
        (is.na(theme_ranked$overlap_count) | theme_ranked$overlap_count >= minimum_overlap)
    }
    theme_summary <- .scan_term_summary(theme_ora, theme_ranked)
    focus_map <- unique(theme$mapping[c("set_id", "set_name", "curated_theme", "focus")])
    iron_exact <- .scan_iron_subset(exact_summary)
    iron_themes <- if (nrow(theme_summary)) {
      names(focus_map)[1:2] <- c("source_set_id", "source_set_name")
      focus_lookup <- unique(theme$mapping[c("curated_theme", "focus")])
      x <- merge(theme_summary, focus_lookup, by.x = "set_name", by.y = "curated_theme",
                 all.x = TRUE, sort = FALSE)
      x[grepl("^iron", x$focus), , drop = FALSE]
    } else theme_summary
  } else {
    theme <- list(themes = data.frame(), mapping = data.frame(),
                  membership = .empty_membership())
    theme_ora <- .scan_empty_enrichment()
    theme_ranked <- .scan_empty_enrichment()
    theme_summary <- data.frame()
    iron_exact <- data.frame()
    iron_themes <- data.frame()
  }
  non_evaluable <- sum(
    if ("evaluable" %in% names(exact_ranked)) !exact_ranked$evaluable else logical(),
    if ("evaluable" %in% names(theme_ranked)) !theme_ranked$evaluable else logical(),
    na.rm = TRUE
  )
  if (non_evaluable > 0L) {
    warning(
      "Ranked enrichment could not evaluate ", non_evaluable,
      " pathway result", if (non_evaluable == 1L) "" else "s",
      " because the enrichment engine returned a non-finite statistic. ",
      "They remain in the ranked audit tables with an exclusion reason; ",
      "valid pathways and heatmaps will continue normally.",
      call. = FALSE
    )
  }
  studies <- list(ranked=data.frame(),audit=data.frame())
  if(study_enrichment=='always' || (study_enrichment=='auto' &&
      !any(is.finite(scan$meta_analysis$meta_rho)))) {
    studies <- capture_ranked_warnings(.scan_study_ranked(scan,membership,methods,
      minimum_overlap,minimum_size,maximum_size,inter_gene_cor,...))
    if(nrow(studies$ranked))studies$ranked$strict_support <-
      studies$ranked$evaluable %in% TRUE & studies$ranked$family_fdr<=term_fdr &
      studies$ranked$global_fdr<=global_fdr &
      (is.na(studies$ranked$overlap_count) | studies$ranked$overlap_count>=minimum_overlap)
  }
  structure(list(
    selection = selection,
    studies = studies,
    gene_annotations = gene_annotations,
    exact = list(membership = membership, ora = exact_ora,
                 ranked = exact_ranked, summary = exact_summary),
    themes = list(dictionary = theme$themes, term_mapping = theme$mapping,
                  membership = theme$membership, ora = theme_ora,
                  ranked = theme_ranked, summary = theme_summary),
    iron = list(exact_terms = iron_exact, themes = iron_themes),
    config = list(methods = methods, cutoff = cutoff, view = view,
                  study_enrichment=study_enrichment,study_enrichment_version=1L,
                  curated = isTRUE(curated),
                  term_fdr = term_fdr, global_fdr = global_fdr,
                  minimum_overlap = minimum_overlap, minimum_size = minimum_size,
                  maximum_size = maximum_size, inter_gene_cor = inter_gene_cor,
                  non_evaluable_ranked_results = non_evaluable,
                  ranked_engine_warnings = ranked_engine_warnings)
  ), class = "pa_scan_enrichment")
}

#' @export
print.pa_scan_enrichment <- function(x, ...) {
  cat("paannotate scan enrichment\n")
  cat("  exact terms:", nrow(x$exact$summary), "\n")
  cat("  strict exact terms:", sum(x$exact$summary$evidence_tier != "Exploratory"), "\n")
  if (isTRUE(x$config$curated)) {
    cat("  curated themes:", nrow(x$themes$summary), "\n")
    cat("  iron-focused results:", nrow(x$iron$exact_terms) + nrow(x$iron$themes), "\n")
  } else cat("  curated themes: not requested\n")
  invisible(x)
}
