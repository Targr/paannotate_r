.metadata_target_field <- function(field, metadata) {
  if (!is.character(field) || length(field) != 1L || is.na(field) ||
      !nzchar(trimws(field))) {
    stop("field must name one metadata column, such as 'medium_family'.",
         call. = FALSE)
  }
  aliases <- c(
    medium = "medium_family", media = "medium_family",
    strain = "strain_standardized", strains = "strain_standardized",
    treatment = "treatment_standardized", context = "analysis_context",
    oxygen = "oxygen_condition"
  )
  requested <- trimws(field)
  key <- tolower(requested)
  if (key %in% names(aliases)) requested <- unname(aliases[key])
  exact <- which(tolower(names(metadata)) == tolower(requested))
  if (length(exact) != 1L) {
    stop("Metadata field '", field, "' is not available. Run pa_metadata_coverage() to see usable fields.",
         call. = FALSE)
  }
  names(metadata)[exact]
}

.metadata_target_level <- function(field, value) {
  if (!is.character(value) || length(value) != 1L || is.na(value) ||
      !nzchar(trimws(value))) {
    stop("positive and reference must each contain one non-blank metadata value.",
         call. = FALSE)
  }
  value <- trimws(value)
  if (field == "medium_family") {
    mapped <- .whiteley_map_medium(value)
    if (mapped$medium_mapping_status == "mapped") value <- mapped$medium_family
  } else if (field == "treatment_standardized") {
    mapped <- .whiteley_map_treatment(value)
    if (mapped$treatment_mapping_status == "mapped") value <- mapped$treatment_name
  } else if (field == "strain_standardized") {
    mapped <- .whiteley_map_strain(value)
    if (mapped$strain_mapping_status == "mapped") value <- mapped$strain_standardized
  }
  value
}

.metadata_target_adjustment_status <- function(metadata, indicator, adjustment) {
  if (is.null(adjustment)) return(c(status = "not requested", residual_df = NA))
  design_data <- metadata
  variables <- intersect(all.vars(adjustment), names(design_data))
  for (variable in variables) {
    values <- unique(design_data[[variable]][!is.na(design_data[[variable]])])
    if (length(values) <= 1L) design_data[[variable]] <- rep(0, nrow(design_data))
  }
  design <- tryCatch(stats::model.matrix(adjustment, data = design_data),
                     error = function(e) NULL)
  if (is.null(design) || nrow(design) != nrow(metadata) ||
      any(!is.finite(design))) {
    return(c(status = "adjustment model unavailable", residual_df = NA))
  }
  residual <- .scan_residualize(indicator, design)
  status <- if (residual$df < 1L) {
    "insufficient residual degrees of freedom"
  } else if (!is.finite(stats::sd(residual$values)) ||
             stats::sd(residual$values) < sqrt(.Machine$double.eps)) {
    "contrast fully explained by adjustment"
  } else "available"
  c(status = status, residual_df = residual$df)
}

.metadata_target_audit <- function(
    whiteley, field, positive, reference, minimum_samples_per_group,
    min_samples_per_project, minimum_projects, adjustment = NULL,
    target_name = NULL) {
  metadata <- as.data.frame(whiteley$metadata, stringsAsFactors = FALSE)
  field <- .metadata_target_field(field, metadata)
  positive <- .metadata_target_level(field, positive)
  reference <- .metadata_target_level(field, reference)
  if (.whiteley_normalize_match(positive) == .whiteley_normalize_match(reference)) {
    stop("positive and reference resolve to the same metadata value.", call. = FALSE)
  }
  if (!is.numeric(minimum_samples_per_group) ||
      length(minimum_samples_per_group) != 1L ||
      !is.finite(minimum_samples_per_group) || minimum_samples_per_group < 2) {
    stop("minimum_samples_per_group must be one integer of at least 2.", call. = FALSE)
  }
  minimum_samples_per_group <- as.integer(minimum_samples_per_group)
  cutoffs <- sort(unique(as.integer(min_samples_per_project)))
  if (!length(cutoffs) || any(!is.finite(cutoffs) | cutoffs < 4)) {
    stop("min_samples_per_project must contain integers of at least 4.", call. = FALSE)
  }
  if (!is.numeric(minimum_projects) || length(minimum_projects) != 1L ||
      !is.finite(minimum_projects) || minimum_projects < 1) {
    stop("minimum_projects must be one positive integer.", call. = FALSE)
  }
  minimum_projects <- as.integer(minimum_projects)
  raw <- as.character(metadata[[field]])
  raw[is.na(raw)] <- ""
  normalized <- .whiteley_normalize_match(raw)
  positive_key <- .whiteley_normalize_match(positive)
  reference_key <- .whiteley_normalize_match(reference)
  role <- ifelse(
    normalized == positive_key & nzchar(normalized), "positive",
    ifelse(normalized == reference_key & nzchar(normalized), "reference",
           ifelse(!nzchar(normalized), "missing", "other level"))
  )
  projects <- unique(as.character(metadata$bioproject_id))
  readiness <- lapply(projects, function(project) {
    idx <- which(metadata$bioproject_id == project)
    contrast_idx <- idx[role[idx] %in% c("positive", "reference")]
    positive_n <- sum(role[idx] == "positive")
    reference_n <- sum(role[idx] == "reference")
    adjustment_info <- if (length(contrast_idx)) {
      .metadata_target_adjustment_status(
        metadata[contrast_idx, , drop = FALSE],
        as.numeric(role[contrast_idx] == "positive"), adjustment
      )
    } else c(status = if (is.null(adjustment)) "not requested" else
               "no contrast samples", residual_df = NA)
    row <- data.frame(
      bioproject_id = project, cohort_samples = length(idx),
      positive_samples = positive_n, reference_samples = reference_n,
      contrast_samples = positive_n + reference_n,
      other_level_samples = sum(role[idx] == "other level"),
      missing_target_metadata = sum(role[idx] == "missing"),
      passes_group_minimum = positive_n >= minimum_samples_per_group &
        reference_n >= minimum_samples_per_group,
      adjustment_status = unname(adjustment_info["status"]),
      residual_df = suppressWarnings(as.numeric(adjustment_info["residual_df"])),
      stringsAsFactors = FALSE
    )
    for (cutoff in cutoffs) {
      row[[paste0("eligible_at_n", cutoff)]] <-
        row$passes_group_minimum & row$contrast_samples >= cutoff
    }
    row
  })
  project_readiness <- do.call(rbind, readiness)
  minimum_column <- paste0("eligible_at_n", min(cutoffs))
  eligible_projects <- project_readiness$bioproject_id[
    project_readiness[[minimum_column]] %in% TRUE
  ]
  sample_assignments <- data.frame(
    biosample_id = metadata$biosample_id,
    biosample_id_original = if ("biosample_id_original" %in% names(metadata))
      metadata$biosample_id_original else metadata$biosample_id,
    bioproject_id = metadata$bioproject_id,
    metadata_field = field, metadata_value = raw,
    contrast_role = role,
    included_in_contrast = role %in% c("positive", "reference") &
      metadata$bioproject_id %in% eligible_projects,
    exclusion_reason = "", stringsAsFactors = FALSE
  )
  sample_assignments$exclusion_reason[role == "missing"] <-
    "target metadata is missing"
  sample_assignments$exclusion_reason[role == "other level"] <-
    "metadata value is outside the requested contrast"
  failed_project <- role %in% c("positive", "reference") &
    !metadata$bioproject_id %in% eligible_projects
  sample_assignments$exclusion_reason[failed_project] <-
    "BioProject lacks the required samples in both contrast groups"
  documented <- .metadata_value_status(raw) == "documented"
  documented_levels <- unique(raw[documented])
  level_counts <- if (length(documented_levels)) do.call(rbind, lapply(
    documented_levels, function(level) {
    idx <- which(raw == level)
    data.frame(
      metadata_value = level, samples = length(idx),
      bioprojects = length(unique(metadata$bioproject_id[idx])),
      stringsAsFactors = FALSE
    )
  })) else data.frame(metadata_value = character(), samples = integer(),
                      bioprojects = integer(), stringsAsFactors = FALSE)
  if (nrow(level_counts)) {
    level_counts <- level_counts[order(-level_counts$samples,
                                       level_counts$metadata_value), , drop = FALSE]
  }
  cutoff_readiness <- do.call(rbind, lapply(cutoffs, function(cutoff) {
    column <- paste0("eligible_at_n", cutoff)
    chosen <- project_readiness[[column]] %in% TRUE
    project_ids <- project_readiness$bioproject_id[chosen]
    sample_keep <- metadata$bioproject_id %in% project_ids &
      role %in% c("positive", "reference")
    data.frame(
      minimum_samples_per_project = cutoff,
      eligible_projects = sum(chosen),
      positive_samples = sum(sample_keep & role == "positive"),
      reference_samples = sum(sample_keep & role == "reference"),
      meta_analysis_possible = sum(chosen) >= minimum_projects,
      stringsAsFactors = FALSE
    )
  }))
  target_name <- if (is.null(target_name) || !nzchar(trimws(target_name))) {
    paste0(positive, " vs ", reference)
  } else as.character(target_name)[1]
  summary <- data.frame(
    item = c(
      "metadata field", "positive level", "reference level",
      "samples after cohort filters", "samples in requested contrast",
      "eligible projects at smallest cutoff", "minimum samples per group",
      "minimum projects for meta-analysis", "analysis ready"
    ),
    value = c(
      field, positive, reference, nrow(metadata),
      sum(role %in% c("positive", "reference")), length(eligible_projects),
      minimum_samples_per_group, minimum_projects,
      length(eligible_projects) >= minimum_projects
    ), stringsAsFactors = FALSE
  )
  structure(list(
    valid = length(eligible_projects) >= minimum_projects,
    summary = summary, project_readiness = project_readiness,
    cutoff_readiness = cutoff_readiness, sample_assignments = sample_assignments,
    level_counts = level_counts,
    selected_metadata = metadata[sample_assignments$included_in_contrast, , drop = FALSE],
    config = list(
      field = field, positive = positive, reference = reference,
      target_name = target_name,
      minimum_samples_per_group = minimum_samples_per_group,
      min_samples_per_project = cutoffs, minimum_projects = minimum_projects,
      adjustment = if (is.null(adjustment)) NULL else
        paste(deparse(adjustment), collapse = "")
    )
  ), class = "pa_whiteley_metadata_target_check")
}

.metadata_target_load_cohort <- function(
    whiteley, use_curated_414, metadata_overlay, strains, media, contexts,
    include_engineered, bioprojects, filters, exclude_filters,
    metadata_filter, filter_match, missing_metadata, profile, cache_dir,
    release_archive, counts_file, metadata_file, datasummary_file,
    refresh, rebuild, metadata_only) {
  chosen_profile <- if (!is.null(profile)) profile else if (isTRUE(use_curated_414)) {
    "whiteley_pao1_414_v1"
  } else "whiteley_full_v1"
  if (is.null(whiteley)) {
    whiteley <- pa_load_whiteley(
      profile = chosen_profile, cache_dir = cache_dir,
      release_archive = release_archive, counts_file = counts_file,
      metadata_file = metadata_file, datasummary_file = datasummary_file,
      refresh = refresh, rebuild = rebuild, metadata_overlay = metadata_overlay,
      metadata_only = metadata_only
    )
  } else if (!is.null(metadata_overlay)) {
    whiteley <- .whiteley_apply_metadata_overlay(whiteley, metadata_overlay)
  }
  .whiteley_select_cohort(
    whiteley, strains, media, contexts, include_engineered, bioprojects,
    filters, exclude_filters, metadata_filter, filter_match, missing_metadata
  )
}

#' Preview a Whiteley metadata comparison
#'
#' Shows whether a two-level metadata comparison can be estimated within
#' BioProjects before expression is loaded or a long analysis is started.
#'
#' @param field Metadata column or friendly alias such as `"medium"`,
#'   `"treatment"`, or `"strain"`.
#' @param positive,reference The two values to compare. Positive gene effects
#'   point toward `positive`; negative effects point toward `reference`.
#' @param target_name Reader-facing name for the comparison.
#' @param minimum_samples_per_group Samples required from each level inside a
#'   BioProject.
#' @param min_samples_per_project One or more total contrast-sample cutoffs.
#' @param minimum_projects Projects required to call the comparison ready.
#' @param adjustment Optional covariate formula checked for confounding.
#' @inheritParams pa_check_whiteley_cohort
#' @return A `pa_whiteley_metadata_target_check` object.
#' @export
pa_check_whiteley_metadata_target <- function(
    field, positive, reference, target_name = NULL,
    minimum_samples_per_group = 3, min_samples_per_project = c(6, 7, 8),
    minimum_projects = 3, adjustment = NULL,
    use_curated_414 = FALSE, whiteley = NULL, metadata_overlay = NULL,
    strains = NULL, media = NULL, contexts = NULL, include_engineered = TRUE,
    bioprojects = NULL, filters = list(), exclude_filters = list(),
    metadata_filter = NULL, filter_match = c("exact", "contains", "regex"),
    missing_metadata = c("exclude", "include", "error"), profile = NULL,
    cache_dir = file.path(tools::R_user_dir("paannotate", "cache"), "Whiteley"),
    release_archive = NULL, counts_file = NULL, metadata_file = NULL,
    datasummary_file = NULL, refresh = FALSE, rebuild = FALSE) {
  filter_match <- match.arg(filter_match)
  missing_metadata <- match.arg(missing_metadata)
  cohort <- .metadata_target_load_cohort(
    whiteley, use_curated_414, metadata_overlay, strains, media, contexts,
    include_engineered, bioprojects, filters, exclude_filters,
    metadata_filter, filter_match, missing_metadata, profile, cache_dir,
    release_archive, counts_file, metadata_file, datasummary_file,
    refresh, rebuild, metadata_only = TRUE
  )
  result <- .metadata_target_audit(
    cohort, field, positive, reference, minimum_samples_per_group,
    min_samples_per_project, minimum_projects, adjustment, target_name
  )
  result$cohort_audit <- cohort$cohort_audit
  result$profile_id <- cohort$profile_id
  result
}

#' @export
print.pa_whiteley_metadata_target_check <- function(x, ...) {
  cat("paannotate Whiteley metadata-target preview\n")
  cat("  comparison:", x$config$target_name, "\n")
  cat("  field:", x$config$field, "\n")
  cat("  direction: positive =", x$config$positive,
      "; negative =", x$config$reference, "\n")
  cat("  eligible projects at n", min(x$config$min_samples_per_project), ": ",
      x$cutoff_readiness$eligible_projects[1], "\n", sep = "")
  cat("  ready:", x$valid, "\n")
  print(x$cutoff_readiness, row.names = FALSE)
  invisible(x)
}

.metadata_target_project_effects <- function(scan, matrix_value, metadata,
                                             field, positive, reference) {
  rows <- list(); counter <- 0L
  positive_key <- .whiteley_normalize_match(positive)
  reference_key <- .whiteley_normalize_match(reference)
  for (project in unique(scan$project_correlations$project_id)) {
    project_rows <- scan$project_correlations[
      scan$project_correlations$project_id == project, , drop = FALSE
    ]
    genes <- unique(project_rows$gene_id)
    project_metadata <- metadata[metadata$bioproject_id == project, , drop = FALSE]
    value <- .whiteley_normalize_match(project_metadata[[field]])
    positive_ids <- project_metadata$biosample_id[value == positive_key]
    reference_ids <- project_metadata$biosample_id[value == reference_key]
    positive_matrix <- matrix_value[genes, positive_ids, drop = FALSE]
    reference_matrix <- matrix_value[genes, reference_ids, drop = FALSE]
    n_positive <- rowSums(is.finite(positive_matrix))
    n_reference <- rowSums(is.finite(reference_matrix))
    mean_positive <- rowMeans(positive_matrix, na.rm = TRUE)
    mean_reference <- rowMeans(reference_matrix, na.rm = TRUE)
    mean_positive[!is.finite(mean_positive)] <- NA_real_
    mean_reference[!is.finite(mean_reference)] <- NA_real_
    variance <- function(x) apply(x, 1, stats::var, na.rm = TRUE)
    var_positive <- variance(positive_matrix)
    var_reference <- variance(reference_matrix)
    standard_error <- sqrt(var_positive / n_positive + var_reference / n_reference)
    difference <- mean_positive - mean_reference
    statistic <- difference / standard_error
    welch_df <- (var_positive / n_positive + var_reference / n_reference)^2 /
      ((var_positive / n_positive)^2 / pmax(1, n_positive - 1) +
         (var_reference / n_reference)^2 / pmax(1, n_reference - 1))
    pvalue <- 2 * stats::pt(-abs(statistic), df = welch_df)
    invalid <- n_positive < 2 | n_reference < 2 | !is.finite(standard_error) |
      standard_error <= 0 | !is.finite(welch_df)
    difference[invalid] <- standard_error[invalid] <- pvalue[invalid] <- NA_real_
    counter <- counter + 1L
    rows[[counter]] <- data.frame(
      project_id = project, gene_id = genes,
      positive_samples = n_positive, reference_samples = n_reference,
      mean_positive_log2_cpm = mean_positive,
      mean_reference_log2_cpm = mean_reference,
      mean_log2_expression_difference = difference,
      mean_difference_standard_error = standard_error,
      mean_difference_pvalue = pvalue, stringsAsFactors = FALSE
    )
  }
  if (length(rows)) do.call(rbind, rows) else data.frame()
}

.metadata_target_random_effects <- function(effect, standard_error,
                                            minimum_projects = 3L) {
  keep <- is.finite(effect) & is.finite(standard_error) & standard_error > 0
  effect <- effect[keep]; standard_error <- standard_error[keep]
  k <- length(effect)
  empty <- c(
    meta_mean_log2_expression_difference = NA, mean_difference_ci_low = NA,
    mean_difference_ci_high = NA, mean_difference_z_statistic = NA,
    mean_difference_pvalue = NA, mean_difference_tau2 = NA,
    mean_difference_i2_percent = NA, mean_difference_contributing_projects = k
  )
  if (k < minimum_projects) return(empty)
  variance <- standard_error^2
  weight <- 1 / variance
  fixed <- sum(weight * effect) / sum(weight)
  q <- sum(weight * (effect - fixed)^2)
  qdf <- k - 1
  c_value <- sum(weight) - sum(weight^2) / sum(weight)
  tau2 <- if (is.finite(c_value) && c_value > 0) max(0, (q - qdf) / c_value) else 0
  random_weight <- 1 / (variance + tau2)
  estimate <- sum(random_weight * effect) / sum(random_weight)
  se <- sqrt(1 / sum(random_weight))
  z <- estimate / se
  ci <- estimate + c(-1, 1) * stats::qnorm(0.975) * se
  i2 <- if (q > 0) max(0, (q - qdf) / q) * 100 else 0
  c(
    meta_mean_log2_expression_difference = estimate,
    mean_difference_ci_low = ci[1], mean_difference_ci_high = ci[2],
    mean_difference_z_statistic = z,
    mean_difference_pvalue = 2 * stats::pnorm(-abs(z)),
    mean_difference_tau2 = tau2, mean_difference_i2_percent = i2,
    mean_difference_contributing_projects = k
  )
}

.metadata_target_add_differences <- function(scan, matrix_value, metadata,
                                             audit) {
  effects <- .metadata_target_project_effects(
    scan, matrix_value, metadata, audit$config$field,
    audit$config$positive, audit$config$reference
  )
  if (!nrow(effects)) return(scan)
  scan$project_correlations <- merge(
    scan$project_correlations, effects,
    by = c("project_id", "gene_id"), all.x = TRUE, sort = FALSE
  )
  meta_rows <- list(); counter <- 0L
  for (cutoff in sort(unique(scan$meta_analysis$cutoff))) {
    eligible <- scan$project_correlations[
      scan$project_correlations$biological_samples >= cutoff,
      c("project_id", "target", "gene_id",
        "mean_log2_expression_difference", "mean_difference_standard_error"),
      drop = FALSE
    ]
    eligible <- unique(eligible)
    key <- paste(eligible$target, eligible$gene_id, sep = "\r")
    groups <- split(seq_len(nrow(eligible)), key)
    for (idx in groups) {
      part <- eligible[idx, , drop = FALSE]
      statistic <- .metadata_target_random_effects(
        part$mean_log2_expression_difference,
        part$mean_difference_standard_error,
        scan$thresholds$minimum_meta_projects
      )
      counter <- counter + 1L
      meta_rows[[counter]] <- data.frame(
        cutoff = cutoff, target = part$target[1], gene_id = part$gene_id[1],
        as.list(statistic), stringsAsFactors = FALSE
      )
    }
  }
  difference_meta <- if (length(meta_rows)) do.call(rbind, meta_rows) else data.frame()
  if (nrow(difference_meta)) {
    difference_meta$mean_difference_fdr <- NA_real_
    for (cutoff in unique(difference_meta$cutoff)) {
      idx <- which(difference_meta$cutoff == cutoff)
      p <- difference_meta$mean_difference_pvalue[idx]
      adjusted <- rep(NA_real_, length(idx))
      valid <- is.finite(p)
      if (any(valid)) adjusted[valid] <- stats::p.adjust(p[valid], method = "BH")
      difference_meta$mean_difference_fdr[idx] <- adjusted
    }
    scan$meta_analysis <- merge(
      scan$meta_analysis, difference_meta,
      by = c("cutoff", "target", "gene_id"), all.x = TRUE, sort = FALSE
    )
  }
  scan$metadata_target_project_effects <- effects
  scan
}

#' Scan genes associated with a Whiteley metadata contrast
#'
#' Encodes a two-level metadata comparison within each BioProject, calculates
#' point-biserial gene associations, combines projects by random-effects
#' meta-analysis, and retains an unadjusted log2-CPM group difference for
#' interpretation. Projects containing only one requested level do not enter
#' the analysis.
#'
#' @inheritParams pa_check_whiteley_metadata_target
#' @param fdr,rho,i2 Convenient evidence thresholds. Here `rho` is the absolute
#'   point-biserial association with the positive-versus-reference indicator.
#' @param thresholds Optional complete [pa_scan_thresholds()] object.
#' @param minimum_pairwise_samples,minimum_residual_df Association/model
#'   safeguards.
#' @param minimum_gene_cpm,minimum_gene_detection_fraction,minimum_gene_detected_samples,minimum_gene_mad
#'   Within-project candidate-gene filters.
#' @return A `pa_target_scan` compatible with [pa_enrich_scan()] and
#'   [pa_write_scan()].
#' @export
pa_scan_whiteley_metadata <- function(
    field, positive, reference, target_name = NULL,
    minimum_samples_per_group = 3, min_samples_per_project = c(6, 7, 8),
    fdr = 0.05, rho = 0.30, i2 = 75, thresholds = NULL,
    minimum_pairwise_samples = 5, minimum_residual_df = 4,
    minimum_gene_cpm = 1, minimum_gene_detection_fraction = 0.25,
    minimum_gene_detected_samples = 3, minimum_gene_mad = 0.10,
    adjustment = NULL,
    use_curated_414 = FALSE, whiteley = NULL, metadata_overlay = NULL,
    strains = NULL, media = NULL, contexts = NULL, include_engineered = TRUE,
    bioprojects = NULL, filters = list(), exclude_filters = list(),
    metadata_filter = NULL, filter_match = c("exact", "contains", "regex"),
    missing_metadata = c("exclude", "include", "error"), profile = NULL,
    cache_dir = file.path(tools::R_user_dir("paannotate", "cache"), "Whiteley"),
    release_archive = NULL, counts_file = NULL, metadata_file = NULL,
    datasummary_file = NULL, refresh = FALSE, rebuild = FALSE) {
  filter_match <- match.arg(filter_match)
  missing_metadata <- match.arg(missing_metadata)
  if (is.null(thresholds)) {
    thresholds <- pa_scan_thresholds(fdr = fdr, rho = rho, i2 = i2)
  } else if (!inherits(thresholds, "pa_scan_thresholds")) {
    if (is.list(thresholds)) thresholds <- do.call(pa_scan_thresholds, thresholds) else
      stop("thresholds must come from pa_scan_thresholds().", call. = FALSE)
  }
  cohort <- .metadata_target_load_cohort(
    whiteley, use_curated_414, metadata_overlay, strains, media, contexts,
    include_engineered, bioprojects, filters, exclude_filters,
    metadata_filter, filter_match, missing_metadata, profile, cache_dir,
    release_archive, counts_file, metadata_file, datasummary_file,
    refresh, rebuild, metadata_only = FALSE
  )
  if (is.null(cohort$counts)) {
    stop("The supplied Whiteley object contains metadata only; reload it with metadata_only=FALSE.",
         call. = FALSE)
  }
  audit <- .metadata_target_audit(
    cohort, field, positive, reference, minimum_samples_per_group,
    min_samples_per_project, thresholds$minimum_meta_projects,
    adjustment, target_name
  )
  if (!audit$valid) {
    smallest <- audit$cutoff_readiness[1, , drop = FALSE]
    stop(
      "The metadata contrast is not estimable: only ", smallest$eligible_projects,
      " BioProject(s) contain at least ", audit$config$minimum_samples_per_group,
      " samples from both '", audit$config$positive, "' and '",
      audit$config$reference, "'; ", thresholds$minimum_meta_projects,
      " projects are required. Run pa_check_whiteley_metadata_target() for the audit.",
      call. = FALSE
    )
  }
  keep <- audit$sample_assignments$included_in_contrast
  selected_ids <- audit$sample_assignments$biosample_id[keep]
  metadata <- cohort$metadata[match(selected_ids, cohort$metadata$biosample_id),
                              , drop = FALSE]
  counts <- cohort$counts[, selected_ids, drop = FALSE]
  normalization_metadata <- metadata
  normalization_metadata$.sample_id <- metadata$biosample_id
  normalization_metadata$.project_id <- metadata$bioproject_id
  normalized <- .whiteley_normalize_projects(counts, normalization_metadata)
  matrix_value <- normalized$matrix
  gene_qc <- list(); counter <- 0L
  for (project in unique(metadata$bioproject_id)) {
    ids <- metadata$biosample_id[metadata$bioproject_id == project]
    auxiliary <- normalized$project_data[[project]]
    minimum_detected <- max(
      as.integer(minimum_gene_detected_samples),
      ceiling(minimum_gene_detection_fraction * length(ids))
    )
    eligible <- rowSums(auxiliary$cpm[, ids, drop = FALSE] >= minimum_gene_cpm,
                        na.rm = TRUE) >= minimum_detected &
      apply(auxiliary$log_cpm[, ids, drop = FALSE], 1, function(value) {
        observed <- stats::mad(value, constant = 1, na.rm = TRUE)
        is.finite(observed) && observed >= minimum_gene_mad
      })
    matrix_value[!eligible, ids] <- NA_real_
    counter <- counter + 1L
    gene_qc[[counter]] <- data.frame(
      project_id = project, eligible_candidate_genes = sum(eligible),
      minimum_detected_samples = minimum_detected, stringsAsFactors = FALSE
    )
  }
  target_id <- paste0("METADATA_TARGET_", .scan_slug(audit$config$field))
  indicator <- as.numeric(
    .whiteley_normalize_match(metadata[[audit$config$field]]) ==
      .whiteley_normalize_match(audit$config$positive)
  )
  expression <- rbind(matrix_value, stats::setNames(indicator, colnames(matrix_value)))
  rownames(expression)[nrow(expression)] <- target_id
  targets <- pa_targets(
    individual = stats::setNames(target_id, audit$config$target_name),
    score_method = "mean_z", id_policy = "as_is"
  )
  scan <- pa_scan_targets(
    expression = expression, metadata = metadata, targets = targets,
    sample_id_col = "biosample_id", project_id_col = "bioproject_id",
    data_type = "normalized_log", id_policy = "as_is",
    adjustment = adjustment, min_samples_per_project = min_samples_per_project,
    minimum_pairwise_samples = minimum_pairwise_samples,
    minimum_residual_df = minimum_residual_df,
    minimum_target_members = 1, minimum_target_fraction = 1,
    minimum_target_coherence = -Inf, minimum_target_score_sd = 0,
    thresholds = thresholds, correlation = "pearson",
    exclude_target_genes = TRUE
  )
  scan$metadata_target_audit <- audit
  scan$cohort_audit <- cohort$cohort_audit
  scan$metadata_overlay_audit <- cohort$metadata_overlay_audit
  scan$config$analysis_type <- "whiteley_metadata_contrast"
  scan$config$metadata_target <- audit$config
  scan$config$effect_measure <- paste0(
    "point-biserial rho; positive = ", audit$config$positive,
    ", negative = ", audit$config$reference
  )
  scan$config$whiteley_profile <- list(
    profile_id = cohort$profile_id, profile_version = cohort$profile_version,
    provenance = cohort$provenance
  )
  scan$gene_input_summary <- scan$gene_input_summary[
    scan$gene_input_summary$gene_id != target_id, , drop = FALSE
  ]
  project_gene_qc <- do.call(rbind, gene_qc)
  readiness <- audit$project_readiness
  names(readiness)[names(readiness) == "bioproject_id"] <- "project_id"
  scan$project_qc <- merge(scan$project_qc, readiness, by = "project_id",
                           all.x = TRUE, sort = FALSE, suffixes = c("", ".audit"))
  scan$project_qc <- merge(scan$project_qc, project_gene_qc, by = "project_id",
                           all.x = TRUE, sort = FALSE,
                           suffixes = c(".scan", ".whiteley_filter"))
  roles <- audit$sample_assignments[c("biosample_id", "metadata_value", "contrast_role")]
  names(roles)[1] <- "sample_id"
  scan$target_scores <- merge(scan$target_scores, roles, by = "sample_id",
                              all.x = TRUE, sort = FALSE)
  scan <- .metadata_target_add_differences(scan, matrix_value, metadata, audit)
  scan
}

#' Run a complete Whiteley metadata-to-pathway comparison
#'
#' Runs [pa_scan_whiteley_metadata()], canonical enrichment, and the standard
#' audited report in one call. Optional curated pathways require
#' `curated=TRUE`.
#'
#' @inheritParams pa_scan_whiteley_metadata
#' @param output_dir Report destination.
#' @param membership Annotation object/file. `NULL` obtains cached/fresh PAO1
#'   GO and KEGG annotations.
#' @param enrich Run pathway enrichment.
#' @param curated Include paannotate's manually curated umbrella and iron
#'   collections; canonical database terms are the default.
#' @param enrichment_args,report_args Additional named arguments for
#'   [pa_enrich_scan()] and [pa_write_scan()].
#' @param ... Additional arguments passed to [pa_scan_whiteley_metadata()],
#'   including cohort filters, thresholds, and metadata overlays.
#' @return A `pa_scan_pipeline` object.
#' @export
pa_run_whiteley_metadata <- function(
    field, positive, reference, output_dir, target_name = NULL,
    membership = NULL, enrich = TRUE, curated = FALSE,
    enrichment_args = list(), report_args = list(), ...) {
  if (!is.list(enrichment_args) || !is.list(report_args)) {
    stop("enrichment_args and report_args must be named lists.", call. = FALSE)
  }
  scan <- pa_scan_whiteley_metadata(
    field = field, positive = positive, reference = reference,
    target_name = target_name, ...
  )
  enrichment <- NULL
  if (isTRUE(enrich)) {
    if (is.null(membership)) membership <- fetch_pa_annotations()
    membership <- .scan_read_membership(membership)
    enrichment <- do.call(pa_enrich_scan, utils::modifyList(
      list(scan = scan, membership = membership, curated = curated), enrichment_args
    ))
  }
  files <- do.call(pa_write_scan, utils::modifyList(
    list(scan = scan, enrichment = enrichment, output_dir = output_dir), report_args
  ))
  structure(list(scan = scan, enrichment = enrichment, files = files),
            class = "pa_scan_pipeline")
}
