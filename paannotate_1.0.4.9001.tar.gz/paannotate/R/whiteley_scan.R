.whiteley_profile_catalog <- function() {
  data.frame(
    profile_id = c("whiteley_full_v1", "whiteley_pao1_414_v1"),
    profile_version = c("1.0.0", "1.0.0"),
    label = c(
      "Full Whiteley release: 5,821 analyzable project-specific BioSamples in 470 project groups",
      "Curated Whiteley PAO1 compendium: 414 BioSamples in 46 BioProjects"
    ),
    release = rep("Whiteley database v0.1.0 (2026-02-12 raw dataset)", 2),
    expected_features = c(5586L, 5586L),
    expected_samples = c(5821L, 414L),
    expected_projects = c(470L, 46L),
    expected_manifest_samples = c(5932L, 414L),
    expected_manifest_projects = c(474L, 46L),
    expected_runs = c(7301L, 523L),
    stringsAsFactors = FALSE
  )
}

.whiteley_extdata <- function(filename) {
  path <- system.file("extdata", filename, package = "paannotate")
  if (!nzchar(path)) {
    candidates <- c(
      file.path("inst", "extdata", filename),
      file.path("work", "paannotate_v040", "paannotate", "inst", "extdata", filename)
    )
    path <- candidates[file.exists(candidates)][1]
  }
  if (is.na(path) || !nzchar(path) || !file.exists(path)) {
    stop("Packaged Whiteley resource is unavailable: ", filename, call. = FALSE)
  }
  path
}

.whiteley_utf8 <- function(x) iconv(as.character(x), from = "", to = "UTF-8", sub = "?")

.whiteley_nonblank <- function(x) !is.na(x) & nzchar(trimws(.whiteley_utf8(x)))

.whiteley_fill <- function(primary, fallback = "") {
  answer <- as.character(primary)
  fallback <- rep(as.character(fallback), length.out = length(answer))
  use_fallback <- !.whiteley_nonblank(answer)
  answer[use_fallback] <- fallback[use_fallback]
  answer[is.na(answer)] <- ""
  answer
}

.whiteley_overlay <- function() {
  utils::read.csv(
    .whiteley_extdata("whiteley_pao1_metadata_v1.csv"),
    colClasses = "character", check.names = FALSE, stringsAsFactors = FALSE,
    na.strings = c("", "NA")
  )
}

.whiteley_medium_dictionary <- function() {
  dictionary <- utils::read.csv(
    .whiteley_extdata("whiteley_medium_dictionary_v2.csv"),
    colClasses = "character", check.names = FALSE, stringsAsFactors = FALSE
  )
  required <- c("dictionary_version", "rule_id", "medium_family", "pattern",
                "description")
  missing <- setdiff(required, names(dictionary))
  if (length(missing)) stop("Whiteley medium dictionary lacks: ",
                            paste(missing, collapse = ", "), call. = FALSE)
  dictionary
}

.whiteley_map_medium <- function(values) {
  dictionary <- .whiteley_medium_dictionary()
  text <- tolower(trimws(.whiteley_utf8(values)))
  family <- rule <- description <- rep("", length(text))
  for (i in seq_len(nrow(dictionary))) {
    matched <- !nzchar(family) & nzchar(text) & grepl(
      dictionary$pattern[i], text, perl = TRUE
    )
    family[matched] <- dictionary$medium_family[i]
    rule[matched] <- dictionary$rule_id[i]
    description[matched] <- dictionary$description[i]
  }
  data.frame(
    medium_family = family,
    medium_mapping_status = ifelse(!nzchar(text), "missing",
                                   ifelse(nzchar(family), "mapped", "unmapped")),
    medium_mapping_rule = rule,
    medium_mapping_description = description,
    medium_dictionary_version = unique(dictionary$dictionary_version)[1],
    stringsAsFactors = FALSE
  )
}

.whiteley_resolve_media <- function(values) {
  original <- as.character(unlist(values, use.names = FALSE))
  mapped <- .whiteley_map_medium(original)$medium_family
  unique(c(original, mapped[nzchar(mapped)]))
}

.whiteley_add_medium_mapping <- function(manifest) {
  fields <- c("medium_base", "extracted_growth_medium", "medium_full", "medium_raw")
  for (field in fields) if (!field %in% names(manifest)) manifest[[field]] <- ""
  medium_source <- .whiteley_fill(manifest$medium_base,
                                  manifest$extracted_growth_medium)
  medium_source <- .whiteley_fill(medium_source, manifest$medium_full)
  medium_source <- .whiteley_fill(medium_source, manifest$medium_raw)
  medium_mapping <- .whiteley_map_medium(medium_source)
  for (field in names(medium_mapping)) manifest[[field]] <- medium_mapping[[field]]
  manifest
}

.whiteley_medium_mapping_current <- function(manifest) {
  required <- c("medium_family", "medium_mapping_status", "medium_mapping_rule",
                "medium_dictionary_version")
  all(required %in% names(manifest)) &&
    isTRUE(all(manifest$medium_dictionary_version ==
                 unique(.whiteley_medium_dictionary()$dictionary_version)[1]))
}

.whiteley_add_overlay <- function(manifest) {
  overlay <- .whiteley_overlay()
  overlay_project <- .whiteley_fill(overlay$bioproject_id, overlay[["Bioproject ID"]])
  manifest_original <- if ("biosample_id_original" %in% names(manifest)) {
    manifest$biosample_id_original
  } else manifest$biosample_id
  exact_key <- paste(manifest_original, manifest$bioproject_id, sep = "\r")
  overlay_key <- paste(overlay$biosample_id, overlay_project, sep = "\r")
  index <- match(exact_key, overlay_key)
  unique_overlay <- !duplicated(overlay$biosample_id) &
    !duplicated(overlay$biosample_id, fromLast = TRUE)
  unique_manifest <- !duplicated(manifest_original) &
    !duplicated(manifest_original, fromLast = TRUE)
  fallback <- match(manifest_original, overlay$biosample_id)
  use_fallback <- is.na(index) & !is.na(fallback) & unique_manifest
  use_fallback[use_fallback] <- unique_overlay[fallback[use_fallback]]
  index[use_fallback] <- fallback[use_fallback]

  fields <- c(
    "pao1_class", "identity_confidence", "engineered_genotype",
    "rna_collection_context", "context_assignment_status", "context_confidence",
    "host_scientific_name", "host_common_name", "host_taxon_id",
    "disease_or_injury", "inflammatory_state", "inflammation_basis",
    "host_model", "anatomical_site", "sample_material", "infection_context",
    "infection_phase", "inoculum_context", "condition_curation_status",
    "condition_curation_note", "study_arm_id", "strain", "background_genotype",
    "strain_origin", "medium_base", "medium_full", "medium_raw", "growth_mode",
    "growth_phase", "oxygen_condition", "temperature_c", "treatment",
    "treatment_dose", "exposure_duration_raw", "sampling_timepoint", "time_raw",
    "extracted_growth_medium", "extracted_growth_mode", "extracted_growth_phase",
    "extracted_oxygen_condition", "extracted_temperature_C", "extracted_treatment",
    "extracted_treatment_dose", "extracted_treatment_duration",
    "extracted_sampling_timepoint"
  )
  for (field in fields) {
    incoming <- rep("", nrow(manifest))
    if (field %in% names(overlay)) incoming[!is.na(index)] <- overlay[[field]][index[!is.na(index)]]
    if (!field %in% names(manifest)) manifest[[field]] <- ""
    manifest[[field]] <- .whiteley_fill(manifest[[field]], incoming)
  }
  raw_strain <- if ("strain_raw" %in% names(manifest)) manifest$strain_raw else ""
  if ("Strain" %in% names(overlay)) {
    overlay_strain <- rep("", nrow(manifest))
    overlay_strain[!is.na(index)] <- overlay[["Strain"]][index[!is.na(index)]]
    raw_strain <- .whiteley_fill(raw_strain, overlay_strain)
  }
  manifest$strain_raw <- raw_strain
  manifest$strain <- .whiteley_fill(manifest$strain, raw_strain)
  manifest$strain_standardized <- manifest$strain
  if (!"analysis_context" %in% names(manifest)) manifest$analysis_context <- ""
  manifest$analysis_context <- .whiteley_fill(
    manifest$analysis_context, manifest$rna_collection_context
  )
  manifest <- .whiteley_add_standard_mappings(manifest)
  manifest$curated_metadata_available <- !is.na(index)
  known_engineered <- .whiteley_nonblank(manifest$engineered_genotype) |
    grepl("derived|engineered|mutant", manifest$pao1_class, ignore.case = TRUE)
  known_wild_type <- grepl("wild.?type", manifest$pao1_class, ignore.case = TRUE)
  manifest$engineered_status <- ifelse(
    known_engineered, "engineered", ifelse(known_wild_type, "wild_type", "unknown")
  )
  manifest
}

.whiteley_profile_manifest <- function(profile = "whiteley_pao1_414_v1") {
  catalog <- .whiteley_profile_catalog()
  if (!profile %in% catalog$profile_id) {
    stop("Unknown Whiteley profile: ", profile, ". Available profiles: ",
         paste(catalog$profile_id, collapse = ", "), call. = FALSE)
  }
  if (identical(profile, "whiteley_full_v1")) {
    stop("The full profile manifest is built from all_metadata.csv at preparation time.",
         call. = FALSE)
  }
  filename <- paste0(profile, "_manifest.csv")
  manifest <- utils::read.csv(.whiteley_extdata(filename), colClasses = "character",
                              check.names = FALSE,
                              stringsAsFactors = FALSE)
  required <- c("profile_id", "profile_version", "biosample_id", "sra_runs",
                "bioproject_id", "study_arm_id", "analysis_context")
  missing <- setdiff(required, names(manifest))
  if (length(missing)) stop("Whiteley profile manifest lacks: ",
                            paste(missing, collapse = ", "), call. = FALSE)
  if (nrow(manifest) != 414L || length(unique(manifest$biosample_id)) != 414L ||
      length(unique(manifest$bioproject_id)) != 46L) {
    stop("The built-in Whiteley profile failed its 414-sample/46-project integrity check.",
         call. = FALSE)
  }
  .whiteley_add_overlay(manifest)
}

.whiteley_split_runs <- function(x) {
  runs <- unlist(strsplit(as.character(x), "[;,|[:space:]]+", perl = TRUE))
  trimws(runs[nzchar(trimws(runs))])
}

.whiteley_find_counts <- function(directory) {
  files <- list.files(directory, pattern = "all_featurecounts[.]csv$",
                      recursive = TRUE, full.names = TRUE, ignore.case = TRUE)
  if (length(files) != 1L) {
    stop("Expected exactly one all_featurecounts.csv in the Whiteley release; found ",
         length(files), ".", call. = FALSE)
  }
  files[1]
}

.whiteley_find_metadata <- function(directory) {
  files <- list.files(directory, pattern = "all_metadata[.]csv$",
                      recursive = TRUE, full.names = TRUE, ignore.case = TRUE)
  if (length(files) != 1L) {
    stop("Expected exactly one all_metadata.csv in the Whiteley release; found ",
         length(files), ".", call. = FALSE)
  }
  files[1]
}

.whiteley_find_datasummary <- function(directory) {
  files <- list.files(directory, pattern = "all_datasummary[.]csv$",
                      recursive = TRUE, full.names = TRUE, ignore.case = TRUE)
  if (length(files) != 1L) {
    stop("Expected exactly one all_datasummary.csv in the Whiteley release; found ",
         length(files), ".", call. = FALSE)
  }
  files[1]
}

.whiteley_unquote <- function(x) {
  x <- sub("^\ufeff", "", x)
  sub('^"(.*)"$', "\\1", x)
}

.whiteley_count_run_ids <- function(path) {
  connection <- file(path, open = "rt")
  on.exit(close(connection), add = TRUE)
  invisible(readLines(connection, n = 1L, warn = FALSE))
  answer <- character()
  repeat {
    lines <- readLines(connection, n = 1000L, warn = FALSE)
    if (!length(lines)) break
    comma <- regexpr(",", lines, fixed = TRUE)
    ids <- ifelse(comma > 0L, substr(lines, 1L, comma - 1L), lines)
    answer <- c(answer, .whiteley_unquote(ids))
  }
  answer <- answer[!answer %in% c("Chr", "Start", "End", "Strand", "Length")]
  if (!length(answer) || anyDuplicated(answer)) {
    stop("Whiteley count rows are empty or duplicated.", call. = FALSE)
  }
  answer
}

.whiteley_collapse <- function(x) {
  values <- unique(trimws(.whiteley_utf8(x)))
  values <- values[!is.na(values) & nzchar(values)]
  paste(values, collapse = "; ")
}

.whiteley_build_full_manifest <- function(counts_file, metadata_file,
                                           datasummary_file = NULL) {
  run_ids <- .whiteley_count_run_ids(counts_file)
  raw <- utils::read.csv(
    metadata_file, colClasses = "character", check.names = FALSE,
    stringsAsFactors = FALSE, na.strings = c("", "NA")
  )
  required <- c("SRA Number", "Biosample ID", "Sample ID", "Bioproject ID")
  missing <- setdiff(required, names(raw))
  if (length(missing)) stop("Whiteley all_metadata.csv lacks: ",
                            paste(missing, collapse = ", "), call. = FALSE)
  raw <- raw[!duplicated(raw[["SRA Number"]]), , drop = FALSE]
  matched <- raw[match(run_ids, raw[["SRA Number"]]), , drop = FALSE]
  matched[["SRA Number"]] <- run_ids
  original <- .whiteley_fill(matched[["Biosample ID"]], matched[["Sample ID"]])
  original <- .whiteley_fill(original, paste0("RUN:", run_ids))
  project <- .whiteley_fill(matched[["Bioproject ID"]], "UNASSIGNED")

  project_count <- tapply(project, original, function(x) length(unique(x)))
  reused <- names(project_count)[project_count > 1L]
  analysis_id <- original
  analysis_id[original %in% reused] <- paste0(
    original[original %in% reused], "__", gsub("[^A-Za-z0-9_.-]", "_",
                                                project[original %in% reused])
  )
  groups <- split(seq_along(run_ids), factor(analysis_id, levels = unique(analysis_id)))
  first <- vapply(groups, `[`, integer(1), 1L)
  manifest <- data.frame(
    profile_id = "whiteley_full_v1", profile_version = "1.0.0",
    cohort_id = "full_release", analysis_context = "",
    biosample_id = names(groups), biosample_id_original = original[first],
    sra_runs = vapply(groups, function(i) paste(run_ids[i], collapse = "; "), character(1)),
    technical_run_count = lengths(groups), bioproject_id = project[first],
    stringsAsFactors = FALSE, check.names = FALSE
  )
  raw_fields <- c(
    study_accession = "Study Accession", study_title = "Study Title",
    sample_title = "Sample Title", taxon_id = "Taxon ID", strain_raw = "Strain",
    publish_date = "Publish Date", library_strategy = "Library Strategy",
    library_source = "Library Source", library_selection = "Library Selection",
    library_layout = "Library Layout", instrument_model = "Instrument Model",
    country = "Country"
  )
  for (field in names(raw_fields)) {
    source <- raw_fields[[field]]
    manifest[[field]] <- if (source %in% names(matched)) {
      vapply(groups, function(i) .whiteley_collapse(matched[[source]][i]), character(1))
    } else ""
  }
  manifest$release_metadata_available <- manifest$bioproject_id != "UNASSIGNED"
  manifest$count_qc_status <- "not_listed_in_datasummary"
  if (!is.null(datasummary_file)) {
    summary <- utils::read.csv(datasummary_file, colClasses = "character",
                               check.names = FALSE, stringsAsFactors = FALSE)
    required_summary <- c("Sample", "Reads Assigned to features")
    missing_summary <- setdiff(required_summary, names(summary))
    if (length(missing_summary)) stop("Whiteley all_datasummary.csv lacks: ",
                                      paste(missing_summary, collapse = ", "),
                                      call. = FALSE)
    assigned <- suppressWarnings(as.numeric(summary[["Reads Assigned to features"]]))
    names(assigned) <- summary$Sample
    group_assigned <- vapply(manifest$sra_runs, function(value) {
      ids <- .whiteley_split_runs(value)
      values <- assigned[ids]
      if (any(is.na(values))) NA_real_ else sum(values)
    }, numeric(1))
    manifest$count_qc_status[is.finite(group_assigned) & group_assigned > 0] <- "usable"
    manifest$count_qc_status[is.finite(group_assigned) & group_assigned <= 0] <-
      "excluded_zero_assigned_reads"
    manifest$assigned_feature_reads <- group_assigned
  } else {
    manifest$assigned_feature_reads <- NA_real_
  }
  manifest <- .whiteley_add_overlay(manifest)
  catalog <- .whiteley_profile_catalog()
  row <- catalog[catalog$profile_id == "whiteley_full_v1", , drop = FALSE]
  projects <- length(unique(manifest$bioproject_id))
  if (length(run_ids) != row$expected_runs ||
      nrow(manifest) != row$expected_manifest_samples ||
      projects != row$expected_manifest_projects) {
    stop(
      "The full Whiteley release failed its integrity check (expected ",
      row$expected_runs, " runs, ", row$expected_manifest_samples,
      " project-specific BioSamples, and ", row$expected_manifest_projects,
      " project groups; observed ", length(run_ids), ", ",
      nrow(manifest), ", and ", projects, ").",
      call. = FALSE
    )
  }
  manifest
}

.whiteley_read_transposed_counts <- function(path, manifest, quiet = FALSE) {
  connection <- file(path, open = "rt")
  on.exit(close(connection), add = TRUE)
  header <- readLines(connection, n = 1L, warn = FALSE)
  if (!length(header)) stop("Whiteley count file is empty: ", path, call. = FALSE)
  fields <- strsplit(header, ",", fixed = TRUE)[[1]]
  genes <- .whiteley_unquote(fields[-1])
  exact_gene <- grepl("^PA[0-9]{4}[A-Z]?$", toupper(genes))
  if (sum(exact_gene) < 5000L) {
    stop("Whiteley count header did not contain the expected PAO1 gene columns.",
         call. = FALSE)
  }
  # Retain the 23 decimal-suffixed features supplied by this release. Extended
  # identifier mode keeps them distinct; exact mode deliberately excludes them
  # after normalization. Features absent from the release cannot be recovered.
  keep_gene <- rep(TRUE, length(genes))
  genes <- toupper(genes)
  if (anyDuplicated(genes)) stop("Whiteley release has duplicate PAO1 genes.",
                                 call. = FALSE)

  run_rows <- do.call(rbind, lapply(seq_len(nrow(manifest)), function(i) {
    runs <- .whiteley_split_runs(manifest$sra_runs[i])
    data.frame(run_id = runs, biosample_id = manifest$biosample_id[i],
               stringsAsFactors = FALSE)
  }))
  if (!nrow(run_rows) || anyDuplicated(run_rows$run_id)) {
    stop("Whiteley profile contains an empty or duplicated run mapping.", call. = FALSE)
  }
  sample_index <- match(run_rows$biosample_id, manifest$biosample_id)
  names(sample_index) <- run_rows$run_id
  counts <- matrix(0, nrow = length(genes), ncol = nrow(manifest),
                   dimnames = list(genes, manifest$biosample_id))
  coordinate_names <- c("Chr", "Start", "End", "Strand", "Length")
  coordinates <- stats::setNames(vector("list", length(coordinate_names)), coordinate_names)
  found <- stats::setNames(logical(nrow(run_rows)), run_rows$run_id)
  line_count <- 1L
  repeat {
    line <- readLines(connection, n = 1L, warn = FALSE)
    if (!length(line)) break
    line_count <- line_count + 1L
    comma <- regexpr(",", line, fixed = TRUE)[1]
    if (comma < 1L) next
    row_id <- .whiteley_unquote(substr(line, 1L, comma - 1L))
    if (!row_id %in% c(run_rows$run_id, coordinate_names)) next
    values <- strsplit(line, ",", fixed = TRUE)[[1]][-1]
    if (length(values) != length(keep_gene)) {
      stop("Unexpected field count at Whiteley row ", line_count, " (", row_id, ").",
           call. = FALSE)
    }
    values <- values[keep_gene]
    if (row_id %in% coordinate_names) {
      coordinates[[row_id]] <- values
      next
    }
    numeric_values <- suppressWarnings(as.numeric(values))
    if (any(!is.finite(numeric_values)) || any(numeric_values < 0)) {
      stop("Invalid raw counts for Whiteley run ", row_id, ".", call. = FALSE)
    }
    counts[, sample_index[[row_id]]] <- counts[, sample_index[[row_id]]] + numeric_values
    found[[row_id]] <- TRUE
  }
  missing_runs <- names(found)[!found]
  if (length(missing_runs)) {
    stop("The Whiteley release is missing ", length(missing_runs),
         " runs required by the PAO1 profile; first missing: ", missing_runs[1],
         call. = FALSE)
  }
  if (any(colSums(counts) <= 0)) stop("One or more aggregated BioSamples has no counts.",
                                      call. = FALSE)
  gene_coordinates <- data.frame(gene_id = genes, stringsAsFactors = FALSE)
  for (column in coordinate_names) {
    value <- coordinates[[column]]
    if (is.null(value)) value <- rep(NA_character_, length(genes))
    gene_coordinates[[column]] <- if (column %in% c("Start", "End", "Length"))
      suppressWarnings(as.numeric(value)) else as.character(value)
  }
  if (!quiet) message("Prepared ", nrow(counts), " PAO1-reference features across ",
                      ncol(counts), " project-specific BioSamples.")
  list(counts = counts, gene_coordinates = gene_coordinates,
       selected_runs = nrow(run_rows))
}

.whiteley_build_profile <- function(counts_file, manifest, profile, quiet = FALSE,
                                     metadata_file = NULL) {
  parsed <- .whiteley_read_transposed_counts(counts_file, manifest, quiet = quiet)
  reference <- data.frame(
    gene_id = rownames(parsed$counts),
    whiteley_median = apply(parsed$counts, 1, stats::median),
    whiteley_mean = rowMeans(parsed$counts),
    whiteley_detection_fraction = rowMeans(parsed$counts > 0),
    whiteley_data_type = "raw_counts",
    stringsAsFactors = FALSE
  )
  reference <- reference[grepl("^PA[0-9]{4}[A-Z]?$", reference$gene_id), , drop = FALSE]
  structure(list(
    counts = parsed$counts,
    metadata = manifest,
    reference_by_locus = reference,
    gene_coordinates = parsed$gene_coordinates,
    data_type = "raw_counts",
    sample_columns = colnames(parsed$counts),
    profile_id = profile,
    profile_version = unique(manifest$profile_version)[1],
    provenance = list(
      counts_file = normalizePath(path.expand(counts_file), winslash = "/"),
      metadata_file = if (is.null(metadata_file)) "packaged curated manifest" else
        normalizePath(path.expand(metadata_file), winslash = "/"),
      cohort_manifest = if (identical(profile, "whiteley_pao1_414_v1")) {
        "packaged, frozen 414-sample PAO1 cohort manifest"
      } else {
        "all count runs joined to all_metadata.csv; BioSamples split by BioProject when reused"
      },
      biological_samples = nrow(manifest),
      bioprojects = length(unique(manifest$bioproject_id)),
      selected_runs = parsed$selected_runs,
      prepared_at = format(Sys.time(), tz = "UTC", usetz = TRUE)
    )
  ), class = "pa_whiteley")
}

.whiteley_resolve_release <- function(
    cache_dir, release_archive = NULL, counts_file = NULL, metadata_file = NULL,
    datasummary_file = NULL,
    refresh = FALSE, require_metadata = TRUE) {
  if (!is.null(counts_file)) {
    counts_file <- normalizePath(path.expand(counts_file), winslash = "/", mustWork = TRUE)
    if (is.null(metadata_file) && isTRUE(require_metadata)) {
      metadata_file <- .whiteley_find_metadata(dirname(counts_file))
    }
    if (is.null(datasummary_file) && isTRUE(require_metadata)) {
      datasummary_file <- .whiteley_find_datasummary(dirname(counts_file))
    }
  } else if (!is.null(release_archive)) {
    release_archive <- normalizePath(path.expand(release_archive), winslash = "/",
                                     mustWork = TRUE)
    extraction_dir <- file.path(cache_dir, "whiteley_v0.1.0_raw")
    if (refresh && dir.exists(extraction_dir)) {
      unlink(extraction_dir, recursive = TRUE, force = TRUE)
    }
    dir.create(extraction_dir, recursive = TRUE, showWarnings = FALSE)
    utils::unzip(release_archive, exdir = extraction_dir)
    counts_file <- .whiteley_find_counts(extraction_dir)
    if (isTRUE(require_metadata)) {
      metadata_file <- .whiteley_find_metadata(extraction_dir)
      datasummary_file <- .whiteley_find_datasummary(extraction_dir)
    }
  } else {
    release <- fetch_whiteley_release(cache_dir = cache_dir, refresh = refresh)
    counts_file <- .whiteley_find_counts(release$extraction_dir)
    if (isTRUE(require_metadata)) {
      metadata_file <- .whiteley_find_metadata(release$extraction_dir)
      datasummary_file <- .whiteley_find_datasummary(release$extraction_dir)
    }
  }
  if (!is.null(metadata_file)) {
    metadata_file <- normalizePath(path.expand(metadata_file), winslash = "/", mustWork = TRUE)
  }
  if (!is.null(datasummary_file)) {
    datasummary_file <- normalizePath(path.expand(datasummary_file), winslash = "/",
                                      mustWork = TRUE)
  }
  list(counts_file = counts_file, metadata_file = metadata_file,
       datasummary_file = datasummary_file)
}

.whiteley_metadata_object <- function(manifest, profile, provenance = list(),
                                       release_exclusions = NULL) {
  structure(list(
    counts = NULL, metadata = manifest, reference_by_locus = NULL,
    gene_coordinates = NULL, data_type = "raw_counts", sample_columns = manifest$biosample_id,
    profile_id = profile, profile_version = unique(manifest$profile_version)[1],
    metadata_only = TRUE,
    release_exclusions = release_exclusions,
    provenance = utils::modifyList(list(
      biological_samples = nrow(manifest),
      bioprojects = length(unique(manifest$bioproject_id))
    ), provenance)
  ), class = "pa_whiteley")
}

#' Load a Whiteley expression profile
#'
#' The default profile uses every count run in the Whiteley release, aggregates
#' technical runs to project-specific BioSamples, and joins the release metadata.
#' The frozen 414-sample PAO1 cohort remains available as
#' `profile = "whiteley_pao1_414_v1"`. A structured PAO1 metadata overlay adds
#' media, context, strain, and genotype fields where they have been curated.
#' The prepared matrix is cached after the first run.
#'
#' @param profile Built-in cohort profile identifier.
#' @param cache_dir Directory for the downloaded release and prepared cache.
#' @param release_archive Optional local Whiteley release ZIP, avoiding a
#'   download.
#' @param counts_file Optional extracted `all_featurecounts.csv`, avoiding a
#'   download and unzip.
#' @param metadata_file Optional extracted `all_metadata.csv`. It is discovered
#'   beside `counts_file` when omitted.
#' @param datasummary_file Optional extracted `all_datasummary.csv`, used to
#'   exclude profiles with zero assigned feature reads before normalization.
#' @param refresh Redownload/re-extract the release and rebuild the cache.
#' @param rebuild Rebuild the prepared profile from an existing release.
#' @param metadata_overlay Optional reviewed metadata overlay table, CSV/XLSX,
#'   or [pa_merge_metadata_overlay()] result. It is applied after loading the
#'   cached profile, so changing metadata never rebuilds the count matrix.
#' @param metadata_only Build/load only the cohort manifest. This is used for a
#'   fast cohort preview and does not parse the count matrix.
#' @param quiet Suppress preparation messages.
#' @return A `pa_whiteley` object with raw BioSample counts and embedded cohort
#'   metadata.
#' @export
pa_load_whiteley <- function(
    profile = "whiteley_full_v1",
    cache_dir = file.path(tools::R_user_dir("paannotate", "cache"), "Whiteley"),
    release_archive = NULL, counts_file = NULL, metadata_file = NULL,
    datasummary_file = NULL,
    refresh = FALSE, rebuild = FALSE, metadata_overlay = NULL,
    metadata_only = FALSE, quiet = FALSE) {
  catalog <- .whiteley_profile_catalog()
  if (!profile %in% catalog$profile_id) {
    stop("Unknown Whiteley profile: ", profile, ". Available profiles: ",
         paste(catalog$profile_id, collapse = ", "), call. = FALSE)
  }
  catalog_row <- catalog[catalog$profile_id == profile, , drop = FALSE]
  cache_dir <- path.expand(cache_dir)
  dir.create(cache_dir, recursive = TRUE, showWarnings = FALSE)
  cache_file <- file.path(cache_dir, paste0(profile, ".rds"))
  manifest_cache <- file.path(cache_dir, paste0(profile, "_manifest.csv"))
  finish <- function(object) .whiteley_apply_metadata_overlay(object, metadata_overlay)

  if (isTRUE(metadata_only) && !refresh && !rebuild && file.exists(manifest_cache)) {
    manifest <- utils::read.csv(manifest_cache, colClasses = "character",
                                check.names = FALSE, stringsAsFactors = FALSE)
    if (!.whiteley_metadata_mapping_current(manifest)) {
      manifest <- .whiteley_add_overlay(manifest)
      tryCatch(
        utils::write.csv(manifest, manifest_cache, row.names = FALSE, na = ""),
        error = function(condition) warning(
          "The metadata dictionaries were applied in memory but the manifest cache could not be updated: ",
          conditionMessage(condition), call. = FALSE
        )
      )
    }
    excluded <- if ("count_qc_status" %in% names(manifest)) {
      manifest[manifest$count_qc_status == "excluded_zero_assigned_reads", , drop = FALSE]
    } else manifest[FALSE, , drop = FALSE]
    if ("count_qc_status" %in% names(manifest)) {
      manifest <- manifest[manifest$count_qc_status != "excluded_zero_assigned_reads",
                           , drop = FALSE]
    }
    return(finish(.whiteley_metadata_object(
      manifest, profile, list(manifest_cache = manifest_cache), excluded
    )))
  }
  if (!refresh && !rebuild && file.exists(cache_file)) {
    object <- readRDS(cache_file)
    upgraded <- FALSE
    if (inherits(object, "pa_whiteley") && !is.null(object$metadata) &&
        !.whiteley_metadata_mapping_current(object$metadata)) {
      object$metadata <- .whiteley_add_overlay(object$metadata)
      if (!is.null(object$release_exclusions) && nrow(object$release_exclusions)) {
        object$release_exclusions <- .whiteley_add_overlay(object$release_exclusions)
      }
      object$provenance$medium_dictionary_version <-
        unique(.whiteley_medium_dictionary()$dictionary_version)[1]
      object$provenance$treatment_dictionary_version <-
        unique(.whiteley_treatment_dictionary()$dictionary_version)[1]
      object$provenance$strain_dictionary_version <-
        unique(.whiteley_strain_dictionary()$dictionary_version)[1]
      upgraded <- TRUE
    }
    if (inherits(object, "pa_whiteley") && identical(object$profile_id, profile) &&
        nrow(object$counts) == catalog_row$expected_features &&
        ncol(object$counts) == catalog_row$expected_samples &&
        identical(colnames(object$counts), object$metadata$biosample_id)) {
      if (upgraded) tryCatch(
        saveRDS(
          object, cache_file,
          compress = if (identical(profile, "whiteley_full_v1")) "gzip" else "xz"
        ),
        error = function(condition) warning(
          "The metadata dictionaries were applied in memory but the prepared cache could not be updated: ",
          conditionMessage(condition), call. = FALSE
        )
      )
      if (isTRUE(metadata_only)) {
        return(finish(.whiteley_metadata_object(
          object$metadata, profile, object$provenance, object$release_exclusions
        )))
      }
      return(finish(object))
    }
    warning("Ignoring an incompatible Whiteley cache and rebuilding it.", call. = FALSE)
  }
  if (identical(profile, "whiteley_pao1_414_v1")) {
    manifest <- .whiteley_profile_manifest(profile)
  } else if (!refresh && !rebuild && file.exists(manifest_cache)) {
    manifest <- utils::read.csv(manifest_cache, colClasses = "character",
                                check.names = FALSE, stringsAsFactors = FALSE)
  } else {
    files <- .whiteley_resolve_release(
      cache_dir, release_archive, counts_file, metadata_file, datasummary_file, refresh,
      require_metadata = TRUE
    )
    counts_file <- files$counts_file
    metadata_file <- files$metadata_file
    datasummary_file <- files$datasummary_file
    manifest <- .whiteley_build_full_manifest(counts_file, metadata_file,
                                               datasummary_file)
  }
  if (!.whiteley_metadata_mapping_current(manifest)) {
    manifest <- .whiteley_add_overlay(manifest)
  }
  utils::write.csv(manifest, manifest_cache, row.names = FALSE, na = "")
  release_exclusions <- if ("count_qc_status" %in% names(manifest)) {
    manifest[manifest$count_qc_status == "excluded_zero_assigned_reads", , drop = FALSE]
  } else manifest[FALSE, , drop = FALSE]
  manifest <- if ("count_qc_status" %in% names(manifest)) {
    manifest[manifest$count_qc_status != "excluded_zero_assigned_reads", , drop = FALSE]
  } else manifest
  if (isTRUE(metadata_only)) {
    return(finish(.whiteley_metadata_object(manifest, profile, list(
      counts_file = counts_file, metadata_file = metadata_file,
      datasummary_file = datasummary_file,
      manifest_cache = normalizePath(manifest_cache, winslash = "/")
    ), release_exclusions)))
  }
  if (is.null(counts_file)) {
    files <- .whiteley_resolve_release(
      cache_dir, release_archive, counts_file, metadata_file, datasummary_file, refresh,
      require_metadata = identical(profile, "whiteley_full_v1")
    )
    counts_file <- files$counts_file
    if (is.null(metadata_file)) metadata_file <- files$metadata_file
    if (is.null(datasummary_file)) datasummary_file <- files$datasummary_file
  }
  counts_file <- normalizePath(path.expand(counts_file), winslash = "/", mustWork = TRUE)
  object <- .whiteley_build_profile(
    counts_file, manifest, profile, quiet = quiet, metadata_file = metadata_file
  )
  object$release_exclusions <- release_exclusions
  object$provenance$medium_dictionary_version <-
    unique(.whiteley_medium_dictionary()$dictionary_version)[1]
  object$provenance$treatment_dictionary_version <-
    unique(.whiteley_treatment_dictionary()$dictionary_version)[1]
  object$provenance$strain_dictionary_version <-
    unique(.whiteley_strain_dictionary()$dictionary_version)[1]
  object$provenance$cache_file <- normalizePath(cache_file, winslash = "/",
                                                mustWork = FALSE)
  object$provenance$manifest_cache <- normalizePath(manifest_cache, winslash = "/")
  saveRDS(object, cache_file,
          compress = if (identical(profile, "whiteley_full_v1")) "gzip" else "xz")
  finish(object)
}

.whiteley_normalize_match <- function(x) {
  tolower(gsub("[^[:alnum:]]+", "", trimws(as.character(x))))
}

.whiteley_filter_fields <- function(name, metadata) {
  aliases <- list(
    strain = c("strain_standardized", "strain", "strain_raw"),
    strains = c("strain_standardized", "strain", "strain_raw"),
    medium = c("medium_family", "medium_base", "medium_full", "medium_raw",
               "extracted_growth_medium"),
    media = c("medium_family", "medium_base", "medium_full", "medium_raw",
              "extracted_growth_medium"),
    context = c("analysis_context", "rna_collection_context", "infection_context"),
    contexts = c("analysis_context", "rna_collection_context", "infection_context"),
    bioproject = "bioproject_id", bioprojects = "bioproject_id",
    genotype = c("engineered_genotype", "background_genotype"),
    host = c("host_scientific_name", "host_common_name", "host_model"),
    treatment = c("treatment_standardized", "treatment", "treatment_raw",
                  "treatment_class", "extracted_treatment"),
    growth_mode = c("growth_mode", "extracted_growth_mode"),
    oxygen = c("oxygen_condition", "extracted_oxygen_condition")
  )
  fields <- if (name %in% names(aliases)) aliases[[name]] else name
  fields <- intersect(fields, names(metadata))
  if (!length(fields)) {
    stop("Unknown Whiteley metadata filter field: ", name, ".", call. = FALSE)
  }
  fields
}

.whiteley_match_rows <- function(metadata, fields, values, mode, missing_metadata) {
  values <- as.character(unlist(values, use.names = FALSE))
  values <- values[!is.na(values) & nzchar(trimws(values))]
  if (!length(values)) stop("Metadata filter values cannot be empty.", call. = FALSE)
  matrix_value <- do.call(cbind, lapply(fields, function(field) {
    value <- as.character(metadata[[field]])
    value[is.na(value)] <- ""
    value
  }))
  if (is.null(dim(matrix_value))) matrix_value <- matrix(matrix_value, ncol = 1L)
  present <- nzchar(trimws(as.vector(matrix_value)))
  dim(present) <- dim(matrix_value)
  missing <- rowSums(present) == 0L
  if (missing_metadata == "error" && any(missing)) {
    stop("The requested filter uses missing metadata for ", sum(missing),
         " samples (fields: ", paste(fields, collapse = ", "), ").", call. = FALSE)
  }
  matched <- rep(FALSE, nrow(metadata))
  if (mode == "exact") {
    wanted <- .whiteley_normalize_match(values)
    for (column in seq_len(ncol(matrix_value))) {
      matched <- matched | .whiteley_normalize_match(matrix_value[, column]) %in% wanted
    }
  } else if (mode == "contains") {
    patterns <- tolower(values)
    for (column in seq_len(ncol(matrix_value))) {
      haystack <- tolower(matrix_value[, column])
      for (pattern in patterns) matched <- matched | grepl(pattern, haystack, fixed = TRUE)
    }
  } else {
    pattern <- paste0("(?:", paste(values, collapse = ")|(?:"), ")")
    for (column in seq_len(ncol(matrix_value))) {
      matched <- matched | grepl(pattern, matrix_value[, column], ignore.case = TRUE,
                                 perl = TRUE)
    }
  }
  if (missing_metadata == "include") matched[missing] <- TRUE
  matched
}

.whiteley_project_sizes <- function(metadata) {
  if (!nrow(metadata)) {
    return(data.frame(bioproject_id = character(), biological_samples = integer(),
                      stringsAsFactors = FALSE))
  }
  answer <- as.data.frame(table(metadata$bioproject_id), stringsAsFactors = FALSE)
  names(answer) <- c("bioproject_id", "biological_samples")
  answer[order(-answer$biological_samples, answer$bioproject_id), , drop = FALSE]
}

.whiteley_select_cohort <- function(
    whiteley, strains = NULL, media = NULL, contexts = NULL,
    include_engineered = TRUE, bioprojects = NULL, filters = list(),
    exclude_filters = list(), metadata_filter = NULL,
    filter_match = c("exact", "contains", "regex"),
    missing_metadata = c("exclude", "include", "error")) {
  if (!inherits(whiteley, "pa_whiteley") || is.null(whiteley$metadata)) {
    stop("whiteley must be returned by pa_load_whiteley().", call. = FALSE)
  }
  filter_match <- match.arg(filter_match)
  missing_metadata <- match.arg(missing_metadata)
  if (!is.list(filters) || (length(filters) && (is.null(names(filters)) ||
      any(!nzchar(names(filters)))))) {
    stop("filters must be a named list, such as list(country = 'USA').", call. = FALSE)
  }
  if (!is.list(exclude_filters) || (length(exclude_filters) &&
      (is.null(names(exclude_filters)) || any(!nzchar(names(exclude_filters)))))) {
    stop("exclude_filters must be a named list.", call. = FALSE)
  }
  metadata <- as.data.frame(whiteley$metadata, stringsAsFactors = FALSE)
  release_exclusions <- if (is.null(whiteley$release_exclusions)) {
    metadata[FALSE, , drop = FALSE]
  } else as.data.frame(whiteley$release_exclusions, stringsAsFactors = FALSE)
  included <- rep(TRUE, nrow(metadata))
  reasons <- rep("", nrow(metadata))
  steps <- data.frame(
    step = "Starting release manifest",
    remaining_samples = nrow(metadata) + nrow(release_exclusions),
    excluded_this_step = 0L, stringsAsFactors = FALSE
  )
  if (nrow(release_exclusions)) {
    steps <- rbind(steps, data.frame(
      step = "release count QC (exclude zero assigned reads)",
      remaining_samples = nrow(metadata),
      excluded_this_step = nrow(release_exclusions), stringsAsFactors = FALSE
    ))
  }
  apply_rule <- function(pass, label) {
    if (length(pass) != nrow(metadata)) {
      stop("Internal cohort filter returned the wrong number of rows.", call. = FALSE)
    }
    pass[is.na(pass)] <- missing_metadata == "include"
    newly <- included & !pass
    failed <- !pass
    reasons[failed] <<- ifelse(
      nzchar(reasons[failed]), paste(reasons[failed], label, sep = "; "), label
    )
    included <<- included & pass
    steps <<- rbind(steps, data.frame(
      step = label, remaining_samples = sum(included),
      excluded_this_step = sum(newly), stringsAsFactors = FALSE
    ))
  }
  include_field <- function(name, values, label = name) {
    if (is.null(values)) return(invisible(NULL))
    fields <- .whiteley_filter_fields(name, metadata)
    apply_rule(.whiteley_match_rows(metadata, fields, values, filter_match,
                                    missing_metadata), paste0("include ", label))
  }
  media_resolved <- if (is.null(media)) NULL else .whiteley_resolve_media(media)
  include_field("strains", strains, "strain")
  include_field("media", media_resolved, "medium family")
  include_field("contexts", contexts, "context")
  include_field("bioprojects", bioprojects, "BioProject")
  if (!isTRUE(include_engineered)) {
    engineered <- if ("engineered_status" %in% names(metadata)) {
      metadata$engineered_status == "engineered"
    } else .whiteley_nonblank(metadata$engineered_genotype)
    engineered[is.na(engineered)] <- FALSE
    apply_rule(!engineered, "exclude explicitly engineered samples")
  }
  if (length(filters)) {
    for (name in names(filters)) include_field(name, filters[[name]], name)
  }
  if (length(exclude_filters)) {
    for (name in names(exclude_filters)) {
      fields <- .whiteley_filter_fields(name, metadata)
      matched <- .whiteley_match_rows(metadata, fields, exclude_filters[[name]],
                                      filter_match, "exclude")
      apply_rule(!matched, paste0("exclude ", name))
    }
  }
  if (!is.null(metadata_filter)) {
    keep <- if (is.function(metadata_filter)) {
      metadata_filter(metadata)
    } else if (inherits(metadata_filter, "formula") && length(metadata_filter) == 2L) {
      eval(metadata_filter[[2]], envir = metadata, enclos = environment(metadata_filter))
    } else {
      stop("metadata_filter must be a function or one-sided formula.", call. = FALSE)
    }
    if (!is.logical(keep) || length(keep) != nrow(metadata)) {
      stop("metadata_filter must return one logical value per sample.", call. = FALSE)
    }
    if (missing_metadata == "error" && anyNA(keep)) {
      stop("metadata_filter returned missing values.", call. = FALSE)
    }
    apply_rule(keep, "custom metadata_filter")
  }
  if (!any(included)) stop("The requested Whiteley filters selected zero samples.",
                           call. = FALSE)

  audit_columns <- intersect(c(
    "biosample_id", "biosample_id_original", "sra_runs", "bioproject_id",
    "strain_standardized", "strain_raw", "pao1_class", "engineered_status",
    "analysis_context", "medium_family", "medium_base", "medium_full",
    "medium_raw", "medium_mapping_status", "medium_mapping_rule",
    "medium_mapping_description", "medium_dictionary_version", "growth_mode",
    "oxygen_condition", "treatment_standardized", "treatment", "treatment_class",
    "host_scientific_name", "study_title",
    "sample_title", "curated_metadata_available", "release_metadata_available"
  ), names(metadata))
  selection <- metadata[audit_columns]
  selection$included <- included
  selection$exclusion_reason <- ifelse(included, "", reasons)
  if (nrow(release_exclusions)) {
    release_selection <- release_exclusions[audit_columns]
    release_selection$included <- FALSE
    release_selection$exclusion_reason <- "release count QC: zero assigned feature reads"
    selection <- rbind(selection, release_selection)
  }
  selected_metadata <- metadata[included, , drop = FALSE]
  selected_counts <- if (is.null(whiteley$counts)) NULL else
    whiteley$counts[, selected_metadata$biosample_id, drop = FALSE]
  before <- .whiteley_project_sizes(metadata)
  names(before)[2] <- "samples_before"
  after <- .whiteley_project_sizes(selected_metadata)
  names(after)[2] <- "samples_after"
  project_sizes <- merge(before, after, by = "bioproject_id", all = TRUE, sort = FALSE)
  project_sizes$samples_before[is.na(project_sizes$samples_before)] <- 0L
  project_sizes$samples_after[is.na(project_sizes$samples_after)] <- 0L
  project_sizes <- project_sizes[order(-project_sizes$samples_after,
                                       project_sizes$bioproject_id), , drop = FALSE]
  audit <- list(
    summary = steps, selection = selection, project_sizes = project_sizes,
    config = list(
      profile_id = whiteley$profile_id, strains = strains, media = media,
      media_requested = media, media_resolved = media_resolved,
      contexts = contexts, include_engineered = include_engineered,
      bioprojects = bioprojects, filters = filters,
      exclude_filters = exclude_filters,
      metadata_filter = if (is.null(metadata_filter)) NULL else
        paste(deparse(metadata_filter), collapse = " "),
      filter_match = filter_match, missing_metadata = missing_metadata
    )
  )
  result <- whiteley
  result$counts <- selected_counts
  result$metadata <- selected_metadata
  result$sample_columns <- selected_metadata$biosample_id
  result$cohort_audit <- audit
  result$provenance$release_manifest_samples <- nrow(metadata) + nrow(release_exclusions)
  result$provenance$release_count_qc_exclusions <- nrow(release_exclusions)
  result$provenance$unfiltered_biological_samples <- nrow(metadata)
  result$provenance$biological_samples <- nrow(selected_metadata)
  result$provenance$bioprojects <- length(unique(selected_metadata$bioproject_id))
  result$provenance$cohort_filter_applied <- nrow(selected_metadata) != nrow(metadata) ||
    length(filters) || length(exclude_filters) || !is.null(metadata_filter)
  result
}

#' Preview and audit a Whiteley cohort without running correlations
#'
#' @param use_curated_414 Use the frozen 414-sample/46-project preset. The
#'   default is the complete Whiteley release.
#' @param whiteley Optional object from [pa_load_whiteley()].
#' @param strains,contexts Friendly inclusion filters.
#' @param media Medium-family filter. Common aliases such as `"LB"`,
#'   `"lysogeny broth"`, and `"M9"` resolve through the versioned medium
#'   dictionary before matching.
#' @param include_engineered Retain samples explicitly annotated as engineered.
#' @param bioprojects Optional BioProject IDs to retain.
#' @param filters,exclude_filters Additional named metadata filters.
#' @param metadata_filter Optional function or one-sided formula evaluated on
#'   the sample metadata.
#' @param filter_match Matching style for text filters.
#' @param missing_metadata What to do when a requested field is blank.
#' @param profile Optional explicit profile ID retained for compatibility.
#' @param metadata_overlay Optional reviewed metadata overlay, applied without
#'   rebuilding counts.
#' @param cache_dir,release_archive,counts_file,metadata_file,datasummary_file,refresh,rebuild
#'   Passed to [pa_load_whiteley()].
#' @return A `pa_whiteley_cohort_check` with selection and project audits.
#' @export
pa_check_whiteley_cohort <- function(
    use_curated_414 = FALSE, whiteley = NULL, metadata_overlay = NULL,
    strains = NULL, media = NULL, contexts = NULL, include_engineered = TRUE,
    bioprojects = NULL, filters = list(), exclude_filters = list(),
    metadata_filter = NULL, filter_match = c("exact", "contains", "regex"),
    missing_metadata = c("exclude", "include", "error"), profile = NULL,
    cache_dir = file.path(tools::R_user_dir("paannotate", "cache"), "Whiteley"),
    release_archive = NULL, counts_file = NULL, metadata_file = NULL,
    datasummary_file = NULL,
    refresh = FALSE, rebuild = FALSE) {
  chosen_profile <- if (!is.null(profile)) profile else if (isTRUE(use_curated_414)) {
    "whiteley_pao1_414_v1"
  } else "whiteley_full_v1"
  if (is.null(whiteley)) {
    whiteley <- pa_load_whiteley(
      profile = chosen_profile, cache_dir = cache_dir,
      release_archive = release_archive, counts_file = counts_file,
      metadata_file = metadata_file, datasummary_file = datasummary_file,
      refresh = refresh, rebuild = rebuild,
      metadata_overlay = metadata_overlay, metadata_only = TRUE
    )
  } else if (!is.null(metadata_overlay)) whiteley <-
    .whiteley_apply_metadata_overlay(whiteley, metadata_overlay)
  selected <- .whiteley_select_cohort(
    whiteley, strains, media, contexts, include_engineered, bioprojects,
    filters, exclude_filters, metadata_filter, filter_match, missing_metadata
  )
  structure(list(
    profile_id = selected$profile_id,
    selected_metadata = selected$metadata,
    summary = selected$cohort_audit$summary,
    selection = selected$cohort_audit$selection,
    project_sizes = selected$cohort_audit$project_sizes,
    config = selected$cohort_audit$config
  ), class = "pa_whiteley_cohort_check")
}

#' @export
print.pa_whiteley_cohort_check <- function(x, ...) {
  cat("paannotate Whiteley cohort preview\n")
  cat("  profile:", x$profile_id, "\n")
  cat("  selected samples:", nrow(x$selected_metadata), "\n")
  cat("  selected project groups:",
      length(unique(x$selected_metadata$bioproject_id)), "\n")
  cat("  explicitly curated metadata:",
      sum(x$selected_metadata$curated_metadata_available %in% TRUE), "samples\n")
  invisible(x)
}

.whiteley_normalize_projects <- function(matrix_value, metadata) {
  if (!requireNamespace("edgeR", quietly = TRUE)) {
    stop("The built-in Whiteley workflow requires the optional edgeR package.",
         call. = FALSE)
  }
  projects <- unique(metadata$.project_id)
  normalized <- matrix(NA_real_, nrow(matrix_value), ncol(matrix_value),
                       dimnames = dimnames(matrix_value))
  project_data <- stats::setNames(vector("list", length(projects)), projects)
  for (project in projects) {
    ids <- metadata$.sample_id[metadata$.project_id == project]
    raw <- matrix_value[, ids, drop = FALSE]
    libraries <- colSums(raw)
    if (any(!is.finite(libraries)) || any(libraries <= 0)) {
      stop("Project ", project, " contains a non-positive library.",
           call. = FALSE)
    }
    dge <- edgeR::DGEList(counts = raw)
    normalization_warnings <- character()
    dge <- withCallingHandlers(
      edgeR::calcNormFactors(dge, method = "TMM"),
      warning = function(condition) {
        normalization_warnings <<- c(normalization_warnings,
                                      conditionMessage(condition))
        invokeRestart("muffleWarning")
      }
    )
    if (any(!is.finite(dge$samples$norm.factors) |
            dge$samples$norm.factors <= 0)) {
      dge$samples$norm.factors <- rep(1, ncol(raw))
      normalization_warnings <- c(
        normalization_warnings,
        "TMM returned invalid factors; library-size scaling was used"
      )
    }
    cpm <- edgeR::cpm(dge, log = FALSE)
    log_cpm <- edgeR::cpm(dge, log = TRUE, prior.count = 2)
    normalized[, ids] <- log_cpm
    project_data[[project]] <- list(
      cpm = cpm, log_cpm = log_cpm, library_sizes = libraries,
      normalization = "edgeR TMM within BioProject; log2 CPM prior.count=2",
      normalization_warning = paste(unique(normalization_warnings), collapse = "; ")
    )
  }
  list(matrix = normalized, project_data = project_data)
}

.whiteley_make_targets <- function(targets, target_name, separate) {
  if (inherits(targets, "pa_targets")) return(targets)
  if (is.list(targets)) {
    return(pa_targets(sets = targets, score_method = "median_z"))
  }
  if (!is.character(targets) || !length(targets)) {
    stop("targets must be PAO1 locus tags, a named list, or a pa_targets object.",
         call. = FALSE)
  }
  if (isTRUE(separate)) {
    labels <- names(targets)
    if (is.null(labels)) labels <- targets
    names(targets) <- labels
    pa_targets(individual = targets, score_method = "median_z")
  } else {
    sets <- list(targets)
    names(sets) <- target_name
    pa_targets(sets = sets, score_method = "median_z")
  }
}

#' Scan arbitrary genes across the Whiteley compendium
#'
#' This is the target-only interface for the Whiteley analysis. By default it
#' uses the complete release; set `use_curated_414 = TRUE` for the exact frozen
#' 414-sample PAO1 cohort used by the earlier pipeline. The
#' expression matrix, BioProject membership, technical-run aggregation, and
#' study-arm fields are loaded automatically. Correlations are calculated
#' within BioProjects and combined across projects; they are never calculated
#' by pooling unrelated samples.
#' The Whiteley release does not contain every PAO1 locus. In particular,
#' PA0714.1 (PhrD) is absent from its count header. Individually requested
#' targets missing from that header stop with an explicit error; they cannot
#' be reconstructed from neighboring genes.
#'
#' @param targets Character vector for one signature, named list of signatures,
#'   or a [pa_targets()] object.
#' @param target_name Name used when a character vector is one signature.
#' @param separate Treat each element of a character vector as a separate target.
#' @param whiteley Optional prepared [pa_load_whiteley()] object.
#' @param use_curated_414 Use the frozen 414-sample/46-project preset instead of
#'   the default full release.
#' @param strains,contexts Friendly cohort inclusion filters.
#' @param media Medium-family filter. Common aliases such as `"LB"`,
#'   `"lysogeny broth"`, and `"M9"` resolve through the versioned medium
#'   dictionary before matching.
#' @param include_engineered Retain samples explicitly annotated as engineered.
#' @param bioprojects BioProject IDs to retain.
#' @param filters,exclude_filters Additional named metadata filters, for example
#'   `list(country = "USA", growth_mode = "Biofilm")`.
#' @param metadata_filter Optional function or one-sided formula for advanced
#'   sample selection.
#' @param filter_match Text matching mode used by all metadata filters.
#' @param missing_metadata How requested filters handle blank metadata.
#' @param profile Optional explicit profile identifier retained for compatibility.
#' @param metadata_overlay Optional reviewed metadata overlay, applied without
#'   rebuilding counts.
#' @param cache_dir,release_archive,counts_file,metadata_file,datasummary_file,refresh,rebuild Passed to
#'   [pa_load_whiteley()] when `whiteley` is omitted.
#' @param adjustment Built-in study-arm adjustment; use `NULL` for total mode only.
#' @param min_samples_per_project One or more BioProject size cutoffs.
#' @param fdr,rho,i2 Convenient evidence thresholds.
#' @param thresholds Optional complete [pa_scan_thresholds()] object, overriding
#'   `fdr`, `rho`, and `i2`.
#' @param minimum_target_members,minimum_target_fraction Target usability rules.
#' @param minimum_target_coherence Minimum median pairwise target-gene rho.
#' @param minimum_target_score_sd Minimum within-project score standard deviation.
#' @param ... Additional arguments passed to [pa_scan_targets()].
#' @return A `pa_target_scan` object.
#' @export
pa_scan_whiteley <- function(
    targets, target_name = "target_signature", separate = FALSE,
    whiteley = NULL, metadata_overlay = NULL, use_curated_414 = FALSE,
    strains = NULL, media = NULL, contexts = NULL, include_engineered = TRUE,
    bioprojects = NULL, filters = list(), exclude_filters = list(),
    metadata_filter = NULL, filter_match = c("exact", "contains", "regex"),
    missing_metadata = c("exclude", "include", "error"), profile = NULL,
    cache_dir = file.path(tools::R_user_dir("paannotate", "cache"), "Whiteley"),
    release_archive = NULL, counts_file = NULL, metadata_file = NULL,
    datasummary_file = NULL,
    refresh = FALSE, rebuild = FALSE,
    adjustment = ~ study_arm_id, min_samples_per_project = c(6, 7, 8),
    fdr = 0.05, rho = 0.30, i2 = 75, thresholds = NULL,
    minimum_target_members = 1, minimum_target_fraction = 0.5,
    minimum_target_coherence = 0.10, minimum_target_score_sd = 0.05, ...) {
  chosen_profile <- if (!is.null(profile)) profile else if (isTRUE(use_curated_414)) {
    "whiteley_pao1_414_v1"
  } else "whiteley_full_v1"
  if (is.null(whiteley)) {
    whiteley <- pa_load_whiteley(
      profile = chosen_profile, cache_dir = cache_dir, release_archive = release_archive,
      counts_file = counts_file, metadata_file = metadata_file,
      datasummary_file = datasummary_file,
      refresh = refresh, rebuild = rebuild, metadata_overlay = metadata_overlay
    )
  } else if (!is.null(metadata_overlay)) whiteley <-
    .whiteley_apply_metadata_overlay(whiteley, metadata_overlay)
  if (!inherits(whiteley, "pa_whiteley") || is.null(whiteley$profile_id)) {
    stop("whiteley must be an object returned by pa_load_whiteley().",
         call. = FALSE)
  }
  if (is.null(whiteley$counts)) {
    stop("The supplied Whiteley object contains metadata only; reload it with metadata_only = FALSE before scanning.",
         call. = FALSE)
  }
  whiteley <- .whiteley_select_cohort(
    whiteley, strains, media, contexts, include_engineered, bioprojects,
    filters, exclude_filters, metadata_filter, filter_match, missing_metadata
  )
  target_object <- .whiteley_make_targets(targets, target_name, separate)
  individual_targets <- target_object$targets$target[
    target_object$targets$requested_members == 1L
  ]
  missing_members <- target_object$membership[
    target_object$membership$target %in% individual_targets &
      !target_object$membership$gene_id %in% rownames(whiteley$counts),
    "gene_id", drop = TRUE
  ]
  if (length(missing_members)) {
    stop(
      "The Whiteley count release does not quantify target ",
      paste(unique(missing_members), collapse = ", "),
      ". This gene is absent from all_featurecounts.csv, so its expression ",
      "and correlations cannot be inferred from this release. Re-quantify ",
      "the source reads with a reference containing it, or use ",
      "pa_run_p2c_cohort() with P2C study counts that include the gene.",
      call. = FALSE
    )
  }
  if (is.null(thresholds)) thresholds <- pa_scan_thresholds(fdr = fdr, rho = rho, i2 = i2)
  pa_scan_targets(
    expression = whiteley, metadata = NULL, targets = target_object,
    adjustment = adjustment, min_samples_per_project = min_samples_per_project,
    minimum_target_members = minimum_target_members,
    minimum_target_fraction = minimum_target_fraction,
    minimum_target_coherence = minimum_target_coherence,
    minimum_target_score_sd = minimum_target_score_sd,
    thresholds = thresholds, ...
  )
}

#' Run the complete Whiteley target-to-heatmap workflow
#'
#' @inheritParams pa_scan_whiteley
#' @param output_dir Report destination.
#' @param membership Annotation object/file. When omitted and `enrich=TRUE`,
#'   paannotate obtains cached/fresh PAO1 GO and KEGG annotations.
#' @param enrich Run pathway enrichment.
#' @param curated Include paannotate's manually curated umbrella and iron
#'   collections; canonical database terms are the default.
#' @param enrichment_args,report_args Additional named arguments for
#'   [pa_enrich_scan()] and [pa_write_scan()].
#' @return A `pa_scan_pipeline` object with scan, enrichment, and output paths.
#' @export
pa_run_whiteley <- function(
    targets, output_dir, target_name = "target_signature", separate = FALSE,
    whiteley = NULL, membership = NULL, enrich = TRUE, curated = FALSE,
    custom_pathways = NULL, pathway_library_mode = "append", pathway_activity = FALSE,
    minimum_pathway_members = 3, minimum_pathway_fraction = .5,
    metadata_overlay = NULL,
    use_curated_414 = FALSE,
    strains = NULL, media = NULL, contexts = NULL, include_engineered = TRUE,
    bioprojects = NULL, filters = list(), exclude_filters = list(),
    metadata_filter = NULL, filter_match = c("exact", "contains", "regex"),
    missing_metadata = c("exclude", "include", "error"), profile = NULL,
    cache_dir = file.path(tools::R_user_dir("paannotate", "cache"), "Whiteley"),
    release_archive = NULL, counts_file = NULL, metadata_file = NULL,
    datasummary_file = NULL,
    refresh = FALSE, rebuild = FALSE,
    adjustment = ~ study_arm_id, min_samples_per_project = c(6, 7, 8),
    fdr = 0.05, rho = 0.30, i2 = 75, thresholds = NULL,
    enrichment_args = list(), report_args = list(),
    checkpoint_dir = NULL, checkpoint_key = NULL, stop_file = NULL, ...) {
  if(isTRUE(enrich)){
    if(is.null(membership))membership <- if(pathway_library_mode=="custom") .empty_membership() else fetch_pa_annotations()
    membership <- .p2c_combine_pathways(.scan_read_membership(membership),custom_pathways,pathway_library_mode)
  }
  scan_path<-if(is.null(checkpoint_dir))NULL else file.path(checkpoint_dir,'scan.rds')
  saved_scan<-if(is.null(scan_path))NULL else .p2c_resume_read(scan_path,checkpoint_key)
  if(!is.null(saved_scan)){
    scan<-saved_scan$value
    .p2c_resume_event('whiteley_checkpoint','Reused completed transcriptome scan')
  }else{
    scan <- pa_scan_whiteley(
    targets = targets, target_name = target_name, separate = separate,
    whiteley = whiteley, metadata_overlay = metadata_overlay,
    use_curated_414 = use_curated_414,
    strains = strains, media = media, contexts = contexts,
    include_engineered = include_engineered, bioprojects = bioprojects,
    filters = filters, exclude_filters = exclude_filters,
    metadata_filter = metadata_filter, filter_match = filter_match,
    missing_metadata = missing_metadata, profile = profile, cache_dir = cache_dir,
    release_archive = release_archive, counts_file = counts_file,
    metadata_file = metadata_file, datasummary_file = datasummary_file,
    refresh = refresh, rebuild = rebuild,
    adjustment = adjustment,
    min_samples_per_project = min_samples_per_project,
    fdr = fdr, rho = rho, i2 = i2, thresholds = thresholds,
    pathway_membership = if(isTRUE(pathway_activity)&&isTRUE(enrich)) .as_membership(membership) else NULL,
    minimum_pathway_members=minimum_pathway_members, minimum_pathway_fraction=minimum_pathway_fraction,
    checkpoint_dir=if(is.null(checkpoint_dir))NULL else file.path(checkpoint_dir,'studies'),
    checkpoint_key=checkpoint_key,stop_file=stop_file,...
    )
    if(!is.null(scan_path)) .p2c_resume_write(scan_path,list(key=checkpoint_key,value=scan))
  }
  .p2c_resume_pause(stop_file)
  enriched <- NULL
  if (isTRUE(enrich)) {
    .p2c_progress('enrichment','Testing pathway enrichment')
    enrichment_path<-if(is.null(checkpoint_dir))NULL else file.path(checkpoint_dir,'enrichment.rds')
    saved_enrichment<-if(is.null(enrichment_path))NULL else .p2c_resume_read(enrichment_path,checkpoint_key)
    if(!is.null(saved_enrichment)){
      scan$pathway_membership_audit<-saved_enrichment$audit
      enriched<-saved_enrichment$value
      .p2c_resume_event('whiteley_checkpoint','Reused completed enrichment')
    }else{
      if (is.null(membership)) membership <- fetch_pa_annotations()
      membership <- .scan_read_membership(membership)
      scan$pathway_membership_audit <- .p2c_membership_audit(membership,scan$candidate_genes,if(is.null(enrichment_args$minimum_size))5 else enrichment_args$minimum_size)
      if(!is.null(checkpoint_dir))set.seed(as.integer(Sys.getenv('P2C_RANDOM_SEED','1729'))+100000L)
      enriched <- do.call(pa_enrich_scan, utils::modifyList(
        list(scan = scan, membership = membership, curated = curated), enrichment_args
      ))
      if(!is.null(enrichment_path)) .p2c_resume_write(enrichment_path,list(key=checkpoint_key,value=enriched,audit=scan$pathway_membership_audit))
    }
  }
  .p2c_resume_pause(stop_file)
  .p2c_progress('reports','Preparing tables and figures')
  files <- do.call(pa_write_scan, utils::modifyList(
    list(scan = scan, enrichment = enriched, output_dir = output_dir), report_args
  ))
  .p2c_resume_pause(stop_file)
  structure(list(scan = scan, enrichment = enriched, files = files),
            class = "pa_scan_pipeline")
}
