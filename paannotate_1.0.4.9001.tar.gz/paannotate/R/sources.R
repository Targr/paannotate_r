.split_annotation_values <- function(x) {
  values <- trimws(unlist(strsplit(as.character(x), "[;|]", perl = TRUE)))
  unique(values[!is.na(values) & values != "" & values != "-"])
}

.pseudo_set_id <- function(x) {
  slug <- tolower(gsub("[^A-Za-z0-9]+", "_", trimws(x)))
  paste0("pseudocap_", gsub("^_|_$", "", slug))
}

.read_gff3 <- function(path) {
  raw <- utils::read.delim(path, header = FALSE, sep = "\t", quote = "",
                           comment.char = "#", stringsAsFactors = FALSE,
                           fill = TRUE, check.names = FALSE)
  if (ncol(raw) < 9L) stop("The GFF3 file does not have nine columns.", call. = FALSE)
  raw <- raw[, seq_len(9), drop = FALSE]
  names(raw) <- c("seqid", "source", "type", "start", "end", "score",
                  "strand", "phase", "attributes")
  attribute <- function(key) {
    pattern <- paste0("(?:^|;)", key, "=([^;]+)")
    value <- sub(paste0(".*", pattern, ".*"), "\\1", raw$attributes, perl = TRUE)
    value[!grepl(pattern, raw$attributes, perl = TRUE)] <- ""
    utils::URLdecode(value)
  }
  data.frame(
    locus_tag = ifelse(attribute("locus_tag") != "", attribute("locus_tag"),
                       ifelse(attribute("ID") != "", attribute("ID"),
                              attribute("Name"))),
    gene_name = attribute("Name"), product = attribute("product"),
    start = suppressWarnings(as.numeric(raw$start)),
    end = suppressWarnings(as.numeric(raw$end)),
    source = raw$source, type = raw$type,
    stringsAsFactors = FALSE, check.names = FALSE
  )
}

.first_matching_column <- function(data, patterns) {
  for (pattern in patterns) {
    hit <- grep(pattern, names(data), ignore.case = TRUE, value = TRUE)
    if (length(hit)) return(hit[1])
  }
  NA_character_
}

.parse_pseudocap <- function(path) {
  extension <- tolower(tools::file_ext(path))
  data <- if (extension %in% c("gff", "gff3")) {
    .read_gff3(path)
  } else {
    .read_raw_table(path)$data
  }
  locus_column <- .first_matching_column(data, c(
    "^locus[_ .-]*tag$", "^gene[_ .-]*id$", "^locus$", "^feature[_ .-]*id$"
  ))
  if (is.na(locus_column)) {
    counts <- vapply(data, function(x) sum(.looks_like_locus(x), na.rm = TRUE),
                     integer(1))
    if (max(counts, 0L) == 0L) {
      stop("No PAO1 locus-tag column was found in the PseudoCAP input.",
           call. = FALSE)
    }
    locus_column <- names(data)[which.max(counts)]
  }
  loci <- .exact_pao1_locus(data[[locus_column]])
  keep <- !is.na(loci)
  data <- data[keep, , drop = FALSE]
  loci <- loci[keep]
  if (!length(loci)) stop("No exact PAO1 locus tags were found.", call. = FALSE)

  name_column <- .first_matching_column(data, c("^gene[_ .-]*name$", "^name$"))
  product_column <- .first_matching_column(data, c("product", "description", "^function$"))
  start_column <- .first_matching_column(data, c("^start$", "start[_ .-]*position"))
  end_column <- .first_matching_column(data, c("^end$", "stop[_ .-]*position"))
  length_column <- .first_matching_column(data, c("gene[_ .-]*length", "^length$"))
  gene_length <- rep(NA_real_, nrow(data))
  if (!is.na(length_column)) {
    gene_length <- suppressWarnings(as.numeric(data[[length_column]]))
  } else if (!is.na(start_column) && !is.na(end_column)) {
    gene_length <- abs(suppressWarnings(as.numeric(data[[end_column]])) -
                         suppressWarnings(as.numeric(data[[start_column]]))) + 1
  }
  blank <- function(column) if (is.na(column)) rep("", nrow(data)) else
    as.character(data[[column]])
  basic <- data.frame(
    gene_id = loci,
    pseudocap_gene_name = blank(name_column),
    pseudocap_product = blank(product_column),
    gene_length = gene_length,
    stringsAsFactors = FALSE
  )
  groups <- split(seq_len(nrow(basic)), basic$gene_id)
  by_locus <- do.call(rbind, lapply(names(groups), function(locus) {
    index <- groups[[locus]]
    lengths <- basic$gene_length[index]
    data.frame(
      gene_id = locus,
      pseudocap_gene_name = .collapse_unique(basic$pseudocap_gene_name[index]),
      pseudocap_product = .collapse_unique(basic$pseudocap_product[index]),
      gene_length = if (any(is.finite(lengths))) lengths[which(is.finite(lengths))[1]]
      else NA_real_, stringsAsFactors = FALSE
    )
  }))
  rownames(by_locus) <- NULL

  source_column <- .first_matching_column(data, c("database[_ .-]*source", "^database$"))
  pathway_name <- .first_matching_column(data, c("pathway[_ .-]*name", "^pathway$"))
  pathway_id <- .first_matching_column(data, c("pathway[_ .-]*(id|accession)",
                                               "^accession$"))
  functional_columns <- grep(
    "pseudocap|functional[_ .-]*(class|category)|^category$|^class$",
    names(data), ignore.case = TRUE, value = TRUE
  )
  functional_columns <- setdiff(functional_columns,
                                c(locus_column, source_column, pathway_name,
                                  pathway_id, name_column, product_column))
  membership_rows <- list()
  cursor <- 0L
  if (!is.na(pathway_name)) {
    for (i in seq_len(nrow(data))) {
      source_value <- if (is.na(source_column)) "PseudoCAP" else
        as.character(data[[source_column]][i])
      if (!is.na(source_column) && (is.na(source_value) ||
          !grepl("PseudoCAP", source_value, ignore.case = TRUE))) next
      terms <- .split_annotation_values(data[[pathway_name]][i])
      for (term in terms) {
        cursor <- cursor + 1L
        identifier <- if (!is.na(pathway_id)) trimws(as.character(data[[pathway_id]][i]))
        else ""
        if (is.na(identifier) || identifier == "") identifier <- .pseudo_set_id(term)
        membership_rows[[cursor]] <- data.frame(
          gene_id = loci[i], database = "PseudoCAP", ontology = "PseudoCAP pathway",
          set_id = identifier, set_name = term, stringsAsFactors = FALSE
        )
      }
    }
  }
  for (column in functional_columns) {
    for (i in seq_len(nrow(data))) {
      for (term in .split_annotation_values(data[[column]][i])) {
        cursor <- cursor + 1L
        membership_rows[[cursor]] <- data.frame(
          gene_id = loci[i], database = "PseudoCAP",
          ontology = "PseudoCAP functional class",
          set_id = .pseudo_set_id(term), set_name = term,
          stringsAsFactors = FALSE
        )
      }
    }
  }
  membership <- if (length(membership_rows)) unique(do.call(rbind, membership_rows))
  else .empty_membership()
  structure(
    list(by_locus = by_locus, membership = membership,
         metadata = list(source_file = normalizePath(path, winslash = "/"),
                         imported_at = format(Sys.time(), tz = "UTC", usetz = TRUE),
                         rows = nrow(data), membership_rows = nrow(membership))),
    class = "pa_pseudocap"
  )
}

#' Import PseudoCAP/Pseudomonas Genome Database annotations
#'
#' Imports a PAO1 annotation CSV/TSV/GFF3 export or a URL to one. Gene length,
#' product information, PseudoCAP pathways, and functional classes are retained
#' when those fields are present. The official download page is
#' <https://pseudomonas.com/strain/download>.
#'
#' @param source Local CSV, TSV, TXT, GFF, or GFF3 file.
#' @param url Optional direct download URL used when `source` is omitted.
#' @param cache_dir Download/cache directory.
#' @param refresh Download the URL again even when cached.
#' @return A `pa_pseudocap` object with `by_locus`, `membership`, and metadata.
#' @export
fetch_pseudocap_annotations <- function(
    source = NULL, url = NULL,
    cache_dir = file.path(tools::R_user_dir("paannotate", "cache"), "PseudoCAP"),
    refresh = FALSE) {
  if (is.null(source) && is.null(url)) {
    stop("Supply a downloaded PseudoCAP/Pseudomonas Genome Database file or a direct URL. See https://pseudomonas.com/strain/download",
         call. = FALSE)
  }
  if (is.null(source)) {
    dir.create(path.expand(cache_dir), recursive = TRUE, showWarnings = FALSE)
    filename <- basename(sub("[?].*$", "", url))
    if (filename == "" || !grepl("[.]", filename)) filename <- "pseudocap.csv"
    source <- file.path(path.expand(cache_dir), filename)
    if (refresh || !file.exists(source)) {
      status <- utils::download.file(url, source, mode = "wb", quiet = TRUE)
      if (!identical(status, 0L)) stop("PseudoCAP download failed.", call. = FALSE)
    }
  }
  source <- path.expand(source)
  if (!file.exists(source)) stop("PseudoCAP input not found: ", source, call. = FALSE)
  .parse_pseudocap(source)
}

.numeric_expression_columns <- function(data, exclude = "gene_id") {
  candidates <- setdiff(names(data), exclude)
  keep <- vapply(candidates, function(column) {
    original <- data[[column]]
    converted <- suppressWarnings(as.numeric(original))
    nonblank <- !is.na(original) & trimws(as.character(original)) != ""
    sum(!is.na(converted) & nonblank) >= max(1, floor(0.8 * sum(nonblank)))
  }, logical(1))
  candidates[keep]
}

#' Import the Whiteley Lab PAO1 transcriptomic database
#'
#' Reads an exported count/TPM matrix and optional sample metadata. The result
#' includes per-gene reference summaries that can be added to an analysis.
#' Raw counts and TPMs are labelled separately and are never treated as
#' interchangeable inputs for differential-expression modelling.
#'
#' @param counts_file Count or TPM matrix file.
#' @param metadata_file Optional sample metadata file.
#' @param orientation Matrix orientation passed to [pa_read()].
#' @param gene_id Gene identifier column or `"auto"`.
#' @param data_type `"auto"`, `"raw_counts"`, or `"tpm"`.
#' @param sheet Excel sheet name or number.
#' @return A `pa_whiteley` object.
#' @export
import_whiteley <- function(
    counts_file, metadata_file = NULL,
    orientation = c("auto", "genes_in_rows", "genes_in_columns"),
    gene_id = "auto", data_type = c("auto", "raw_counts", "tpm"), sheet = 1) {
  orientation <- match.arg(orientation)
  data_type <- match.arg(data_type)
  imported <- pa_read(counts_file, orientation, gene_id, sheet = sheet)
  counts <- imported$data
  metadata <- if (is.null(metadata_file)) NULL else .read_raw_table(metadata_file, sheet)$data
  numeric_columns <- .numeric_expression_columns(counts)
  if (!is.null(metadata)) {
    sample_patterns <- paste(c(
      "^sample[_ .-]*id$", "^biosample[_ .-]*id$", "^sra[_ .-]*(number|run)$",
      "^run[_ .-]*(accession|id)$", "^sample$"
    ), collapse = "|")
    sample_candidates <- grep(sample_patterns, names(metadata), ignore.case = TRUE,
                              value = TRUE)
    if (length(sample_candidates)) {
      matches <- lapply(sample_candidates, function(column) {
        intersect(as.character(metadata[[column]]), numeric_columns)
      })
      best <- which.max(lengths(matches))
      if (length(matches[[best]])) numeric_columns <- matches[[best]]
    }
  }
  if (!length(numeric_columns)) stop("No numeric sample columns were found.", call. = FALSE)
  matrix_data <- lapply(counts[numeric_columns], function(x)
    suppressWarnings(as.numeric(x)))
  matrix_data <- as.data.frame(matrix_data, check.names = FALSE)
  if (data_type == "auto") {
    clue <- tolower(paste(counts_file, names(counts), collapse = " "))
    data_type <- if (grepl("tpm|transcripts per million", clue)) "tpm" else "raw_counts"
  }
  values <- as.matrix(matrix_data)
  reference <- data.frame(
    gene_id = .exact_pao1_locus(counts$gene_id),
    whiteley_median = apply(values, 1, stats::median, na.rm = TRUE),
    whiteley_mean = rowMeans(values, na.rm = TRUE),
    whiteley_detection_fraction = rowMeans(values > 0, na.rm = TRUE),
    whiteley_data_type = data_type,
    stringsAsFactors = FALSE
  )
  reference <- reference[!is.na(reference$gene_id), , drop = FALSE]
  structure(
    list(counts = counts, metadata = metadata, reference_by_locus = reference,
         data_type = data_type, sample_columns = numeric_columns,
         provenance = list(
           counts_file = normalizePath(path.expand(counts_file), winslash = "/"),
           metadata_file = if (is.null(metadata_file)) NA_character_ else
             normalizePath(path.expand(metadata_file), winslash = "/"),
           imported_at = format(Sys.time(), tz = "UTC", usetz = TRUE)
         )),
    class = "pa_whiteley"
  )
}

#' @export
print.pa_whiteley <- function(x, ...) {
  if (!is.null(x$profile_id)) {
    cat("Whiteley expression profile:", x$profile_id, "v", x$profile_version, "\n ")
    if (is.null(x$counts)) cat("metadata only;") else cat(nrow(x$counts), "features;")
    cat(nrow(x$metadata), "project-specific BioSamples;",
        length(unique(x$metadata$bioproject_id)), "project groups\n")
  } else {
    cat("Whiteley Lab reference:", nrow(x$reference_by_locus), "PAO1 genes;",
        length(x$sample_columns), "numeric columns; type =", x$data_type, "\n")
  }
  invisible(x)
}

#' Download a released Whiteley Lab transcriptomic dataset
#'
#' Downloads and unpacks the Whiteley Lab database archive. Because release
#' layouts can change, this returns a manifest rather than guessing which file
#' is counts versus metadata; pass the selected files to [import_whiteley()].
#'
#' @param cache_dir Destination directory.
#' @param refresh Download again when the archive already exists.
#' @param asset_url Direct release-asset URL. Defaults to the 2026-02-12 raw
#'   dataset published with database release v0.1.0.
#' @return A list containing archive, extraction directory, and file manifest.
#' @export
fetch_whiteley_release <- function(
    cache_dir = file.path(tools::R_user_dir("paannotate", "cache"), "Whiteley"),
    refresh = FALSE,
    asset_url = paste0(
      "https://github.com/thewhiteleylab/Pseudomonas_Aeruginosa_Database/",
      "releases/download/v0.1.0/2-12-26_rawdataset.zip")) {
  cache_dir <- path.expand(cache_dir)
  dir.create(cache_dir, recursive = TRUE, showWarnings = FALSE)
  archive <- file.path(cache_dir, basename(asset_url))
  if (refresh || !file.exists(archive) || file.info(archive)$size == 0) {
    status <- utils::download.file(asset_url, archive, mode = "wb", quiet = TRUE)
    if (!identical(status, 0L)) stop("Whiteley release download failed.", call. = FALSE)
  }
  extraction_dir <- file.path(cache_dir, tools::file_path_sans_ext(basename(archive)))
  dir.create(extraction_dir, recursive = TRUE, showWarnings = FALSE)
  utils::unzip(archive, exdir = extraction_dir)
  files <- list.files(extraction_dir, recursive = TRUE, full.names = TRUE)
  list(archive = normalizePath(archive, winslash = "/"),
       extraction_dir = normalizePath(extraction_dir, winslash = "/"),
       files = normalizePath(files, winslash = "/", mustWork = FALSE),
       source_url = asset_url)
}

.attach_whiteley_reference <- function(data, whiteley) {
  if (is.null(whiteley)) return(data)
  if (!inherits(whiteley, "pa_whiteley")) {
    stop("whiteley_reference must be created by import_whiteley().", call. = FALSE)
  }
  reference <- whiteley$reference_by_locus
  for (column in setdiff(names(reference), "gene_id")) {
    data[[column]] <- reference[[column]][match(data$pao1_locus, reference$gene_id)]
  }
  data
}
