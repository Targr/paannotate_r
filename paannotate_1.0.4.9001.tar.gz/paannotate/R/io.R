.read_raw_table <- function(source, sheet = 1) {
  if (is.data.frame(source)) {
    data <- source
    source_label <- "in-memory data frame"
  } else {
    source <- path.expand(source)
    if (!file.exists(source)) stop("Input file not found: ", source, call. = FALSE)
    extension <- tolower(tools::file_ext(source))
    data <- switch(
      extension,
      csv = utils::read.csv(source, stringsAsFactors = FALSE,
                            check.names = FALSE),
      tsv = utils::read.delim(source, stringsAsFactors = FALSE,
                              check.names = FALSE),
      txt = utils::read.delim(source, stringsAsFactors = FALSE,
                              check.names = FALSE),
      xls = as.data.frame(
        readxl::read_excel(source, sheet = sheet, .name_repair = "minimal"),
        stringsAsFactors = FALSE
      ),
      xlsx = as.data.frame(
        readxl::read_excel(source, sheet = sheet, .name_repair = "minimal"),
        stringsAsFactors = FALSE
      ),
      stop("Unsupported input format '.", extension,
           "'. Use CSV, TSV, TXT, XLS, or XLSX.", call. = FALSE)
    )
    source_label <- normalizePath(source, winslash = "/", mustWork = TRUE)
  }
  if (!nrow(data)) stop("The input has no data rows.", call. = FALSE)
  if (!ncol(data)) stop("The input has no columns.", call. = FALSE)
  list(data = data, source = source_label)
}

.looks_like_locus <- function(x) {
  grepl("^PA[0-9]{4}([A-Z]|\\.[0-9]+)?$", toupper(trimws(as.character(x))))
}

.detect_orientation <- function(data) {
  locus_headers <- sum(.looks_like_locus(names(data)))
  locus_columns <- vapply(data, function(x) sum(.looks_like_locus(x), na.rm = TRUE),
                          integer(1))
  field_words <- gsub("[^a-z0-9]", "", tolower(as.character(data[[1]])))
  recognizable_fields <- sum(field_words %in% c(
    "geneid", "locus", "locustag", "log2foldchange", "log2fc", "logfc",
    "pvalue", "pval", "padj", "fdr", "qvalue"
  ), na.rm = TRUE)
  if (locus_headers >= 2L && (recognizable_fields >= 1L ||
                             locus_headers > max(locus_columns))) {
    return(list(value = "genes_in_columns", confidence = "high",
                reason = paste(locus_headers, "PAO1 locus tags are column names")))
  }
  if (max(locus_columns, 0L) >= 2L) {
    return(list(value = "genes_in_rows", confidence = "high",
                reason = "PAO1 locus tags occur down a column"))
  }
  list(value = "genes_in_rows", confidence = "low",
       reason = "no strong transposed-table signal; conventional rows assumed")
}

.transpose_gene_table <- function(data) {
  labels <- trimws(as.character(data[[1]]))
  labels[is.na(labels) | labels == ""] <- paste0("field_", which(is.na(labels) |
                                                               labels == ""))
  labels <- make.unique(labels, sep = "_")
  gene_ids <- names(data)[-1]
  if (!length(gene_ids)) stop("A transposed table needs at least two columns.",
                              call. = FALSE)
  answer <- data.frame(gene_id = gene_ids, stringsAsFactors = FALSE,
                       check.names = FALSE)
  for (i in seq_along(labels)) {
    answer[[labels[i]]] <- unname(unlist(data[i, -1, drop = FALSE],
                                         use.names = FALSE))
  }
  answer
}

.apply_column_map <- function(data, column_map) {
  if (is.null(column_map)) return(data)
  if (is.list(column_map)) column_map <- unlist(column_map, use.names = TRUE)
  if (is.null(names(column_map)) || any(names(column_map) == "")) {
    stop("column_map must be named, for example c(padj = 'FDR').",
         call. = FALSE)
  }
  missing <- setdiff(unname(column_map), names(data))
  if (length(missing)) {
    stop("column_map refers to missing columns: ", paste(missing, collapse = ", "),
         call. = FALSE)
  }
  for (canonical in names(column_map)) {
    actual <- unname(column_map[[canonical]])
    names(data)[names(data) == actual] <- canonical
  }
  data
}

.common_column_aliases <- function(data) {
  aliases <- list(
    gene_id = c("geneid", "locus", "locustag", "locusid", "paolocus"),
    log2FoldChange = c("log2foldchange", "log2fc", "logfc"),
    pvalue = c("pvalue", "pval", "p"),
    padj = c("padj", "adjustedpvalue", "adjpvalue", "fdr", "qvalue")
  )
  normalized <- gsub("[^a-z0-9]", "", tolower(names(data)))
  renamed <- character()
  for (canonical in names(aliases)) {
    if (canonical %in% names(data)) next
    hit <- which(normalized %in% aliases[[canonical]])
    if (length(hit) == 1L) {
      renamed <- c(renamed, paste0(names(data)[hit], " -> ", canonical))
      names(data)[hit] <- canonical
      normalized[hit] <- tolower(canonical)
    }
  }
  list(data = data, renamed = renamed)
}

.detect_gene_id_column <- function(data, gene_id = "auto") {
  if (!identical(gene_id, "auto")) {
    if (!gene_id %in% names(data)) {
      stop("Gene identifier column not found: ", gene_id, call. = FALSE)
    }
    return(gene_id)
  }
  preferred <- c("gene_id", "locus_tag", "locus", "PAO1_locus")
  hit <- preferred[preferred %in% names(data)]
  if (length(hit)) return(hit[1])
  counts <- vapply(data, function(x) sum(.looks_like_locus(x), na.rm = TRUE),
                   integer(1))
  if (max(counts, 0L) > 0L) return(names(data)[which.max(counts)])
  names(data)[1]
}

#' Read and normalize a paannotate input table
#'
#' Reads delimited text, Excel, or an in-memory data frame. It can detect and
#' transpose files whose genes are columns, apply an explicit column map, and
#' standardize a detected gene identifier column to `gene_id`.
#'
#' @param source A file path or data frame.
#' @param orientation `"auto"`, `"genes_in_rows"`, or `"genes_in_columns"`.
#' @param gene_id Gene identifier column, or `"auto"`.
#' @param column_map Named character vector whose names are desired canonical
#'   names and whose values are names in the input.
#' @param sheet Excel sheet name or number.
#' @param standardize_gene_id Rename the detected identifier to `gene_id`.
#' @return A `pa_input` object containing `data`, `audit`, and `provenance`.
#' @export
pa_read <- function(source, orientation = c("auto", "genes_in_rows",
                                            "genes_in_columns"),
                    gene_id = "auto", column_map = NULL, sheet = 1,
                    standardize_gene_id = TRUE) {
  orientation <- match.arg(orientation)
  raw <- .read_raw_table(source, sheet)
  detected <- .detect_orientation(raw$data)
  used <- if (orientation == "auto") detected$value else orientation
  data <- raw$data
  if (used == "genes_in_columns") data <- .transpose_gene_table(data)
  data <- .apply_column_map(data, column_map)
  aliases <- .common_column_aliases(data)
  data <- aliases$data
  id_column <- .detect_gene_id_column(data, gene_id)
  original_id_column <- id_column
  if (standardize_gene_id && id_column != "gene_id") {
    names(data)[names(data) == id_column] <- "gene_id"
    id_column <- "gene_id"
  }
  audit <- data.frame(
    check = c("source", "orientation", "orientation confidence",
              "orientation reason", "gene identifier", "renamed aliases",
              "dimensions"),
    value = c(raw$source, used,
              if (orientation == "auto") detected$confidence else "user supplied",
              detected$reason, original_id_column,
              if (length(aliases$renamed)) paste(aliases$renamed, collapse = "; ")
              else "none",
              paste(nrow(data), "genes x", ncol(data), "columns")),
    stringsAsFactors = FALSE
  )
  structure(
    list(data = data, audit = audit,
         provenance = list(source = raw$source, orientation = used,
                           gene_id_column = id_column)),
    class = "pa_input"
  )
}

#' @export
print.pa_input <- function(x, ...) {
  cat("paannotate input:\n")
  print(x$audit, row.names = FALSE)
  invisible(x)
}

#' Inspect a file before analysis
#'
#' @inheritParams pa_read
#' @return Invisibly, the same `pa_input` object returned by [pa_read()].
#' @export
pa_check_input <- function(source, orientation = c("auto", "genes_in_rows",
                                                   "genes_in_columns"),
                           gene_id = "auto", column_map = NULL, sheet = 1) {
  value <- pa_read(source, orientation, gene_id, column_map, sheet)
  print(value)
  invisible(value)
}

.handle_duplicate_ids <- function(data, id_column, action, label) {
  values <- toupper(trimws(as.character(data[[id_column]])))
  duplicated_values <- unique(values[duplicated(values) & !is.na(values) & values != ""])
  if (length(duplicated_values) && action == "error") {
    stop(label, " contains duplicate gene identifiers (for example ",
         duplicated_values[1], "). Set duplicate_action = 'first' only if this is intentional.",
         call. = FALSE)
  }
  if (length(duplicated_values)) data <- data[!duplicated(values), , drop = FALSE]
  data$.pa_join_key <- toupper(trimws(as.character(data[[id_column]])))
  data
}

#' Join expression and differential-statistics files by gene
#'
#' This function performs a checked key-based join, not a position-based
#' concatenation, so different row orders cannot silently attach statistics to
#' the wrong genes.
#'
#' @param expression_file Expression file or data frame.
#' @param statistics_file P-value/fold-change file or data frame.
#' @param expression_orientation,statistics_orientation Orientation passed to
#'   [pa_read()].
#' @param expression_gene_id,statistics_gene_id Identifier columns or `"auto"`.
#' @param expression_column_map,statistics_column_map Optional named maps.
#' @param join `"inner"`, `"left"`, or `"full"`.
#' @param duplicate_action `"error"` or `"first"`.
#' @param minimum_match Minimum fraction of expression genes that must occur in
#'   the statistics file.
#' @param output_file Optional `.csv` or `.tsv` output path.
#' @param sheet Excel sheet name or number.
#' @return A `pa_input` containing the joined table and a join audit.
#' @export
pa_combine <- function(
    expression_file, statistics_file,
    expression_orientation = c("auto", "genes_in_rows", "genes_in_columns"),
    statistics_orientation = c("auto", "genes_in_rows", "genes_in_columns"),
    expression_gene_id = "auto", statistics_gene_id = "auto",
    expression_column_map = NULL, statistics_column_map = NULL,
    join = c("inner", "left", "full"),
    duplicate_action = c("error", "first"), minimum_match = 0.5,
    output_file = NULL, sheet = 1) {
  expression_orientation <- match.arg(expression_orientation)
  statistics_orientation <- match.arg(statistics_orientation)
  join <- match.arg(join)
  duplicate_action <- match.arg(duplicate_action)
  if (!is.numeric(minimum_match) || length(minimum_match) != 1L ||
      minimum_match < 0 || minimum_match > 1) {
    stop("minimum_match must be between zero and one.", call. = FALSE)
  }
  expression <- pa_read(expression_file, expression_orientation,
                        expression_gene_id, expression_column_map, sheet)$data
  statistics <- pa_read(statistics_file, statistics_orientation,
                        statistics_gene_id, statistics_column_map, sheet)$data
  expression <- .handle_duplicate_ids(expression, "gene_id", duplicate_action,
                                      "Expression input")
  statistics <- .handle_duplicate_ids(statistics, "gene_id", duplicate_action,
                                      "Statistics input")
  matched <- sum(expression$.pa_join_key %in% statistics$.pa_join_key &
                 expression$.pa_join_key != "")
  match_rate <- matched / nrow(expression)
  if (match_rate < minimum_match) {
    stop("Only ", round(100 * match_rate, 1),
         "% of expression rows matched statistics rows; minimum_match is ",
         round(100 * minimum_match, 1), "%. Check identifiers and orientation.",
         call. = FALSE)
  }
  all_x <- join %in% c("left", "full")
  all_y <- join == "full"
  shared <- intersect(setdiff(names(expression), c("gene_id", ".pa_join_key")),
                      setdiff(names(statistics), c("gene_id", ".pa_join_key")))
  if (length(shared)) {
    names(statistics)[match(shared, names(statistics))] <- paste0(shared, "_statistics")
  }
  statistics$.pa_statistics_gene_id <- statistics$gene_id
  statistics$gene_id <- NULL
  joined <- merge(expression, statistics, by = ".pa_join_key", all.x = all_x,
                  all.y = all_y, sort = FALSE)
  missing_gene_id <- is.na(joined$gene_id) | joined$gene_id == ""
  joined$gene_id[missing_gene_id] <- joined$.pa_statistics_gene_id[missing_gene_id]
  joined$.pa_statistics_gene_id <- NULL
  joined$.pa_join_key <- NULL
  joined <- joined[c("gene_id", setdiff(names(joined), "gene_id"))]
  audit <- data.frame(
    check = c("expression rows", "statistics rows", "matched expression rows",
              "match rate", "join", "output rows", "overlapping columns renamed"),
    value = c(nrow(expression), nrow(statistics), matched,
              paste0(round(100 * match_rate, 1), "%"), join, nrow(joined),
              if (length(shared)) paste(paste0(shared, "_statistics"), collapse = "; ")
              else "none"),
    stringsAsFactors = FALSE
  )
  if (!is.null(output_file)) {
    extension <- tolower(tools::file_ext(output_file))
    if (extension == "csv") {
      utils::write.csv(joined, output_file, row.names = FALSE)
    } else if (extension %in% c("tsv", "txt")) {
      utils::write.table(joined, output_file, sep = "\t", row.names = FALSE,
                         quote = FALSE)
    } else stop("output_file must end in .csv, .tsv, or .txt.", call. = FALSE)
  }
  structure(list(data = joined, audit = audit,
                 provenance = list(expression = expression_file,
                                   statistics = statistics_file,
                                   join = join, match_rate = match_rate)),
            class = "pa_input")
}
