.read_expression_file <- function(input_file, sheet = 1) {
  extension <- tolower(tools::file_ext(input_file))
  data <- switch(
    extension,
    csv = utils::read.csv(
      input_file, stringsAsFactors = FALSE, check.names = FALSE
    ),
    tsv = utils::read.delim(
      input_file, stringsAsFactors = FALSE, check.names = FALSE
    ),
    txt = utils::read.delim(
      input_file, stringsAsFactors = FALSE, check.names = FALSE
    ),
    xls = as.data.frame(
      readxl::read_excel(input_file, sheet = sheet, .name_repair = "minimal"),
      stringsAsFactors = FALSE
    ),
    xlsx = as.data.frame(
      readxl::read_excel(input_file, sheet = sheet, .name_repair = "minimal"),
      stringsAsFactors = FALSE
    ),
    stop(
      "Unsupported input format '.", extension,
      "'. Use CSV, TSV, TXT, XLS, or XLSX.", call. = FALSE
    )
  )
  if (!nrow(data)) stop("The input file has no data rows.", call. = FALSE)
  data
}

.coerce_numeric <- function(data, columns) {
  for (column in columns) {
    original <- data[[column]]
    converted <- suppressWarnings(as.numeric(original))
    invalid <- is.na(converted) & !is.na(original) &
      trimws(as.character(original)) != ""
    if (any(invalid)) {
      stop(
        "Column '", column, "' contains nonnumeric data. Example: ",
        as.character(original[which(invalid)[1]]), call. = FALSE
      )
    }
    data[[column]] <- converted
  }
  data
}

.fold_change_direction <- function(data, group_a_samples, group_b_samples,
                                   group_a_label, group_b_label) {
  mean_a <- rowMeans(data[group_a_samples], na.rm = TRUE)
  mean_b <- rowMeans(data[group_b_samples], na.rm = TRUE)
  rough_a_over_b <- log2((mean_a + 0.5) / (mean_b + 0.5))
  usable <- is.finite(data$log2FoldChange) & is.finite(rough_a_over_b) &
    data$log2FoldChange != 0 & rough_a_over_b != 0
  if (!any(usable)) {
    stop("The fold-change direction could not be checked.", call. = FALSE)
  }
  agreement <- mean(
    sign(data$log2FoldChange[usable]) == sign(rough_a_over_b[usable])
  )
  if (agreement >= 0.75) {
    positive_label <- group_a_label
    negative_label <- group_b_label
    positive_is_group_a <- TRUE
  } else if (agreement <= 0.25) {
    positive_label <- group_b_label
    negative_label <- group_a_label
    positive_is_group_a <- FALSE
  } else {
    stop(
      "Fold-change direction is ambiguous: agreement with ",
      group_a_label, " / ", group_b_label, " expression means is ",
      round(agreement, 3), ".", call. = FALSE
    )
  }
  list(
    mean_a = mean_a, mean_b = mean_b, agreement = agreement,
    positive_label = positive_label, negative_label = negative_label,
    positive_is_group_a = positive_is_group_a
  )
}

.empty_enrichment <- function() {
  data.frame(
    group = character(), database = character(), ontology = character(),
    set_id = character(), set_name = character(),
    annotated_background = integer(), selected_in_background = integer(),
    set_size = integer(), selected_in_set = integer(),
    overlap_genes = character(), odds_ratio = numeric(),
    pvalue = numeric(), padj = numeric(),
    statistically_supported = logical(), stringsAsFactors = FALSE
  )
}

.enrich_one_ontology <- function(membership, selected_genes, group_label,
                                 minimum_size, maximum_size) {
  background <- unique(membership$gene_id)
  selected <- intersect(unique(selected_genes), background)
  sets <- unique(membership[c("set_id", "set_name")])
  rows <- lapply(seq_len(nrow(sets)), function(i) {
    members <- unique(
      membership$gene_id[membership$set_id == sets$set_id[i]]
    )
    set_size <- length(members)
    if (set_size < minimum_size || set_size > maximum_size) return(NULL)
    a <- length(intersect(selected, members))
    b <- length(setdiff(selected, members))
    c_value <- length(setdiff(members, selected))
    d <- length(setdiff(background, union(selected, members)))
    test <- stats::fisher.test(
      matrix(c(a, b, c_value, d), nrow = 2, byrow = TRUE),
      alternative = "greater"
    )
    data.frame(
      group = group_label,
      database = membership$database[1],
      ontology = membership$ontology[1],
      set_id = sets$set_id[i],
      set_name = sets$set_name[i],
      annotated_background = length(background),
      selected_in_background = length(selected),
      set_size = set_size,
      selected_in_set = a,
      overlap_genes = paste(sort(intersect(selected, members)),
                            collapse = "; "),
      odds_ratio = if (length(test$estimate)) {
        unname(test$estimate)
      } else {
        NA_real_
      },
      pvalue = test$p.value,
      stringsAsFactors = FALSE
    )
  })
  rows <- Filter(Negate(is.null), rows)
  if (!length(rows)) return(NULL)
  result <- do.call(rbind, rows)
  result$padj <- stats::p.adjust(result$pvalue, method = "BH")
  result$statistically_supported <- result$padj < 0.05 &
    result$selected_in_set > 0
  result
}

.run_group_enrichment <- function(membership, tested_loci, selected_genes,
                                  group_label, minimum_size, maximum_size) {
  membership <- unique(membership[
    membership$gene_id %in% tested_loci,
    c("gene_id", "database", "ontology", "set_id", "set_name"),
    drop = FALSE
  ])
  if (!nrow(membership)) return(.empty_enrichment())
  strata <- split(
    membership,
    interaction(membership$database, membership$ontology, drop = TRUE)
  )
  results <- lapply(
    strata, .enrich_one_ontology,
    selected_genes = selected_genes,
    group_label = group_label,
    minimum_size = minimum_size,
    maximum_size = maximum_size
  )
  results <- Filter(Negate(is.null), results)
  if (!length(results)) return(.empty_enrichment())
  result <- do.call(rbind, results)
  rownames(result) <- NULL
  result[
    order(
      !result$statistically_supported, result$padj, result$pvalue,
      -result$selected_in_set
    ),
    , drop = FALSE
  ]
}

.coverage_table <- function(data) {
  total <- nrow(data)
  counts <- c(
    input_rows = total,
    exact_pao1_locus = sum(!is.na(data$pao1_locus)),
    kegg = sum(data$has_kegg_annotation),
    uniprot = sum(data$has_uniprot_annotation),
    go = sum(data$has_go_annotation),
    pseudocap = sum(data$has_pseudocap_annotation),
    whiteley_reference = if ("whiteley_median" %in% names(data)) {
      sum(!is.na(data$whiteley_median))
    } else 0,
    any_external_annotation = sum(data$has_external_annotation)
  )
  data.frame(
    annotation = names(counts),
    rows = as.integer(counts),
    total_rows = total,
    percent = 100 * as.integer(counts) / total,
    stringsAsFactors = FALSE
  )
}

.summary_patterns <- function(group_a_enrichment, group_b_enrichment,
                              top_patterns) {
  combined <- rbind(group_a_enrichment, group_b_enrichment)
  if (!nrow(combined)) return(.empty_enrichment())
  groups <- split(combined, combined$group)
  rows <- lapply(groups, function(data) {
    data <- data[
      order(
        !data$statistically_supported, data$padj, data$pvalue,
        -data$selected_in_set
      ),
      , drop = FALSE
    ]
    utils::head(data, top_patterns)
  })
  result <- do.call(rbind, rows)
  rownames(result) <- NULL
  result
}

.top_genes <- function(significant, top_genes, id_col, name_col,
                       description_col) {
  if (!nrow(significant)) return(significant)
  significant <- significant[
    order(-abs(significant$log2FoldChange), significant$padj),
    , drop = FALSE
  ]
  columns <- unique(c(
    id_col, name_col, description_col, "pao1_locus", "gene_label",
    "direction", "mean_group_a", "mean_group_b", "log2FoldChange",
    "pvalue", "padj", "kegg_pathway_names", "uniprot_protein_name",
    "go_biological_process", "go_molecular_function",
    "go_cellular_component", "uniprot_function", "pseudocap_gene_name",
    "pseudocap_product", "gene_length", "whiteley_median",
    "whiteley_detection_fraction", "whiteley_data_type"
  ))
  columns <- columns[columns %in% names(significant)]
  utils::head(significant[columns], top_genes)
}

.write_outputs <- function(result, output_dir) {
  folders <- file.path(
    output_dir, c("summary", "genes", "statistics")
  )
  for (folder in folders) {
    dir.create(folder, recursive = TRUE, showWarnings = FALSE)
  }
  files <- list(
    "summary/comparison_summary.csv" = result$comparison_summary,
    "summary/group_annotation_patterns.csv" = result$group_patterns,
    "summary/top_differential_genes.csv" = result$top_differential_genes,
    "genes/all_genes_annotated.csv" = result$all_genes,
    "genes/significant_genes.csv" = result$significant_genes,
    "statistics/annotation_coverage.csv" = result$annotation_coverage,
    "statistics/group_a_enrichment.csv" = result$group_a_enrichment,
    "statistics/group_b_enrichment.csv" = result$group_b_enrichment
  )
  if (!is.null(result$bias_aware_enrichment)) {
    files[["statistics/bias_aware_enrichment.csv"]] <-
      result$bias_aware_enrichment$results
  }
  if (!is.null(result$ranked_enrichment)) {
    files[["statistics/ranked_enrichment.csv"]] <-
      result$ranked_enrichment$results
    files[["statistics/ranked_genes.csv"]] <-
      result$ranked_enrichment$ranked_genes
  }
  for (relative_path in names(files)) {
    utils::write.csv(
      files[[relative_path]], file.path(output_dir, relative_path),
      row.names = FALSE
    )
  }
  utils::write.csv(
    result$replicate_correlations,
    file.path(output_dir, "statistics", "replicate_correlations.csv"),
    row.names = TRUE
  )
}

#' Analyze a PAO1 differential-expression file
#'
#' Reads a CSV, TSV, TXT, XLS, or XLSX file; checks the supplied fold-change
#' direction; annotates exact PAO1 locus tags using KEGG, UniProt, and GO; and
#' summarizes significant genes and annotation patterns for both groups.
#'
#' @param input_file Input CSV, TSV, TXT, XLS, or XLSX file.
#' @param group_a_samples Expression columns belonging to Group A.
#' @param group_b_samples Expression columns belonging to Group B.
#' @param group_a_label Plain-language name for Group A.
#' @param group_b_label Plain-language name for Group B.
#' @param output_dir Output directory. Defaults to `<input>_analysis`.
#' @param sheet Excel sheet name or number.
#' @param gene_id_col PA locus identifier column.
#' @param gene_name_col Gene-name column; created blank if absent.
#' @param gene_description_col Description column; created blank if absent.
#' @param cache_dir Shared annotation cache.
#' @param refresh_annotations Force fresh KEGG and UniProt downloads.
#' @param padj_cutoff Adjusted P-value threshold for genes.
#' @param log2fc_cutoff Absolute log2 fold-change threshold for genes.
#' @param enrichment_padj_cutoff Adjusted P-value threshold for patterns.
#' @param minimum_gene_set_size Minimum enrichment term size.
#' @param maximum_gene_set_size Maximum enrichment term size.
#' @param top_genes Number of largest significant differences in the summary.
#' @param top_patterns Number of annotation patterns per group in the summary.
#' @param orientation Input orientation; see [pa_read()].
#' @param column_map Optional input-column mapping; see [pa_read()].
#' @param pseudocap_file,pseudocap_url Optional PseudoCAP annotation source.
#' @param whiteley_reference Optional object from [import_whiteley()].
#' @param bias_adjust Run goseq-style selection-bias-aware enrichment.
#' @param bias_type,bias_col Bias definition passed to [pa_enrich_bias()].
#' @param ranked_method Optional `"camera_pr"` or `"fgsea"` full-ranked test.
#' @param rank_statistic_col Ranking statistic passed to [pa_enrich_ranked()].
#' @param inter_gene_cor Inter-gene correlation used by CAMERA.
#' @return A list containing the tables written to `output_dir`.
#' @export
analyze_pa_csv <- function(
    input_file,
    group_a_samples,
    group_b_samples,
    group_a_label = "Group A",
    group_b_label = "Group B",
    output_dir = NULL,
    sheet = 1,
    gene_id_col = "gene_id",
    gene_name_col = "gene_name",
    gene_description_col = "gene_description",
    cache_dir = file.path(tools::R_user_dir("paannotate", "cache"), "PAO1"),
    refresh_annotations = FALSE,
    padj_cutoff = 0.05,
    log2fc_cutoff = 1,
    enrichment_padj_cutoff = 0.05,
    minimum_gene_set_size = 3,
    maximum_gene_set_size = 500,
    top_genes = 25,
    top_patterns = 20,
    orientation = c("auto", "genes_in_rows", "genes_in_columns"),
    column_map = NULL,
    pseudocap_file = NULL,
    pseudocap_url = NULL,
    whiteley_reference = NULL,
    bias_adjust = FALSE,
    bias_type = c("gene_length", "mean_expression", "custom"),
    bias_col = NULL,
    ranked_method = NULL,
    rank_statistic_col = "auto",
    inter_gene_cor = 0.01) {
  orientation <- match.arg(orientation)
  bias_type <- match.arg(bias_type)
  input_is_file <- is.character(input_file) && length(input_file) == 1L
  if (input_is_file) {
    input_file <- path.expand(input_file)
    if (!file.exists(input_file)) {
      stop("Input file not found: ", input_file, call. = FALSE)
    }
    input_label <- normalizePath(input_file, winslash = "/")
  } else if (inherits(input_file, "pa_input")) {
    input_label <- "pa_input object"
  } else if (is.data.frame(input_file)) {
    input_label <- "in-memory data frame"
  } else stop("input_file must be a path, data frame, or pa_input.", call. = FALSE)
  if (is.null(output_dir)) {
    output_dir <- if (input_is_file) file.path(
        dirname(input_file),
        paste0(tools::file_path_sans_ext(basename(input_file)), "_analysis")
      ) else file.path(getwd(), "paannotate_analysis")
  }
  output_dir <- path.expand(output_dir)
  if (!length(group_a_samples) || !length(group_b_samples) ||
      length(intersect(group_a_samples, group_b_samples))) {
    stop("Sample groups must be nonempty and must not overlap.",
         call. = FALSE)
  }
  imported <- if (inherits(input_file, "pa_input")) input_file else
    pa_read(input_file, orientation = orientation, gene_id = gene_id_col,
            column_map = column_map, sheet = sheet)
  data <- imported$data
  gene_id_col <- "gene_id"
  required <- c(
    gene_id_col, "log2FoldChange", "pvalue", "padj",
    group_a_samples, group_b_samples
  )
  missing <- setdiff(required, names(data))
  if (length(missing)) {
    stop("Missing required columns: ", paste(missing, collapse = ", "),
         call. = FALSE)
  }
  data$original_row_number <- seq_len(nrow(data))
  data <- .coerce_numeric(
    data,
    unique(c(
      group_a_samples, group_b_samples,
      "log2FoldChange", "pvalue", "padj"
    ))
  )
  expression_columns <- data[c(group_a_samples, group_b_samples)]
  if (any(vapply(
    expression_columns, function(x) any(x < 0, na.rm = TRUE), logical(1)
  ))) {
    stop("Expression columns contain negative values.", call. = FALSE)
  }
  direction <- .fold_change_direction(
    data, group_a_samples, group_b_samples,
    group_a_label, group_b_label
  )
  data$mean_group_a <- direction$mean_a
  data$mean_group_b <- direction$mean_b
  data$direction <- ifelse(
    data$log2FoldChange > 0, direction$positive_label,
    ifelse(data$log2FoldChange < 0, direction$negative_label, "No change")
  )
  data$significant <- !is.na(data$padj) & data$padj < padj_cutoff &
    !is.na(data$log2FoldChange) &
    abs(data$log2FoldChange) >= log2fc_cutoff
  annotations <- .fetch_annotations(
    cache_dir, refresh_annotations, pseudocap_file, pseudocap_url
  )
  data <- .annotate_genes(
    data, annotations, gene_id_col, gene_name_col, gene_description_col
  )
  data <- .attach_whiteley_reference(data, whiteley_reference)
  significant <- data[data$significant, , drop = FALSE]
  significant <- significant[
    order(significant$padj, -abs(significant$log2FoldChange)),
    , drop = FALSE
  ]
  if (direction$positive_is_group_a) {
    group_a_rows <- data$significant & data$log2FoldChange > 0
    group_b_rows <- data$significant & data$log2FoldChange < 0
  } else {
    group_a_rows <- data$significant & data$log2FoldChange < 0
    group_b_rows <- data$significant & data$log2FoldChange > 0
  }
  tested_loci <- unique(data$pao1_locus[!is.na(data$pao1_locus)])
  group_a_loci <- unique(data$pao1_locus[group_a_rows &
                                           !is.na(data$pao1_locus)])
  group_b_loci <- unique(data$pao1_locus[group_b_rows &
                                           !is.na(data$pao1_locus)])
  group_a_enrichment <- .run_group_enrichment(
    annotations$membership, tested_loci, group_a_loci, group_a_label,
    minimum_gene_set_size, maximum_gene_set_size
  )
  group_b_enrichment <- .run_group_enrichment(
    annotations$membership, tested_loci, group_b_loci, group_b_label,
    minimum_gene_set_size, maximum_gene_set_size
  )
  group_a_enrichment$statistically_supported <-
    group_a_enrichment$padj < enrichment_padj_cutoff &
    group_a_enrichment$selected_in_set > 0
  group_b_enrichment$statistically_supported <-
    group_b_enrichment$padj < enrichment_padj_cutoff &
    group_b_enrichment$selected_in_set > 0
  coverage <- .coverage_table(data)
  summary <- data.frame(
    input_file = input_label,
    group_a = group_a_label,
    group_a_samples = paste(group_a_samples, collapse = "; "),
    group_b = group_b_label,
    group_b_samples = paste(group_b_samples, collapse = "; "),
    positive_log2fc_means = direction$positive_label,
    sign_agreement_with_group_a_over_group_b = direction$agreement,
    total_genes = nrow(data),
    significant_genes = sum(data$significant),
    significant_higher_in_group_a = sum(group_a_rows),
    significant_higher_in_group_b = sum(group_b_rows),
    annotated_genes = sum(data$has_external_annotation),
    supported_patterns_group_a = sum(
      group_a_enrichment$statistically_supported
    ),
    supported_patterns_group_b = sum(
      group_b_enrichment$statistically_supported
    ),
    padj_cutoff = padj_cutoff,
    absolute_log2fc_cutoff = log2fc_cutoff,
    enrichment_padj_cutoff = enrichment_padj_cutoff,
    stringsAsFactors = FALSE
  )
  correlations <- stats::cor(
    log2(as.matrix(expression_columns) + 1),
    method = "spearman", use = "pairwise.complete.obs"
  )
  result <- list(
    comparison_summary = summary,
    group_patterns = .summary_patterns(
      group_a_enrichment, group_b_enrichment, top_patterns
    ),
    top_differential_genes = .top_genes(
      significant, top_genes, gene_id_col, gene_name_col,
      gene_description_col
    ),
    all_genes = data[order(data$original_row_number), , drop = FALSE],
    significant_genes = significant,
    annotation_coverage = coverage,
    group_a_enrichment = group_a_enrichment,
    group_b_enrichment = group_b_enrichment,
    replicate_correlations = correlations,
    input_audit = imported$audit,
    annotation_membership = annotations$membership,
    annotation_provenance = list(
      pseudocap = annotations$pseudocap_metadata,
      whiteley = if (is.null(whiteley_reference)) NULL else
        whiteley_reference$provenance
    )
  )
  result$bias_aware_enrichment <- if (isTRUE(bias_adjust)) {
    pa_enrich_bias(
      data, annotations, gene_id_col = "pao1_locus", bias = bias_type,
      bias_col = bias_col, expression_cols = c(group_a_samples, group_b_samples),
      padj_cutoff = padj_cutoff, log2fc_cutoff = log2fc_cutoff
    )
  } else NULL
  result$ranked_enrichment <- if (!is.null(ranked_method) &&
                                  !identical(ranked_method, "none")) {
    pa_enrich_ranked(
      data, annotations, method = ranked_method,
      gene_id_col = "pao1_locus", statistic_col = rank_statistic_col,
      inter_gene_cor = inter_gene_cor,
      minimum_size = minimum_gene_set_size,
      maximum_size = maximum_gene_set_size
    )
  } else NULL
  .write_outputs(result, output_dir)
  invisible(result)
}
