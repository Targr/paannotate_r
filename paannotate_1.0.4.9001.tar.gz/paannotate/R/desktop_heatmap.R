# Shared figure renderer. Source values and identifiers are never styled in place.
.p2c_render_heatmap <- function(source, style, base_path) {
  `%or%` <- function(a,b) if(is.null(a) || !length(a)) b else a
  numeric_cell <- function(v){
    if(is.null(v)||!length(v))return(NA_real_)
    if(length(v)!=1L||is.list(v)||is.logical(v))stop("Heatmap cells must be single numbers or missing values.")
    answer<-suppressWarnings(as.numeric(v))
    if(length(answer)!=1L)stop("Heatmap cells must be single numbers or missing values.")
    if(is.finite(answer))answer else NA_real_
  }
  m <- do.call(rbind,lapply(source$values,function(x)vapply(x,numeric_cell,numeric(1))))
  rownames(m) <- unlist(source$row_ids);colnames(m) <- unlist(source$column_ids)
  q <- NULL
  if(!is.null(source$adjusted_p)){
    q <- do.call(rbind,lapply(source$adjusted_p,function(x)vapply(x,numeric_cell,numeric(1))))
    if(!identical(dim(q),dim(m)))stop("Significance matrix does not match the heatmap.")
    dimnames(q) <- dimnames(m)
  }
  label <- function(ids,original,changed){vapply(seq_along(ids),function(i)as.character(changed[[ids[i]]] %or% original[[i]]),character(1))}
  rl <- setNames(label(rownames(m),source$row_labels,style$row_labels),rownames(m))
  cl <- setNames(label(colnames(m),source$column_labels,style$column_labels),colnames(m))
  order_axis <- function(value,mode,requested,labels){
    if(identical(mode,"sort"))return(order(labels[rownames(value)],rownames(value)))
    if(identical(mode,"manual"))return(match(c(intersect(unlist(requested),rownames(value)),setdiff(rownames(value),unlist(requested))),rownames(value)))
    if(identical(mode,"cluster") && nrow(value)>1L){
      d <- tryCatch(stats::dist(value),error=function(e)NULL)
      if(!is.null(d) && all(is.finite(d)))return(stats::hclust(d)$order)
    }
    seq_len(nrow(value))
  }
  m <- m[order_axis(m,style$row_order %or% "cluster",style$rows,rl),,drop=FALSE]
  groups<-if(length(source$column_groups))setNames(unlist(source$column_groups),unlist(source$column_ids)) else NULL
  condition_groups<-identical(source$column_group_type,'condition')
  grouped<-!is.null(groups)&&if(condition_groups)!isFALSE(style$group_columns) else !isFALSE(style$group_studies)
  if(grouped){
    order_columns<-unlist(lapply(unique(groups[colnames(m)]),function(g){ids<-colnames(m)[groups[colnames(m)]==g];ids[order_axis(t(m[,ids,drop=FALSE]),style$column_order %or% "preserve",style$columns,cl)]}),use.names=FALSE)
    m<-m[,order_columns,drop=FALSE]
  }else m <- m[,order_axis(t(m),style$column_order %or% "cluster",style$columns,cl),drop=FALSE]
  if(!is.null(q))q <- q[rownames(m),colnames(m),drop=FALSE]
  dots <- isTRUE(style$dots)
  row_dots <- dots && identical(source$significance_scope,'row')
  row_q <- if(is.null(source$row_adjusted_p))NULL else setNames(vapply(source$row_adjusted_p,numeric_cell,numeric(1)),unlist(source$row_ids))
  if(dots && is.null(q) && !row_dots)stop("Adjusted P values are unavailable for this figure.")
  if(row_dots && is.null(row_q))stop('Comparison significance is unavailable for these genes.')
  if(row_dots && is.null(style$dot_label))style$dot_label <- if(identical(style$statistic_method,'edger'))'edgeR row FDR' else 'DESeq2 row adjusted P'
  threshold <- as.numeric(style$dot_threshold %or% .05)
  dot_color <- style$dot_color %or% "#FFFFFF";dot_outline <- style$dot_outline %or% "#333333"
  dot_size <- as.numeric(style$dot_size %or% 4.5)
  supported <- if(is.null(q))matrix(FALSE,nrow(m),ncol(m)) else is.finite(m)&is.finite(q)&q<=threshold
  count_supported <- supported
  if(identical(source$dot_direction,"negative"))count_supported <- count_supported & m<0
  if(identical(source$dot_direction,"positive"))count_supported <- count_supported & m>0
  counts <- isTRUE(style$support_counts) && !is.null(q)
  support_text <- if(counts)paste0(rowSums(count_supported,na.rm=TRUE),"/",rowSums(is.finite(m)&is.finite(q))) else character()
  direction <- source$dot_direction %or% "both"
  count_label <- paste(strwrap(style$support_label %or% paste0(paste0("Significant / evaluable ",if(identical(source$selection$column_unit,"target\u2013study tests"))if(identical(source$support_unit,"targets"))"unique targets (any study)" else if(identical(source$support_unit,"studies"))"studies (any target)" else "target\u2013study tests" else source$column_unit %or% "targets"),if(direction!="both")paste0(" (",direction,")") else ""),22),collapse="\n")
  rh <- rownames(m) %in% unlist(style$highlight_rows);ch <- colnames(m) %in% unlist(style$highlight_columns)
  mark <- isTRUE(style$markers %or% TRUE)
  rlabels <- paste0(ifelse(rh & mark,"* ",""),rl[rownames(m)])
  clabels <- paste0(ifelse(ch & mark,"* ",""),cl[colnames(m)])
  if(grouped&&!condition_groups)for(j in seq_along(clabels))if(is.null(style$column_labels[[colnames(m)[j]]]))clabels[j]<-sub(" \\(PRJ[^)]+\\)$","",clabels[j])
  if(grouped&&condition_groups&&identical(source$column_unit,'condition\u2013target tests'))for(j in seq_along(clabels)){
    suffix<-paste0(' (',groups[colnames(m)[j]],')')
    if(is.null(style$column_labels[[colnames(m)[j]]])&&endsWith(clabels[j],suffix))clabels[j]<-substr(clabels[j],1,nchar(clabels[j])-nchar(suffix))
  }
  palette <- unlist(style$colors %or% c("#2166AC","#92C5DE","#F7F7F7","#F4A582","#B2182B"))
  missing <- style$na_color %or% "#D6D6D6";hi <- style$highlight_color %or% "#1A624D"
  finite <- as.numeric(m[is.finite(m)]);limit <- source$limit %or% if(length(finite))max(abs(finite)) else 1
  if(!is.finite(limit) || limit==0)limit <- 1
  low <- as.numeric(style$range_min %or% -limit);high <- as.numeric(style$range_max %or% limit);center <- as.numeric(style$center %or% 0)
  n <- length(palette);half <- floor(n/2)
  breaks <- c(seq(low,center,length.out=half+1L)[- (half+1L)],seq(center,high,length.out=n-half+1L))
  continuous <- identical(style$scale_mode,"continuous")
  anchors <- c(seq(low,center,length.out=half+1L)[-(half+1L)],seq(center,high,length.out=n-half))
  ramp <- grDevices::colorRamp(palette,space="Lab")
  fill_value <- function(v) {
    if(!is.finite(v))return(missing)
    v <- max(low,min(high,v))
    if(!continuous)return(palette[findInterval(v,breaks,all.inside=TRUE)])
    fraction <- stats::approx(anchors,seq(0,1,length.out=n),xout=v,rule=2)$y
    rgb <- pmax(0,pmin(255,as.numeric(ramp(fraction))))
    grDevices::rgb(rgb[1],rgb[2],rgb[3],maxColorValue=255)
  }
  font <- as.numeric(style$font_size %or% 10);rotation <- as.numeric(style$rotation %or% 45)
  title <- style$title %or% source$title;subtitle <- style$subtitle %or% "";legend <- style$legend_title %or% (source[["statistic"]] %or% "Plotted value")
  legend <- paste(strwrap(legend,22),collapse="\n")
  wrap_lines <- function(text,n){
    text<-paste(vapply(strsplit(as.character(text),"\n",fixed=TRUE)[[1]],function(line){
      words<-strsplit(line," ",fixed=TRUE)[[1]]
      words<-vapply(words,function(word){if(nchar(word)<=n)return(word);paste(substring(word,seq(1,nchar(word),n),pmin(seq(1,nchar(word),n)+n-1,nchar(word))),collapse=" ")},character(1))
      paste(strwrap(paste(words,collapse=" "),n),collapse="\n")
    },character(1)),collapse="\n");text
  }
  legend<-wrap_lines(legend,22)
  if(!is.null(source$support_numerator)&&counts){
    numerator<-setNames(unlist(source$support_numerator),unlist(source$row_ids));denominator<-setNames(unlist(source$support_denominator),unlist(source$row_ids))
    support_text<-paste0(numerator[rownames(m)],"/",denominator[rownames(m)])
  }
  if(!isFALSE(style$wrap)){rlabels<-vapply(rlabels,wrap_lines,character(1),n=48);clabels<-vapply(clabels,wrap_lines,character(1),n=24)}
  title_lines <- if(isFALSE(style$wrap))title else wrap_lines(title,80)
  subtitle <- if(isFALSE(style$wrap))subtitle else wrap_lines(subtitle,100)
  dir.create(dirname(base_path),recursive=TRUE,showWarnings=FALSE)
  pdf_device<-function(file,width=7,height=7){if(isTRUE(capabilities('cairo')))grDevices::cairo_pdf(file,width=width,height=height,family='sans') else grDevices::pdf(file,width=width,height=height,useDingbats=FALSE)}
  tmp <- tempfile(fileext=".pdf");pdf_device(tmp);par(family="sans",cex=font/12)
  measure <- function(x,size=font)max(c(.1,graphics::strwidth(unlist(strsplit(x,"\n",fixed=TRUE)),units="inches",cex=size/font)))
  count_width <- if(counts)max(1.15,measure(strsplit(count_label,"\n",fixed=TRUE)[[1]],font*.75)+.2) else 0
  row_width <- measure(rlabels)*1.15+.35+count_width;column_width <- measure(clabels)
  legend_width <- max(1.9,measure(strsplit(legend,"\n",fixed=TRUE)[[1]])+.4,measure(paste(formatC(low,digits=3,format="g"),"to",formatC(high,digits=3,format="g")))+.4,
    measure(style$missing_label %or% "Missing",font*.85)+.6,if(any(rh)|any(ch))measure(style$highlight_label %or% "Bold / side bar: highlighted",font*.8)+.6 else 0,
    if(dots)measure(paste0(style$dot_label %or% "Adjusted P"," <= ",format(threshold)),font*.8)+.6 else 0)
  top_width <- max(measure(strsplit(title_lines,"\n",fixed=TRUE)[[1]],font*1.3),measure(strsplit(subtitle,"\n",fixed=TRUE)[[1]]),measure(legend))
  grDevices::dev.off();unlink(tmp)
  row_lines<-max(lengths(strsplit(rlabels,"\n",fixed=TRUE)));column_lines<-max(lengths(strsplit(clabels,"\n",fixed=TRUE)))
  cellw <- max(.22,font/72*.8,if(rotation==0)column_width+.12 else font/72*1.5*column_lines/sin(rotation*pi/180));cellh <- max(.20,font/72*(1.2*row_lines+.45))
  title_height <- length(strsplit(title_lines,"\n",fixed=TRUE)[[1]])*font/72*1.7
  subtitle_height <- if(nzchar(subtitle))length(strsplit(subtitle,"\n",fixed=TRUE)[[1]])*font/72*1.4 else 0
  count_height <- if(counts)length(strsplit(count_label,"\n",fixed=TRUE)[[1]])*font/72*1.1+.15 else 0
  left <- max(.5,column_width*cos(rotation*pi/180)+.25);right <- row_width+legend_width;top <- .5+title_height+subtitle_height+count_height
  group_label<-function(g){
    count<-sum(groups[colnames(m)]==g)
    suffix<-if(!condition_groups)'' else if(identical(source$column_unit,'condition\u2013target tests'))paste0(' (',count,' target',if(count==1)'' else 's',')') else paste0(' (n = ',count,')')
    wrap_lines(paste0(g,suffix),28)
  }
  group_height<-if(grouped)max(.45,.18+font/72*1.1*max(vapply(unique(groups[colnames(m)]),function(g)length(strsplit(group_label(g),'\n',fixed=TRUE)[[1]]),integer(1)))) else 0
  top<-top+group_height
  bottom <- max(.65,column_width*sin(rotation*pi/180)+.35)
  width <- max(7,top_width+1,left+right+ncol(m)*cellw,column_width*cos(rotation*pi/180)+left+right+1)
  legend_title_height <- length(strsplit(legend,"\n",fixed=TRUE)[[1]])*font/72*1.4
  height <- max(4,top+bottom+nrow(m)*cellh,top+bottom+legend_title_height+(n+3)*.3+if(dots).8 else 0)
  # Explicit size is a minimum so fitting never clips labels or titles.
  width <- max(width,as.numeric(style$width %or% 0));height <- max(height,as.numeric(style$height %or% 0))
  if(isTRUE(style$layout_only))return(list(width=width,height=height))
  if(width>80 || height>100)stop("Labels or matrix exceed the supported figure size. Use shorter display labels or fewer plotted items.")
  svg_mode <- FALSE;svg_text <- character()
  draw_text <- function(label,x=.5,y=.5,just="centre",rot=0,gp=grid::gpar(),edit=NULL){
    if(svg_mode)svg_text <<- c(svg_text,.p2c_svg_text(label,x,y,just,rot,gp,edit,height)) else grid::grid.text(label,x=x,y=y,just=just,rot=rot,gp=gp)
  }
  plot <- function(){
    grid::grid.newpage()
    draw_text(title_lines,edit=list(key="title",value=title),x=.5,y=grid::unit(height-.3,"inches"),just="top",gp=grid::gpar(fontsize=font*1.3,fontface="bold"))
    if(nzchar(subtitle))draw_text(subtitle,edit=list(key="subtitle",value=style$subtitle),x=.5,y=grid::unit(height-.35-title_height,"inches"),just="top",gp=grid::gpar(fontsize=font))
    w <- width-left-right;h <- height-top-bottom
    grid::pushViewport(grid::viewport(x=grid::unit(left,"inches"),y=grid::unit(bottom,"inches"),width=grid::unit(w,"inches"),height=grid::unit(h,"inches"),just=c("left","bottom")))
    for(i in seq_len(nrow(m)))for(j in seq_len(ncol(m))){
      v <- m[i,j];band <- if(is.finite(v))findInterval(max(low,min(high,v)),breaks,all.inside=TRUE) else NA_integer_
      grid::grid.rect(x=(j-.5)/ncol(m),y=1-(i-.5)/nrow(m),width=1/ncol(m),height=1/nrow(m),gp=grid::gpar(fill=fill_value(v),col=NA))
      if(dots && !row_dots && supported[i,j])grid::grid.circle(x=(j-.5)/ncol(m),y=1-(i-.5)/nrow(m),
        r=grid::unit(min(dot_size/2,w/ncol(m)*72*.22,h/nrow(m)*72*.22),"points"),
        gp=grid::gpar(fill=dot_color,col=dot_outline,lwd=.65))
    }
    if(grouped){
      current_groups<-groups[colnames(m)]
      for(g in unique(current_groups)){
        js<-which(current_groups==g);start<-(min(js)-1)/ncol(m);end<-max(js)/ncol(m)
        fill<-source$column_group_colors[[g]] %or% if(condition_groups)c('#CBD5E1','#BDD5CC')[(match(g,unique(current_groups))-1L)%%2L+1L] else '#EDF2EF'
        if(!grepl('^#[0-9A-Fa-f]{6}$',fill))fill<-'#EDF2EF'
        band_height<-group_height-.1;band_y<-grid::unit(1,'npc')+grid::unit(group_height/2,'inches')
        grid::grid.rect(x=(start+end)/2,y=band_y,width=end-start,height=grid::unit(band_height,'inches'),gp=grid::gpar(fill=fill,col='#758A80'))
        draw_text(group_label(g),x=(start+end)/2,y=band_y,gp=grid::gpar(fontsize=font*.8,fontface='bold',col='#22332C'))
        if(min(js)>1)grid::grid.lines(x=c(start,start),y=c(0,1),gp=grid::gpar(col='#203832',lwd=1.5))
      }
    }
    for(i in seq_len(nrow(m))){
      if(row_dots && is.finite(row_q[rownames(m)[i]]) && row_q[rownames(m)[i]]<=threshold)
        grid::grid.circle(x=grid::unit(1,'npc')+grid::unit(.08,'inches'),y=1-(i-.5)/nrow(m),r=grid::unit(dot_size/2,'points'),gp=grid::gpar(fill=dot_color,col=dot_outline,lwd=.65))
      if(rh[i])grid::grid.rect(x=grid::unit(-.10,"inches"),y=1-(i-.5)/nrow(m),width=grid::unit(.08,"inches"),height=1/nrow(m),gp=grid::gpar(fill=hi,col=NA))
      draw_text(rlabels[i],edit=list(key="row_labels",id=rownames(m)[i],value=rl[rownames(m)[i]]),x=grid::unit(1,"npc")+grid::unit(if(row_dots).2 else .12,"inches"),y=1-(i-.5)/nrow(m),just="left",gp=grid::gpar(fontsize=font,fontface=if(rh[i])"bold" else "plain"))
      if(counts)draw_text(support_text[i],x=grid::unit(1,"npc")+grid::unit(row_width-count_width/2,"inches"),y=1-(i-.5)/nrow(m),just="center",gp=grid::gpar(fontsize=font*.9))
    }
    for(j in seq_len(ncol(m))){
      if(ch[j])grid::grid.rect(x=(j-.5)/ncol(m),y=grid::unit(1,"npc")+grid::unit(.08,"inches"),width=1/ncol(m),height=grid::unit(.06,"inches"),gp=grid::gpar(fill=hi,col=NA))
      draw_text(clabels[j],edit=list(key="column_labels",id=colnames(m)[j],value=cl[colnames(m)[j]]),x=(j-.5)/ncol(m),y=grid::unit(-.12,"inches"),rot=rotation,just=c(if(rotation==0)"center" else "right","center"),gp=grid::gpar(fontsize=font,fontface=if(ch[j])"bold" else "plain"))
    }
    grid::popViewport()
    lx <- width-legend_width/2;ly <- height-top-legend_title_height-.15
    draw_text(legend,edit=list(key="legend_title",value=legend),x=grid::unit(lx,"inches"),y=grid::unit(height-top,"inches"),just=c("center","top"),gp=grid::gpar(fontsize=font))
    if(continuous){
      bar_height <- max(1.8,min(3,n*.3)); bar_top <- ly; steps <- 256L
      for(k in seq_len(steps)){
        f <- (k-.5)/steps
        grid::grid.rect(x=grid::unit(lx-.35,"inches"),y=grid::unit(bar_top-(1-f)*bar_height,"inches"),width=grid::unit(.22,"inches"),height=grid::unit(bar_height/steps+.001,"inches"),gp=grid::gpar(fill=fill_value(low+f*(high-low)),col=NA))
      }
      for(v in c(low,center,high)){
        y <- bar_top-(1-(v-low)/(high-low))*bar_height
        draw_text(formatC(v,digits=3,format="g"),edit=list(key="_range"),x=grid::unit(lx-.16,"inches"),y=grid::unit(y,"inches"),just="left",gp=grid::gpar(fontsize=font*.85))
      }
      missing_y <- bar_top-bar_height-.4
    }else{
    for(k in seq_len(n)){
      y <- ly-(k-.5)*.30
      grid::grid.rect(x=grid::unit(lx-.35,"inches"),y=grid::unit(y,"inches"),width=grid::unit(.22,"inches"),height=grid::unit(.22,"inches"),gp=grid::gpar(fill=palette[n-k+1],col="#555555"))
      text <- paste(formatC(breaks[n-k+1],digits=3,format="g"),"to",formatC(breaks[n-k+2],digits=3,format="g"))
      draw_text(text,edit=list(key="_range"),x=grid::unit(lx-.16,"inches"),y=grid::unit(y,"inches"),just="left",gp=grid::gpar(fontsize=font*.85))
    }
      missing_y <- ly-(n+.5)*.3
    }
    grid::grid.rect(x=grid::unit(lx-.35,"inches"),y=grid::unit(missing_y,"inches"),width=grid::unit(.22,"inches"),height=grid::unit(.22,"inches"),gp=grid::gpar(fill=missing,col="#555555"))
    draw_text(style$missing_label %or% "Missing",edit=list(key="missing_label"),x=grid::unit(lx-.16,"inches"),y=grid::unit(missing_y,"inches"),just="left",gp=grid::gpar(fontsize=font*.85))
    if(any(rh)|any(ch))draw_text(style$highlight_label %or% if(mark)"* Highlighted" else "Bold / side bar: highlighted",edit=list(key="highlight_label"),x=grid::unit(lx-.45,"inches"),y=grid::unit(missing_y-.4,"inches"),just="left",gp=grid::gpar(fontsize=font*.8))
    if(dots){
      dy <- missing_y-if(any(rh)|any(ch)).8 else .4
      grid::grid.circle(x=grid::unit(lx-.35,"inches"),y=grid::unit(dy,"inches"),r=grid::unit(dot_size/2,"points"),gp=grid::gpar(fill=dot_color,col=dot_outline,lwd=.65))
      draw_text(paste0(style$dot_label %or% "Adjusted P"," <= ",format(threshold)),edit=list(key="dot_label",value=style$dot_label %or% "Adjusted P"),x=grid::unit(lx-.16,"inches"),y=grid::unit(dy,"inches"),just="left",gp=grid::gpar(fontsize=font*.8))
    }
    if(counts)draw_text(count_label,edit=list(key="support_label"),x=grid::unit(width-right+row_width-count_width/2,"inches"),y=grid::unit(height-top+.12,"inches"),just=c("center","bottom"),gp=grid::gpar(fontsize=font*.75))
  }
  formats <- unlist(style$formats %or% c("svg","pdf","png"));if(any(!formats%in%c("svg","pdf","png")))stop("Unsupported figure format")
  files <- paste0(base_path,".",formats)
  for(file in files){
    if(grepl("[.]pdf$",file)&&isTRUE(style$pdf_device_open)){svg_mode<-FALSE;plot();next}
    svg_mode <- grepl("[.]svg$",file);svg_text <- character()
    if(grepl("[.]svg$",file))grDevices::svg(file,width=width,height=height) else if(grepl("[.]pdf$",file))pdf_device(file,width,height) else grDevices::png(file,width=width,height=height,units="in",res=min(180,sqrt(20000000/(width*height))))
    tryCatch(plot(),finally=grDevices::dev.off())
    if(svg_mode){document<-paste(readLines(file,warn=FALSE),collapse="\n");document<-sub("</svg>",paste0("<g id=\"p2c-editable-text\">",paste(svg_text,collapse="\n"),"</g></svg>"),document,fixed=TRUE);writeLines(document,file)}
  }
  files
}
