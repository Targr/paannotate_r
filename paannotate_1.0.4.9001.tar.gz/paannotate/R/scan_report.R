.scan_write_csv <- function(data, path) {
  data <- as.data.frame(data, stringsAsFactors = FALSE)
  if (!ncol(data)) data <- data.frame(message = "No rows", stringsAsFactors = FALSE)
  connection <- if (grepl("\\.gz$", path, ignore.case = TRUE)) gzfile(path, "wt") else path
  on.exit(if (inherits(connection, "connection")) close(connection), add = TRUE)
  utils::write.csv(data, connection, row.names = FALSE, na = "")
  invisible(path)
}

.scan_or <- function(x, fallback) {
  if (is.null(x) || !length(x) || (length(x) == 1L && is.na(x))) fallback else x
}

.scan_has_curated <- function(enrichment) {
  if (is.null(enrichment)) return(FALSE)
  if (!is.null(enrichment$config$curated)) return(isTRUE(enrichment$config$curated))
  is.data.frame(enrichment$themes$summary) && nrow(enrichment$themes$summary) > 0L
}

.scan_write_lines <- function(lines, path) {
  writeLines(as.character(lines), path, useBytes = TRUE)
  invisible(path)
}

.scan_decorate <- function(data, scan, enrichment = NULL) {
  data <- as.data.frame(data, stringsAsFactors = FALSE)
  if ("target" %in% names(data) && !"target_label" %in% names(data)) {
    labels <- scan$targets$targets[c("target", "target_label")]
    data <- merge(data, labels, by = "target", all.x = TRUE, sort = FALSE)
  }
  annotations <- if (!is.null(enrichment)) enrichment$gene_annotations else NULL
  if ("gene_id" %in% names(data) && !is.null(annotations) && nrow(annotations)) {
    data <- merge(data, annotations, by = "gene_id", all.x = TRUE, sort = FALSE)
  }
  data
}

.scan_how_to_read <- function(scan, enrichment = NULL) {
  adjusted <- any(scan$project_qc$adjustment_status == "available")
  metadata_target <- !is.null(scan$config$metadata_target)
  profile_text <- if (!is.null(scan$config$whiteley_profile)) {
    profile <- scan$config$whiteley_profile
    samples <- .scan_or(profile$provenance$biological_samples, NA_integer_)
    projects <- .scan_or(profile$provenance$bioprojects, NA_integer_)
    preset <- if (identical(profile$profile_id, "whiteley_pao1_414_v1")) {
      "the frozen 414-sample preset"
    } else "the full Whiteley release"
    paste0("This scan used ", preset, " (", profile$profile_id, "), after filters: ",
           samples, " project-specific BioSamples in ", projects,
           " project groups. See the Cohort sheets and 00_cohort CSV files for every inclusion decision.")
  } else {
    "This scan used user-supplied expression and sample-to-project information."
  }
  rows <- c(
    "Start here", "Cross_cutoff contains relationships that passed at least one requested sample cutoff.",
    "Whiteley profile", profile_text,
    "Why projects remain internal", if (metadata_target) {
      "The requested metadata levels are compared separately inside each BioProject and then meta-analyzed. A project containing only one level cannot distinguish the metadata effect from a project-specific laboratory effect."
    } else {
      "Correlations are calculated separately inside each BioProject and then meta-analyzed. The project labels prevent unrelated experiments from being pooled as if they were replicates."
    },
    "Selection", if (adjusted) {
      "Persistent means supported in both total and covariate-adjusted analyses with the same direction."
    } else {
      "No usable adjustment was supplied; selected relationships are supported in total mode only."
    },
    "FDR scope", "meta_fdr is Benjamini-Hochberg corrected across every gene-target test within each cutoff and analysis mode.",
    "Heterogeneity", "I2 is the percent of cross-project variability not explained by sampling error; lower is more consistent.",
    "Stability", "Core/Supported evidence requires random-effects and fixed-effect sign agreement plus leave-one-project-out sign stability.",
    "Cutoffs", paste("Requested minimum samples per project:", paste(scan$config$min_samples_per_project, collapse = ", ")),
    "Exact pathways", "Exact_terms retains the original GO, KEGG, PseudoCAP, and other term identities.",
    "Audit", "Full project correlations and all meta-analysis rows are written as compressed CSV files beside this workbook."
  )
  if (.scan_has_curated(enrichment)) {
    rows <- c(
      rows,
      "Umbrella pathways", "Themes are rebuilt as curated gene sets and retested; they are not merely renamed exact-term p-values.",
      "Iron", "Iron sheets/panels include core iron acquisition/regulation plus separately labeled contextual iron/redox themes."
    )
  }
  if (metadata_target) {
    target <- scan$config$metadata_target
    rows <- c(
      rows,
      "Metadata-target direction", paste0(
        "Positive means higher expression or positive association with '",
        target$positive, "'; Negative points toward '", target$reference, "'."
      ),
      "Metadata-target effect", paste0(
        "meta_rho is a within-project point-biserial association. The additional ",
        "mean_log2_expression_difference columns show the unadjusted difference ",
        "in normalized log2 CPM (", target$positive, " minus ", target$reference, ")."
      ),
      "Metadata-target audit", paste0(
        "The Metadata_target workbook sheets and 00_metadata_target files show ",
        "the sample coding, per-project group counts, and every excluded project."
      )
    )
  }
  if (is.null(enrichment)) {
    rows <- c(rows, "Enrichment", "No membership collection was supplied, so enrichment and pathway heatmaps were not run.")
  }
  data.frame(section = rows[c(TRUE, FALSE)], explanation = rows[c(FALSE, TRUE)],
             stringsAsFactors = FALSE)
}

.scan_sheet_name <- function(x, used = character()) {
  value <- substr(gsub("[\\[\\]*?:/\\\\]", "_", x), 1, 31)
  base <- value
  index <- 1L
  while (value %in% used) {
    index <- index + 1L
    suffix <- paste0("_", index)
    value <- paste0(substr(base, 1, 31 - nchar(suffix)), suffix)
  }
  value
}

.scan_add_sheet <- function(workbook, name, data, used, maximum_rows) {
  sheet <- .scan_sheet_name(name, used)
  openxlsx::addWorksheet(workbook, sheet, gridLines = FALSE)
  data <- as.data.frame(data, stringsAsFactors = FALSE)
  truncated <- nrow(data) > maximum_rows
  if (truncated) data <- data[seq_len(maximum_rows), , drop = FALSE]
  if (!ncol(data)) data <- data.frame(message = "No rows", stringsAsFactors = FALSE)
  if (!nrow(data)) data <- data[NA_integer_, , drop = FALSE]
  openxlsx::writeDataTable(workbook, sheet, data, withFilter = nrow(data) > 1,
                           tableStyle = "TableStyleMedium2")
  openxlsx::freezePane(workbook, sheet, firstRow = TRUE)
  openxlsx::pageSetup(workbook, sheet, orientation = "landscape",
                      fitToWidth = 1, fitToHeight = 0)
  if (ncol(data)) {
    widths <- pmin(45, pmax(10, vapply(seq_along(data), function(i) {
      max(nchar(c(names(data)[i], as.character(utils::head(data[[i]], 200)))), na.rm = TRUE) + 2
    }, numeric(1))))
    openxlsx::setColWidths(workbook, sheet, cols = seq_along(data), widths = widths)
  }
  if (identical(name, "How_to_read") && ncol(data) >= 2L) {
    openxlsx::setColWidths(workbook, sheet, cols = 1:2, widths = c(24, 110))
    wrap <- openxlsx::createStyle(wrapText = TRUE, valign = "top")
    openxlsx::addStyle(workbook, sheet, wrap, rows = seq_len(nrow(data)) + 1L,
                       cols = 1:2, gridExpand = TRUE, stack = TRUE)
    openxlsx::setRowHeights(workbook, sheet, rows = seq_len(nrow(data)) + 1L,
                            heights = 32)
  }
  rho_columns <- grep("(^|_)rho$|meta_rho$|selected_rho$", names(data),
                      ignore.case = TRUE)
  if (length(rho_columns) && nrow(data)) {
    for (column in rho_columns) {
      openxlsx::conditionalFormatting(
        workbook, sheet, cols = column, rows = seq_len(nrow(data)) + 1L,
        type = "colourScale", style = c("#2166AC", "#FFFFFF", "#B2182B")
      )
    }
  }
  if (truncated) {
    openxlsx::writeComment(workbook, sheet, col = 1, row = 1,
                           comment = openxlsx::createComment(
                             paste("Workbook view truncated at", maximum_rows,
                                   "rows; the CSV audit contains all rows.")))
  }
  list(name = sheet, truncated = truncated)
}

.scan_write_workbook <- function(scan, enrichment, path, maximum_rows) {
  if (!requireNamespace("openxlsx", quietly = TRUE)) {
    warning("Skipping Excel workbook: optional package 'openxlsx' is unavailable.",
            call. = FALSE)
    return(NULL)
  }
  wb <- openxlsx::createWorkbook(creator = "paannotate")
  used <- character()
  add <- function(name, data) {
    info <- .scan_add_sheet(wb, name, data, used, maximum_rows)
    used <<- c(used, info$name)
    invisible(info)
  }
  add("How_to_read", .scan_how_to_read(scan, enrichment))
  if (!is.null(scan$cohort_audit)) {
    add("Cohort_summary", scan$cohort_audit$summary)
    add("Cohort_selection", scan$cohort_audit$selection)
    add("Cohort_projects", scan$cohort_audit$project_sizes)
  }
  if (!is.null(scan$metadata_target_audit)) {
    add("Metadata_target_summary", scan$metadata_target_audit$summary)
    add("Metadata_target_cutoffs", scan$metadata_target_audit$cutoff_readiness)
    add("Metadata_target_projects", scan$metadata_target_audit$project_readiness)
    add("Metadata_target_samples", scan$metadata_target_audit$sample_assignments)
    add("Metadata_target_levels", scan$metadata_target_audit$level_counts)
  }
  add("Cross_cutoff", .scan_decorate(scan$cross_cutoff, scan, enrichment))
  add("Gene_summary", .scan_decorate(scan$gene_summary, scan, enrichment))
  for (cutoff in scan$config$min_samples_per_project) {
    x <- scan$relationships[scan$relationships$cutoff == cutoff &
                              scan$relationships$persistent %in% TRUE, , drop = FALSE]
    add(paste0("N", cutoff, "_selected"), .scan_decorate(x, scan, enrichment))
  }
  passing <- scan$meta_analysis[scan$meta_analysis$evidence_class %in%
                                  c("Core tracker", "Supported tracker",
                                    "Context-dependent signal"), , drop = FALSE]
  add("All_passing_modes", .scan_decorate(passing, scan, enrichment))
  add("Project_QC", scan$project_qc)
  add("Target_QC", scan$target_qc)
  add("Denominators", scan$denominators)
  if (!is.null(enrichment)) {
    add("Exact_terms", enrichment$exact$summary)
    add("Exact_ORA", enrichment$exact$ora)
    add("Exact_ranked", enrichment$exact$ranked)
    add("Study_pathway_ranked", enrichment$studies$ranked)
    add("Study_pathway_audit", enrichment$studies$audit)
    if (.scan_has_curated(enrichment)) {
      add("Umbrella_themes", enrichment$themes$summary)
      add("Theme_term_map", enrichment$themes$term_mapping)
      add("Iron_exact", enrichment$iron$exact_terms)
      add("Iron_themes", enrichment$iron$themes)
    }
  }
  openxlsx::saveWorkbook(wb, path, overwrite = TRUE)
  path
}

.scan_summary_matrix <- function(summary, maximum_terms = 40) {
  if (is.null(summary) || !nrow(summary)) return(NULL)
  required <- c("set_name", "database", "target", "cutoff", "direction")
  if (length(setdiff(required, names(summary)))) return(NULL)
  available <- intersect(c("ora_best_fdr", "ranked_best_fdr"), names(summary))
  if (!length(available)) return(NULL)
  fdr <- do.call(pmin, c(lapply(summary[available], function(x) {
    value <- suppressWarnings(as.numeric(x))
    value[!is.finite(value)] <- NA_real_
    value
  }), na.rm = TRUE))
  fdr[!is.finite(fdr)] <- NA_real_
  direction_sign <- rep(NA_real_, nrow(summary))
  direction_sign[summary$direction %in% "Positive"] <- 1
  direction_sign[summary$direction %in% "Negative"] <- -1
  score <- direction_sign *
    pmin(12, -log10(pmax(fdr, 1e-12)))
  valid <- is.finite(score) &
    !is.na(summary$set_name) & nzchar(trimws(as.character(summary$set_name))) &
    !is.na(summary$database) & nzchar(trimws(as.character(summary$database))) &
    !is.na(summary$target) & nzchar(trimws(as.character(summary$target))) &
    !is.na(summary$cutoff)
  if (!any(valid)) return(NULL)
  summary <- summary[valid, , drop = FALSE]
  score <- score[valid]
  fdr <- fdr[valid]
  row_label <- paste0(summary$set_name, " [", summary$database, "]")
  col_label <- paste0(summary$target, " | n", summary$cutoff)
  matrix_value <- matrix(NA_real_, length(unique(row_label)), length(unique(col_label)),
                         dimnames = list(unique(row_label), unique(col_label)))
  saved_fdr <- matrix_value
  for (i in seq_along(score)) {
    if (!is.finite(score[i])) next
    old <- matrix_value[row_label[i], col_label[i]]
    if (!is.finite(old) || abs(score[i]) > abs(old)) {
      matrix_value[row_label[i], col_label[i]] <- score[i]
      saved_fdr[row_label[i], col_label[i]] <- fdr[i]
    }
  }
  strength <- apply(abs(matrix_value), 1, function(z) {
    z <- z[is.finite(z)]
    if (length(z)) max(z) else NA_real_
  })
  strength <- strength[is.finite(strength)]
  if (!length(strength)) return(NULL)
  keep <- names(sort(strength, decreasing = TRUE))[
    seq_len(min(maximum_terms, length(strength)))
  ]
  answer <- matrix_value[keep, , drop = FALSE]
  attr(answer,"statistic") <- "Signed -log10 best FDR (capped at 12)"
  attr(answer,"kind") <- "pathways"
  attr(answer,"adjusted_p") <- saved_fdr[keep, , drop = FALSE]
  attr(answer,"significance_definition") <- paste(
    "Dots mark the best saved FDR supporting each summary cell, selected across",
    "enrichment methods/directions. This is descriptive support, not an omnibus",
    "or combined adjusted P value. Choose a method-specific view for inference."
  )
  if("set_id" %in% names(summary)){
    attr(answer,"row_ids") <- vapply(keep,function(label){
      ix <- row_label==label
      paste(sort(unique(paste(summary$database[ix],summary$set_id[ix],sep=":"))),collapse=" | ")
    },character(1))
  }
  answer
}

.scan_relationship_matrix <- function(scan, maximum_genes = 60, target = NULL) {
  cutoff <- max(scan$config$min_samples_per_project)
  x <- scan$relationships[scan$relationships$cutoff == cutoff &
                            scan$relationships$persistent %in% TRUE, , drop = FALSE]
  if (!is.null(target)) x <- x[x$target %in% target, , drop = FALSE]
  if (!nrow(x)) return(NULL)
  strength <- tapply(abs(x$selected_rho), x$gene_id, max, na.rm = TRUE)
  genes <- names(sort(strength, decreasing = TRUE))[seq_len(min(maximum_genes,
                                                                length(strength)))]
  result <- matrix(NA_real_, length(genes), length(unique(x$target)),
                   dimnames = list(genes, unique(x$target)))
  for (i in seq_len(nrow(x))) {
    if (x$gene_id[i] %in% genes) result[x$gene_id[i], x$target[i]] <- x$selected_rho[i]
  }
  attr(result,"statistic") <- "Selected correlation (rho)"
  result
}

.scan_render_heatmap <- function(matrix_value, base_path, title, limit = NULL) {
  if (is.null(matrix_value) || !length(matrix_value) || !nrow(matrix_value) || !ncol(matrix_value)) return(character())
  if (!requireNamespace("jsonlite",quietly=TRUE)) return(character())
  rows <- rownames(matrix_value);cols <- colnames(matrix_value)
  if(is.null(rows))rows <- paste0("row_",seq_len(nrow(matrix_value)))
  if(is.null(cols))cols <- paste0("column_",seq_len(ncol(matrix_value)))
  stable_rows <- attr(matrix_value,"row_ids");if(is.null(stable_rows))stable_rows <- rows
  statistic <- attr(matrix_value,"statistic");if(is.null(statistic))statistic <- if(identical(limit,1))"Correlation (rho)" else "Plotted effect / score"
  source <- list(schema=1,title=title,statistic=statistic,limit=limit,
    row_ids=as.list(make.unique(stable_rows)),column_ids=as.list(make.unique(cols)),
    row_labels=as.list(rows),column_labels=as.list(cols),
    values=lapply(seq_len(nrow(matrix_value)),function(i)as.list(matrix_value[i,])),
    original_order=list(rows=as.list(make.unique(stable_rows)),columns=as.list(make.unique(cols))),
    clustering=list(rows="hclust Euclidean; finite distances only",columns="hclust Euclidean; finite distances only"),
    missing="Unavailable cells are null, never zero",source_analysis=basename(dirname(base_path)))
  source$kind <- attr(matrix_value,"kind")
  q <- attr(matrix_value,"adjusted_p")
  if(!is.null(q)){
    if(!identical(dim(q),dim(matrix_value)))stop("Saved significance dimensions do not match the pathway matrix.")
    source$adjusted_p <- lapply(seq_len(nrow(q)),function(i)as.list(q[i,]))
    source$significance_definition <- attr(matrix_value,"significance_definition")
  }
  dir.create(dirname(base_path),recursive=TRUE,showWarnings=FALSE)
  jsonlite::write_json(source,paste0(base_path,".heatmap.json"),auto_unbox=TRUE,na="null",digits=NA,pretty=TRUE)
  .p2c_render_heatmap(source,list(),base_path)
}

.scan_write_heatmaps <- function(scan, enrichment, directory,
                                 maximum_genes, maximum_terms) {
  status_rows <- list()
  status_counter <- 0L
  files <- character()
  record_status <- function(scope, target, heatmap, status, reason = "", made = character()) {
    status_counter <<- status_counter + 1L
    status_rows[[status_counter]] <<- data.frame(
      scope = scope, target = target, heatmap = heatmap, status = status,
      reason = reason, files = paste(basename(made), collapse = "; "),
      stringsAsFactors = FALSE
    )
  }
  status_path <- file.path(directory, "heatmap_status.csv")
  if (!requireNamespace("pheatmap", quietly = TRUE)) {
    warning("Skipping heatmaps: optional package 'pheatmap' is unavailable.",
            call. = FALSE)
    record_status("combined", "all", "all", "skipped",
                  "Optional package 'pheatmap' is unavailable")
    .scan_write_csv(do.call(rbind, status_rows), status_path)
    return(c(heatmap_status = status_path))
  }
  render_one <- function(scope, target, name, matrix_builder, base_path, title,
                         limit = NULL) {
    tryCatch({
      matrix_value <- matrix_builder()
      if (is.null(matrix_value) || !length(matrix_value) ||
          !nrow(matrix_value) || !ncol(matrix_value)) {
        record_status(scope, target, name, "no_results",
                      "No finite, evaluable values were available")
        return(invisible(character()))
      }
      made <- .scan_render_heatmap(matrix_value, base_path, title, limit)
      made <- made[file.exists(made)]
      if (length(made)) {
        files <<- c(files, made)
        record_status(scope, target, name, "created", made = made)
      } else {
        record_status(scope, target, name, "skipped",
                      "The plotting engine did not create a file")
      }
      invisible(made)
    }, error = function(e) {
      reason <- conditionMessage(e)
      record_status(scope, target, name, "failed", reason)
      warning("Could not render ", name, " heatmap",
              if (!identical(target, "all")) paste0(" for ", target) else "",
              ": ", reason, ". Other heatmaps will continue.", call. = FALSE)
      invisible(character())
    })
  }
  iron_summary <- function(target = NULL) {
    common <- intersect(names(enrichment$iron$exact_terms), names(enrichment$iron$themes))
    iron <- if (length(common)) rbind(
      enrichment$iron$exact_terms[common], enrichment$iron$themes[common]
    ) else data.frame()
    if (!is.null(target) && nrow(iron) && "target" %in% names(iron)) {
      iron <- iron[iron$target %in% target, , drop = FALSE]
    }
    iron
  }
  render_one(
    "combined", "all", "correlated_genes",
    function() .scan_relationship_matrix(scan, maximum_genes),
    file.path(directory, "correlated_genes"),
    "Selected gene-target correlations", limit = 1
  )
  if (!is.null(enrichment)) {
    render_one(
      "combined", "all", "exact_pathways",
      function() .scan_summary_matrix(enrichment$exact$summary, maximum_terms),
      file.path(directory, "exact_pathways"),
      "Exact pathway and ontology enrichment"
    )
    if (.scan_has_curated(enrichment)) {
      render_one(
        "combined", "all", "curated_umbrella_themes",
        function() .scan_summary_matrix(enrichment$themes$summary, maximum_terms),
        file.path(directory, "curated_umbrella_themes"),
        "Curated umbrella pathways"
      )
      render_one(
        "combined", "all", "iron_focused_pathways",
        function() .scan_summary_matrix(iron_summary(), maximum_terms),
        file.path(directory, "iron_focused_pathways"),
        "Iron-focused pathways and systems"
      )
    }
  }
  targets <- unique(as.character(scan$targets$targets$target))
  if (length(targets) > 1L) {
    by_target <- file.path(directory, "by_target")
    dir.create(by_target, recursive = TRUE, showWarnings = FALSE)
    for (target in targets) {
      slug <- .scan_slug(target)
      if (!nzchar(slug)) slug <- paste0("target_", match(target, targets))
      target_dir <- file.path(by_target, slug)
      dir.create(target_dir, recursive = TRUE, showWarnings = FALSE)
      render_one(
        "individual", target, "correlated_genes",
        function() .scan_relationship_matrix(scan, maximum_genes, target),
        file.path(target_dir, "correlated_genes"),
        paste0(target, ": selected gene correlations"), limit = 1
      )
      if (!is.null(enrichment)) {
        render_one(
          "individual", target, "exact_pathways",
          function() {
            x <- enrichment$exact$summary
            if (nrow(x)) x <- x[x$target %in% target, , drop = FALSE]
            .scan_summary_matrix(x, maximum_terms)
          },
          file.path(target_dir, "exact_pathways"),
          paste0(target, ": exact pathway and ontology enrichment")
        )
        if (.scan_has_curated(enrichment)) {
          render_one(
            "individual", target, "curated_umbrella_themes",
            function() {
              x <- enrichment$themes$summary
              if (nrow(x)) x <- x[x$target %in% target, , drop = FALSE]
              .scan_summary_matrix(x, maximum_terms)
            },
            file.path(target_dir, "curated_umbrella_themes"),
            paste0(target, ": curated umbrella pathways")
          )
          render_one(
            "individual", target, "iron_focused_pathways",
            function() .scan_summary_matrix(iron_summary(target), maximum_terms),
            file.path(target_dir, "iron_focused_pathways"),
            paste0(target, ": iron-focused pathways and systems")
          )
        }
      }
    }
  }
  files <- c(files, .p2c_result_heatmaps(scan, enrichment, directory, maximum_genes, maximum_terms))
  status <- if (length(status_rows)) do.call(rbind, status_rows) else data.frame(
    scope = character(), target = character(), heatmap = character(),
    status = character(), reason = character(), files = character(),
    stringsAsFactors = FALSE
  )
  .scan_write_csv(status, status_path)
  files <- files[file.exists(files)]
  names(files) <- paste0("heatmap_", seq_along(files))
  c(files, heatmap_status = status_path)
}

#' Write a complete target-scan report
#'
#' Writes auditable CSV tables, a reader-oriented Excel workbook, and PNG/PDF
#' heatmaps for selected relationships and exact pathways. Optional curated
#' umbrella and iron-focused outputs are included only when they were requested
#' during enrichment.
#'
#' @param scan A `pa_target_scan` object.
#' @param enrichment Optional `pa_scan_enrichment` object.
#' @param output_dir Destination directory.
#' @param workbook,heatmaps Write optional Excel and heatmap artifacts.
#' @param maximum_excel_rows Maximum rows placed in any workbook sheet; complete
#'   tables always remain in CSV/CSV.GZ.
#' @param maximum_heatmap_genes,maximum_heatmap_terms Display caps.
#' @param output_options Optional P2C output selection list. NULL preserves the complete report.
#' @param internal_dir Application working directory for editable checkpoints when output_options is supplied.
#' @return Named character vector of principal output files.
#' @export
pa_write_scan <- function(
    scan, enrichment = NULL, output_dir, workbook = TRUE, heatmaps = TRUE,
    maximum_excel_rows = 200000, maximum_heatmap_genes = 60,
    maximum_heatmap_terms = 40, output_options = NULL, internal_dir = NULL) {
  if (!inherits(scan, "pa_target_scan")) stop("scan must be a pa_target_scan object.",
                                               call. = FALSE)
  if (!is.null(enrichment) && !inherits(enrichment, "pa_scan_enrichment")) {
    stop("enrichment must be NULL or a pa_scan_enrichment object.", call. = FALSE)
  }
  if(!is.null(output_options))return(.p2c_write_selected_scan(scan,enrichment,output_dir,internal_dir,output_options,maximum_excel_rows,maximum_heatmap_genes,maximum_heatmap_terms))
  output_dir <- path.expand(output_dir)
  dir.create(output_dir,recursive=TRUE,showWarnings=FALSE)
  .p2c_write_activity_audit(scan,output_dir)
  subdirectories <- file.path(output_dir, c(
    "00_audit", "00_cohort", "00_metadata_target", "01_project",
    "02_correlations", "03_meta_analysis",
    "04_relationships", "05_enrichment", "06_heatmaps"
  ))
  invisible(vapply(subdirectories, dir.create, logical(1), recursive = TRUE,
                   showWarnings = FALSE))
  audit <- file.path(output_dir, "00_audit")
  .scan_write_csv(.scan_how_to_read(scan, enrichment), file.path(audit, "how_to_read.csv"))
  .scan_write_lines(utils::capture.output(dput(scan$config)), file.path(audit, "scan_config.R"))
  .scan_write_lines(utils::capture.output(dput(as.list(scan$thresholds))),
                    file.path(audit, "thresholds.R"))
  saveRDS(scan, file.path(audit, "pa_target_scan.rds"), compress = "xz")
  .scan_write_csv(scan$targets$membership, file.path(audit, "target_membership.csv"))
  .scan_write_csv(scan$input_audit$summary, file.path(audit, "input_summary.csv"))
  .scan_write_csv(scan$input_audit$invalid_expression_gene_ids,
                  file.path(audit, "invalid_expression_gene_ids.csv"))
  .scan_write_csv(scan$input_audit$invalid_target_gene_ids,
                  file.path(audit, "invalid_target_gene_ids.csv"))
  .scan_write_csv(data.frame(sample_id = scan$input_audit$unmatched_metadata_samples),
                  file.path(audit, "unmatched_metadata_samples.csv"))
  .scan_write_csv(data.frame(sample_id = scan$input_audit$unmatched_expression_samples),
                  file.path(audit, "unmatched_expression_samples.csv"))
  if (!is.null(scan$cohort_audit)) {
    cohort_dir <- file.path(output_dir, "00_cohort")
    .scan_write_csv(scan$cohort_audit$summary,
                    file.path(cohort_dir, "filter_summary.csv"))
    .scan_write_csv(scan$cohort_audit$selection,
                    file.path(cohort_dir, "sample_selection_audit.csv.gz"))
    .scan_write_csv(scan$cohort_audit$project_sizes,
                    file.path(cohort_dir, "project_sizes_before_after.csv"))
    .scan_write_lines(utils::capture.output(dput(scan$cohort_audit$config)),
                      file.path(cohort_dir, "cohort_config.R"))
  }
  if (!is.null(scan$metadata_overlay_audit)) {
    .scan_write_csv(scan$metadata_overlay_audit,
                    file.path(output_dir, "00_cohort", "metadata_overlay_changes.csv"))
  }
  if (!is.null(scan$metadata_target_audit)) {
    metadata_target_dir <- file.path(output_dir, "00_metadata_target")
    .scan_write_csv(scan$metadata_target_audit$summary,
                    file.path(metadata_target_dir, "summary.csv"))
    .scan_write_csv(scan$metadata_target_audit$cutoff_readiness,
                    file.path(metadata_target_dir, "cutoff_readiness.csv"))
    .scan_write_csv(scan$metadata_target_audit$project_readiness,
                    file.path(metadata_target_dir, "project_readiness.csv"))
    .scan_write_csv(scan$metadata_target_audit$sample_assignments,
                    file.path(metadata_target_dir, "sample_group_assignments.csv.gz"))
    .scan_write_csv(scan$metadata_target_audit$level_counts,
                    file.path(metadata_target_dir, "available_level_counts.csv"))
    .scan_write_lines(utils::capture.output(dput(scan$metadata_target_audit$config)),
                      file.path(metadata_target_dir, "contrast_config.R"))
  }
  project_dir <- file.path(output_dir, "01_project")
  .scan_write_csv(scan$project_qc, file.path(project_dir, "project_qc.csv"))
  .scan_write_csv(scan$target_qc, file.path(project_dir, "target_qc.csv"))
  .scan_write_csv(scan$target_scores, file.path(project_dir, "target_scores.csv.gz"))
  if (!is.null(scan$metadata_target_project_effects)) {
    .scan_write_csv(scan$metadata_target_project_effects,
                    file.path(project_dir, "metadata_target_project_effects.csv.gz"))
  }
  .scan_write_csv(.scan_decorate(scan$project_correlations, scan, enrichment),
                  file.path(output_dir, "02_correlations", "project_correlations.csv.gz"))
  .scan_write_csv(.scan_decorate(scan$meta_analysis, scan, enrichment),
                  file.path(output_dir, "03_meta_analysis", "full_statistical_audit.csv.gz"))
  passing <- scan$meta_analysis[scan$meta_analysis$evidence_class %in%
                                  c("Core tracker", "Supported tracker",
                                    "Context-dependent signal"), , drop = FALSE]
  .scan_write_csv(.scan_decorate(passing, scan, enrichment),
                  file.path(output_dir, "03_meta_analysis", "all_passing_modes.csv"))
  relation_dir <- file.path(output_dir, "04_relationships")
  .scan_write_csv(.scan_decorate(scan$cross_cutoff, scan, enrichment),
                  file.path(relation_dir, "cross_cutoff.csv"))
  .scan_write_csv(.scan_decorate(scan$gene_summary, scan, enrichment),
                  file.path(relation_dir, "gene_summary.csv"))
  .scan_write_csv(.scan_decorate(scan$relationships, scan, enrichment),
                  file.path(relation_dir, "all_relationships.csv.gz"))
  .scan_write_csv(scan$denominators, file.path(relation_dir, "denominators.csv"))
  for (cutoff in scan$config$min_samples_per_project) {
    x <- scan$relationships[scan$relationships$cutoff == cutoff &
                              scan$relationships$persistent %in% TRUE, , drop = FALSE]
    .scan_write_csv(.scan_decorate(x, scan, enrichment),
                    file.path(relation_dir, paste0("n", cutoff, "_selected.csv")))
  }
  if (!is.null(enrichment)) {
    enrich_dir <- file.path(output_dir, "05_enrichment")
    tables <- list(
      selection = enrichment$selection, exact_ora = enrichment$exact$ora,
      gene_annotations = enrichment$gene_annotations,
      exact_ranked = enrichment$exact$ranked, exact_summary = enrichment$exact$summary,
      study_ranked = enrichment$studies$ranked, study_rank_audit = enrichment$studies$audit
    )
    if (.scan_has_curated(enrichment)) tables <- c(tables, list(
      theme_dictionary = enrichment$themes$dictionary,
      theme_term_mapping = enrichment$themes$term_mapping,
      theme_membership = enrichment$themes$membership,
      theme_ora = enrichment$themes$ora, theme_ranked = enrichment$themes$ranked,
      theme_summary = enrichment$themes$summary,
      iron_exact_terms = enrichment$iron$exact_terms,
      iron_themes = enrichment$iron$themes
    ))
    for (name in names(tables)) {
      .scan_write_csv(tables[[name]], file.path(enrich_dir, paste0(name, ".csv")))
    }
    .scan_write_lines(utils::capture.output(dput(enrichment$config)),
                      file.path(audit, "enrichment_config.R"))
    saveRDS(enrichment, file.path(audit, "pa_scan_enrichment.rds"), compress = "xz")
  }
  files <- c(report_directory = normalizePath(output_dir, winslash = "/"))
  if (isTRUE(workbook)) {
    workbook_path <- file.path(output_dir, "paannotate_target_scan_report.xlsx")
    made <- .scan_write_workbook(scan, enrichment, workbook_path, maximum_excel_rows)
    if (!is.null(made)) files <- c(files, workbook = made)
  }
  if (isTRUE(heatmaps)) {
    made <- .scan_write_heatmaps(scan, enrichment, file.path(output_dir, "06_heatmaps"),
                                 maximum_heatmap_genes, maximum_heatmap_terms)
    if (length(made)) files <- c(files, heatmaps = made)
  }
  invisible(files)
}

.scan_read_membership <- function(membership) {
  if (!is.character(membership) || length(membership) != 1L) return(membership)
  path <- path.expand(membership)
  if (!file.exists(path)) stop("Membership file not found: ", path, call. = FALSE)
  if (tolower(tools::file_ext(path)) == "rds") readRDS(path) else .read_raw_table(path)$data
}

#' Run target scanning, enrichment, and reporting in one call
#'
#' @param expression,metadata,targets,output_dir Core inputs and destination.
#' @param membership Annotation object/file; when `NULL` and `enrich=TRUE`,
#'   [fetch_pa_annotations()] supplies cached/fresh PAO1 GO and KEGG membership.
#' @param enrich Run enrichment.
#' @param curated Include paannotate's manually curated umbrella pathways.
#' @param adjustment Covariate formula.
#' @param min_samples_per_project Project sample cutoffs.
#' @param fdr,rho,i2 Convenient core evidence thresholds.
#' @param scan_args,enrichment_args,report_args Additional named arguments for
#'   [pa_scan_targets()], [pa_enrich_scan()], and [pa_write_scan()].
#' @return A `pa_scan_pipeline` object containing analysis objects and paths.
#' @export
pa_run_scan <- function(
    expression, metadata, targets, output_dir, membership = NULL, enrich = TRUE,
    curated = FALSE,
    adjustment = NULL, min_samples_per_project = 6,
    fdr = 0.05, rho = 0.30, i2 = 75,
    scan_args = list(), enrichment_args = list(), report_args = list()) {
  if (!is.list(scan_args) || !is.list(enrichment_args) || !is.list(report_args)) {
    stop("scan_args, enrichment_args, and report_args must be named lists.", call. = FALSE)
  }
  defaults <- list(
    expression = expression, metadata = metadata, targets = targets,
    adjustment = adjustment, min_samples_per_project = min_samples_per_project,
    thresholds = pa_scan_thresholds(fdr = fdr, rho = rho, i2 = i2)
  )
  scan_call <- utils::modifyList(defaults, scan_args)
  scan <- do.call(pa_scan_targets, scan_call)
  enriched <- NULL
  if (isTRUE(enrich)) {
    if (is.null(membership)) membership <- fetch_pa_annotations()
    membership <- .scan_read_membership(membership)
    enriched <- do.call(pa_enrich_scan, utils::modifyList(
      list(scan = scan, membership = membership, curated = curated), enrichment_args
    ))
  }
  files <- do.call(pa_write_scan, utils::modifyList(
    list(scan = scan, enrichment = enriched, output_dir = output_dir), report_args
  ))
  structure(list(scan = scan, enrichment = enriched, files = files),
            class = "pa_scan_pipeline")
}

#' Run a complete target scan from YAML
#'
#' @param config_file YAML configuration path. See the packaged
#'   `target_scan_config.yml`, `whiteley_target_scan_config.yml`, and
#'   `whiteley_metadata_target_config.yml` examples.
#' @return A `pa_scan_pipeline` object.
#' @export
pa_run_scan_config <- function(config_file) {
  if (!requireNamespace("yaml", quietly = TRUE)) {
    stop("YAML configuration requires the optional 'yaml' package.", call. = FALSE)
  }
  config_file <- normalizePath(path.expand(config_file), winslash = "/", mustWork = TRUE)
  config <- yaml::read_yaml(config_file)
  base <- dirname(config_file)
  resolve <- function(path) {
    if (is.null(path) || !is.character(path) || length(path) != 1L) return(path)
    if (!grepl("^(/|[A-Za-z]:)", path)) path <- file.path(base, path)
    path
  }
  metadata_target_enabled <- isTRUE(config$metadata_target$enabled)
  targets <- NULL
  if (!metadata_target_enabled) {
    target_config <- config$targets
    if (is.null(target_config)) {
      stop("Configuration must contain targets, or enable metadata_target.",
           call. = FALSE)
    }
    if (!is.null(target_config$table)) {
      targets <- pa_targets(table = resolve(target_config$table),
                            score_method = .scan_or(target_config$score_method, "mean_z"),
                            id_policy = .scan_or(target_config$id_policy, "pao1_exact"))
    } else {
      individual <- unlist(target_config$individual, use.names = TRUE)
      sets <- target_config$sets
      targets <- pa_targets(
        individual = if (length(individual)) individual else NULL,
        sets = sets, score_method = .scan_or(target_config$score_method, "mean_z"),
        id_policy = .scan_or(target_config$id_policy, "pao1_exact")
      )
    }
  }
  scan_args <- .scan_or(config$scan, list())
  if (!is.null(scan_args$adjustment) && is.character(scan_args$adjustment)) {
    scan_args$adjustment <- stats::as.formula(scan_args$adjustment)
  }
  if (!is.null(scan_args$thresholds)) {
    scan_args$thresholds <- do.call(pa_scan_thresholds, scan_args$thresholds)
  }
  membership <- if (!is.null(config$annotations$membership))
    resolve(config$annotations$membership) else NULL
  output_dir <- resolve(.scan_or(config$report$output_dir, "paannotate_target_scan_report"))
  report_args <- .scan_or(config$report[setdiff(names(config$report), "output_dir")], list())
  enrichment_args <- .scan_or(
    config$enrichment[setdiff(names(config$enrichment), "enabled")], list())
  if (isTRUE(config$whiteley$enabled)) {
    whiteley_args <- .scan_or(
      config$whiteley[setdiff(names(config$whiteley), "enabled")], list())
    for (field in intersect(c("cache_dir", "release_archive", "counts_file",
                              "metadata_file", "datasummary_file", "metadata_overlay"),
                            names(whiteley_args))) {
      whiteley_args[[field]] <- resolve(whiteley_args[[field]])
    }
    call <- utils::modifyList(whiteley_args, scan_args)
    if (metadata_target_enabled) {
      metadata_target_args <- .scan_or(
        config$metadata_target[
          setdiff(names(config$metadata_target), "enabled")
        ], list()
      )
      call <- utils::modifyList(call, metadata_target_args)
      call <- utils::modifyList(call, list(
        output_dir = output_dir, membership = membership,
        enrich = .scan_or(config$enrichment$enabled, TRUE),
        enrichment_args = enrichment_args, report_args = report_args
      ))
      return(do.call(pa_run_whiteley_metadata, call))
    }
    call <- utils::modifyList(call, list(
      targets = targets, output_dir = output_dir, membership = membership,
      enrich = .scan_or(config$enrichment$enabled, TRUE),
      enrichment_args = enrichment_args, report_args = report_args
    ))
    return(do.call(pa_run_whiteley, call))
  }
  if (metadata_target_enabled) {
    stop("metadata_target currently requires whiteley.enabled: true.",
         call. = FALSE)
  }
  if (is.null(config$expression$path) || is.null(config$metadata$path)) {
    stop("Generic scan configuration requires expression.path and metadata.path; set whiteley.enabled: true for the built-in target-only cohort.",
         call. = FALSE)
  }
  expression <- resolve(config$expression$path)
  metadata <- resolve(config$metadata$path)
  scan_args <- utils::modifyList(
    config$expression[setdiff(names(config$expression), "path")], scan_args)
  metadata_args <- config$metadata[setdiff(names(config$metadata), "path")]
  if (!is.null(metadata_args$sheet)) {
    metadata_args$metadata_sheet <- metadata_args$sheet
    metadata_args$sheet <- NULL
  }
  scan_args <- utils::modifyList(metadata_args, scan_args)
  pa_run_scan(
    expression = expression, metadata = metadata, targets = targets,
    output_dir = output_dir, membership = membership,
    enrich = .scan_or(config$enrichment$enabled, TRUE),
    scan_args = scan_args,
    enrichment_args = enrichment_args,
    report_args = report_args
  )
}

#' @export
print.pa_scan_pipeline <- function(x, ...) {
  print(x$scan)
  if (!is.null(x$enrichment)) print(x$enrichment)
  cat("  report:", unname(x$files["report_directory"]), "\n")
  invisible(x)
}
