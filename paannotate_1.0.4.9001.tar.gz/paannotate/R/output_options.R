# Selected deliverables; complete analysis/checkpoints stay in application storage.
.p2c_write_selected_scan <- function(scan,enrichment,output_dir,internal_dir,options,
                                     maximum_excel_rows=200000,maximum_heatmap_genes=60,maximum_heatmap_terms=40){
  defaults <- list(formats=c('pdf','png'),figure_types=c('genes','pathways','activity'),figure_scope='combined',
    workbook=TRUE,tables=TRUE,details=FALSE,audits=FALSE,methods=TRUE,editable=TRUE,json=FALSE)
  options <- utils::modifyList(defaults,options)
  # Earlier completed runs can have valid study ranks but no pooled enrichment.
  # Re-export repairs that missing branch from the frozen saved analysis.
  if(!is.null(enrichment) && is.null(enrichment$config$study_enrichment_version) &&
     !any(is.finite(scan$meta_analysis$meta_rho))) {
    args <- enrichment$config[intersect(names(enrichment$config),names(formals(pa_enrich_scan)))]
    enrichment <- do.call(pa_enrich_scan,c(list(scan=scan,membership=enrichment$exact$membership),args))
  }
  if(is.null(internal_dir))stop('Selected output generation needs an application working directory.')
  dir.create(internal_dir,recursive=TRUE,showWarnings=FALSE)
  dir.create(output_dir,recursive=TRUE,showWarnings=FALSE)
  .p2c_progress('reports','Saving editable analysis and summary tables')
  saveRDS(list(scan=scan,enrichment=enrichment),file.path(internal_dir,'Editable_analysis.rds'),compress='xz')
  .p2c_write_member_index(scan,enrichment,internal_dir)
  files <- character()
  csv <- function(data,name){if(is.data.frame(data)){group<-if(grepl('Study_correlations|Study_pathway_correlations',name))'02_correlations' else if(grepl('Complete_meta_analysis|Pathway_activity|Cross_cutoff',name))'03_meta_analysis' else if(grepl('Pathway_|Theme_|Iron_|Enrichment_selection',name))'05_enrichment' else if(grepl('Gene_summary|Selected_relationships|All_relationships|Denominators',name))'04_relationships' else if(grepl('Study_QC|Target_QC|Target_scores',name))'01_project' else '00_audit';path<-file.path(output_dir,group,paste0(name,'.csv'));dir.create(dirname(path),recursive=TRUE,showWarnings=FALSE);.scan_write_csv(data,path);files<<-c(files,path)}}
  if(isTRUE(options$tables)){
    csv(scan$gene_summary,'Gene_summary');csv(scan$cross_cutoff,'Cross_cutoff')
    csv(scan$relationships[scan$relationships$persistent%in%TRUE,,drop=FALSE],'Selected_relationships')
    if(!is.null(enrichment)){
      csv(enrichment$exact$summary,'Pathway_summary');csv(enrichment$exact$ora,'Pathway_ORA');csv(enrichment$exact$ranked,'Pathway_ranked')
      csv(enrichment$studies$ranked,'Pathway_study_ranked')
      csv(enrichment$studies$audit,'Pathway_study_rank_audit')
      if(.scan_has_curated(enrichment)){csv(enrichment$themes$summary,'Theme_summary');csv(enrichment$themes$ora,'Theme_ORA');csv(enrichment$themes$ranked,'Theme_ranked');csv(enrichment$iron$exact_terms,'Iron_exact_terms');csv(enrichment$iron$themes,'Iron_themes')}
    }
    csv(scan$pathway_meta_analysis,'Pathway_activity')
  }
  if(isTRUE(options$details)){
    csv(scan$meta_analysis,'Complete_meta_analysis');csv(scan$project_correlations,'Study_correlations')
    csv(scan$target_scores,'Target_scores');csv(scan$relationships,'All_relationships')
    csv(scan$pathway_project_correlations,'Study_pathway_correlations')
    csv(scan$denominators,'Denominators');if(!is.null(enrichment))csv(enrichment$selection,'Enrichment_selection')
  }
  if(isTRUE(options$audits)){
    csv(scan$project_qc,'Study_QC');csv(scan$target_qc,'Target_QC');csv(scan$targets$membership,'Target_membership')
    csv(scan$pathway_activity_audit,'Pathway_activity_membership_audit');csv(scan$pathway_membership_audit,'Pathway_enrichment_membership_audit')
    if(!is.null(scan$cohort_audit)){csv(scan$cohort_audit$summary,'Cohort_summary');csv(scan$cohort_audit$selection,'Sample_selection')}
    if(!is.null(enrichment)){
      csv(enrichment$gene_annotations,'Gene_annotations')
      if(.scan_has_curated(enrichment)){csv(enrichment$themes$dictionary,'Theme_dictionary');csv(enrichment$themes$term_mapping,'Theme_term_mapping');csv(enrichment$themes$membership,'Theme_membership')}
    }
  }
  if(isTRUE(options$methods)){
    path<-file.path(output_dir,'00_audit','Methods.txt');dir.create(dirname(path),recursive=TRUE,showWarnings=FALSE)
    writeLines(c('Paannotate Whiteley analysis',utils::capture.output(dput(scan$config)),
      'Evidence thresholds',utils::capture.output(dput(as.list(scan$thresholds))),
      'Enrichment settings',utils::capture.output(dput(enrichment$config)),scan$pathway_activity_method),path)
    if(is.data.frame(enrichment$studies$ranked) && nrow(enrichment$studies$ranked))write('Study-specific enrichment uses complete signed normal scores from saved two-sided gene correlation P values. BH family: all pathways and targets within study/mode/method. Global BH: all study enrichment tests across studies, modes and targets. These results are not pooled evidence. FGSEA is a competitive ranked gene-set test; it does not model inter-gene correlation. Seeds and rank tie fractions are saved in Pathway_study_rank_audit.csv.',path,append=TRUE)
    files<-c(files,path)
  }
  if(isTRUE(options$workbook)){
    path<-file.path(output_dir,'Whiteley_results.xlsx');made<-.scan_write_workbook(scan,enrichment,path,maximum_excel_rows)
    if(!is.null(made))files<-c(files,made)
  }
  sources <- .p2c_result_heatmaps(scan,enrichment,file.path(internal_dir,'Figure_sources'),maximum_heatmap_genes,maximum_heatmap_terms)
  subset_source <- function(source,columns,preserve=FALSE){
    m<-do.call(rbind,lapply(source$values,function(row)vapply(row,function(v)if(is.null(v))NA_real_ else as.numeric(v),numeric(1))));if(is.null(dim(m)))m<-matrix(m,ncol=length(source$column_ids))
    m<-m[,columns,drop=FALSE];strength<-apply(abs(m),1,function(v)if(any(is.finite(v)))max(v,na.rm=TRUE) else -Inf)
    rows<-if(preserve)seq_along(source$row_ids) else head(order(-strength,unlist(source$row_ids)),min(400,source$default_top_n));rows<-rows[is.finite(strength[rows])]
    if(!length(rows))return(NULL)
    for(k in intersect(c('row_ids','row_labels','row_metadata'),names(source)))source[[k]]<-source[[k]][rows]
    for(k in intersect(c('column_ids','column_labels'),names(source)))source[[k]]<-source[[k]][columns]
    for(k in intersect(c('values','adjusted_p','pvalues','sample_counts','study_counts'),names(source)))source[[k]]<-lapply(rows,function(i)source[[k]][[i]][columns])
    source
  }
  status<-list(meta_evaluable=sum(is.finite(scan$meta_analysis$meta_rho)),
    minimum_meta_projects=scan$thresholds$minimum_meta_projects,
    study_correlations=sum(is.finite(scan$project_correlations$rho)),rendered=0L,skipped=0L)
  status$message<-if(status$meta_evaluable==0L)paste0('No combined estimates meet the minimum of ',status$minimum_meta_projects,
    ' independent studies. Available figures show individual-study correlations and pathway enrichment when evaluable; they are not combined evidence.') else 'Combined and individual-study estimates are available.'
  source_number<-0L
  .p2c_progress('figures','Rendering saved statistical figures',0,length(sources),'figure sources')
  for(path in sources){
    source_number<-source_number+1L
    .p2c_progress('figures',paste('Rendering',basename(path)),source_number-1L,length(sources),'figure sources')
    source<-jsonlite::fromJSON(path,simplifyVector=FALSE)
    edit<-options$figure_edits[[basename(path)]]
    if(!is.null(edit))source<-edit$source
    category<-if(grepl('pathway_activity',basename(path),fixed=TRUE))'activity' else source$kind
    if(!category%in%unlist(options$figure_types))next
    name<-sub('[.]heatmap[.]json$','',basename(path));dir.create(file.path(output_dir,'06_heatmaps',if(category=='activity')'pathway_activity' else category),recursive=TRUE,showWarnings=FALSE)
    if(isTRUE(options$json)){target<-file.path(output_dir,'06_heatmaps',if(category=='activity')'pathway_activity' else category,basename(path));file.copy(path,target,overwrite=TRUE);files<-c(files,target)}
    if(!length(options$formats))next
    groups<-list()
    if(options$figure_scope%in%c('combined','both'))groups[['combined']]<-seq_along(source$column_ids)
    if(options$figure_scope%in%c('individual','both'))for(i in seq_along(source$column_ids))groups[[paste0('target_',i,'_',.scan_slug(source$column_ids[[i]]))]]<-i
    for(group in names(groups)){
      selected<-subset_source(source,groups[[group]],!is.null(edit));if(is.null(selected)){status$skipped<-status$skipped+1L;next}
      status$rendered<-status$rendered+1L
      files<-c(files,.p2c_render_heatmap(selected,utils::modifyList(if(is.null(edit))list() else edit$style,list(formats=unlist(options$formats))),file.path(output_dir,'06_heatmaps',if(category=='activity')'pathway_activity' else category,paste0(name,'_',group))))
    }
  }
  if(isTRUE(options$json)){
    path<-file.path(output_dir,'00_audit','Analysis_settings.json');dir.create(dirname(path),recursive=TRUE,showWarnings=FALSE);public_options<-options;public_options$figure_edits<-NULL;jsonlite::write_json(list(config=scan$config,thresholds=unclass(scan$thresholds),outputs=public_options),path,auto_unbox=TRUE,pretty=TRUE);files<-c(files,path)
  }
  jsonlite::write_json(status,file.path(internal_dir,'Figure_status.json'),auto_unbox=TRUE,pretty=TRUE)
  .p2c_progress('publishing','Saving figures and indexing results')
  invisible(c(report_directory=normalizePath(output_dir),files))
}
