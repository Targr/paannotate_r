.pa_function_registry <- function() {
  data.frame(
    function_name = c(
      "pa_help", "pa_check_setup", "pa_check_input", "pa_read", "pa_combine",
      "fetch_pseudocap_annotations", "fetch_pa_annotations",
      "fetch_whiteley_release", "import_whiteley", "analyze_pa_csv", "pa_run",
      "pa_run_custom",
      "pa_enrich_bias", "pa_enrich_ranked", "pa_targets",
      "pa_scan_thresholds", "pa_check_scan", "pa_scan_targets",
      "pa_load_whiteley", "pa_check_whiteley_cohort", "pa_scan_whiteley", "pa_run_whiteley",
      "pa_metadata_coverage", "pa_build_accession_graph",
      "pa_fetch_whiteley_metadata", "pa_export_metadata_queue",
      "pa_validate_metadata", "pa_merge_metadata_overlay",
      "pa_check_whiteley_metadata_target", "pa_scan_whiteley_metadata",
      "pa_run_whiteley_metadata",
      "pa_enrich_scan", "pa_focus_pathways", "pa_write_scan", "pa_run_scan",
      "pa_run_scan_config"
    ),
    use = c(
      "List functions or show a beginner workflow.",
      "Check whether optional enrichment packages are installed.",
      "Preview orientation, aliases, identifier choice, and dimensions.",
      "Read a normal or transposed CSV/TSV/Excel table.",
      "Safely join expression and statistics files by gene ID.",
      "Import a PseudoCAP/Pseudomonas Genome Database export.",
      "Fetch KEGG/UniProt-GOA and merge optional PseudoCAP annotations.",
      "Download and unpack the Whiteley Lab released raw dataset.",
      "Import a Whiteley count/TPM matrix and sample metadata.",
      "Run the original compatible annotation and enrichment workflow.",
      "Beginner wrapper for one-file or two-file analyses.",
      "Run one custom dataset through correlation, comparison, or existing-results analysis.",
      "Run goseq-style selection-bias-aware over-representation analysis.",
      "Run full-ranked CAMERA/CAMERA-PR or fgsea enrichment.",
      "Define individual genes or named multi-gene signatures.",
      "Set FDR, rho, I2, project-count, direction, and stability rules.",
      "Preflight expression, metadata, project, sample, ID, and target coverage.",
      "Run project correlations and random-effects meta-analysis.",
      "Load/cache the full Whiteley release or frozen 414-sample preset.",
      "Preview Whiteley strain/media/context filters without running correlations.",
      "Scan Whiteley using only target genes and thresholds as user inputs.",
      "Run Whiteley scan, enrichment, workbook, and heatmaps in one call.",
      "Measure which Whiteley metadata fields and projects most need curation.",
      "Link samples to BioSample, BioProject, SRA, GEO, and PubMed accessions.",
      "Cache machine-readable public metadata as review candidates.",
      "Make a project-by-project Excel workbook for human metadata review.",
      "Check review keys, values, provenance, and protected fields before use.",
      "Apply approved metadata edits as an auditable versioned overlay.",
      "Preview whether two metadata levels can be compared within BioProjects.",
      "Test every gene against a replicated Whiteley metadata contrast.",
      "Run a metadata contrast through gene testing, enrichment, and heatmaps.",
      "Enrich scan results for exact pathways, umbrellas, and iron systems.",
      "Make focused pathway tables and figures without rerunning a scan.",
      "Write audit tables, Excel report, and PNG/PDF heatmaps.",
      "Run the complete scan-to-report workflow in one R call.",
      "Run the complete workflow from a portable YAML configuration."
    ),
    example = c(
      "pa_help('workflow')", "pa_check_setup()", "pa_check_input('results.csv')",
      "pa_read('results.csv', orientation='auto')",
      "pa_combine('counts.csv', 'stats.csv')",
      "fetch_pseudocap_annotations('PAO1.csv')",
      "fetch_pa_annotations(pseudocap_file='PAO1.csv')",
      "fetch_whiteley_release()", "import_whiteley('TPM.csv', data_type='tpm')",
      "analyze_pa_csv('results.csv', c('A1','A2'), c('B1','B2'))",
      "pa_run('counts.csv', c('A1','A2'), c('B1','B2'), statistics_file='stats.csv')",
      "pa_run_custom('counts.csv', 'report', metadata='samples.csv', condition='treatment', comparison=c('treated','control'))",
      "pa_enrich_bias(result$all_genes, result$annotation_membership)",
      "pa_enrich_ranked(result$all_genes, result$annotation_membership)",
      "pa_targets(individual=c(Pf='PA0728'), sets=list(Pf_block=c('PA0728','PA0729')))",
      "pa_scan_thresholds(fdr=.05, rho=.30, i2=75)",
      "pa_check_scan(expression, metadata, targets)",
      "pa_scan_targets(expression, metadata, targets, min_samples_per_project=c(6,7,8))",
      "pa_load_whiteley()",
      "pa_check_whiteley_cohort(strains='PAO1', media='LB')",
      "pa_scan_whiteley(c('PA0723','PA2384'), target_name='my_signature')",
      "pa_run_whiteley('PA0723', 'whiteley_report')",
      "pa_metadata_coverage(output_dir='metadata_coverage')",
      "pa_build_accession_graph(output_file='accession_graph.csv.gz')",
      "pa_fetch_whiteley_metadata(maximum_records=20)",
      "pa_export_metadata_queue(candidates=harvest)",
      "pa_validate_metadata('whiteley_metadata_review.xlsx')",
      "pa_merge_metadata_overlay(base, 'whiteley_metadata_review.xlsx')",
      "pa_check_whiteley_metadata_target('medium', 'M9', 'SCFM')",
      "pa_scan_whiteley_metadata('medium', 'M9', 'SCFM')",
      "pa_run_whiteley_metadata('medium', 'M9', 'SCFM', 'M9_vs_SCFM')",
      "pa_enrich_scan(scan, annotations)",
      "pa_focus_pathways(result, focus='iron')",
      "pa_write_scan(scan, enrichment, 'report')",
      "pa_run_scan(expression, metadata, targets, 'report')",
      "pa_run_scan_config('target_scan.yml')"
    ),
    stringsAsFactors = FALSE
  )
}

#' Beginner help for paannotate
#'
#' Lists all public functions and their uses. Use `pa_help("workflow")` for a
#' copyable workflow or `pa_help("enrichment")` for method selection guidance.
#' Standard R help remains available, for example `?pa_combine`.
#'
#' @param topic `NULL`, `"workflow"`, `"input"`, `"references"`,
#'   `"enrichment"`, `"target_scan"`, or `"metadata"`.
#' @return Invisibly, the function registry.
#' @export
pa_help <- function(topic = NULL) {
  registry <- .pa_function_registry()
  if (is.null(topic) || identical(topic, "functions")) {
    cat("paannotate public functions\n\n")
    print(registry, row.names = FALSE, right = FALSE)
    cat("\nTry pa_help('target_scan'), pa_help('metadata'), pa_help('workflow'), pa_help('input'), pa_help('references'), or pa_help('enrichment').\n")
  } else {
    topic <- match.arg(tolower(topic), c("workflow", "input", "references",
                                         "enrichment", "target_scan", "metadata"))
    text <- switch(
      topic,
      workflow = c(
        "One custom dataset, one main function:",
        "",
        "Which genes and pathways track with a target gene?",
        "  result <- pa_run_custom('expression.xlsx', 'PA0719_report',",
        "                          targets='PA0719')",
        "",
        "Which genes and pathways differ between two conditions?",
        "  result <- pa_run_custom('counts.xlsx', 'treated_report',",
        "                          metadata='samples.xlsx', condition='treatment',",
        "                          comparison=c('treated','control'))",
        "",
        "Already have DESeq2, edgeR, or limma gene results?",
        "  result <- pa_run_custom('results.csv', 'existing_results_report')",
        "",
        "Canonical GO/KEGG terms are shown by default. Add curated=TRUE only",
        "when you also want paannotate's optional umbrella pathways."
      ),
      input = c(
        "For genes stored across columns:",
        "  pa_read('odd.csv', orientation='genes_in_columns')",
        "For unusual column names:",
        "  pa_read('odd.csv', column_map=c(gene_id='Locus', padj='FDR', log2FoldChange='logFC'))",
        "For separate files:",
        "  pa_combine('counts.csv', 'stats.csv', minimum_match=0.8)"
      ),
      references = c(
        "PseudoCAP/Pseudomonas Genome Database:",
        "  pseudo <- fetch_pseudocap_annotations('PAO1_annotations.csv')",
        "Whiteley Lab database:",
        "  whiteley <- pa_load_whiteley() # full release by default",
        "  legacy <- pa_load_whiteley('whiteley_pao1_414_v1') # frozen preset",
        "  released <- fetch_whiteley_release() # lower-level release access",
        "  custom <- import_whiteley('TPM.csv', 'metadata.csv', data_type='tpm')",
        "Pass pseudocap_file and whiteley_reference to pa_run() or analyze_pa_csv()."
      ),
      enrichment = c(
        "Use both methods because they answer different questions:",
        "  pa_enrich_bias(...)   # selected genes, adjusted for length/expression bias",
        "  pa_enrich_ranked(..., method='camera_pr') # all genes + correlation assumption",
        "  pa_enrich_ranked(..., method='camera', expression=log_expr, design=design, inter_gene_cor=NA)",
        "The full camera form estimates within-set correlation from normalized log-expression.",
        "fgsea is available as a ranked sensitivity analysis but does not model inter-gene correlation.",
        "Canonical database terms are the default; curated=TRUE adds optional paannotate umbrella pathways."
      ),
      metadata = c(
        "Reviewable Whiteley metadata workflow (counts are never rebuilt):",
        "  base <- pa_load_whiteley(metadata_only=TRUE)",
        "  pa_metadata_coverage(base, output_dir='metadata_coverage')",
        "  graph <- pa_build_accession_graph(base, 'accession_graph.csv.gz')",
        "  harvest <- pa_fetch_whiteley_metadata(graph, maximum_records=20)",
        "  pa_export_metadata_queue(base, harvest, output_file='metadata_review.xlsx')",
        "  pa_validate_metadata('metadata_review.xlsx', base)",
        "  overlay <- pa_merge_metadata_overlay(base, 'metadata_review.xlsx',",
        "                                       metadata_version='lab_review_2026_01')",
        "  pa_run_whiteley('PA0723', 'report', metadata_overlay=overlay)",
        "Only approved, nonblank review_* values are applied; every changed cell is audited.",
        "Test a reviewed metadata contrast:",
        "  pa_check_whiteley_metadata_target('medium', 'M9', 'SCFM',",
        "                                     metadata_overlay=overlay)",
        "  pa_run_whiteley_metadata('medium', 'M9', 'SCFM', 'M9_vs_SCFM',",
        "                            metadata_overlay=overlay)"
      ),
      target_scan = c(
        "Built-in Whiteley target-only workflow (no metadata upload):",
        "  pa_check_whiteley_cohort(strains='PAO1', media=c('LB','M9'))",
        "  result <- pa_run_whiteley(",
        "    targets=c('PA0723','PA2384'), target_name='my_signature',",
        "    output_dir='whiteley_report', min_samples_per_project=c(6,7,8),",
        "    fdr=.05, rho=.30, i2=75",
        "  )",
        "Set use_curated_414=TRUE for exact compatibility with the old cohort.",
        "Compare two replicated metadata levels within projects:",
        "  pa_check_whiteley_metadata_target('medium', 'M9', 'SCFM')",
        "  pa_run_whiteley_metadata('medium', 'M9', 'SCFM', 'M9_vs_SCFM')",
        "One custom dataset (no project meta-analysis):",
        "  pa_run_custom('expression.xlsx', 'custom_report', targets='PA0719')",
        "Use condition= plus comparison=c('treated','control') for a two-group experiment.",
        "",
        "Advanced workflow for a different multi-project compendium:",
        "  targets <- pa_targets(individual=c(Pf='PA0728'),",
        "                        sets=list(Pf_block=c('PA0728','PA0729')))",
        "  pa_check_scan('expression.xlsx', 'metadata.xlsx', targets)",
        "  result <- pa_run_scan(",
        "    'expression.xlsx', 'metadata.xlsx', targets, 'scan_report',",
        "    min_samples_per_project=c(6,7,8), fdr=.05, rho=.30, i2=75",
        "  )",
        "Make a smaller pathway report afterward without rerunning the scan:",
        "  pa_focus_pathways(result, focus='iron')",
        "  pa_focus_pathways(result, focus=list(Secretion=c('type III secretion','type VI secretion')))",
        "Use whiteley_target_scan_config.yml for gene targets or",
        "whiteley_metadata_target_config.yml for a metadata comparison in YAML."
      )
    )
    cat(paste(text, collapse = "\n"), "\n")
  }
  invisible(registry)
}

#' Check optional paannotate capabilities
#'
#' @return A data frame showing whether optional enrichment packages exist.
#' @export
pa_check_setup <- function() {
  packages <- c("goseq", "limma", "fgsea", "edgeR", "openxlsx", "pheatmap", "yaml")
  result <- data.frame(
    capability = c("bias-aware enrichment", "correlation-aware ranked enrichment",
                   "fast ranked sensitivity analysis", "raw-count normalization",
                   "Excel scan reports", "scan heatmaps", "YAML scan configuration"),
    package = packages,
    installed = vapply(packages, requireNamespace, logical(1), quietly = TRUE),
    stringsAsFactors = FALSE
  )
  bioconductor <- result$package %in% c("goseq", "limma", "fgsea", "edgeR")
  result$install <- ifelse(result$installed, "ready", ifelse(
    bioconductor, paste0("BiocManager::install('", result$package, "')"),
    paste0("install.packages('", result$package, "')")
  ))
  print(result, row.names = FALSE)
  invisible(result)
}

#' Beginner one-file or two-file PAO1 workflow
#'
#' Combines files when needed, optionally imports a Whiteley reference, and
#' delegates to [analyze_pa_csv()]. By default it adds a full-ranked,
#' correlation-aware CAMERA-PR result while preserving the legacy thresholded
#' Fisher enrichment tables.
#'
#' @param expression_file Expression file.
#' @param group_a_samples,group_b_samples Sample columns for the two groups.
#' @param statistics_file Optional separate statistics file.
#' @param output_dir Output directory.
#' @param orientation,statistics_orientation File orientations.
#' @param pseudocap_file Optional PseudoCAP export.
#' @param whiteley_counts_file,whiteley_metadata_file Optional Whiteley files.
#' @param whiteley_data_type `"auto"`, `"raw_counts"`, or `"tpm"`.
#' @param bias_adjust Run bias-aware goseq enrichment.
#' @param ranked_method `"camera_pr"`, `"fgsea"`, or `"none"`.
#' @param ... Additional arguments for [analyze_pa_csv()].
#' @return The analysis result list.
#' @export
pa_run <- function(
    expression_file, group_a_samples, group_b_samples,
    statistics_file = NULL, output_dir = NULL,
    orientation = c("auto", "genes_in_rows", "genes_in_columns"),
    statistics_orientation = c("auto", "genes_in_rows", "genes_in_columns"),
    pseudocap_file = NULL, whiteley_counts_file = NULL,
    whiteley_metadata_file = NULL,
    whiteley_data_type = c("auto", "raw_counts", "tpm"),
    bias_adjust = FALSE, ranked_method = "camera_pr", ...) {
  orientation <- match.arg(orientation)
  statistics_orientation <- match.arg(statistics_orientation)
  whiteley_data_type <- match.arg(whiteley_data_type)
  input <- if (is.null(statistics_file)) {
    pa_read(expression_file, orientation = orientation)
  } else {
    pa_combine(
      expression_file, statistics_file,
      expression_orientation = orientation,
      statistics_orientation = statistics_orientation
    )
  }
  whiteley <- if (is.null(whiteley_counts_file)) NULL else
    import_whiteley(whiteley_counts_file, whiteley_metadata_file,
                    data_type = whiteley_data_type)
  arguments <- c(
    list(
      input_file = input, group_a_samples = group_a_samples,
      group_b_samples = group_b_samples, output_dir = output_dir,
      pseudocap_file = pseudocap_file, whiteley_reference = whiteley,
      bias_adjust = bias_adjust, ranked_method = ranked_method
    ),
    list(...)
  )
  do.call(analyze_pa_csv, arguments)
}
