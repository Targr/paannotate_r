# Complete, method-specific figure sources. Selection and styling never refit tests.
.p2c_table_heatmap <- function(data, directory, name, title, statistic, kind,
                              q_definition, default_n=30, limit=NULL) {
  if(!is.data.frame(data) || !nrow(data))return(character())
  required <- c('row_id','row_label','column_id','column_label','value')
  if(length(setdiff(required,names(data))))stop('Incomplete heatmap result table.')
  if(anyDuplicated(paste(data$row_id,data$column_id,sep='\r')))stop('Ambiguous heatmap cells: choose one method, cutoff and analysis mode.')
  rows <- unique(as.character(data$row_id));cols <- unique(as.character(data$column_id))
  matrix_for <- function(key){
    m <- matrix(NA_real_,length(rows),length(cols))
    if(key %in% names(data))m[cbind(match(data$row_id,rows),match(data$column_id,cols))] <- suppressWarnings(as.numeric(data[[key]]))
    lapply(seq_len(nrow(m)),function(i)as.list(m[i,]))
  }
  first <- match(rows,data$row_id)
  metadata <- lapply(first,function(i){
    fields <- intersect(c('row_id','row_label','database','ontology','set_id','set_name','gene_names','protein_name'),names(data))
    as.list(data[i,fields,drop=FALSE])
  })
  source <- list(schema=2,title=title,statistic=statistic,kind=kind,limit=limit,
    full_results=TRUE,default_top_n=default_n,row_ids=as.list(rows),column_ids=as.list(cols),
    row_labels=as.list(as.character(data$row_label[first])),
    column_labels=as.list(as.character(data$column_label[match(cols,data$column_id)])),
    row_metadata=metadata,values=matrix_for('value'),adjusted_p=matrix_for('q'),
    pvalues=matrix_for('pvalue'),sample_counts=matrix_for('n'),study_counts=matrix_for('k'),
    significance_definition=q_definition,
    missing='Unavailable effects or significance are null; never zero-filled.',
    column_unit=if(startsWith(name,'study_'))'study\u2013target tests' else 'targets',
    source_analysis=basename(dirname(directory)))
  dir.create(directory,recursive=TRUE,showWarnings=FALSE)
  path <- file.path(directory,paste0(name,'.heatmap.json'))
  jsonlite::write_json(source,path,auto_unbox=TRUE,na='null',digits=NA,pretty=FALSE)
  path
}

.p2c_result_heatmaps <- function(analysis,enrichment,directory,maximum_genes=60,maximum_terms=40) {
  files <- character();scan <- inherits(analysis,'pa_target_scan')
  if(!is.null(enrichment))files <- c(files,.p2c_study_pathway_heatmaps(enrichment,directory,maximum_terms))
  # Study estimates remain useful when fewer than three independent studies
  # can enter the meta-analysis. Never substitute them for a combined estimate.
  study_sources <- function(d,kind,prefix,labels=NULL){
    if(!is.data.frame(d)||!nrow(d))return(character())
    answer<-character()
    for(mode in unique(d$analysis_mode)){
      x<-d[d$analysis_mode==mode,,drop=FALSE]
      x$q<-NA_real_
      for(project in unique(x$project_id)){
        idx<-which(x$project_id==project)
        x$q[idx]<-stats::p.adjust(x$pvalue[idx],method='BH')
      }
      x$row_id<-x$gene_id;x$row_label<-x$gene_id
      if(!is.null(labels))x$row_label<-labels$set_name[match(x$gene_id,labels$gene_id)]
      x$row_label[is.na(x$row_label)|!nzchar(x$row_label)]<-x$row_id[is.na(x$row_label)|!nzchar(x$row_label)]
      x$column_id<-paste(x$project_id,x$target,sep='::')
      x$column_label<-paste0(x$target,' (',x$project_id,')')
      x$value<-x$rho;x$n<-x$pairwise_samples;x$k<-1
      answer<-c(answer,.p2c_table_heatmap(x,directory,paste0(prefix,'_',mode),
        paste0(if(kind=='genes')'Gene' else 'Pathway activity','\u2013target correlations \u00b7 individual studies \u00b7 ',mode),
        'Within-study correlation (rho)',kind,
        'BH across all evaluated gene\u2013target tests (or pathway\u2013target tests for activity) within each independent study and analysis mode. These are study-specific estimates, not meta-analysis results.',
        if(kind=='genes')maximum_genes else maximum_terms,1))
    }
    answer
  }
  if(scan){
    files<-c(files,study_sources(analysis$project_correlations,'genes','study_gene_correlations'))
    labels<-analysis$pathway_meta_analysis
    files<-c(files,study_sources(analysis$pathway_project_correlations,'pathways','study_pathway_activity',labels))
    d <- analysis$meta_analysis
    if(nrow(d))for(cutoff in unique(d$cutoff))for(mode in unique(d$analysis_mode)){
      x <- d[d$cutoff==cutoff & d$analysis_mode==mode,,drop=FALSE]
      if(!nrow(x)||!any(is.finite(x$meta_rho)))next
      x$row_id <- x$gene_id;x$row_label <- x$gene_id;x$column_id <- x$target;x$column_label <- x$target
      x$value <- x$meta_rho;x$q <- x$meta_fdr;x$n <- x$contributing_samples;x$k <- x$contributing_projects
      files <- c(files,.p2c_table_heatmap(x,directory,paste0('complete_gene_correlations_',mode,'_n',cutoff),
        paste0('Gene\u2013target correlations \u00b7 ',mode,' \u00b7 minimum ',cutoff,' samples per study'),
        'Meta-analysis correlation (rho)','genes',
        'BH across every gene\u2013target test within this sample cutoff and analysis mode; original meta_fdr.',maximum_genes,1))
    }
  }else{
    x <- analysis$gene_results
    if(nrow(x)){
      x$row_id <- x$gene_id;x$row_label <- x$gene_id;x$column_id <- x$target;x$column_label <- x$target
      x$value <- x$effect;x$q <- if('fdr'%in%names(x))x$fdr else NA_real_
      x$n <- if('pairwise_samples'%in%names(x))x$pairwise_samples else analysis$sample_count
      files <- c(files,.p2c_table_heatmap(x,directory,'complete_gene_results',
        if(analysis$mode=='correlation')'Gene\u2013target correlations' else 'Gene comparison effects',
        if(analysis$mode=='correlation')'Correlation (rho)' else 'Comparison effect (log2 scale)','genes',
        if(analysis$mode=='correlation')'Original BH-adjusted gene P values within each target.' else 'Original supplied or model-adjusted gene P values; see the analysis methods.',maximum_genes,
        if(analysis$mode=='correlation')1 else NULL))
    }
  }
  if(!is.null(enrichment))for(collection in c('exact','themes')){
    part <- enrichment[[collection]]
    if(is.null(part))next
    for(method in unique(c(as.character(part$ranked$method),'ora'))){
      d <- if(method=='ora')part$ora else part$ranked[part$ranked$method==method,,drop=FALSE]
      if(!is.data.frame(d) || !nrow(d))next
      for(cutoff in unique(d$cutoff)){
        directions <- if(method=='ora')unique(d$direction) else 'ranked'
        for(direction in directions){
          x <- d[d$cutoff==cutoff,,drop=FALSE]
          if(method=='ora')x <- x[x$direction==direction,,drop=FALSE]
          if(!nrow(x))next
          x$row_id <- paste(x$database,x$ontology,x$set_id,sep='::');x$row_label <- paste0(x$set_name,' [',x$database,']')
          x$column_id <- x$target;x$column_label <- x$target;x$q <- x$global_fdr
          if(method=='fgsea'){
            x$value <- x$enrichment_score;statistic <- 'Normalized enrichment score (NES)'
          }else if(method=='ora'){
            x$value <- ifelse(x$direction=='Negative',-1,1)*log2(pmax(1,x$fold_enrichment))
            statistic <- paste0('Signed log2 overrepresentation fold enrichment \u00b7 ',direction,' gene set')
          }else{
            x$value <- sign(x$enrichment_score)*pmin(12,-log10(pmax(x$q,1e-12)))
            statistic <- 'CAMERA direction \u00d7 -log10 adjusted P (capped at 12); not a correlation or NES'
          }
          files <- c(files,.p2c_table_heatmap(x,directory,paste0('complete_',collection,'_',method,'_',tolower(direction),'_n',cutoff),
            paste0(if(collection=='exact')'Pathways' else 'Curated pathways',' \u00b7 ',method,' \u00b7 ',direction,' \u00b7 n',cutoff),
            statistic,'pathways','Original global_fdr from the named enrichment result table. The original adjustment family is preserved; display selection never recalculates it. See enrichment methods and full tables for family/global FDR.',maximum_terms))
        }
      }
    }
  }
  # Actual pathway\u2013target correlations are a separate statistic and testing family.
  if(is.data.frame(analysis$pathway_meta_analysis) && nrow(analysis$pathway_meta_analysis)){
    d <- analysis$pathway_meta_analysis
    for(cutoff in unique(d$cutoff))for(mode in unique(d$analysis_mode)){
      x <- d[d$cutoff==cutoff & d$analysis_mode==mode,,drop=FALSE]
      if(!nrow(x)||!any(is.finite(x$meta_rho)))next
      x$row_id <- x$gene_id;x$row_label <- x$set_name;x$column_id <- x$target;x$column_label <- x$target
      x$value <- x$meta_rho;x$q <- x$meta_fdr;x$n <- x$contributing_samples;x$k <- x$contributing_projects
      files <- c(files,.p2c_table_heatmap(x,directory,paste0('pathway_activity_',mode,'_n',cutoff),
        paste0('Pathway activity\u2013target correlations \u00b7 ',mode,' \u00b7 n',cutoff),'Pathway activity correlation (rho)','pathways',
        'BH across all pathway\u2013target tests within cutoff and analysis mode, before any display selection.',maximum_terms,1))
    }
  }
  if(is.data.frame(analysis$pathway_results) && nrow(analysis$pathway_results)){
    x <- analysis$pathway_results;x$row_id <- x$gene_id;x$row_label <- x$set_name
    x$column_id <- x$target;x$column_label <- x$target;x$value <- x$rho;x$q <- x$fdr;x$n <- x$pairwise_samples
    files <- c(files,.p2c_table_heatmap(x,directory,'pathway_activity_correlations',
      'Pathway activity\u2013target correlations','Pathway activity correlation (rho)','pathways',
      'BH across all evaluable pathway\u2013target tests in this single-dataset analysis.',maximum_terms,1))
  }
  files
}
