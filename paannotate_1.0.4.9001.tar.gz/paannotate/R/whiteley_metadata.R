.metadata_priority_fields <- function() c(
  "study_arm_id", "strain_standardized", "engineered_status",
  "analysis_context", "medium_family", "medium_base", "treatment_standardized",
  "treatment", "growth_mode", "growth_phase", "oxygen_condition",
  "temperature_c", "treatment_dose", "exposure_duration_raw",
  "sampling_timepoint", "host_scientific_name", "anatomical_site",
  "sample_material", "disease_or_injury"
)

.metadata_value_status <- function(x) {
  value <- tolower(trimws(as.character(x)))
  answer <- rep("documented", length(value))
  answer[is.na(x) | !nzchar(value)] <- "missing"
  answer[value %in% c(
    "unknown", "unassigned", "unclear", "not reported", "not_reported",
    "not available", "unspecified", "undetermined"
  )] <- "unknown"
  answer[value %in% c(
    "not applicable", "not_applicable", "n/a", "na", "none"
  )] <- "not_applicable"
  answer
}

.metadata_resolved <- function(x) {
  .metadata_value_status(x) %in% c("documented", "not_applicable")
}

.metadata_read_table <- function(x, review_sheet = TRUE) {
  if (inherits(x, "pa_metadata_overlay")) return(x$metadata)
  if (inherits(x, "pa_metadata_harvest")) return(x$raw_attributes)
  if (inherits(x, "pa_whiteley")) return(as.data.frame(x$metadata, stringsAsFactors = FALSE))
  if (inherits(x, "pa_whiteley_cohort_check")) {
    return(as.data.frame(x$selected_metadata, stringsAsFactors = FALSE))
  }
  if (is.data.frame(x)) return(as.data.frame(x, stringsAsFactors = FALSE))
  if (!is.character(x) || length(x) != 1L) {
    stop("Metadata must be a data frame, pa_whiteley object, review workbook, CSV/TSV, or RDS file.",
         call. = FALSE)
  }
  path <- normalizePath(path.expand(x), winslash = "/", mustWork = TRUE)
  extension <- tolower(tools::file_ext(path))
  if (extension == "rds") return(.metadata_read_table(readRDS(path), review_sheet))
  if (extension %in% c("xlsx", "xls") && isTRUE(review_sheet)) {
    sheets <- readxl::excel_sheets(path)
    sheet <- if ("Reviewed_Metadata" %in% sheets) "Reviewed_Metadata" else sheets[1]
    return(as.data.frame(readxl::read_excel(path, sheet = sheet),
                         stringsAsFactors = FALSE, check.names = FALSE))
  }
  .read_raw_table(path)$data
}

.metadata_resolve_whiteley <- function(
    whiteley = NULL, profile = "whiteley_full_v1",
    cache_dir = file.path(tools::R_user_dir("paannotate", "cache"), "Whiteley")) {
  if (is.null(whiteley)) {
    return(pa_load_whiteley(profile = profile, cache_dir = cache_dir,
                            metadata_only = TRUE))
  }
  if (inherits(whiteley, "pa_whiteley")) return(whiteley)
  metadata <- .metadata_read_table(whiteley)
  if (!"profile_id" %in% names(metadata)) metadata$profile_id <- "user_metadata"
  if (!"profile_version" %in% names(metadata)) metadata$profile_version <- "user"
  if (!"biosample_id_original" %in% names(metadata) &&
      "biosample_id" %in% names(metadata)) {
    metadata$biosample_id_original <- metadata$biosample_id
  }
  .whiteley_metadata_object(
    metadata, profile = unique(as.character(metadata$profile_id))[1]
  )
}

.metadata_empty_coverage <- function() data.frame(
  field = character(), samples = integer(), documented = integer(),
  explicit_not_applicable = integer(), unknown = integer(), missing = integer(),
  resolved_percent = numeric(), stringsAsFactors = FALSE
)

#' Audit Whiteley metadata completeness
#'
#' Measures documented, explicitly inapplicable, unknown, and blank values by
#' field, sample, and BioProject, and counts each documented value by sample and
#' BioProject. Project priorities depend only on sample count and missing
#' high-value metadata; expression results never influence them.
#'
#' @param whiteley A `pa_whiteley` object, metadata table/file, or `NULL` to load
#'   the cached full Whiteley manifest without parsing counts.
#' @param fields Fields to audit. `NULL` uses the analysis-oriented defaults.
#' @param priority_fields Fields used to rank projects for review.
#' @param output_dir Optional directory for CSV and Excel coverage reports.
#' @param profile,cache_dir Used when `whiteley=NULL`.
#' @return A `pa_metadata_coverage` object.
#' @export
pa_metadata_coverage <- function(
    whiteley = NULL, fields = NULL, priority_fields = NULL, output_dir = NULL,
    profile = "whiteley_full_v1",
    cache_dir = file.path(tools::R_user_dir("paannotate", "cache"), "Whiteley")) {
  object <- .metadata_resolve_whiteley(whiteley, profile, cache_dir)
  metadata <- as.data.frame(object$metadata, stringsAsFactors = FALSE)
  if (!nrow(metadata)) stop("The metadata table has no samples.", call. = FALSE)
  if (!"biosample_id" %in% names(metadata)) {
    stop("Metadata must contain biosample_id.", call. = FALSE)
  }
  if (!"bioproject_id" %in% names(metadata)) metadata$bioproject_id <- "UNASSIGNED"
  defaults <- .metadata_priority_fields()
  if (is.null(fields)) fields <- intersect(defaults, names(metadata))
  fields <- unique(as.character(fields))
  missing_fields <- setdiff(fields, names(metadata))
  if (length(missing_fields)) {
    warning("Skipping metadata fields that are absent: ",
            paste(missing_fields, collapse = ", "), call. = FALSE)
    fields <- intersect(fields, names(metadata))
  }
  if (!length(fields)) stop("None of the requested metadata fields exist.", call. = FALSE)
  if (is.null(priority_fields)) priority_fields <- intersect(defaults, fields)
  priority_fields <- intersect(unique(as.character(priority_fields)), fields)
  if (!length(priority_fields)) priority_fields <- fields
  field_rows <- lapply(fields, function(field) {
    status <- .metadata_value_status(metadata[[field]])
    data.frame(
      field = field, samples = length(status),
      documented = sum(status == "documented"),
      explicit_not_applicable = sum(status == "not_applicable"),
      unknown = sum(status == "unknown"), missing = sum(status == "missing"),
      resolved_percent = round(100 * mean(status %in% c("documented", "not_applicable")), 1),
      stringsAsFactors = FALSE
    )
  })
  field_coverage <- do.call(rbind, field_rows)
  status_matrix <- vapply(fields, function(field) {
    .metadata_value_status(metadata[[field]])
  }, character(nrow(metadata)))
  if (is.null(dim(status_matrix))) status_matrix <- matrix(status_matrix, ncol = 1L)
  colnames(status_matrix) <- fields
  resolved_matrix <- status_matrix %in% c("documented", "not_applicable")
  dim(resolved_matrix) <- dim(status_matrix)
  sample_coverage <- data.frame(
    biosample_id = metadata$biosample_id,
    bioproject_id = metadata$bioproject_id,
    resolved_fields = rowSums(resolved_matrix),
    unresolved_fields = ncol(resolved_matrix) - rowSums(resolved_matrix),
    resolved_percent = round(100 * rowMeans(resolved_matrix), 1),
    stringsAsFactors = FALSE
  )
  if ("curated_metadata_available" %in% names(metadata)) {
    sample_coverage$curated_metadata_available <-
      metadata$curated_metadata_available %in% TRUE
  }
  if ("reviewed_metadata_available" %in% names(metadata)) {
    sample_coverage$reviewed_metadata_available <-
      metadata$reviewed_metadata_available %in% TRUE
  }
  priority_index <- match(priority_fields, fields)
  groups <- split(seq_len(nrow(metadata)), metadata$bioproject_id)
  project_coverage <- do.call(rbind, lapply(names(groups), function(project) {
    idx <- groups[[project]]
    resolved <- resolved_matrix[idx, priority_index, drop = FALSE]
    missing_by_field <- colSums(!resolved)
    data.frame(
      bioproject_id = project, samples = length(idx),
      curated_samples = if ("curated_metadata_available" %in% names(metadata)) {
        sum(metadata$curated_metadata_available[idx] %in% TRUE)
      } else NA_integer_,
      reviewed_samples = if ("reviewed_metadata_available" %in% names(metadata)) {
        sum(metadata$reviewed_metadata_available[idx] %in% TRUE)
      } else 0L,
      priority_resolved_percent = round(100 * mean(resolved), 1),
      unresolved_priority_cells = sum(!resolved),
      fields_missing_for_every_sample = paste(
        names(missing_by_field)[missing_by_field == length(idx)], collapse = "; "
      ),
      stringsAsFactors = FALSE
    )
  }))
  project_coverage$priority_score <- round(
    project_coverage$samples * (100 - project_coverage$priority_resolved_percent) / 100,
    2
  )
  project_coverage <- project_coverage[
    order(-project_coverage$priority_score, -project_coverage$samples,
          project_coverage$bioproject_id), , drop = FALSE
  ]
  project_coverage$review_rank <- seq_len(nrow(project_coverage))
  project_coverage <- project_coverage[c(
    "review_rank", setdiff(names(project_coverage), "review_rank")
  )]
  pairs <- list(
    c("medium_base", "medium_family", "medium_mapping_status"),
    c("treatment", "treatment_standardized", "treatment_mapping_status"),
    c("strain_raw", "strain_standardized", "strain_mapping_status")
  )
  unresolved <- list()
  counter <- 0L
  for (pair in pairs) {
    if (!all(pair[1:2] %in% names(metadata))) next
    raw_status <- .metadata_value_status(metadata[[pair[1]]])
    standardized_status <- .metadata_value_status(metadata[[pair[2]]])
    keep <- raw_status == "documented" & standardized_status != "documented"
    if (pair[3] %in% names(metadata)) {
      keep <- keep | (raw_status == "documented" & metadata[[pair[3]]] == "unmapped")
    }
    if (!any(keep)) next
    tab <- as.data.frame(table(as.character(metadata[[pair[1]]][keep])),
                         stringsAsFactors = FALSE)
    names(tab) <- c("raw_value", "sample_count")
    tab$field <- pair[2]
    counter <- counter + 1L
    unresolved[[counter]] <- tab[c("field", "raw_value", "sample_count")]
  }
  unresolved_values <- if (length(unresolved)) do.call(rbind, unresolved) else
    data.frame(field = character(), raw_value = character(), sample_count = integer(),
               stringsAsFactors = FALSE)
  if (nrow(unresolved_values)) {
    unresolved_values <- unresolved_values[
      order(unresolved_values$field, -unresolved_values$sample_count), , drop = FALSE
    ]
  }
  level_rows <- list(); level_counter <- 0L
  for (field in fields) {
    value <- as.character(metadata[[field]])
    documented <- .metadata_value_status(value) == "documented"
    for (level in unique(value[documented])) {
      idx <- which(value == level & documented)
      level_counter <- level_counter + 1L
      level_rows[[level_counter]] <- data.frame(
        field = field, value = level, samples = length(idx),
        bioprojects = length(unique(metadata$bioproject_id[idx])),
        stringsAsFactors = FALSE
      )
    }
  }
  level_coverage <- if (length(level_rows)) do.call(rbind, level_rows) else
    data.frame(field = character(), value = character(), samples = integer(),
               bioprojects = integer(), stringsAsFactors = FALSE)
  if (nrow(level_coverage)) {
    level_coverage <- level_coverage[
      order(level_coverage$field, -level_coverage$samples, level_coverage$value),
      , drop = FALSE
    ]
  }
  result <- structure(list(
    field_coverage = field_coverage, sample_coverage = sample_coverage,
    project_coverage = project_coverage, level_coverage = level_coverage,
    unresolved_values = unresolved_values,
    priority_fields = priority_fields,
    provenance = list(profile_id = object$profile_id,
                      samples = nrow(metadata),
                      projects = length(unique(metadata$bioproject_id)),
                      created_at = format(Sys.time(), tz = "UTC", usetz = TRUE))
  ), class = "pa_metadata_coverage")
  if (!is.null(output_dir)) {
    output_dir <- path.expand(output_dir)
    dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
    .scan_write_csv(field_coverage, file.path(output_dir, "field_coverage.csv"))
    .scan_write_csv(sample_coverage, file.path(output_dir, "sample_coverage.csv.gz"))
    .scan_write_csv(project_coverage, file.path(output_dir, "project_coverage.csv"))
    .scan_write_csv(level_coverage, file.path(output_dir, "level_coverage.csv"))
    .scan_write_csv(
      project_coverage[is.na(project_coverage$curated_samples) |
                         project_coverage$curated_samples == 0, , drop = FALSE],
      file.path(output_dir, "projects_without_overlay.csv")
    )
    .scan_write_csv(unresolved_values, file.path(output_dir, "unresolved_values.csv"))
    if (requireNamespace("openxlsx", quietly = TRUE)) {
      workbook <- openxlsx::createWorkbook(creator = "paannotate")
      used <- character()
      for (item in c("field_coverage", "project_coverage", "level_coverage",
                     "unresolved_values")) {
        info <- .scan_add_sheet(workbook, item, result[[item]], used, 200000)
        used <- c(used, info$name)
      }
      openxlsx::saveWorkbook(
        workbook, file.path(output_dir, "metadata_coverage.xlsx"), overwrite = TRUE
      )
    }
    result$output_dir <- normalizePath(output_dir, winslash = "/")
  }
  result
}

#' @export
print.pa_metadata_coverage <- function(x, ...) {
  cat("paannotate metadata coverage\n")
  cat("  samples:", x$provenance$samples, "\n")
  cat("  projects:", x$provenance$projects, "\n")
  cat("  audited fields:", nrow(x$field_coverage), "\n")
  cat("  median resolved field coverage:",
      round(stats::median(x$field_coverage$resolved_percent), 1), "%\n")
  if (!is.null(x$output_dir)) cat("  report:", x$output_dir, "\n")
  invisible(x)
}

.metadata_graph_rows <- function(metadata, row, relationship, accession,
                                 accession_type, database) {
  if (!length(accession)) return(NULL)
  accession <- unique(accession[!is.na(accession) & nzchar(accession)])
  if (!length(accession)) return(NULL)
  data.frame(
    biosample_id = metadata$biosample_id[row],
    biosample_id_original = if ("biosample_id_original" %in% names(metadata)) {
      metadata$biosample_id_original[row]
    } else metadata$biosample_id[row],
    bioproject_id = metadata$bioproject_id[row], relationship = relationship,
    accession = accession, accession_type = accession_type,
    database = database, stringsAsFactors = FALSE
  )
}

.metadata_find_accessions <- function(text, pattern) {
  hit <- regmatches(text, gregexpr(pattern, text, perl = TRUE, ignore.case = TRUE))[[1]]
  if (identical(hit, character(0)) || identical(hit, "")) character() else
    unique(toupper(hit))
}

#' Build the public-accession graph for Whiteley samples
#'
#' Expands the Whiteley manifest into explicit BioProject, BioSample, SRA study,
#' experiment, run, GEO, and PubMed relationships. The graph is the seed for
#' machine-readable source retrieval and makes technical-run relationships
#' explicit.
#'
#' @inheritParams pa_metadata_coverage
#' @param output_file Optional CSV or CSV.GZ destination.
#' @return A `pa_metadata_accession_graph` data frame.
#' @export
pa_build_accession_graph <- function(
    whiteley = NULL, output_file = NULL, profile = "whiteley_full_v1",
    cache_dir = file.path(tools::R_user_dir("paannotate", "cache"), "Whiteley")) {
  object <- .metadata_resolve_whiteley(whiteley, profile, cache_dir)
  metadata <- as.data.frame(object$metadata, stringsAsFactors = FALSE)
  if (!all(c("biosample_id", "bioproject_id") %in% names(metadata))) {
    stop("Whiteley metadata must contain biosample_id and bioproject_id.", call. = FALSE)
  }
  pieces <- list()
  counter <- 0L
  for (i in seq_len(nrow(metadata))) {
    add <- function(...) {
      value <- .metadata_graph_rows(metadata, i, ...)
      if (!is.null(value)) {
        counter <<- counter + 1L
        pieces[[counter]] <<- value
      }
    }
    project <- .metadata_find_accessions(metadata$bioproject_id[i], "PRJ[A-Z]{2}[0-9]+")
    sample_text <- if ("biosample_id_original" %in% names(metadata)) {
      metadata$biosample_id_original[i]
    } else metadata$biosample_id[i]
    sample <- .metadata_find_accessions(sample_text, "SAM[A-Z]*[0-9]+")
    add("member_of_project", project, "bioproject", "bioproject")
    add("biological_sample", sample, "biosample", "biosample")
    if ("study_accession" %in% names(metadata)) {
      study <- .metadata_find_accessions(metadata$study_accession[i],
                                         "(SRP|ERP|DRP)[0-9]+")
      add("sequencing_study", study, "sra_study", "sra")
    }
    if ("sra_runs" %in% names(metadata)) {
      runs <- .metadata_find_accessions(metadata$sra_runs[i], "(SRR|ERR|DRR)[0-9]+")
      add("technical_run", runs, "sra_run", "sra")
    }
    searchable <- paste(vapply(metadata, function(column) {
      value <- as.character(column[i]); ifelse(is.na(value), "", value)
    }, character(1)), collapse = " | ")
    add("sequencing_experiment",
        .metadata_find_accessions(searchable, "(SRX|ERX|DRX)[0-9]+"),
        "sra_experiment", "sra")
    add("geo_series", .metadata_find_accessions(searchable, "GSE[0-9]+"),
        "geo_series", "gds")
    add("geo_sample", .metadata_find_accessions(searchable, "GSM[0-9]+"),
        "geo_sample", "gds")
    publication_columns <- grep("pubmed|pmid", names(metadata),
                                ignore.case = TRUE, value = TRUE)
    if (length(publication_columns)) {
      publication_text <- paste(vapply(publication_columns, function(column) {
        value <- as.character(metadata[[column]][i]); ifelse(is.na(value), "", value)
      }, character(1)), collapse = " | ")
      add("publication", .metadata_find_accessions(publication_text, "[0-9]{6,9}"),
          "pubmed", "pubmed")
    }
  }
  graph <- if (length(pieces)) unique(do.call(rbind, pieces)) else data.frame(
    biosample_id = character(), biosample_id_original = character(),
    bioproject_id = character(), relationship = character(), accession = character(),
    accession_type = character(), database = character(), stringsAsFactors = FALSE
  )
  rownames(graph) <- NULL
  class(graph) <- c("pa_metadata_accession_graph", "data.frame")
  if (!is.null(output_file)) .scan_write_csv(graph, path.expand(output_file))
  graph
}

#' @export
print.pa_metadata_accession_graph <- function(x, ...) {
  cat("paannotate metadata accession graph\n")
  cat("  biological samples:", length(unique(x$biosample_id)), "\n")
  cat("  projects:", length(unique(x$bioproject_id)), "\n")
  cat("  accession links:", nrow(x), "\n")
  print(as.data.frame(table(x$accession_type), stringsAsFactors = FALSE),
        row.names = FALSE)
  invisible(x)
}

.metadata_xml_decode <- function(x) {
  x <- gsub("&lt;", "<", x, fixed = TRUE)
  x <- gsub("&gt;", ">", x, fixed = TRUE)
  x <- gsub("&quot;", '"', x, fixed = TRUE)
  x <- gsub("&#39;|&apos;", "'", x, perl = TRUE)
  gsub("&amp;", "&", x, fixed = TRUE)
}

.metadata_xml_text <- function(x) {
  .metadata_xml_decode(trimws(gsub("<[^>]+>", " ", x, perl = TRUE)))
}

.metadata_xml_blocks <- function(text, tag) {
  pattern <- paste0("(?s)<", tag, "\\b[^>]*>.*?</", tag, ">")
  hit <- regmatches(text, gregexpr(pattern, text, perl = TRUE))[[1]]
  if (identical(hit, "")) character() else hit
}

.metadata_xml_attribute <- function(tag, name) {
  pattern <- paste0("(?s).*?\\b", name, '="([^"]*)".*')
  value <- sub(pattern, "\\1", tag, perl = TRUE)
  if (identical(value, tag)) "" else .metadata_xml_decode(value)
}

.metadata_xml_tag_value <- function(block, tag) {
  pattern <- paste0("(?s).*?<", tag, "\\b[^>]*>(.*?)</", tag, ">.*")
  value <- sub(pattern, "\\1", block, perl = TRUE)
  if (identical(value, block)) "" else .metadata_xml_text(value)
}

.metadata_attribute_row <- function(sample, project, source_database,
                                    source_accession, name, value, file) {
  data.frame(
    biosample_id = sample, bioproject_id = project,
    source_database = source_database, source_accession = source_accession,
    attribute_name = name, raw_value = value,
    source_url = switch(
      source_database,
      biosample = paste0("https://www.ncbi.nlm.nih.gov/biosample/", source_accession),
      bioproject = paste0("https://www.ncbi.nlm.nih.gov/bioproject/", source_accession),
      sra = paste0("https://www.ncbi.nlm.nih.gov/sra/?term=", source_accession),
      gds = paste0("https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=", source_accession),
      pubmed = paste0("https://pubmed.ncbi.nlm.nih.gov/", source_accession), ""
    ),
    cached_record = normalizePath(file, winslash = "/", mustWork = FALSE),
    stringsAsFactors = FALSE
  )
}

.metadata_parse_biosample_xml <- function(text, file) {
  blocks <- .metadata_xml_blocks(text, "BioSample")
  rows <- list(); counter <- 0L
  for (block in blocks) {
    opening <- sub("(?s)^(<BioSample\\b[^>]*>).*", "\\1", block, perl = TRUE)
    accession <- .metadata_xml_attribute(opening, "accession")
    project <- .metadata_find_accessions(block, "PRJ[A-Z]{2}[0-9]+")
    project <- if (length(project)) project[1] else ""
    title <- .metadata_xml_tag_value(block, "Title")
    if (nzchar(title)) {
      counter <- counter + 1L
      rows[[counter]] <- .metadata_attribute_row(
        accession, project, "biosample", accession, "sample_title", title, file
      )
    }
    attributes <- regmatches(
      block, gregexpr("(?s)<Attribute\\b[^>]*>.*?</Attribute>", block, perl = TRUE)
    )[[1]]
    for (attribute in attributes) {
      opening_attribute <- sub("(?s)^(<Attribute\\b[^>]*>).*", "\\1",
                               attribute, perl = TRUE)
      name <- .metadata_xml_attribute(opening_attribute, "harmonized_name")
      if (!nzchar(name)) name <- .metadata_xml_attribute(opening_attribute, "attribute_name")
      if (!nzchar(name)) name <- .metadata_xml_attribute(opening_attribute, "display_name")
      value <- .metadata_xml_text(attribute)
      if (!nzchar(name) || !nzchar(value)) next
      counter <- counter + 1L
      rows[[counter]] <- .metadata_attribute_row(
        accession, project, "biosample", accession, name, value, file
      )
    }
  }
  if (length(rows)) do.call(rbind, rows) else data.frame()
}

.metadata_parse_sra_xml <- function(text, file) {
  blocks <- .metadata_xml_blocks(text, "EXPERIMENT_PACKAGE")
  rows <- list(); counter <- 0L
  tags <- c("TITLE", "DESIGN_DESCRIPTION", "LIBRARY_STRATEGY", "LIBRARY_SOURCE",
            "LIBRARY_SELECTION", "LIBRARY_LAYOUT", "INSTRUMENT_MODEL")
  for (block in blocks) {
    sample <- .metadata_find_accessions(block, "SAM[A-Z]*[0-9]+")
    project <- .metadata_find_accessions(block, "PRJ[A-Z]{2}[0-9]+")
    accession <- .metadata_find_accessions(block, "(SRX|ERX|DRX)[0-9]+")
    sample <- if (length(sample)) sample[1] else ""
    project <- if (length(project)) project[1] else ""
    accession <- if (length(accession)) accession[1] else ""
    for (tag in tags) {
      value <- .metadata_xml_tag_value(block, tag)
      if (!nzchar(value)) next
      counter <- counter + 1L
      rows[[counter]] <- .metadata_attribute_row(
        sample, project, "sra", accession, tolower(tag), value, file
      )
    }
  }
  if (length(rows)) do.call(rbind, rows) else data.frame()
}

.metadata_parse_project_xml <- function(text, file, requested = character()) {
  blocks <- .metadata_xml_blocks(text, "Package")
  if (!length(blocks)) blocks <- .metadata_xml_blocks(text, "DocumentSummary")
  if (!length(blocks)) blocks <- text
  rows <- list(); counter <- 0L
  for (block in blocks) {
    projects <- .metadata_find_accessions(block, "PRJ[A-Z]{2}[0-9]+")
    if (!length(projects) && length(blocks) == 1L) projects <- requested
    projects <- unique(projects)
    if (!length(projects)) next
    title <- .metadata_xml_tag_value(block, "Title")
    if (!nzchar(title)) title <- .metadata_xml_tag_value(block, "Name")
    description <- .metadata_xml_tag_value(block, "Description")
    values <- c(project_title = title, project_description = description)
    for (project in projects) {
    for (name in names(values)) {
      if (!nzchar(values[[name]])) next
      counter <- counter + 1L
      rows[[counter]] <- .metadata_attribute_row(
        "", project, "bioproject", project, name, values[[name]], file
      )
    }
    }
  }
  if (length(rows)) do.call(rbind, rows) else data.frame()
}

.metadata_parse_generic_xml <- function(text, file, database, requested = character()) {
  blocks <- .metadata_xml_blocks(text, "DocumentSummary")
  if (!length(blocks)) blocks <- text
  rows <- list(); counter <- 0L
  tags <- if (database == "gds") {
    c("title", "summary", "taxon", "gdsType", "GPL", "PDAT")
  } else c("ArticleTitle", "AbstractText", "Title")
  pattern <- if (database == "gds") "(?:GSE|GSM|GDS)[0-9]+" else "[0-9]{6,9}"
  for (block in blocks) {
    accessions <- .metadata_find_accessions(block, pattern)
    if (!length(accessions) && length(blocks) == 1L) accessions <- requested
    if (!length(accessions)) next
    for (tag in tags) {
      value <- .metadata_xml_tag_value(block, tag)
      if (!nzchar(value)) next
      for (accession in unique(accessions)) {
        counter <- counter + 1L
        rows[[counter]] <- .metadata_attribute_row(
          "", "", database, accession, tolower(tag), value, file
        )
      }
    }
  }
  if (length(rows)) do.call(rbind, rows) else data.frame()
}

.metadata_parse_record_file <- function(file, database, requested = character()) {
  text <- paste(readLines(file, warn = FALSE, encoding = "UTF-8"), collapse = "\n")
  if (database == "biosample") return(.metadata_parse_biosample_xml(text, file))
  if (database == "sra") return(.metadata_parse_sra_xml(text, file))
  if (database == "bioproject") {
    return(.metadata_parse_project_xml(text, file, requested))
  }
  if (database %in% c("gds", "pubmed")) {
    return(.metadata_parse_generic_xml(text, file, database, requested))
  }
  data.frame()
}

.metadata_eutils_parameters <- function(api_key = NULL, email = NULL) {
  values <- c(tool = "paannotate")
  if (!is.null(email) && nzchar(email)) values <- c(values, email = email)
  if (!is.null(api_key) && nzchar(api_key)) values <- c(values, api_key = api_key)
  paste0("&", paste(names(values), utils::URLencode(values, reserved = TRUE),
                     sep = "=", collapse = "&"))
}

.metadata_download <- function(url, destination) {
  temporary <- tempfile(tmpdir = dirname(destination), fileext = ".download")
  on.exit(if (file.exists(temporary)) unlink(temporary), add = TRUE)
  status <- utils::download.file(
    url, temporary, quiet = TRUE, mode = "wb", method = "libcurl",
    headers = c("User-Agent" = "paannotate metadata curator")
  )
  if (!identical(status, 0L) || !file.exists(temporary) || file.info(temporary)$size == 0) {
    stop("Metadata download returned an empty response.", call. = FALSE)
  }
  if (!file.rename(temporary, destination)) {
    if (!file.copy(temporary, destination, overwrite = TRUE)) {
      stop("Could not save metadata response: ", destination, call. = FALSE)
    }
    unlink(temporary)
  }
  destination
}

#' Retrieve public metadata records for the Whiteley accession graph
#'
#' Uses NCBI E-utilities to retrieve machine-readable records rather than
#' scraping webpage layouts. Responses are cached verbatim and parsed
#' conservatively; the returned attributes are proposals for review, not silent
#' replacements for the analysis metadata.
#'
#' @param whiteley A Whiteley object/table or an object returned by
#'   [pa_build_accession_graph()].
#' @param projects Optional BioProject subset.
#' @param sources Any of `"biosample"`, `"bioproject"`, `"sra"`, `"geo"`,
#'   and `"pubmed"`.
#' @param cache_dir Destination for immutable source responses and fetch audits.
#' @param refresh Redownload batches already present in the cache.
#' @param batch_size Accessions combined in one Entrez query.
#' @param maximum_records Optional safety cap, useful for testing a few records.
#' @param api_key,email Optional NCBI credentials/contact information.
#' @param profile Used when `whiteley=NULL`.
#' @param quiet Suppress progress messages.
#' @return A `pa_metadata_harvest` containing the accession graph, complete
#'   fetch audit, cached files, and parsed raw attributes.
#' @export
pa_fetch_whiteley_metadata <- function(
    whiteley = NULL, projects = NULL,
    sources = c("biosample", "bioproject", "sra", "geo"),
    cache_dir = file.path(tools::R_user_dir("paannotate", "cache"),
                          "Whiteley", "metadata_sources"),
    refresh = FALSE, batch_size = 20, maximum_records = Inf,
    api_key = Sys.getenv("NCBI_API_KEY", unset = ""), email = NULL,
    profile = "whiteley_full_v1", quiet = FALSE) {
  sources <- unique(match.arg(sources,
                              c("biosample", "bioproject", "sra", "geo", "pubmed"),
                              several.ok = TRUE))
  if (!is.numeric(batch_size) || length(batch_size) != 1L ||
      !is.finite(batch_size) || batch_size < 1 || batch_size > 100) {
    stop("batch_size must be between 1 and 100.", call. = FALSE)
  }
  graph <- if (inherits(whiteley, "pa_metadata_accession_graph")) whiteley else
    pa_build_accession_graph(whiteley, profile = profile)
  if (!is.null(projects)) graph <- graph[graph$bioproject_id %in% projects, , drop = FALSE]
  wanted_types <- c(
    if ("biosample" %in% sources) "biosample",
    if ("bioproject" %in% sources) "bioproject",
    if ("sra" %in% sources) c("sra_study", "sra_experiment", "sra_run"),
    if ("geo" %in% sources) c("geo_series", "geo_sample"),
    if ("pubmed" %in% sources) "pubmed"
  )
  requested <- unique(graph[graph$accession_type %in% wanted_types,
                            c("database", "accession"), drop = FALSE])
  if (is.finite(maximum_records)) {
    maximum_records <- max(0L, as.integer(maximum_records))
    requested <- utils::head(requested, maximum_records)
  }
  if (!nrow(requested)) stop("No accessions matched the requested metadata sources.",
                             call. = FALSE)
  cache_dir <- path.expand(cache_dir)
  dir.create(cache_dir, recursive = TRUE, showWarnings = FALSE)
  manifest_rows <- list(); manifest_counter <- 0L
  parsed_rows <- list(); parsed_counter <- 0L
  extra <- .metadata_eutils_parameters(api_key, email)
  delay <- if (nzchar(api_key)) 0.11 else 0.35
  for (database in unique(requested$database)) {
    accessions <- sort(unique(requested$accession[requested$database == database]))
    chunks <- split(accessions, ceiling(seq_along(accessions) / as.integer(batch_size)))
    database_dir <- file.path(cache_dir, database)
    dir.create(database_dir, recursive = TRUE, showWarnings = FALSE)
    for (batch_index in seq_along(chunks)) {
      batch <- chunks[[batch_index]]
      filename <- paste0(
        "batch_", sprintf("%05d", batch_index), "_",
        gsub("[^A-Za-z0-9]", "", batch[1]), "_",
        gsub("[^A-Za-z0-9]", "", batch[length(batch)]), ".xml"
      )
      destination <- file.path(database_dir, filename)
      status <- "cached"
      error_message <- ""
      search_url <- fetch_url <- ""
      if (isTRUE(refresh) || !file.exists(destination)) {
        status <- "fetched"
        tryCatch({
          term_tag <- if (database == "pubmed") "UID" else "Accession"
          term <- paste0("(", batch, "[", term_tag, "])", collapse = " OR ")
          search_url <- paste0(
            "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=",
            database, "&retmode=xml&retmax=100000&term=",
            utils::URLencode(term, reserved = TRUE), extra
          )
          search_file <- tempfile(fileext = ".xml")
          on.exit(if (file.exists(search_file)) unlink(search_file), add = TRUE)
          .metadata_download(search_url, search_file)
          search_text <- paste(readLines(search_file, warn = FALSE), collapse = "")
          ids <- regmatches(search_text,
                            gregexpr("(?<=<Id>)[0-9]+(?=</Id>)", search_text,
                                     perl = TRUE))[[1]]
          if (!length(ids) || identical(ids, "")) {
            status <- "no_match"
            file.copy(search_file, destination, overwrite = TRUE)
          } else {
            Sys.sleep(delay)
            fetch_url <- paste0(
              "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=",
              database, "&retmode=xml&id=", paste(ids, collapse = ","), extra
            )
            .metadata_download(fetch_url, destination)
          }
        }, error = function(e) {
          status <<- "failed"
          error_message <<- conditionMessage(e)
        })
        Sys.sleep(delay)
      }
      manifest_counter <- manifest_counter + 1L
      manifest_rows[[manifest_counter]] <- data.frame(
        database = database, batch = batch_index,
        requested_accessions = paste(batch, collapse = "; "),
        requested_count = length(batch), status = status,
        error = error_message, cached_file = destination,
        search_url = search_url, fetch_url = fetch_url,
        retrieved_at = format(Sys.time(), tz = "UTC", usetz = TRUE),
        stringsAsFactors = FALSE
      )
      if (file.exists(destination) && status %in% c("fetched", "cached")) {
        parsed <- tryCatch(
          .metadata_parse_record_file(destination, database, batch),
          error = function(e) data.frame()
        )
        if (nrow(parsed)) {
          parsed_counter <- parsed_counter + 1L
          parsed_rows[[parsed_counter]] <- parsed
        }
      }
      if (!quiet) message(database, " batch ", batch_index, "/", length(chunks),
                          ": ", status)
    }
  }
  fetch_manifest <- do.call(rbind, manifest_rows)
  raw_attributes <- if (length(parsed_rows)) do.call(rbind, parsed_rows) else
    data.frame(
      biosample_id = character(), bioproject_id = character(),
      source_database = character(), source_accession = character(),
      attribute_name = character(), raw_value = character(),
      source_url = character(), cached_record = character(),
      stringsAsFactors = FALSE
    )
  .scan_write_csv(fetch_manifest, file.path(cache_dir, "fetch_manifest.csv"))
  .scan_write_csv(raw_attributes, file.path(cache_dir, "raw_attributes.csv.gz"))
  structure(list(
    accession_graph = graph, fetch_manifest = fetch_manifest,
    raw_attributes = raw_attributes,
    cache_dir = normalizePath(cache_dir, winslash = "/", mustWork = TRUE),
    config = list(projects = projects, sources = sources, batch_size = batch_size,
                  maximum_records = maximum_records, refresh = refresh)
  ), class = "pa_metadata_harvest")
}

#' @export
print.pa_metadata_harvest <- function(x, ...) {
  cat("paannotate public metadata harvest\n")
  cat("  accession links:", nrow(x$accession_graph), "\n")
  cat("  fetch batches:", nrow(x$fetch_manifest), "\n")
  cat("  parsed attributes:", nrow(x$raw_attributes), "\n")
  cat("  failed batches:", sum(x$fetch_manifest$status == "failed"), "\n")
  cat("  cache:", x$cache_dir, "\n")
  invisible(x)
}

.metadata_canonical_field <- function(x) {
  name <- tolower(gsub("[^a-z0-9]+", "_", trimws(as.character(x))))
  answer <- rep("", length(name))
  rules <- list(
    strain_raw = "(^|_)(strain|isolate)($|_)",
    background_genotype = "genotype|genetic_background|mutation|mutant",
    medium_base = "growth_medium|culture_medium|growth_media|culture_media|^medium$",
    treatment = "treatment|compound|drug|antibiotic|exposure",
    treatment_dose = "dose|concentration",
    exposure_duration_raw = "treatment_duration|exposure_duration|duration",
    sampling_timepoint = "time_point|timepoint|sampling_time|collection_time",
    growth_mode = "growth_mode|biofilm|planktonic",
    growth_phase = "growth_phase|culture_phase",
    oxygen_condition = "oxygen|aerobic|anaerobic|microaerobic",
    temperature_c = "temperature",
    host_scientific_name = "host_scientific|host_organism|^host$",
    anatomical_site = "anatomical|tissue|body_site",
    sample_material = "isolation_source|sample_source|source_name|sample_material",
    disease_or_injury = "disease|injury|infection_status",
    analysis_context = "collection_context|in_vivo|in_vitro",
    sample_title = "sample_title|^title$"
  )
  for (field in names(rules)) {
    use <- !nzchar(answer) & grepl(rules[[field]], name, perl = TRUE)
    answer[use] <- field
  }
  answer
}

.metadata_prepare_candidates <- function(attributes) {
  if (inherits(attributes, "pa_metadata_harvest")) {
    harvest <- attributes
    attributes <- harvest$raw_attributes
    graph <- unique(as.data.frame(harvest$accession_graph)[
      c("accession", "biosample_id", "bioproject_id")
    ])
    if (nrow(attributes) && nrow(graph)) {
      attributes$.candidate_order <- seq_len(nrow(attributes))
      attributes <- merge(attributes, graph, by.x = "source_accession",
                          by.y = "accession", all.x = TRUE,
                          suffixes = c("", ".graph"), sort = FALSE)
      for (field in c("biosample_id", "bioproject_id")) {
        graph_field <- paste0(field, ".graph")
        if (graph_field %in% names(attributes)) {
          attributes[[field]] <- .whiteley_fill(
            attributes[[field]], attributes[[graph_field]]
          )
          attributes[[graph_field]] <- NULL
        }
      }
      attributes <- attributes[order(attributes$.candidate_order), , drop = FALSE]
      attributes$.candidate_order <- NULL
    }
  } else {
    attributes <- .metadata_read_table(attributes, review_sheet = FALSE)
  }
  required <- c("biosample_id", "attribute_name", "raw_value")
  if (length(setdiff(required, names(attributes)))) {
    stop("Candidate attributes must contain biosample_id, attribute_name, and raw_value.",
         call. = FALSE)
  }
  if (!"source_database" %in% names(attributes)) attributes$source_database <- "user"
  if (!"bioproject_id" %in% names(attributes)) attributes$bioproject_id <- ""
  attributes$canonical_field <- .metadata_canonical_field(attributes$attribute_name)
  attributes$proposed_value <- as.character(attributes$raw_value)
  attributes$proposal_confidence <- ifelse(
    attributes$source_database %in% c("biosample", "gds"), "high", "medium"
  )
  derived <- list(); derived_index <- 0L
  medium <- attributes$canonical_field == "medium_base"
  if (any(medium)) {
    index <- which(medium)
    mapped <- .whiteley_map_medium(attributes$raw_value[index])
    usable <- mapped$medium_mapping_status == "mapped"
    if (any(usable)) {
      extra <- attributes[index[usable], , drop = FALSE]
      extra$canonical_field <- "medium_family"
      extra$proposed_value <- mapped$medium_family[usable]
      derived_index <- derived_index + 1L
      derived[[derived_index]] <- extra
    }
  }
  treatment <- attributes$canonical_field == "treatment"
  if (any(treatment)) {
    index <- which(treatment)
    mapped <- .whiteley_map_treatment(attributes$raw_value[index])
    usable <- mapped$treatment_mapping_status == "mapped"
    if (any(usable)) {
      standardized <- attributes[index[usable], , drop = FALSE]
      standardized$canonical_field <- "treatment_standardized"
      standardized$proposed_value <- mapped$treatment_name[usable]
      derived_index <- derived_index + 1L
      derived[[derived_index]] <- standardized
      classes <- attributes[index[usable], , drop = FALSE]
      classes$canonical_field <- "treatment_class"
      classes$proposed_value <- mapped$treatment_class[usable]
      derived_index <- derived_index + 1L
      derived[[derived_index]] <- classes
    }
  }
  strain <- attributes$canonical_field == "strain_raw"
  if (any(strain)) {
    index <- which(strain)
    mapped <- .whiteley_map_strain(attributes$raw_value[index])
    usable <- mapped$strain_mapping_status == "mapped"
    if (any(usable)) {
      extra <- attributes[index[usable], , drop = FALSE]
      extra$canonical_field <- "strain_standardized"
      extra$proposed_value <- mapped$strain_standardized[usable]
      derived_index <- derived_index + 1L
      derived[[derived_index]] <- extra
    }
  }
  if (length(derived)) attributes <- unique(do.call(rbind, c(list(attributes), derived)))
  rownames(attributes) <- NULL
  attributes
}

.metadata_review_fields <- function(metadata) {
  unique(c(intersect(.metadata_priority_fields(), names(metadata)),
           intersect(c("strain_raw", "treatment_class", "medium_full",
                       "background_genotype", "host_scientific_name",
                       "anatomical_site", "sample_material"), names(metadata))))
}

#' Export a project-oriented Whiteley metadata review workbook
#'
#' Builds a central editable table plus project context sheets. Automatically
#' harvested attributes remain proposals with source links; reviewers enter
#' accepted or corrected values only in columns beginning with `review_`.
#'
#' @param whiteley Whiteley object or metadata table/file.
#' @param candidates Optional `pa_metadata_harvest` or raw attribute table.
#' @param projects BioProject IDs, `"priority"`, or `NULL` for all projects.
#' @param maximum_projects Maximum priority projects exported at once.
#' @param output_file XLSX destination.
#' @param fields Metadata fields exposed for review.
#' @inheritParams pa_metadata_coverage
#' @return Invisibly, a list containing the workbook tables and path.
#' @export
pa_export_metadata_queue <- function(
    whiteley = NULL, candidates = NULL, projects = "priority",
    maximum_projects = 25, output_file = "whiteley_metadata_review.xlsx",
    fields = NULL, profile = "whiteley_full_v1",
    cache_dir = file.path(tools::R_user_dir("paannotate", "cache"), "Whiteley")) {
  if (!requireNamespace("openxlsx", quietly = TRUE)) {
    stop("Metadata review workbooks require openxlsx. Install it with install.packages('openxlsx').",
         call. = FALSE)
  }
  object <- .metadata_resolve_whiteley(whiteley, profile, cache_dir)
  metadata <- as.data.frame(object$metadata, stringsAsFactors = FALSE)
  coverage <- pa_metadata_coverage(object)
  if (identical(projects, "priority")) {
    projects <- utils::head(coverage$project_coverage$bioproject_id,
                            as.integer(maximum_projects))
  } else if (is.null(projects)) projects <- unique(metadata$bioproject_id)
  projects <- unique(as.character(projects))
  selected <- metadata[metadata$bioproject_id %in% projects, , drop = FALSE]
  if (!nrow(selected)) stop("No samples matched the requested BioProjects.", call. = FALSE)
  if (is.null(fields)) fields <- .metadata_review_fields(metadata)
  fields <- intersect(unique(as.character(fields)), names(metadata))
  identifiers <- intersect(c(
    "biosample_id", "biosample_id_original", "bioproject_id", "sra_runs",
    "study_accession", "study_title", "sample_title"
  ), names(selected))
  review <- selected[c(identifiers, fields)]
  names(review)[match(fields, names(review))] <- paste0("existing_", fields)
  prepared_candidates <- data.frame()
  project_candidates <- data.frame()
  if (!is.null(candidates)) {
    prepared_candidates <- .metadata_prepare_candidates(candidates)
    project_candidates <- prepared_candidates[
      !nzchar(trimws(as.character(prepared_candidates$biosample_id))) &
        prepared_candidates$bioproject_id %in% projects, , drop = FALSE
    ]
    original <- if ("biosample_id_original" %in% names(selected)) {
      selected$biosample_id_original
    } else selected$biosample_id
    candidate_key <- paste(prepared_candidates$biosample_id,
                           prepared_candidates$bioproject_id, sep = "\r")
    selected_key <- paste(original, selected$bioproject_id, sep = "\r")
    candidate_index <- match(candidate_key, selected_key)
    fallback <- match(prepared_candidates$biosample_id, original)
    unique_original <- !duplicated(original) & !duplicated(original, fromLast = TRUE)
    use_fallback <- is.na(candidate_index) & !is.na(fallback) &
      (!nzchar(trimws(as.character(prepared_candidates$bioproject_id))) |
         unique_original[fallback])
    candidate_index[use_fallback] <- fallback[use_fallback]
    prepared_candidates$analysis_biosample_id <- selected$biosample_id[candidate_index]
    prepared_candidates$bioproject_id <- ifelse(
      is.na(candidate_index), prepared_candidates$bioproject_id,
      selected$bioproject_id[candidate_index]
    )
    prepared_candidates <- prepared_candidates[
      !is.na(prepared_candidates$analysis_biosample_id) &
        prepared_candidates$bioproject_id %in% projects, , drop = FALSE
    ]
    for (field in fields) {
      proposed <- rep("", nrow(review))
      for (i in seq_len(nrow(review))) {
        values <- prepared_candidates$proposed_value[
          prepared_candidates$analysis_biosample_id == review$biosample_id[i] &
            prepared_candidates$canonical_field == field
        ]
        values <- unique(values[!is.na(values) & nzchar(trimws(values))])
        proposed[i] <- paste(values, collapse = "; ")
      }
      review[[paste0("proposed_", field)]] <- proposed
    }
  }
  for (field in fields) review[[paste0("review_", field)]] <- ""
  review$review_status <- ""
  review$review_confidence <- ""
  review$review_source <- ""
  review$review_evidence <- ""
  review$reviewer_note <- ""
  instructions <- data.frame(
    step = c(
      "1", "2", "3", "4", "5", "6"
    ),
    instruction = c(
      "Review one BioProject at a time; the project sheets provide context.",
      "Enter accepted or corrected values only in review_* columns on Reviewed_Metadata.",
      "Leave a review_* cell blank to preserve the existing package value.",
      "Set review_status to approved, unresolved, or rejected.",
      "Record a source accession/URL and short evidence statement for substantive changes.",
      "Run pa_validate_metadata() before pa_merge_metadata_overlay()."
    ), stringsAsFactors = FALSE
  )
  workbook <- openxlsx::createWorkbook(creator = "paannotate")
  used <- character()
  add <- function(name, data) {
    info <- .scan_add_sheet(workbook, name, data, used, 200000)
    used <<- c(used, info$name)
    info$name
  }
  add("Instructions", instructions)
  add("Project_Priority", coverage$project_coverage[
    coverage$project_coverage$bioproject_id %in% projects, , drop = FALSE
  ])
  review_sheet <- add("Reviewed_Metadata", review)
  add("Raw_Candidates", prepared_candidates)
  add("Project_Candidates", project_candidates)
  for (project in projects) {
    context <- review[review$bioproject_id == project, , drop = FALSE]
    if (nrow(context)) add(paste0("Project_", project), context)
  }
  review_columns <- grep("^review_", names(review))
  if (length(review_columns) && nrow(review)) {
    style <- openxlsx::createStyle(fgFill = "#FFF2CC", wrapText = TRUE)
    openxlsx::addStyle(workbook, review_sheet, style,
                       rows = seq_len(nrow(review)) + 1L, cols = review_columns,
                       gridExpand = TRUE, stack = TRUE)
  }
  output_file <- path.expand(output_file)
  dir.create(dirname(output_file), recursive = TRUE, showWarnings = FALSE)
  openxlsx::saveWorkbook(workbook, output_file, overwrite = TRUE)
  invisible(structure(list(
    review = review, candidates = prepared_candidates,
    projects = projects,
    output_file = normalizePath(output_file, winslash = "/", mustWork = TRUE)
  ), class = "pa_metadata_review_queue"))
}

.metadata_review_value_columns <- function(data) {
  candidates <- grep("^review_", names(data), value = TRUE)
  setdiff(candidates, c("review_status", "review_confidence", "review_source",
                        "review_evidence", "reviewer_note"))
}

.metadata_protected_fields <- function() c(
  "biosample_id", "biosample_id_original", "bioproject_id", "sra_runs",
  "technical_run_count", "assigned_feature_reads", "count_qc_status",
  "profile_id", "profile_version", "curated_metadata_available",
  "reviewed_metadata_available"
)

#' Validate reviewed Whiteley metadata
#'
#' Checks identifiers, duplicate keys, controlled values, provenance, and
#' contradictions before an overlay can affect cohort selection or adjustment.
#'
#' @param overlay Review workbook or overlay table/file.
#' @param base Optional base Whiteley object/table used to verify sample keys.
#' @param strict Treat provenance warnings as validation errors.
#' @return A `pa_metadata_validation` object.
#' @export
pa_validate_metadata <- function(overlay, base = NULL, strict = FALSE) {
  data <- .metadata_read_table(overlay)
  required <- c("biosample_id", "bioproject_id")
  errors <- warnings <- character()
  missing <- setdiff(required, names(data))
  if (length(missing)) errors <- c(errors, paste("Missing key columns:",
                                                 paste(missing, collapse = ", ")))
  if (!length(missing)) {
    key <- paste(data$biosample_id, data$bioproject_id, sep = "\r")
    if (anyDuplicated(key)) {
      errors <- c(errors, paste(sum(duplicated(key) | duplicated(key, fromLast = TRUE)),
                                "rows have duplicated BioSample/BioProject keys"))
    }
    if (any(!nzchar(trimws(as.character(data$biosample_id))) |
            !nzchar(trimws(as.character(data$bioproject_id))))) {
      errors <- c(errors, "One or more BioSample/BioProject keys are blank")
    }
  }
  reviewed_columns <- .metadata_review_value_columns(data)
  reviewed_fields <- sub("^review_", "", reviewed_columns)
  protected <- intersect(reviewed_fields, .metadata_protected_fields())
  if (length(protected)) errors <- c(errors, paste(
    "Review columns cannot modify protected identifiers/count fields:",
    paste(protected, collapse = ", ")
  ))
  changed <- if (length(reviewed_columns)) {
    reviewed_matrix <- do.call(cbind, lapply(reviewed_columns, function(column) {
      !is.na(data[[column]]) & nzchar(trimws(as.character(data[[column]])))
    }))
    if (is.null(dim(reviewed_matrix))) {
      reviewed_matrix <- matrix(reviewed_matrix, ncol = length(reviewed_columns))
    }
    rowSums(reviewed_matrix) > 0L
  } else rep(FALSE, nrow(data))
  if (any(changed)) {
    if (!"review_status" %in% names(data) ||
        any(!nzchar(trimws(as.character(data$review_status[changed]))))) {
      warnings <- c(warnings, "Reviewed values are present without review_status")
    }
    if (!"review_source" %in% names(data) ||
        any(!nzchar(trimws(as.character(data$review_source[changed]))))) {
      warnings <- c(warnings, "Reviewed values are present without review_source")
    }
    if (!"review_evidence" %in% names(data) ||
        any(!nzchar(trimws(as.character(data$review_evidence[changed]))))) {
      warnings <- c(warnings, "Reviewed values are present without review_evidence")
    }
  }
  if ("review_status" %in% names(data)) {
    value <- tolower(trimws(as.character(data$review_status)))
    bad <- nzchar(value) & !value %in% c("approved", "unresolved", "rejected")
    if (any(bad)) errors <- c(errors, paste("Invalid review_status:",
                                            paste(unique(value[bad]), collapse = ", ")))
  }
  if ("review_confidence" %in% names(data)) {
    value <- tolower(trimws(as.character(data$review_confidence)))
    bad <- nzchar(value) & !value %in% c("high", "medium", "low", "unresolved")
    if (any(bad)) errors <- c(errors, paste("Invalid review_confidence:",
                                            paste(unique(value[bad]), collapse = ", ")))
  }
  controlled <- list(
    medium_family = unique(.whiteley_medium_dictionary()$medium_family),
    treatment_class = unique(.whiteley_treatment_dictionary()$treatment_class),
    strain_standardized = unique(.whiteley_strain_dictionary()$strain_standardized),
    engineered_status = c("engineered", "wild_type", "unknown"),
    analysis_context = c("in_vitro", "in_vivo", "mixed", "unknown"),
    oxygen_condition = c("aerobic", "anaerobic", "microaerobic", "unknown")
  )
  for (field in intersect(names(controlled), reviewed_fields)) {
    value <- as.character(data[[paste0("review_", field)]])
    present <- !is.na(value) & nzchar(trimws(value))
    bad <- present & !tolower(value) %in% tolower(controlled[[field]])
    if (any(bad)) warnings <- c(warnings, paste0(
      "Unrecognized ", field, " value(s): ", paste(unique(value[bad]), collapse = ", ")
    ))
  }
  if (!is.null(base) && !length(missing)) {
    base_data <- .metadata_read_table(base)
    if (all(required %in% names(base_data))) {
      base_key <- paste(base_data$biosample_id, base_data$bioproject_id, sep = "\r")
      overlay_key <- paste(data$biosample_id, data$bioproject_id, sep = "\r")
      unknown <- !overlay_key %in% base_key
      if (any(unknown)) errors <- c(errors, paste(
        sum(unknown), "overlay rows do not match the base BioSample/BioProject keys"
      ))
    }
  }
  if (isTRUE(strict) && length(warnings)) {
    errors <- c(errors, paste0("Strict validation: ", warnings))
  }
  errors <- unique(errors); warnings <- unique(warnings)
  structure(list(
    valid = !length(errors), errors = data.frame(message = errors),
    warnings = data.frame(message = warnings), reviewed_rows = sum(changed),
    reviewed_fields = reviewed_fields, data = data
  ), class = "pa_metadata_validation")
}

#' @export
print.pa_metadata_validation <- function(x, ...) {
  cat("paannotate metadata validation\n")
  cat("  valid:", x$valid, "\n")
  cat("  reviewed rows:", x$reviewed_rows, "\n")
  cat("  errors:", nrow(x$errors), "\n")
  cat("  warnings:", nrow(x$warnings), "\n")
  if (nrow(x$errors)) print(x$errors, row.names = FALSE)
  if (nrow(x$warnings)) print(x$warnings, row.names = FALSE)
  invisible(x)
}

.metadata_overlay_values <- function(data) {
  review_columns <- .metadata_review_value_columns(data)
  keys <- c("biosample_id", "bioproject_id")
  if (length(review_columns)) {
    keep <- c(keys, review_columns,
              intersect(c("review_status", "review_confidence", "review_source",
                          "review_evidence", "reviewer_note"), names(data)))
    result <- data[keep]
    names(result)[match(review_columns, names(result))] <- sub("^review_", "", review_columns)
    if ("review_status" %in% names(result)) {
      approved <- tolower(trimws(as.character(result$review_status))) == "approved"
      for (field in sub("^review_", "", review_columns)) {
        result[[field]][!approved] <- ""
      }
    }
    return(result)
  }
  ignore <- c(
    grep("^(existing|proposed)_", names(data), value = TRUE),
    "review_status", "review_confidence", "review_source", "review_evidence",
    "reviewer_note"
  )
  fields <- setdiff(names(data), c(keys, ignore, .metadata_protected_fields()))
  data[c(keys, fields, intersect(c("metadata_schema_version"), names(data)))]
}

#' Merge a reviewed, versioned Whiteley metadata overlay
#'
#' Applies only nonblank reviewed values, records every changed cell, preserves
#' protected accession/count fields, and reapplies normalization dictionaries.
#'
#' @param base Base Whiteley object or metadata table/file.
#' @param overlay Validated review workbook or overlay table/file.
#' @param conflict Whether nonblank overlay values replace base values, preserve
#'   base values, or cause an error when the values differ.
#' @param metadata_version Version recorded in the merged metadata.
#' @param output_file Optional CSV destination for the merged table; a sibling
#'   changes CSV is also written.
#' @param strict Passed to [pa_validate_metadata()].
#' @return A `pa_metadata_overlay` object with merged metadata and a cell-level
#'   change audit.
#' @export
pa_merge_metadata_overlay <- function(
    base, overlay, conflict = c("reviewed", "base", "error"),
    metadata_version = "user_overlay_v1", output_file = NULL, strict = FALSE) {
  conflict <- match.arg(conflict)
  base_data <- .metadata_read_table(base)
  if (!"reviewed_metadata_available" %in% names(base_data)) {
    base_data$reviewed_metadata_available <- FALSE
  }
  validation <- pa_validate_metadata(overlay, base_data, strict = strict)
  if (!validation$valid) {
    stop("Metadata overlay failed validation: ",
         paste(validation$errors$message, collapse = "; "), call. = FALSE)
  }
  overlay_data <- .metadata_overlay_values(validation$data)
  key_columns <- c("biosample_id", "bioproject_id")
  base_key <- paste(base_data$biosample_id, base_data$bioproject_id, sep = "\r")
  overlay_key <- paste(overlay_data$biosample_id, overlay_data$bioproject_id, sep = "\r")
  index <- match(overlay_key, base_key)
  fields <- setdiff(names(overlay_data), c(
    key_columns, "review_status", "review_confidence", "review_source",
    "review_evidence", "reviewer_note", "metadata_schema_version"
  ))
  changes <- list(); counter <- 0L
  for (field in fields) {
    if (!field %in% names(base_data)) base_data[[field]] <- ""
    incoming <- as.character(overlay_data[[field]])
    use <- !is.na(incoming) & nzchar(trimws(incoming))
    if (!any(use)) next
    old <- as.character(base_data[[field]][index[use]])
    different <- is.na(old) | trimws(old) != trimws(incoming[use])
    if (conflict == "error" && any(different & .metadata_resolved(old))) {
      stop("Overlay conflicts with existing values in field ", field, ".",
           call. = FALSE)
    }
    apply <- use
    if (conflict == "base") {
      apply[use] <- !.metadata_resolved(old)
    }
    if (!any(apply)) next
    target <- index[apply]
    before <- as.character(base_data[[field]][target])
    after <- incoming[apply]
    changed <- is.na(before) | before != after
    if (any(changed)) {
      counter <- counter + 1L
      source_rows <- which(apply)[changed]
      changes[[counter]] <- data.frame(
        biosample_id = overlay_data$biosample_id[source_rows],
        bioproject_id = overlay_data$bioproject_id[source_rows], field = field,
        old_value = before[changed], new_value = after[changed],
        review_confidence = if ("review_confidence" %in% names(overlay_data))
          overlay_data$review_confidence[source_rows] else "",
        review_source = if ("review_source" %in% names(overlay_data))
          overlay_data$review_source[source_rows] else "",
        review_evidence = if ("review_evidence" %in% names(overlay_data))
          overlay_data$review_evidence[source_rows] else "",
        stringsAsFactors = FALSE
      )
    }
    base_data[[field]][target] <- after
  }
  change_audit <- if (length(changes)) do.call(rbind, changes) else data.frame(
    biosample_id = character(), bioproject_id = character(), field = character(),
    old_value = character(), new_value = character(), review_confidence = character(),
    review_source = character(), review_evidence = character(),
    stringsAsFactors = FALSE
  )
  base_data <- .whiteley_add_standard_mappings(base_data)
  manual_standard_fields <- c(
    medium_family = "medium", treatment_standardized = "treatment",
    treatment_class = "treatment", strain_standardized = "strain"
  )
  for (field in intersect(names(manual_standard_fields), change_audit$field)) {
    reviewed <- change_audit[change_audit$field == field, , drop = FALSE]
    reviewed_key <- paste(reviewed$biosample_id, reviewed$bioproject_id, sep = "\r")
    target <- match(reviewed_key,
                    paste(base_data$biosample_id, base_data$bioproject_id, sep = "\r"))
    base_data[[field]][target] <- reviewed$new_value
    prefix <- unname(manual_standard_fields[field])
    status <- paste0(prefix, "_mapping_status")
    rule <- paste0(prefix, "_mapping_rule")
    if (status %in% names(base_data)) base_data[[status]][target] <- "reviewed"
    if (rule %in% names(base_data)) base_data[[rule]][target] <- "manual_review"
  }
  base_data$metadata_schema_version <- metadata_version
  if (nrow(change_audit)) {
    changed_keys <- unique(paste(change_audit$biosample_id,
                                 change_audit$bioproject_id, sep = "\r"))
    base_data$reviewed_metadata_available[
      paste(base_data$biosample_id, base_data$bioproject_id, sep = "\r") %in%
        changed_keys
    ] <- TRUE
  }
  result <- structure(list(
    metadata = base_data, changes = change_audit, validation = validation,
    config = list(conflict = conflict, metadata_version = metadata_version,
                  applied_at = format(Sys.time(), tz = "UTC", usetz = TRUE))
  ), class = "pa_metadata_overlay")
  if (!is.null(output_file)) {
    output_file <- path.expand(output_file)
    dir.create(dirname(output_file), recursive = TRUE, showWarnings = FALSE)
    .scan_write_csv(base_data, output_file)
    change_path <- sub("\\.[^.]+$", "_changes.csv", output_file)
    if (identical(change_path, output_file)) change_path <- paste0(output_file, "_changes.csv")
    .scan_write_csv(change_audit, change_path)
    result$output_file <- normalizePath(output_file, winslash = "/", mustWork = TRUE)
  }
  result
}

#' @export
print.pa_metadata_overlay <- function(x, ...) {
  cat("paannotate metadata overlay\n")
  cat("  version:", x$config$metadata_version, "\n")
  cat("  samples:", nrow(x$metadata), "\n")
  cat("  changed cells:", nrow(x$changes), "\n")
  if (!is.null(x$output_file)) cat("  file:", x$output_file, "\n")
  invisible(x)
}

.whiteley_read_mapping_dictionary <- function(filename) {
  utils::read.csv(.whiteley_extdata(filename), colClasses = "character",
                  check.names = FALSE, stringsAsFactors = FALSE)
}

.whiteley_treatment_dictionary <- function() {
  .whiteley_read_mapping_dictionary("whiteley_treatment_dictionary_v1.csv")
}

.whiteley_strain_dictionary <- function() {
  .whiteley_read_mapping_dictionary("whiteley_strain_dictionary_v1.csv")
}

.whiteley_map_dictionary <- function(values, dictionary, value_columns) {
  text <- tolower(trimws(.whiteley_utf8(values)))
  rule <- rep("", length(text))
  outputs <- lapply(value_columns, function(column) rep("", length(text)))
  names(outputs) <- value_columns
  for (i in seq_len(nrow(dictionary))) {
    matched <- !nzchar(rule) & nzchar(text) & grepl(
      dictionary$pattern[i], text, perl = TRUE, ignore.case = TRUE
    )
    rule[matched] <- dictionary$rule_id[i]
    for (column in value_columns) outputs[[column]][matched] <- dictionary[[column]][i]
  }
  result <- as.data.frame(outputs, stringsAsFactors = FALSE)
  result$mapping_status <- ifelse(!nzchar(text), "missing",
                                  ifelse(nzchar(rule), "mapped", "unmapped"))
  result$mapping_rule <- rule
  result$dictionary_version <- unique(dictionary$dictionary_version)[1]
  result
}

.whiteley_map_treatment <- function(values) {
  result <- .whiteley_map_dictionary(
    values, .whiteley_treatment_dictionary(), c("treatment_name", "treatment_class")
  )
  names(result)[names(result) == "mapping_status"] <- "treatment_mapping_status"
  names(result)[names(result) == "mapping_rule"] <- "treatment_mapping_rule"
  names(result)[names(result) == "dictionary_version"] <-
    "treatment_dictionary_version"
  result
}

.whiteley_map_strain <- function(values) {
  result <- .whiteley_map_dictionary(
    values, .whiteley_strain_dictionary(), c("strain_standardized", "strain_family")
  )
  names(result)[names(result) == "mapping_status"] <- "strain_mapping_status"
  names(result)[names(result) == "mapping_rule"] <- "strain_mapping_rule"
  names(result)[names(result) == "dictionary_version"] <- "strain_dictionary_version"
  result
}

.whiteley_add_standard_mappings <- function(manifest) {
  manifest <- .whiteley_add_medium_mapping(manifest)
  if (!"treatment" %in% names(manifest)) manifest$treatment <- ""
  if (!"extracted_treatment" %in% names(manifest)) manifest$extracted_treatment <- ""
  treatment_raw <- .whiteley_fill(manifest$treatment, manifest$extracted_treatment)
  manifest$treatment_raw <- treatment_raw
  treatment <- .whiteley_map_treatment(treatment_raw)
  for (field in names(treatment)) manifest[[field]] <- treatment[[field]]
  manifest$treatment_standardized <- .whiteley_fill(
    treatment$treatment_name, treatment_raw
  )
  strain_raw <- if ("strain_raw" %in% names(manifest)) manifest$strain_raw else ""
  if ("strain" %in% names(manifest)) strain_raw <- .whiteley_fill(strain_raw, manifest$strain)
  strain <- .whiteley_map_strain(strain_raw)
  for (field in names(strain)) manifest[[field]] <- strain[[field]]
  manifest$strain_standardized <- .whiteley_fill(strain$strain_standardized, strain_raw)
  manifest
}

.whiteley_metadata_mapping_current <- function(manifest) {
  medium <- unique(.whiteley_medium_dictionary()$dictionary_version)[1]
  treatment <- unique(.whiteley_treatment_dictionary()$dictionary_version)[1]
  strain <- unique(.whiteley_strain_dictionary()$dictionary_version)[1]
  all(c("medium_dictionary_version", "treatment_dictionary_version",
        "strain_dictionary_version") %in% names(manifest)) &&
    all(manifest$medium_dictionary_version == medium) &&
    all(manifest$treatment_dictionary_version == treatment) &&
    all(manifest$strain_dictionary_version == strain)
}

.whiteley_apply_metadata_overlay <- function(object, metadata_overlay) {
  if (is.null(metadata_overlay)) return(object)
  if (inherits(metadata_overlay, "pa_metadata_overlay")) {
    overlay_data <- metadata_overlay$metadata
    base_key <- paste(object$metadata$biosample_id,
                      object$metadata$bioproject_id, sep = "\r")
    overlay_key <- paste(overlay_data$biosample_id,
                         overlay_data$bioproject_id, sep = "\r")
    index <- match(base_key, overlay_key)
    if (anyNA(index)) {
      stop("The prepared metadata overlay does not contain every sample in this Whiteley profile.",
           call. = FALSE)
    }
    object$metadata <- overlay_data[index, , drop = FALSE]
    rownames(object$metadata) <- NULL
    changes <- metadata_overlay$changes
    if (nrow(changes)) {
      changes <- changes[
        paste(changes$biosample_id, changes$bioproject_id, sep = "\r") %in% base_key,
        , drop = FALSE
      ]
    }
    object$provenance$metadata_overlay_version <-
      metadata_overlay$config$metadata_version
    object$provenance$metadata_overlay_changed_cells <- nrow(changes)
    object$metadata_overlay_audit <- changes
    return(object)
  }
  overlay_version <- if (inherits(metadata_overlay, "pa_metadata_overlay")) {
    metadata_overlay$config$metadata_version
  } else "user_overlay_v1"
  merged <- pa_merge_metadata_overlay(
    object$metadata, metadata_overlay, metadata_version = overlay_version
  )
  object$metadata <- merged$metadata
  object$provenance$metadata_overlay_version <- merged$config$metadata_version
  object$provenance$metadata_overlay_changed_cells <- nrow(merged$changes)
  object$metadata_overlay_audit <- merged$changes
  object
}
