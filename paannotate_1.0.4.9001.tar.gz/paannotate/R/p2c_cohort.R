#' Load a Paper2Counts cohort for a Whiteley-style target scan
#'
#' The manifest has one row per independent P2C study with `study_id`,
#' `accession`, `counts_path`, `metadata_path`, `organism_key`, and
#' `reference_assembly` columns. Optional `gene_catalog_path` provides symbol
#' aliases such as PhrD. Only exact gene identifiers shared by every study are
#' included; missing genes are reported, never filled with zero counts.
#'
#' @param manifest Path to a P2C cohort scan manifest CSV or a data frame.
#' @return A list with a `pa_whiteley`-compatible object, gene and sample audit,
#'   and alias table.
#' @export
pa_load_p2c_cohort <- function(manifest) {
  input <- if (is.data.frame(manifest)) manifest else
    utils::read.csv(path.expand(manifest), check.names = FALSE,
                    stringsAsFactors = FALSE)
  needed <- c("study_id", "accession", "counts_path", "metadata_path",
              "organism_key", "reference_assembly")
  missing <- setdiff(needed, names(input))
  if (length(missing)) stop("P2C cohort manifest lacks: ",
                            paste(missing, collapse = ", "), call. = FALSE)
  if (nrow(input) < 2L || anyDuplicated(input$study_id) ||
      anyDuplicated(toupper(input$accession))) {
    stop("Select at least two independent studies with unique IDs and accessions.",
         call. = FALSE)
  }
  assemblies <- unique(trimws(as.character(input$reference_assembly)))
  if (length(assemblies) != 1L || !nzchar(assemblies) || is.na(assemblies)) {
    stop("All selected studies need the same recorded reference assembly; ",
         "cross-assembly gene mapping is not inferred.", call. = FALSE)
  }
  organisms <- unique(tolower(trimws(as.character(input$organism_key))))
  if (length(organisms) != 1L || !nzchar(organisms) || is.na(organisms)) {
    stop("All selected studies need the same organism key.", call. = FALSE)
  }
  matrices <- vector("list", nrow(input))
  metadata <- vector("list", nrow(input))
  aliases <- list()
  audit <- vector("list", nrow(input))
  for (i in seq_len(nrow(input))) {
    counts_path <- path.expand(as.character(input$counts_path[i]))
    metadata_path <- path.expand(as.character(input$metadata_path[i]))
    if (!file.exists(counts_path) || !file.exists(metadata_path)) {
      stop("Study ", input$accession[i], " is missing its counts or metadata file.",
           call. = FALSE)
    }
    counts <- utils::read.csv(counts_path, check.names = FALSE,
                              stringsAsFactors = FALSE)
    md <- utils::read.csv(metadata_path, check.names = FALSE,
                          stringsAsFactors = FALSE)
    sample_col <- intersect(c("sample", "sample_id"), names(md))[1]
    if (is.na(sample_col) || ncol(counts) < 2L) {
      stop("Study ", input$accession[i], " needs sample metadata and a gene-by-sample count matrix.",
           call. = FALSE)
    }
    if ("include" %in% names(md)) {
      md <- md[!tolower(trimws(as.character(md$include))) %in%
                 c("0", "false", "no", "exclude"), , drop = FALSE]
    }
    samples <- trimws(as.character(md[[sample_col]]))
    if (length(samples) < 4L || anyNA(samples) || any(!nzchar(samples)) ||
        anyDuplicated(samples) || !all(samples %in% names(counts))) {
      stop("Study ", input$accession[i],
           " needs at least four distinct metadata samples matching count columns.",
           call. = FALSE)
    }
    genes <- toupper(trimws(as.character(counts[[1]])))
    if (anyNA(genes) || any(!nzchar(genes)) || anyDuplicated(genes)) {
      stop("Study ", input$accession[i], " has blank or duplicate gene IDs.",
           call. = FALSE)
    }
    raw <- as.matrix(counts[samples])
    values <- suppressWarnings(as.numeric(raw))
    if (any(!is.finite(values)) || any(values < 0)) {
      stop("Study ", input$accession[i], " needs finite, nonnegative gene count estimates.",
           call. = FALSE)
    }
    mat <- matrix(values, nrow = length(genes),
                  dimnames = list(genes, paste(input$study_id[i], samples, sep = "::")))
    matrices[[i]] <- mat
    md$sample_id <- colnames(mat)
    md$project_id <- as.character(input$study_id[i])
    md$accession <- as.character(input$accession[i])
    md$study_title <- if ("study_name" %in% names(input))
      as.character(input$study_name[i]) else as.character(input$accession[i])
    metadata[[i]] <- md
    audit[[i]] <- data.frame(
      study_id = as.character(input$study_id[i]),
      accession = as.character(input$accession[i]),
      samples = ncol(mat), genes = nrow(mat),
      reference_assembly = assemblies,
      stringsAsFactors = FALSE
    )
    if ("gene_catalog_path" %in% names(input) &&
        !is.na(input$gene_catalog_path[i]) && nzchar(input$gene_catalog_path[i])) {
      catalog_path <- path.expand(as.character(input$gene_catalog_path[i]))
      if (!file.exists(catalog_path)) {
        stop("Gene catalog is missing: ", catalog_path, call. = FALSE)
      }
      catalog <- utils::read.csv(catalog_path, check.names = FALSE,
                                 stringsAsFactors = FALSE)
      if ("gene_id" %in% names(catalog)) {
        alias_rows <- list()
        for (field in intersect(c("gene_symbol", "gene_synonym", "old_locus_tag"),
                                names(catalog))) {
          tokens <- strsplit(as.character(catalog[[field]]), ";", fixed = TRUE)
          alias_rows[[field]] <- data.frame(
            alias = toupper(trimws(unlist(tokens, use.names = FALSE))),
            gene_id = rep(toupper(trimws(as.character(catalog$gene_id))),
                          lengths(tokens)), stringsAsFactors = FALSE
          )
        }
        if (length(alias_rows)) aliases[[i]] <- do.call(rbind, alias_rows)
      }
    }
  }
  shared <- Reduce(intersect, lapply(matrices, rownames))
  study_genes <- stats::setNames(lapply(matrices, rownames),
                                 as.character(input$study_id))
  all_genes <- Reduce(union, study_genes)
  if (length(shared) < 2L) {
    stop("The selected studies share fewer than two exact gene IDs.", call. = FALSE)
  }
  combined <- do.call(cbind, lapply(matrices, function(x) x[shared, , drop = FALSE]))
  fields <- unique(unlist(lapply(metadata, names), use.names = FALSE))
  metadata <- lapply(metadata, function(x) {
    for (field in setdiff(fields, names(x))) x[[field]] <- NA_character_
    x[fields]
  })
  md <- do.call(rbind, metadata)
  rownames(md) <- NULL
  audit <- do.call(rbind, audit)
  audit$shared_genes <- length(shared)
  alias_table <- if (length(aliases)) unique(do.call(rbind, aliases)) else
    data.frame(alias = character(), gene_id = character())
  alias_table <- alias_table[!is.na(alias_table$alias) &
                               nzchar(alias_table$alias) &
                               !is.na(alias_table$gene_id) &
                               alias_table$gene_id %in% all_genes, , drop = FALSE]
  object <- structure(list(
    counts = combined, metadata = md, data_type = "raw_counts",
    profile_id = "p2c_custom_cohort", profile_version = "1.0.0",
    provenance = list(reference_assembly = assemblies,
                      organism_key = organisms, study_inputs = input)
  ), class = "pa_whiteley")
  list(cohort = object, study_audit = audit, aliases = alias_table,
       shared_genes = shared, study_genes = study_genes,
       study_inputs = input)
}

#' Run a Whiteley-style scan of a custom Paper2Counts cohort
#'
#' Each study is normalized separately. Gene-to-target correlations are
#' calculated within studies, then meta-analyzed across studies. Decimal loci
#' such as PA0714.1 remain distinct from PA0714. Gene symbols are resolved
#' only through the supplied P2C gene catalogs and must map unambiguously.
#'
#' @param manifest P2C cohort scan manifest accepted by [pa_load_p2c_cohort()].
#' @param targets Gene IDs or symbols to scan separately.
#' @param output_dir Organized report destination.
#' @param min_samples_per_project Minimum samples per contributing study.
#' @param heatmaps Write heatmaps when the optional plotting package is available.
#' @param workbook Write an Excel workbook when openxlsx is available.
#' @param scan_args Additional named arguments passed to [pa_scan_targets()].
#' @return A `pa_scan_pipeline` object.
#' @export
pa_run_p2c_cohort <- function(
    manifest, targets, output_dir, min_samples_per_project = 6,
    heatmaps = FALSE, workbook = FALSE, scan_args = list(), membership = NULL,
    custom_pathways = NULL, enrich = FALSE, pathway_library_mode = "append",
    pathway_activity = FALSE, minimum_size = 5, minimum_pathway_members = 3, minimum_pathway_fraction = .5) {
  loaded <- pa_load_p2c_cohort(manifest)
  requested <- trimws(as.character(targets))
  requested <- requested[!is.na(requested) & nzchar(requested)]
  if (!length(requested)) stop("Enter at least one target gene.", call. = FALSE)
  resolved <- vapply(requested, function(value) {
    direct <- toupper(value)
    if (direct %in% loaded$shared_genes ||
        any(vapply(loaded$study_genes, function(genes) direct %in% genes,
                   logical(1)))) return(direct)
    hit <- unique(loaded$aliases$gene_id[loaded$aliases$alias == direct])
    if (length(hit) == 1L) return(hit)
    if (length(hit) > 1L) stop("Ambiguous gene symbol: ", value, call. = FALSE)
    stop("Target ", value, " is not an exact shared gene ID or unambiguous catalog alias. ",
         "Check the study gene coverage and reference catalogs.", call. = FALSE)
  }, character(1))
  unavailable <- which(!resolved %in% loaded$shared_genes)
  if (length(unavailable)) {
    index <- unavailable[1]
    absent <- names(loaded$study_genes)[!vapply(
      loaded$study_genes, function(genes) resolved[index] %in% genes,
      logical(1))]
    stop("Target ", requested[index], " (", resolved[index],
         ") is absent from the count matrix in: ", paste(absent, collapse = ", "),
         ". Exact gene IDs are required across selected studies.", call. = FALSE)
  }
  if (anyDuplicated(resolved)) {
    stop("Two target names resolve to the same gene; enter that gene once.",
         call. = FALSE)
  }
  strain <- loaded$cohort$provenance$organism_key
  policy <- if (grepl("pao1", strain, fixed = TRUE)) "pao1_extended" else "as_is"
  names(resolved) <- requested
  target_object <- pa_targets(individual = resolved, id_policy = policy)
  defaults <- list(
    expression = loaded$cohort, metadata = NULL, targets = target_object,
    id_policy = policy, min_samples_per_project = min_samples_per_project,
    thresholds = pa_scan_thresholds(minimum_meta_projects = 2,
                                    supported_min_projects = 2,
                                    context_min_projects = 2)
  )
  if(isTRUE(enrich)){
    if(is.null(membership))membership <- if(pathway_library_mode=="custom") .empty_membership() else if(policy=="pao1_extended")fetch_pa_annotations() else stop("Prepare strain-matched annotation membership for this cohort, or choose custom pathways only.")
    membership <- .p2c_combine_pathways(.scan_read_membership(membership),custom_pathways,pathway_library_mode)
    if(isTRUE(pathway_activity))defaults <- c(defaults,list(pathway_membership=.as_membership(membership),minimum_pathway_members=minimum_pathway_members,minimum_pathway_fraction=minimum_pathway_fraction))
  }
  scan <- do.call(pa_scan_targets, utils::modifyList(defaults, scan_args))
  if(isTRUE(enrich))scan$pathway_membership_audit <- .p2c_membership_audit(membership,scan$candidate_genes,minimum_size)
  scan$config$p2c_cohort_manifest <- if (is.character(manifest))
    normalizePath(manifest, winslash = "/") else "in-memory manifest"
  enriched <- if(isTRUE(enrich))pa_enrich_scan(scan,membership,minimum_size=minimum_size,minimum_overlap=min(3,minimum_size)) else NULL
  files <- pa_write_scan(scan, enrichment=enriched, output_dir = output_dir,
                         heatmaps = heatmaps, workbook = workbook)
  cohort_dir <- file.path(output_dir, "00_cohort")
  dir.create(cohort_dir, recursive = TRUE, showWarnings = FALSE)
  utils::write.csv(loaded$study_inputs,
                   file.path(cohort_dir, "study_inputs.csv"), row.names = FALSE)
  utils::write.csv(loaded$study_audit,
                   file.path(cohort_dir, "study_gene_coverage.csv"), row.names = FALSE)
  utils::write.csv(data.frame(requested = requested, gene_id = unname(resolved)),
                   file.path(cohort_dir, "target_resolution.csv"), row.names = FALSE)
  structure(list(scan = scan, enrichment=enriched, files = files, cohort = loaded),
            class = "pa_scan_pipeline")
}
