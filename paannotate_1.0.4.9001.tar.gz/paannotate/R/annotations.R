.empty_membership <- function() {
  data.frame(
    gene_id = character(), database = character(), ontology = character(),
    set_id = character(), set_name = character(), stringsAsFactors = FALSE
  )
}

.empty_uniprot <- function() {
  data.frame(
    gene_id = character(), uniprot_accession = character(),
    uniprot_gene_names = character(), uniprot_protein_name = character(),
    go_ids = character(), go_biological_process = character(),
    go_molecular_function = character(), go_cellular_component = character(),
    uniprot_function = character(), ec_numbers = character(),
    uniprot_pathway = character(), stringsAsFactors = FALSE
  )
}

.collapse_unique <- function(x) {
  x <- trimws(as.character(x[!is.na(x)]))
  paste(unique(x[x != "" & x != "-"]), collapse = "; ")
}

.exact_pao1_locus <- function(x) {
  x <- toupper(trimws(as.character(x)))
  x[!grepl("^PA[0-9]{4}[A-Z]?$", x)] <- NA_character_
  x
}

.embedded_pao1_locus <- function(x) {
  x <- toupper(as.character(x))
  answer <- rep(NA_character_, length(x))
  has_locus <- grepl("PA[0-9]{4}[A-Z]?", x)
  answer[has_locus] <- sub(
    ".*?(PA[0-9]{4}[A-Z]?).*", "\\1", x[has_locus], perl = TRUE
  )
  answer
}

.valid_cache_file <- function(path, pattern) {
  if (!file.exists(path) || is.na(file.info(path)$size) ||
      file.info(path)$size <= 0) return(FALSE)
  first_line <- tryCatch(
    readLines(path, n = 1, warn = FALSE),
    error = function(e) character()
  )
  length(first_line) == 1 && grepl(pattern, first_line, perl = TRUE)
}

.download_to_cache <- function(url, destination, label, pattern,
                               refresh = FALSE) {
  if (!refresh && .valid_cache_file(destination, pattern)) return(TRUE)
  temporary_file <- tempfile(
    pattern = paste0(basename(destination), "."),
    tmpdir = dirname(destination)
  )
  on.exit(unlink(temporary_file), add = TRUE)
  message("Downloading ", label, "...")
  worked <- tryCatch({
    status <- suppressWarnings(
      utils::download.file(url, temporary_file, mode = "wb", quiet = TRUE)
    )
    identical(status, 0L) && .valid_cache_file(temporary_file, pattern)
  }, error = function(e) FALSE)
  if (!worked) return(FALSE)
  file.copy(temporary_file, destination, overwrite = TRUE)
}

.parse_go <- function(values, loci, ontology) {
  rows <- lapply(seq_along(values), function(i) {
    if (is.na(loci[i]) || is.na(values[i]) || trimws(values[i]) == "") {
      return(NULL)
    }
    terms <- trimws(unlist(strsplit(values[i], ";", fixed = TRUE)))
    terms <- terms[grepl("\\[GO:[0-9]+\\]", terms)]
    if (!length(terms)) return(NULL)
    data.frame(
      gene_id = loci[i], database = "UniProt-GOA", ontology = ontology,
      set_id = sub(".*\\[(GO:[0-9]+)\\].*", "\\1", terms),
      set_name = trimws(sub("\\s*\\[GO:[0-9]+\\].*$", "", terms)),
      stringsAsFactors = FALSE
    )
  })
  rows <- Filter(Negate(is.null), rows)
  if (!length(rows)) return(.empty_membership())
  unique(do.call(rbind, rows))
}

.annotation_column <- function(data, exact, pattern = exact,
                               required = FALSE) {
  if (exact %in% names(data)) return(exact)
  hit <- grep(pattern, names(data), value = TRUE, ignore.case = TRUE)
  if (length(hit)) return(hit[1])
  if (required) stop("Missing annotation column: ", exact, call. = FALSE)
  NA_character_
}

.column_or_blank <- function(data, column) {
  if (is.na(column)) rep("", nrow(data)) else as.character(data[[column]])
}

.parse_kegg <- function(links_file, names_file) {
  links <- utils::read.delim(
    links_file, header = FALSE, sep = "\t", quote = "",
    comment.char = "", stringsAsFactors = FALSE
  )
  pathway_names <- utils::read.delim(
    names_file, header = FALSE, sep = "\t", quote = "",
    comment.char = "", stringsAsFactors = FALSE
  )
  if (ncol(links) != 2 || ncol(pathway_names) != 2) {
    stop("Invalid KEGG cache.", call. = FALSE)
  }
  names(links) <- c("kegg_gene", "kegg_pathway")
  names(pathway_names) <- c("kegg_pathway", "set_name")
  links$gene_id <- toupper(sub("^pae:", "", links$kegg_gene))
  links$set_id <- sub("^path:", "", links$kegg_pathway)
  pathway_names$set_id <- sub("^path:", "", pathway_names$kegg_pathway)
  links$set_name <- pathway_names$set_name[
    match(links$set_id, pathway_names$set_id)
  ]
  missing <- is.na(links$set_name)
  links$set_name[missing] <- links$set_id[missing]
  links$database <- "KEGG"
  links$ontology <- "KEGG pathway"
  unique(links[c("gene_id", "database", "ontology", "set_id", "set_name")])
}

.parse_uniprot <- function(path) {
  raw <- utils::read.delim(
    path, header = TRUE, sep = "\t", quote = "", comment.char = "",
    stringsAsFactors = FALSE, check.names = FALSE
  )
  columns <- list(
    accession = .annotation_column(raw, "Entry", required = TRUE),
    gene_names = .annotation_column(raw, "Gene Names", "^Gene Names$"),
    locus = .annotation_column(
      raw, "Gene Names (ordered locus)", "ordered locus", TRUE
    ),
    protein = .annotation_column(raw, "Protein names"),
    go_ids = .annotation_column(raw, "Gene Ontology IDs"),
    go_bp = .annotation_column(
      raw, "Gene Ontology (biological process)", "biological process"
    ),
    go_mf = .annotation_column(
      raw, "Gene Ontology (molecular function)", "molecular function"
    ),
    go_cc = .annotation_column(
      raw, "Gene Ontology (cellular component)", "cellular component"
    ),
    function_text = .annotation_column(raw, "Function [CC]", "^Function"),
    ec = .annotation_column(raw, "EC number"),
    pathway = .annotation_column(raw, "Pathway", "^Pathway$")
  )
  standard <- data.frame(
    gene_id = .embedded_pao1_locus(.column_or_blank(raw, columns$locus)),
    uniprot_accession = .column_or_blank(raw, columns$accession),
    uniprot_gene_names = .column_or_blank(raw, columns$gene_names),
    uniprot_protein_name = .column_or_blank(raw, columns$protein),
    go_ids = .column_or_blank(raw, columns$go_ids),
    go_biological_process = .column_or_blank(raw, columns$go_bp),
    go_molecular_function = .column_or_blank(raw, columns$go_mf),
    go_cellular_component = .column_or_blank(raw, columns$go_cc),
    uniprot_function = .column_or_blank(raw, columns$function_text),
    ec_numbers = .column_or_blank(raw, columns$ec),
    uniprot_pathway = .column_or_blank(raw, columns$pathway),
    stringsAsFactors = FALSE
  )
  standard <- standard[!is.na(standard$gene_id), , drop = FALSE]
  membership <- unique(rbind(
    .parse_go(standard$go_biological_process, standard$gene_id,
              "GO biological process"),
    .parse_go(standard$go_molecular_function, standard$gene_id,
              "GO molecular function"),
    .parse_go(standard$go_cellular_component, standard$gene_id,
              "GO cellular component")
  ))
  groups <- split(seq_len(nrow(standard)), standard$gene_id)
  rows <- lapply(names(groups), function(locus) {
    index <- groups[[locus]]
    values <- lapply(standard[index, -1, drop = FALSE], .collapse_unique)
    data.frame(
      gene_id = locus,
      as.data.frame(values, stringsAsFactors = FALSE, check.names = FALSE),
      stringsAsFactors = FALSE, check.names = FALSE
    )
  })
  proteins <- if (length(rows)) do.call(rbind, rows) else .empty_uniprot()
  rownames(proteins) <- NULL
  list(proteins = proteins, membership = membership)
}

.collapse_kegg <- function(membership) {
  if (!nrow(membership)) {
    return(data.frame(
      gene_id = character(), kegg_pathway_ids = character(),
      kegg_pathway_names = character(), stringsAsFactors = FALSE
    ))
  }
  groups <- split(seq_len(nrow(membership)), membership$gene_id)
  do.call(rbind, lapply(names(groups), function(locus) {
    index <- groups[[locus]]
    data.frame(
      gene_id = locus,
      kegg_pathway_ids = .collapse_unique(membership$set_id[index]),
      kegg_pathway_names = .collapse_unique(membership$set_name[index]),
      stringsAsFactors = FALSE
    )
  }))
}

.combine_pseudocap_annotations <- function(annotations, pseudocap) {
  if (is.null(pseudocap)) {
    annotations$pseudocap_by_locus <- data.frame(
      gene_id = character(), pseudocap_gene_name = character(),
      pseudocap_product = character(), gene_length = numeric(),
      stringsAsFactors = FALSE
    )
    annotations$pseudocap_metadata <- NULL
    class(annotations) <- c("pa_annotations_v3", "pa_annotations_v2")
    return(annotations)
  }
  annotations$membership <- unique(rbind(
    annotations$membership, pseudocap$membership
  ))
  annotations$pseudocap_by_locus <- pseudocap$by_locus
  annotations$pseudocap_metadata <- pseudocap$metadata
  class(annotations) <- c("pa_annotations_v3", "pa_annotations_v2")
  annotations
}

.fetch_annotations <- function(cache_dir, refresh = FALSE,
                               pseudocap_file = NULL,
                               pseudocap_url = NULL) {
  cache_dir <- path.expand(cache_dir)
  parsed_file <- file.path(cache_dir, "pa_annotations.rds")
  if (!refresh && file.exists(parsed_file)) {
    cached <- tryCatch(readRDS(parsed_file), error = function(e) NULL)
    if (inherits(cached, "pa_annotations_v2")) {
      pseudocap <- if (!is.null(pseudocap_file) || !is.null(pseudocap_url)) {
        fetch_pseudocap_annotations(
          source = pseudocap_file, url = pseudocap_url,
          cache_dir = file.path(cache_dir, "PseudoCAP"), refresh = refresh
        )
      } else NULL
      return(.combine_pseudocap_annotations(cached, pseudocap))
    }
  }
  # Reusing a valid parsed collection requires read access only. Check write
  # access when a refresh or cache rebuild is actually necessary.
  dir.create(cache_dir, recursive = TRUE, showWarnings = FALSE)
  if (!dir.exists(cache_dir) || file.access(cache_dir, 2) != 0) {
    stop("Annotation cache is not writable: ", cache_dir, call. = FALSE)
  }
  kegg_links_file <- file.path(cache_dir, "kegg_gene_pathway.tsv")
  kegg_names_file <- file.path(cache_dir, "kegg_pathway_names.tsv")
  uniprot_file <- file.path(cache_dir, "uniprot_annotations.tsv")
  kegg_ok <- .download_to_cache(
    "https://rest.kegg.jp/link/pathway/pae", kegg_links_file,
    "KEGG gene-pathway annotations",
    "^pae:PA[0-9]{4}[A-Z]?\\tpath:pae[0-9]+", refresh
  ) && .download_to_cache(
    "https://rest.kegg.jp/list/pathway/pae", kegg_names_file,
    "KEGG pathway names", "^(path:)?pae[0-9]+\\t", refresh
  )
  uniprot_ok <- .download_to_cache(
    paste0(
      "https://rest.uniprot.org/uniprotkb/stream?",
      "compressed=false&format=tsv&query=%28proteome%3AUP000002438%29",
      "&fields=accession,gene_names,gene_oln,protein_name,go_id,",
      "go_p,go_f,go_c,cc_function,ec,cc_pathway"
    ),
    uniprot_file, "UniProt and GO annotations",
    "^Entry\\t.*Gene Names \\(ordered locus\\)", refresh
  )
  if (!kegg_ok && !uniprot_ok) {
    stop("KEGG and UniProt annotations are both unavailable.", call. = FALSE)
  }
  kegg <- if (kegg_ok) {
    .parse_kegg(kegg_links_file, kegg_names_file)
  } else {
    warning("KEGG annotations are unavailable.", call. = FALSE)
    .empty_membership()
  }
  uniprot <- if (uniprot_ok) {
    .parse_uniprot(uniprot_file)
  } else {
    warning("UniProt and GO annotations are unavailable.", call. = FALSE)
    list(proteins = .empty_uniprot(), membership = .empty_membership())
  }
  result <- structure(
    list(
      membership = unique(rbind(kegg, uniprot$membership)),
      kegg_by_locus = .collapse_kegg(kegg),
      uniprot_by_locus = uniprot$proteins
    ),
    class = "pa_annotations_v2"
  )
  saveRDS(result, parsed_file)
  pseudocap <- if (!is.null(pseudocap_file) || !is.null(pseudocap_url)) {
    fetch_pseudocap_annotations(
      source = pseudocap_file, url = pseudocap_url,
      cache_dir = file.path(cache_dir, "PseudoCAP"), refresh = refresh
    )
  } else NULL
  .combine_pseudocap_annotations(result, pseudocap)
}

#' Fetch the complete PAO1 annotation collection
#'
#' Retrieves cached KEGG and UniProt-GOA annotations and optionally merges a
#' PseudoCAP/Pseudomonas Genome Database export.
#'
#' @param cache_dir Shared annotation cache.
#' @param refresh Force fresh network downloads.
#' @param pseudocap_file Optional local PseudoCAP annotation export.
#' @param pseudocap_url Optional direct PseudoCAP download URL.
#' @return An annotation object with gene-set membership and locus-level data.
#' @export
fetch_pa_annotations <- function(
    cache_dir = file.path(tools::R_user_dir("paannotate", "cache"), "PAO1"),
    refresh = FALSE, pseudocap_file = NULL, pseudocap_url = NULL) {
  .fetch_annotations(cache_dir, refresh, pseudocap_file, pseudocap_url)
}

.lookup <- function(ids, table, column) {
  if (!nrow(table)) return(rep("", length(ids)))
  values <- table[[column]][match(ids, table$gene_id)]
  values[is.na(values)] <- ""
  values
}

.annotate_genes <- function(data, annotations, id_col, name_col,
                            description_col) {
  if (!name_col %in% names(data)) data[[name_col]] <- ""
  if (!description_col %in% names(data)) data[[description_col]] <- ""
  data[[name_col]][is.na(data[[name_col]])] <- ""
  data[[description_col]][is.na(data[[description_col]])] <- ""
  data$pao1_locus <- .exact_pao1_locus(data[[id_col]])
  fallback <- .exact_pao1_locus(data[[name_col]])
  missing <- is.na(data$pao1_locus)
  data$pao1_locus[missing] <- fallback[missing]
  data$gene_label <- ifelse(
    data[[name_col]] == "" | data[[name_col]] == "-",
    data[[id_col]], data[[name_col]]
  )
  data$kegg_pathway_ids <- .lookup(
    data$pao1_locus, annotations$kegg_by_locus, "kegg_pathway_ids"
  )
  data$kegg_pathway_names <- .lookup(
    data$pao1_locus, annotations$kegg_by_locus, "kegg_pathway_names"
  )
  for (column in setdiff(names(annotations$uniprot_by_locus), "gene_id")) {
    data[[column]] <- .lookup(
      data$pao1_locus, annotations$uniprot_by_locus, column
    )
  }
  pseudocap <- annotations$pseudocap_by_locus
  if (is.null(pseudocap)) {
    pseudocap <- data.frame(
      gene_id = character(), pseudocap_gene_name = character(),
      pseudocap_product = character(), gene_length = numeric(),
      stringsAsFactors = FALSE
    )
  }
  for (column in setdiff(names(pseudocap), "gene_id")) {
    data[[column]] <- if (column == "gene_length") {
      if (!nrow(pseudocap)) rep(NA_real_, nrow(data)) else
        pseudocap[[column]][match(data$pao1_locus, pseudocap$gene_id)]
    } else .lookup(data$pao1_locus, pseudocap, column)
  }
  data$has_kegg_annotation <- data$kegg_pathway_ids != ""
  data$has_uniprot_annotation <- data$uniprot_accession != ""
  data$has_go_annotation <- data$go_ids != ""
  data$has_pseudocap_annotation <- data$pseudocap_gene_name != "" |
    data$pseudocap_product != "" | !is.na(data$gene_length)
  data$has_external_annotation <- data$has_kegg_annotation |
    data$has_uniprot_annotation | data$has_go_annotation |
    data$has_pseudocap_annotation
  data
}
