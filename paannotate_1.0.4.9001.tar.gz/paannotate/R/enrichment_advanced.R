.as_pa_data <- function(x) {
  if (inherits(x, "pa_input")) x$data else if (is.data.frame(x)) x else
    stop("data must be a data frame or pa_input object.", call. = FALSE)
}

.as_membership <- function(membership) {
  if (inherits(membership, "pa_annotations_v2") ||
      inherits(membership, "pa_annotations_v3")) membership <- membership$membership
  required <- c("gene_id", "database", "ontology", "set_id", "set_name")
  if (!is.data.frame(membership) || length(setdiff(required, names(membership)))) {
    stop("membership must contain gene_id, database, ontology, set_id, and set_name.",
         call. = FALSE)
  }
  membership <- membership[required]
  membership$gene_id <- trimws(as.character(membership$gene_id))
  unique(membership[!is.na(membership$gene_id) & membership$gene_id != "", ,
                    drop = FALSE])
}

.require_enrichment_package <- function(package, purpose) {
  if (!requireNamespace(package, quietly = TRUE)) {
    stop("The optional Bioconductor package '", package, "' is required for ",
         purpose, ". Install it with BiocManager::install('", package, "').",
         call. = FALSE)
  }
}

.resolve_gene_ids <- function(data, gene_id_col) {
  if (gene_id_col == "auto") {
    gene_id_col <- if ("pao1_locus" %in% names(data)) "pao1_locus" else
      if ("gene_id" %in% names(data)) "gene_id" else
        .detect_gene_id_column(data, "auto")
  }
  if (!gene_id_col %in% names(data)) stop("Gene ID column not found: ", gene_id_col,
                                          call. = FALSE)
  trimws(as.character(data[[gene_id_col]]))
}

.unique_gene_rows <- function(data, ids) {
  keep <- !is.na(ids) & ids != "" & !duplicated(ids)
  list(data = data[keep, , drop = FALSE], ids = ids[keep])
}

#' Bias-aware over-representation analysis for RNA-seq
#'
#' Uses goseq's probability weighting function to adjust a selected-gene test
#' for gene length, average expression, or another numeric selection bias.
#' This method still needs a selected-gene definition; use [pa_enrich_ranked()]
#' when the goal is to use evidence from every tested gene without a cutoff.
#'
#' @param data Differential-expression data frame or `pa_input`.
#' @param membership Annotation object or five-column gene-set membership table.
#' @param selected Optional logical vector, named 0/1 vector, or character vector
#'   of selected gene IDs. When omitted, `padj_cutoff` and `log2fc_cutoff` apply.
#' @param gene_id_col Gene identifier column or `"auto"`.
#' @param bias `"gene_length"`, `"mean_expression"`, or `"custom"`.
#' @param bias_col Numeric bias column. Inferred from `bias` when omitted.
#' @param bias_values Optional named numeric vector, overriding `bias_col`.
#' @param expression_cols Expression columns used to compute mean expression.
#' @param padj_col,log2fc_col Statistical columns used when `selected` is omitted.
#' @param padj_cutoff,log2fc_cutoff Selected-gene thresholds.
#' @param method goseq method; `"Wallenius"` is recommended.
#' @param use_genes_without_cat Include genes with no category in the background.
#' @return A list containing enrichment results, the probability weighting
#'   function, and the aligned input vectors.
#' @export
pa_enrich_bias <- function(
    data, membership, selected = NULL, gene_id_col = "auto",
    bias = c("gene_length", "mean_expression", "custom"), bias_col = NULL,
    bias_values = NULL, expression_cols = NULL,
    padj_col = "padj", log2fc_col = "log2FoldChange",
    padj_cutoff = 0.05, log2fc_cutoff = 1,
    method = "Wallenius", use_genes_without_cat = FALSE) {
  .require_enrichment_package("goseq", "bias-aware enrichment")
  bias <- match.arg(bias)
  data <- .as_pa_data(data)
  ids <- .resolve_gene_ids(data, gene_id_col)
  unique_rows <- .unique_gene_rows(data, ids)
  data <- unique_rows$data
  ids <- unique_rows$ids
  membership <- .as_membership(membership)

  if (is.null(selected)) {
    missing <- setdiff(c(padj_col, log2fc_col), names(data))
    if (length(missing)) stop("Missing selection columns: ",
                              paste(missing, collapse = ", "), call. = FALSE)
    selected_vector <- !is.na(data[[padj_col]]) & data[[padj_col]] < padj_cutoff &
      !is.na(data[[log2fc_col]]) & abs(data[[log2fc_col]]) >= log2fc_cutoff
  } else if (is.character(selected)) {
    selected_vector <- ids %in% toupper(trimws(selected))
  } else if (!is.null(names(selected))) {
    selected_vector <- as.logical(selected[ids])
    selected_vector[is.na(selected_vector)] <- FALSE
  } else {
    if (length(selected) != nrow(data)) {
      stop("An unnamed selected vector must have one value per unique input gene.",
           call. = FALSE)
    }
    selected_vector <- as.logical(selected)
  }
  if (!any(selected_vector)) stop("No genes were selected.", call. = FALSE)

  if (!is.null(bias_values)) {
    if (is.null(names(bias_values))) {
      if (length(bias_values) != length(ids)) {
        stop("Unnamed bias_values must have one value per gene.", call. = FALSE)
      }
      bias_vector <- as.numeric(bias_values)
    } else bias_vector <- as.numeric(bias_values[ids])
  } else if (!is.null(bias_col)) {
    if (!bias_col %in% names(data)) stop("Bias column not found: ", bias_col,
                                         call. = FALSE)
    bias_vector <- suppressWarnings(as.numeric(data[[bias_col]]))
  } else if (bias == "gene_length") {
    if (!"gene_length" %in% names(data)) {
      stop("gene_length is unavailable. Import PseudoCAP annotations or supply bias_col/bias_values.",
           call. = FALSE)
    }
    bias_col <- "gene_length"
    bias_vector <- suppressWarnings(as.numeric(data$gene_length))
  } else if (bias == "mean_expression") {
    if (is.null(expression_cols) || length(setdiff(expression_cols, names(data)))) {
      stop("Supply valid expression_cols for mean-expression bias.", call. = FALSE)
    }
    numeric_expression <- .coerce_numeric(data, expression_cols)[expression_cols]
    bias_vector <- rowMeans(numeric_expression, na.rm = TRUE)
  } else {
    stop("custom bias requires bias_col or bias_values.", call. = FALSE)
  }
  usable <- is.finite(bias_vector) & bias_vector >= 0
  if (sum(usable) < 2L) stop("Too few genes have usable bias values.", call. = FALSE)
  ids <- ids[usable]
  selected_vector <- selected_vector[usable]
  bias_vector <- bias_vector[usable]
  de <- as.integer(selected_vector)
  names(de) <- ids
  names(bias_vector) <- ids
  membership$key <- paste(membership$database, membership$ontology,
                          membership$set_id, sep = "::")
  mapping <- unique(membership[membership$gene_id %in% ids,
                               c("gene_id", "key"), drop = FALSE])
  probability <- goseq::nullp(de, bias.data = bias_vector, plot.fit = FALSE)
  result <- goseq::goseq(
    probability, gene2cat = mapping, method = method,
    use_genes_without_cat = use_genes_without_cat
  )
  set_metadata <- unique(membership[c("key", "database", "ontology", "set_id",
                                      "set_name")])
  result <- merge(result, set_metadata, by.x = "category", by.y = "key",
                  all.x = TRUE, sort = FALSE)
  result$padj <- stats::p.adjust(result$over_represented_pvalue, method = "BH")
  result <- result[order(result$padj, result$over_represented_pvalue), , drop = FALSE]
  rownames(result) <- NULL
  structure(list(results = result, probability_weighting = probability,
                 selected = de, bias = bias_vector, method = "goseq"),
            class = "pa_enrichment")
}

.rank_statistic <- function(data, ids, statistic_col) {
  if (statistic_col == "auto") {
    candidates <- c("stat", "t", "WaldStatistic", "score")
    statistic_col <- candidates[candidates %in% names(data)][1]
    if (is.na(statistic_col)) statistic_col <- "signed_log10_pvalue"
  }
  if (statistic_col == "signed_log10_pvalue") {
    needed <- c("log2FoldChange", "pvalue")
    if (length(setdiff(needed, names(data)))) {
      stop("Automatic ranking needs a stat/t/score column or log2FoldChange plus pvalue.",
           call. = FALSE)
    }
    p <- suppressWarnings(as.numeric(data$pvalue))
    p[!is.na(p) & p < .Machine$double.xmin] <- .Machine$double.xmin
    statistic <- sign(suppressWarnings(as.numeric(data$log2FoldChange))) * -log10(p)
  } else {
    if (!statistic_col %in% names(data)) stop("Statistic column not found: ",
                                              statistic_col, call. = FALSE)
    statistic <- suppressWarnings(as.numeric(data[[statistic_col]]))
  }
  names(statistic) <- ids
  statistic[is.finite(statistic)]
}

.gene_set_indices <- function(membership, genes, minimum_size, maximum_size) {
  membership$key <- paste(membership$database, membership$ontology,
                          membership$set_id, sep = "::")
  paths <- split(membership$gene_id, membership$key)
  paths <- lapply(paths, function(x) unique(intersect(x, genes)))
  paths <- paths[vapply(paths, length, integer(1)) >= minimum_size &
                   vapply(paths, length, integer(1)) <= maximum_size]
  indices <- lapply(paths, match, table = genes)
  metadata <- unique(membership[c("key", "database", "ontology", "set_id", "set_name")])
  list(paths = paths, indices = indices, metadata = metadata)
}

.decorate_ranked_result <- function(result, metadata, key_column) {
  result$.pa_key <- as.character(result[[key_column]])
  result <- merge(result, metadata, by.x = ".pa_key", by.y = "key",
                  all.x = TRUE, sort = FALSE)
  result$.pa_key <- NULL
  result
}

#' Full-ranked pathway analysis with optional inter-gene correlation control
#'
#' Tests all genes instead of defining an arbitrary significance cutoff.
#' `camera_pr` uses pre-ranked CAMERA with a specified correlation; `camera`
#' uses normalized expression plus a design matrix and can estimate correlation;
#' `fgsea` is a fast ranked alternative that does not model correlation.
#'
#' @param data Differential-expression data frame or `pa_input`.
#' @param membership Annotation object or gene-set membership table.
#' @param method `"camera_pr"`, `"camera"`, or `"fgsea"`.
#' @param gene_id_col Gene identifier column or `"auto"`.
#' @param statistic_col Ranking column, `"auto"`, or
#'   `"signed_log10_pvalue"`.
#' @param expression Optional normalized log-expression matrix for `camera`,
#'   with genes in rows and gene IDs as row names.
#' @param expression_cols Columns in `data` used when `expression` is omitted.
#' @param design Design matrix required by `camera`.
#' @param contrast Coefficient/contrast passed to `limma::camera`.
#' @param inter_gene_cor Numeric correlation, or `NA` with full `camera` to
#'   estimate correlation separately for each gene set.
#' @param minimum_size,maximum_size Gene-set size limits.
#' @param ... Additional arguments passed to `fgsea::fgsea`.
#' @return A `pa_enrichment` object containing results and the complete ranking.
#' @export
pa_enrich_ranked <- function(
    data, membership, method = c("camera_pr", "camera", "fgsea"),
    gene_id_col = "auto", statistic_col = "auto", expression = NULL,
    expression_cols = NULL, design = NULL, contrast = NULL,
    inter_gene_cor = 0.01, minimum_size = 3, maximum_size = 500, ...) {
  method <- match.arg(method)
  data <- .as_pa_data(data)
  ids <- .resolve_gene_ids(data, gene_id_col)
  unique_rows <- .unique_gene_rows(data, ids)
  data <- unique_rows$data
  ids <- unique_rows$ids
  membership <- .as_membership(membership)
  statistic <- .rank_statistic(data, ids, statistic_col)
  if (length(statistic) < 2L) stop("Too few finite ranked statistics.", call. = FALSE)
  sets <- .gene_set_indices(membership, names(statistic), minimum_size, maximum_size)
  if (!length(sets$paths)) stop("No gene sets meet the size and overlap requirements.",
                                call. = FALSE)

  if (method == "camera_pr") {
    .require_enrichment_package("limma", "correlation-aware ranked enrichment")
    result <- limma::cameraPR(statistic, sets$indices,
                              inter.gene.cor = inter_gene_cor)
    result$gene_set <- rownames(result)
    rownames(result) <- NULL
    result <- .decorate_ranked_result(result, sets$metadata, "gene_set")
  } else if (method == "camera") {
    .require_enrichment_package("limma", "correlation-aware ranked enrichment")
    if (is.null(expression)) {
      if (is.null(expression_cols) || length(setdiff(expression_cols, names(data)))) {
        stop("Full camera requires expression or valid expression_cols.", call. = FALSE)
      }
      expression <- as.matrix(.coerce_numeric(data, expression_cols)[expression_cols])
      rownames(expression) <- ids
    }
    if (is.null(rownames(expression))) {
      stop("expression must have PAO1 gene IDs as row names.", call. = FALSE)
    }
    expression <- expression[intersect(names(statistic), rownames(expression)), , drop = FALSE]
    camera_sets <- .gene_set_indices(membership, rownames(expression),
                                     minimum_size, maximum_size)
    if (is.null(design)) stop("Full camera requires a design matrix.", call. = FALSE)
    if (is.null(contrast)) contrast <- ncol(design)
    result <- limma::camera(expression, camera_sets$indices, design,
                            contrast = contrast, inter.gene.cor = inter_gene_cor)
    result$gene_set <- rownames(result)
    rownames(result) <- NULL
    result <- .decorate_ranked_result(result, camera_sets$metadata, "gene_set")
  } else {
    .require_enrichment_package("fgsea", "fast ranked enrichment")
    result <- as.data.frame(fgsea::fgsea(
      pathways = sets$paths, stats = statistic, minSize = minimum_size,
      maxSize = maximum_size, ...
    ))
    result <- .decorate_ranked_result(result, sets$metadata, "pathway")
  }
  structure(list(results = result,
                 ranked_genes = data.frame(gene_id = names(sort(statistic,
                                                                decreasing = TRUE)),
                                           statistic = unname(sort(statistic,
                                                                   decreasing = TRUE)),
                                           stringsAsFactors = FALSE),
                 method = method, inter_gene_cor = inter_gene_cor),
            class = "pa_enrichment")
}

#' @export
print.pa_enrichment <- function(x, ...) {
  cat("paannotate enrichment:", x$method, "\n")
  print(utils::head(x$results, 10), row.names = FALSE)
  invisible(x)
}
