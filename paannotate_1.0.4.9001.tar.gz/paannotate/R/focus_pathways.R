.focus_presets <- function() {
  data.frame(
    preset = c(
      "iron", "secretion", "biofilm", "quorum_sensing", "motility",
      "stress", "resistance", "metabolism", "virulence"
    ),
    label = c(
      "Iron", "Secretion", "Biofilm", "Quorum sensing", "Motility",
      "Stress responses", "Antimicrobial resistance", "Metabolism", "Virulence"
    ),
    pattern = c(
      paste0(
        "\\biron\\b|ferric|ferrous|siderophore|pyoverdine|pyochelin|",
        "\\bheme\\b|hemin|hemophore|iron[- ]sulfur|\\bfe[- ]?s\\b|",
        "\\bfur\\b|prrf|tonb-dependent"
      ),
      "secretion|secretory|type[ -]?(ii|iii|iv|v|vi|2|3|4|5|6)[ -]secretion|t3ss|t6ss",
      "biofilm|alginate|pel polysaccharide|psl polysaccharide|extracellular polymeric",
      "quorum|acyl.?homoserine|homoserine lactone|las[ri]?|rhl[ri]?|pqs",
      "motility|chemotaxis|flagell|pilus|pili|twitching",
      "stress response|oxidative stress|osmotic stress|heat shock|dna damage",
      "antibiotic|antimicrobial|drug resistance|efflux|beta.?lactam|aminoglycoside",
      "metabolic process|metabolism|biosynth|catabol|degrad",
      "virulence|pathogenesis|host interaction|toxin|cytotoxic"
    ),
    stringsAsFactors = FALSE
  )
}

.focus_rbind <- function(pieces) {
  pieces <- Filter(function(x) is.data.frame(x) && nrow(x), pieces)
  if (!length(pieces)) return(data.frame())
  columns <- unique(unlist(lapply(pieces, names), use.names = FALSE))
  pieces <- lapply(pieces, function(x) {
    for (column in setdiff(columns, names(x))) x[[column]] <- NA
    x[columns]
  })
  result <- do.call(rbind, pieces)
  rownames(result) <- NULL
  result
}

.focus_term_columns <- c("database", "ontology", "set_id", "set_name")

.focus_term_key <- function(data) {
  if (!nrow(data)) return(character())
  do.call(paste, c(data[.focus_term_columns], sep = "\r"))
}

.focus_available_terms <- function(enrichment, sources) {
  pieces <- list()
  if ("exact" %in% sources && is.data.frame(enrichment$exact$summary) &&
      nrow(enrichment$exact$summary)) {
    x <- unique(enrichment$exact$summary[.focus_term_columns])
    x$source <- "exact"
    pieces$exact <- x[c("source", .focus_term_columns)]
  }
  if ("themes" %in% sources && is.data.frame(enrichment$themes$summary) &&
      nrow(enrichment$themes$summary)) {
    x <- unique(enrichment$themes$summary[.focus_term_columns])
    x$source <- "themes"
    pieces$themes <- x[c("source", .focus_term_columns)]
  }
  .focus_rbind(pieces)
}

.focus_keep_values <- function(data, column, values) {
  if (is.null(values) || !length(values) || !nrow(data)) return(data)
  if (!column %in% names(data)) return(data[FALSE, , drop = FALSE])
  if (column == "cutoff") {
    keep <- suppressWarnings(as.integer(data[[column]])) %in%
      suppressWarnings(as.integer(values))
  } else {
    keep <- tolower(trimws(as.character(data[[column]]))) %in%
      tolower(trimws(as.character(values)))
  }
  data[!is.na(keep) & keep, , drop = FALSE]
}

.focus_resolve_input <- function(x) {
  source_path <- NULL
  report_directory <- NULL
  if (is.character(x) && length(x) == 1L) {
    source_path <- path.expand(x)
    if (!file.exists(source_path)) stop("Focused-pathway input was not found: ",
                                        source_path, call. = FALSE)
    if (dir.exists(source_path)) {
      candidates <- c(
        file.path(source_path, "00_audit", "pa_scan_enrichment.rds"),
        file.path(source_path, "enrichment_checkpoint.rds"),
        file.path(source_path, "pa_scan_enrichment.rds")
      )
      existing <- candidates[file.exists(candidates)]
      if (!length(existing)) {
        stop("That folder does not contain a saved enrichment checkpoint. Run the analysis with enrich=TRUE first.",
             call. = FALSE)
      }
      source_path <- existing[1]
      report_directory <- if (basename(dirname(source_path)) == "00_audit") {
        dirname(dirname(source_path))
      } else dirname(source_path)
    }
    if (!dir.exists(source_path)) {
      if (tolower(tools::file_ext(source_path)) != "rds") {
        stop("Supply a paannotate result, report folder, or .rds checkpoint.",
             call. = FALSE)
      }
      if (is.null(report_directory) && basename(dirname(source_path)) == "00_audit") {
        report_directory <- dirname(dirname(source_path))
      }
      x <- readRDS(source_path)
    }
  }
  scan <- NULL
  enrichment <- NULL
  if (inherits(x, "pa_scan_pipeline")) {
    scan <- x$scan
    enrichment <- x$enrichment
    if (!is.null(x$files) && "report_directory" %in% names(x$files)) {
      report_directory <- unname(x$files["report_directory"])
    }
  } else if (inherits(x, "pa_custom_pipeline")) {
    scan <- x$analysis
    enrichment <- x$enrichment
    if (!is.null(x$files) && "report_directory" %in% names(x$files)) {
      report_directory <- unname(x$files["report_directory"])
    }
  } else if (inherits(x, "pa_scan_enrichment")) {
    enrichment <- x
  } else {
    stop("x must be a pa_scan_pipeline, pa_custom_pipeline, pa_scan_enrichment, report folder, or saved enrichment .rds file.",
         call. = FALSE)
  }
  if (is.null(enrichment)) {
    stop("This result has no enrichment data. Run it with enrich=TRUE before focusing pathways.",
         call. = FALSE)
  }
  if (is.null(scan) && !is.null(report_directory)) {
    scan_path <- file.path(report_directory, "00_audit", "pa_target_scan.rds")
    if (file.exists(scan_path)) scan <- readRDS(scan_path)
    custom_path <- file.path(report_directory, "analysis_checkpoint.rds")
    if (is.null(scan) && file.exists(custom_path)) scan <- readRDS(custom_path)
  }
  list(enrichment = enrichment, scan = scan, report_directory = report_directory,
       source_path = source_path)
}

.focus_normalize <- function(focus, match) {
  presets <- .focus_presets()
  preset_key <- .scan_slug(as.character(focus))
  if (is.character(focus) && length(focus) && all(preset_key %in% presets$preset)) {
    return(lapply(seq_along(focus), function(i) {
      row <- presets[match(preset_key[i], presets$preset), , drop = FALSE]
      list(name = row$label, queries = as.character(focus[i]),
           patterns = row$pattern, modes = "regex", preset = row$preset,
           is_preset = TRUE)
    }))
  }
  if (is.character(focus)) {
    if (!length(focus) || anyNA(focus) || any(!nzchar(trimws(focus)))) {
      stop("focus must contain at least one non-blank pathway name, ID, or keyword.",
           call. = FALSE)
    }
    name <- if (length(focus) == 1L) focus else "Focused pathways"
    return(list(list(name = name, queries = focus, patterns = focus,
                     modes = rep(match, length(focus)), preset = "",
                     is_preset = rep(FALSE, length(focus)))))
  }
  if (!is.list(focus) || !length(focus)) {
    stop("focus must be a character vector or a named list of pathway collections.",
         call. = FALSE)
  }
  group_names <- names(focus)
  if (is.null(group_names)) group_names <- rep("", length(focus))
  group_names[!nzchar(trimws(group_names))] <- paste0(
    "Focus ", which(!nzchar(trimws(group_names)))
  )
  lapply(seq_along(focus), function(i) {
    queries <- as.character(unlist(focus[[i]], use.names = FALSE))
    if (!length(queries) || anyNA(queries) || any(!nzchar(trimws(queries)))) {
      stop("Every focus collection must contain a non-blank pathway name, ID, or keyword.",
           call. = FALSE)
    }
    preset_marker <- grepl("^preset:", queries, ignore.case = TRUE)
    modes <- rep(match, length(queries))
    patterns <- queries
    preset_names <- rep("", length(queries))
    if (any(preset_marker)) {
      keys <- .scan_slug(sub("^preset:", "", queries[preset_marker], ignore.case = TRUE))
      if (any(!keys %in% presets$preset)) {
        stop("Unknown preset: ", paste(unique(keys[!keys %in% presets$preset]),
                                        collapse = ", "), call. = FALSE)
      }
      rows <- match(keys, presets$preset)
      patterns[preset_marker] <- presets$pattern[rows]
      modes[preset_marker] <- "regex"
      preset_names[preset_marker] <- keys
    }
    list(name = group_names[i], queries = queries, patterns = patterns,
         modes = modes, preset = paste(preset_names[nzchar(preset_names)], collapse = "; "),
         is_preset = preset_marker)
  })
}

.focus_match_terms <- function(terms, groups) {
  rows <- list()
  counter <- 0L
  searchable <- tolower(paste(terms$set_id, terms$set_name, terms$ontology,
                              terms$database, sep = " | "))
  pathway_names <- tolower(as.character(terms$set_name))
  for (group in groups) {
    for (i in seq_along(group$queries)) {
      query <- group$queries[i]
      pattern <- group$patterns[i]
      requested <- group$modes[i]
      exact_id <- tolower(trimws(as.character(terms$set_id))) ==
        tolower(trimws(query))
      exact_name <- tolower(trimws(as.character(terms$set_name))) ==
        tolower(trimws(query))
      exact <- exact_id | exact_name
      effective <- requested
      if (requested == "auto") effective <- if (any(exact)) "exact" else "contains"
      keep <- if (effective == "exact") {
        exact
      } else if (effective == "contains") {
        grepl(tolower(pattern), searchable, fixed = TRUE)
      } else {
        tryCatch(
          grepl(pattern, if (group$is_preset[i]) pathway_names else searchable,
                ignore.case = TRUE, perl = TRUE),
          error = function(e) stop("Invalid focus regular expression '", query,
                                   "': ", conditionMessage(e), call. = FALSE)
        )
      }
      keep[is.na(keep)] <- FALSE
      count <- sum(keep)
      if (count) {
        matched <- terms[keep, , drop = FALSE]
        match_type <- if (effective == "exact") {
          ifelse(exact_id[keep], "exact set ID", "exact set name")
        } else if (effective == "regex" && group$is_preset[i]) {
          "preset keyword"
        } else paste(effective, "keyword")
        counter <- counter + 1L
        rows[[counter]] <- data.frame(
          focus_group = group$name, query = query,
          requested_match = requested, effective_match = effective,
          matched = TRUE, match_type = match_type,
          matches_for_query = count, ambiguous_query = count > 1L,
          matched, stringsAsFactors = FALSE
        )
      } else {
        counter <- counter + 1L
        empty <- as.list(rep(NA_character_, ncol(terms)))
        names(empty) <- names(terms)
        rows[[counter]] <- data.frame(
          focus_group = group$name, query = query,
          requested_match = requested, effective_match = effective,
          matched = FALSE, match_type = "no match",
          matches_for_query = 0L, ambiguous_query = FALSE,
          as.data.frame(empty, stringsAsFactors = FALSE), stringsAsFactors = FALSE
        )
      }
    }
  }
  .focus_rbind(rows)
}

.focus_filter_table <- function(data, selected_terms, targets, cutoffs,
                                directions, methods, evidence, summary = FALSE) {
  if (!is.data.frame(data) || !nrow(data) || !nrow(selected_terms)) {
    return(if (is.data.frame(data)) data[FALSE, , drop = FALSE] else data.frame())
  }
  keep <- .focus_term_key(data) %in% .focus_term_key(selected_terms)
  data <- data[keep, , drop = FALSE]
  data <- .focus_keep_values(data, "target", targets)
  data <- .focus_keep_values(data, "cutoff", cutoffs)
  data <- .focus_keep_values(data, "direction", directions)
  if (!summary && !is.null(methods)) data <- .focus_keep_values(data, "method", methods)
  if (summary && !is.null(methods) && nrow(data)) {
    wants_ora <- "ora" %in% methods
    ranked_methods <- setdiff(methods, "ora")
    ora_available <- if ("ora_best_fdr" %in% names(data)) {
      is.finite(suppressWarnings(as.numeric(data$ora_best_fdr)))
    } else rep(FALSE, nrow(data))
    ranked_available <- if ("ranked_best_fdr" %in% names(data)) {
      is.finite(suppressWarnings(as.numeric(data$ranked_best_fdr)))
    } else rep(FALSE, nrow(data))
    if (length(ranked_methods) && "ranked_methods" %in% names(data)) {
      ranked_available <- ranked_available & vapply(as.character(data$ranked_methods),
        function(value) any(vapply(ranked_methods, function(method) {
          grepl(paste0("(^|; )", method, "($|; )"), value)
        }, logical(1))), logical(1))
    }
    data <- data[(wants_ora & ora_available) |
                   (length(ranked_methods) > 0L & ranked_available), , drop = FALSE]
  }
  if (evidence == "supported" && nrow(data)) {
    supported <- if (summary && "evidence_tier" %in% names(data)) {
      !is.na(data$evidence_tier) & data$evidence_tier != "Exploratory"
    } else if ("strict_support" %in% names(data)) {
      data$strict_support %in% TRUE
    } else rep(FALSE, nrow(data))
    data <- data[supported, , drop = FALSE]
  }
  data
}

.focus_add_source <- function(data, source) {
  if (!is.data.frame(data) || !nrow(data)) return(data)
  data$source <- source
  data[c("source", setdiff(names(data), "source"))]
}

.focus_split_genes <- function(data, column, basis) {
  if (!is.data.frame(data) || !nrow(data) || !column %in% names(data)) {
    return(data.frame())
  }
  rows <- list()
  counter <- 0L
  metadata <- intersect(c("source", .focus_term_columns, "target", "cutoff",
                          "direction", "method", "global_fdr",
                          "enrichment_score", "rank_mode"), names(data))
  for (i in seq_len(nrow(data))) {
    value <- as.character(data[[column]][i])
    if (is.na(value) || !nzchar(trimws(value))) next
    genes <- unique(trimws(strsplit(value, ";", fixed = TRUE)[[1]]))
    genes <- genes[nzchar(genes)]
    if (!length(genes)) next
    counter <- counter + 1L
    row <- data[rep(i, length(genes)), metadata, drop = FALSE]
    row$gene_id <- genes
    row$membership_basis <- basis
    rows[[counter]] <- row
  }
  .focus_rbind(rows)
}

.focus_membership <- function(enrichment, selected_terms, raw) {
  pieces <- list()
  exact_terms <- selected_terms[selected_terms$source == "exact", , drop = FALSE]
  theme_terms <- selected_terms[selected_terms$source == "themes", , drop = FALSE]
  if (nrow(exact_terms) && is.data.frame(enrichment$exact$membership)) {
    x <- enrichment$exact$membership
    x <- x[.focus_term_key(x) %in% .focus_term_key(exact_terms), , drop = FALSE]
    if (nrow(x)) {
      x$source <- "exact"
      x$membership_basis <- "complete pathway membership"
      pieces$exact <- x[c("source", .focus_term_columns, "gene_id", "membership_basis")]
    }
  }
  if (nrow(theme_terms) && is.data.frame(enrichment$themes$membership)) {
    x <- enrichment$themes$membership
    x <- x[.focus_term_key(x) %in% .focus_term_key(theme_terms), , drop = FALSE]
    if (nrow(x)) {
      x$source <- "themes"
      x$membership_basis <- "complete pathway membership"
      pieces$themes <- x[c("source", .focus_term_columns, "gene_id", "membership_basis")]
    }
  }
  # Reports made before exact membership was retained can still provide the
  # genes actually observed in ORA overlaps and ranked leading edges.
  if (nrow(exact_terms) && !is.data.frame(enrichment$exact$membership)) {
    pieces$legacy_ora <- .focus_split_genes(
      .focus_add_source(raw$exact_ora, "exact"), "overlap_genes",
      "observed ORA overlap (legacy report)"
    )
    pieces$legacy_ranked <- .focus_split_genes(
      .focus_add_source(raw$exact_ranked, "exact"), "leading_edge_genes",
      "ranked leading edge (legacy report)"
    )
  }
  result <- unique(.focus_rbind(pieces))
  annotations <- enrichment$gene_annotations
  if (nrow(result) && is.data.frame(annotations) && nrow(annotations)) {
    result <- merge(result, annotations, by = "gene_id", all.x = TRUE, sort = FALSE)
    result <- result[c("gene_id", setdiff(names(result), "gene_id"))]
  }
  result
}

.focus_ranked_matrix <- function(data, maximum_terms) {
  required <- c(.focus_term_columns, "target", "cutoff", "method",
                "enrichment_score", "global_fdr")
  if (!is.data.frame(data) || !nrow(data) || length(setdiff(required, names(data)))) {
    return(NULL)
  }
  value <- suppressWarnings(as.numeric(data$enrichment_score))
  fdr <- suppressWarnings(as.numeric(data$global_fdr))
  keep <- is.finite(value) & is.finite(fdr)
  if ("evaluable" %in% names(data)) keep <- keep & data$evaluable %in% TRUE
  data <- data[keep, , drop = FALSE]
  value <- value[keep]
  fdr <- fdr[keep]
  if (!nrow(data)) return(NULL)
  row_label <- paste0(data$set_name, " [", data$database, "]")
  column_label <- paste0(data$target, " | n", data$cutoff, " | ", data$method)
  matrix_value <- matrix(NA_real_, length(unique(row_label)), length(unique(column_label)),
                         dimnames = list(unique(row_label), unique(column_label)))
  matrix_fdr <- matrix(Inf, nrow(matrix_value), ncol(matrix_value),
                       dimnames = dimnames(matrix_value))
  for (i in seq_along(value)) {
    if (fdr[i] < matrix_fdr[row_label[i], column_label[i]]) {
      matrix_value[row_label[i], column_label[i]] <- value[i]
      matrix_fdr[row_label[i], column_label[i]] <- fdr[i]
    }
  }
  strength <- apply(abs(matrix_value), 1, function(z) {
    z <- z[is.finite(z)]
    if (length(z)) max(z) else NA_real_
  })
  strength <- strength[is.finite(strength)]
  if (!length(strength)) return(NULL)
  keep_rows <- names(sort(strength, decreasing = TRUE))[
    seq_len(min(maximum_terms, length(strength)))
  ]
  matrix_value[keep_rows, , drop = FALSE]
}

.focus_leading_matrix <- function(scan, leading, maximum_genes) {
  if (!inherits(scan, c("pa_target_scan", "pa_custom_analysis")) ||
      !nrow(leading)) return(NULL)
  required <- c("gene_id", "target", "cutoff")
  if (length(setdiff(required, names(leading)))) return(NULL)
  columns <- unique(paste0(leading$target, " | n", leading$cutoff))
  genes <- unique(as.character(leading$gene_id))
  matrix_value <- matrix(NA_real_, length(genes), length(columns),
                         dimnames = list(genes, columns))
  for (i in seq_len(nrow(leading))) {
    mode <- if ("rank_mode" %in% names(leading)) as.character(leading$rank_mode[i]) else ""
    meta <- if (inherits(scan, "pa_custom_analysis")) {
      scan$gene_results[
        scan$gene_results$gene_id == leading$gene_id[i] &
          scan$gene_results$target == leading$target[i], , drop = FALSE
      ]
    } else {
      scan$meta_analysis[
        scan$meta_analysis$gene_id == leading$gene_id[i] &
          scan$meta_analysis$target == leading$target[i] &
          scan$meta_analysis$cutoff == leading$cutoff[i], , drop = FALSE
      ]
    }
    if (!inherits(scan, "pa_custom_analysis") && !is.na(mode) && nzchar(mode) &&
        "analysis_mode" %in% names(meta)) {
      meta <- meta[meta$analysis_mode == mode, , drop = FALSE]
    }
    statistic <- suppressWarnings(as.numeric(if (inherits(scan, "pa_custom_analysis"))
      meta$statistic else meta$z_statistic))
    statistic <- statistic[is.finite(statistic)]
    if (!length(statistic)) next
    column <- paste0(leading$target[i], " | n", leading$cutoff[i])
    old <- matrix_value[leading$gene_id[i], column]
    candidate <- statistic[which.max(abs(statistic))]
    if (!is.finite(old) || abs(candidate) > abs(old)) {
      matrix_value[leading$gene_id[i], column] <- candidate
    }
  }
  strength <- apply(abs(matrix_value), 1, function(z) {
    z <- z[is.finite(z)]
    if (length(z)) max(z) else NA_real_
  })
  strength <- strength[is.finite(strength)]
  if (!length(strength)) return(NULL)
  keep <- names(sort(strength, decreasing = TRUE))[
    seq_len(min(maximum_genes, length(strength)))
  ]
  matrix_value[keep, , drop = FALSE]
}

.focus_top_terms <- function(data, maximum_terms) {
  if (!nrow(data) || !"global_fdr" %in% names(data)) return(data)
  key <- paste(data$source, .focus_term_key(data), sep = "\r")
  fdr <- suppressWarnings(as.numeric(data$global_fdr))
  best <- tapply(fdr, key, function(z) {
    z <- z[is.finite(z)]
    if (length(z)) min(z) else Inf
  })
  chosen <- names(sort(best))[seq_len(min(maximum_terms, length(best)))]
  data[key %in% chosen, , drop = FALSE]
}

.focus_canvas_dimensions <- function(labels, rows = length(labels)) {
  label_characters <- suppressWarnings(max(nchar(as.character(labels)), na.rm = TRUE))
  if (!is.finite(label_characters)) label_characters <- 0
  # Long ontology names need both a wider device and a larger label margin.
  # The caps keep a pathological label from creating an unusably large file.
  list(
    width = min(40, max(18, 11 + 0.16 * label_characters)),
    height = min(30, max(5, 2.5 + rows * 0.24)),
    left_margin = min(55, max(16, 6 + 0.30 * label_characters))
  )
}

.focus_dotplot <- function(data, effect_column, size_column, base_path,
                           title, x_label, maximum_terms) {
  required <- c("source", .focus_term_columns, "target", "cutoff",
                "global_fdr", effect_column)
  if (!is.data.frame(data) || !nrow(data) || length(setdiff(required, names(data)))) {
    return(character())
  }
  effect <- suppressWarnings(as.numeric(data[[effect_column]]))
  fdr <- suppressWarnings(as.numeric(data$global_fdr))
  keep <- is.finite(effect) & is.finite(fdr)
  if ("evaluable" %in% names(data)) keep <- keep & data$evaluable %in% TRUE
  data <- data[keep, , drop = FALSE]
  if (!nrow(data)) return(character())
  data <- .focus_top_terms(data, maximum_terms)
  effect <- suppressWarnings(as.numeric(data[[effect_column]]))
  fdr <- suppressWarnings(as.numeric(data$global_fdr))
  order_rows <- order(fdr, -abs(effect))
  data <- data[order_rows, , drop = FALSE]
  effect <- effect[order_rows]
  fdr <- fdr[order_rows]
  labels <- paste0(data$set_name, " [", data$database, "] - ", data$target,
                   ", n", data$cutoff,
                   if ("method" %in% names(data)) paste0(", ", data$method) else "")
  significance <- pmin(12, -log10(pmax(fdr, 1e-12)))
  palette <- grDevices::colorRampPalette(c("#DCEAF4", "#EF8A62", "#B2182B"))(101)
  color_index <- 1L + round(100 * significance / max(c(significance, 1), na.rm = TRUE))
  colors <- palette[pmax(1L, pmin(101L, color_index))]
  point_size <- rep(1.25, nrow(data))
  if (!is.null(size_column) && size_column %in% names(data)) {
    size <- suppressWarnings(as.numeric(data[[size_column]]))
    finite <- is.finite(size) & size >= 0
    if (any(finite) && diff(range(size[finite])) > 0) {
      point_size[finite] <- 0.8 + 1.8 *
        (sqrt(size[finite]) - min(sqrt(size[finite]))) /
        diff(range(sqrt(size[finite])))
    }
  }
  x_range <- range(c(0, effect), finite = TRUE)
  padding <- max(diff(x_range) * 0.08, 0.1)
  x_range <- x_range + c(-padding, padding)
  canvas <- .focus_canvas_dimensions(labels, nrow(data))
  render <- function() {
    old <- graphics::par(no.readonly = TRUE)
    on.exit(graphics::par(old), add = TRUE)
    graphics::par(mar = c(5, canvas$left_margin, 4, 2))
    y <- rev(seq_len(nrow(data)))
    graphics::plot(effect, y, xlim = x_range, ylim = c(0.5, nrow(data) + 0.5),
                   pch = 21, bg = colors, col = "#333333", cex = point_size,
                   yaxt = "n", ylab = "", xlab = x_label, main = title)
    graphics::axis(2, at = y, labels = labels, las = 2, cex.axis = 0.7)
    graphics::abline(v = 0, lty = 2, col = "#777777")
    graphics::grid(nx = NA, ny = NULL, col = "#EEEEEE")
    graphics::box()
    graphics::mtext("Darker red = smaller original global FDR", side = 1,
                    line = 3.2, cex = 0.75)
  }
  files <- paste0(base_path, c(".png", ".pdf"))
  for (file in files) {
    if (grepl("\\.png$", file)) {
      grDevices::png(file, width = canvas$width, height = canvas$height,
                     units = "in", res = 180)
    } else {
      grDevices::pdf(file, width = canvas$width, height = canvas$height,
                     onefile = FALSE)
    }
    tryCatch(render(), finally = grDevices::dev.off())
  }
  files[file.exists(files)]
}

.focus_readme <- function(group, analysis = NULL) {
  c(
    paste0("Focused pathway report: ", group),
    "",
    "This folder is a filtered view of a completed paannotate enrichment analysis.",
    "No P-values or FDR values were recalculated after choosing these pathways.",
    "That matters because filtering first and correcting afterward would make selected results look artificially stronger.",
    "",
    "match_audit.csv shows exactly which search words or IDs matched which terms.",
    "matched_terms.csv is the unique set of terms included in this folder.",
    "exact_* files retain original GO, KEGG, and other database terms.",
    "theme_* files contain paannotate's retested curated umbrella themes.",
    "pathway_statistics.csv combines the filtered ORA and ranked audit rows.",
    "pathway_membership.csv lists genes belonging to the matched pathways when membership was saved.",
    "leading_edge_genes.csv lists genes driving ranked enrichment results.",
    "",
    "Ranked enrichment uses all tested genes. Positive scores track positively with the target; negative scores track negatively.",
    "ORA asks whether individually selected genes occur in a pathway more often than expected.",
    "The heatmap of pathway significance uses signed -log10(original FDR); it does not perform a new statistical test.",
    if (inherits(analysis, "pa_target_scan")) {
      "The leading-edge heatmap uses the original gene-level meta-analysis z statistics."
    } else if (inherits(analysis, "pa_custom_analysis")) {
      "The leading-edge heatmap uses the original single-dataset gene-level test statistics."
    } else {
      "A leading-edge gene heatmap was not possible because this input did not include the original scan checkpoint."
    },
    "",
    "plot_status.csv records whether each requested figure was created, empty, skipped, or failed."
  )
}

#' Make focused pathway figures from completed scan enrichment
#'
#' Selects pathways of interest from an existing paannotate scan and creates a
#' compact, auditable report without rerunning correlations or enrichment. The
#' original term-level and global FDR values are preserved exactly; they are
#' never recalculated after pathway selection.
#'
#' @param x A `pa_scan_pipeline`, `pa_custom_pipeline`, `pa_scan_enrichment`,
#'   completed report folder, or saved enrichment checkpoint.
#' @param focus A pathway ID/name/keyword, a built-in preset such as `"iron"`,
#'   or a named list such as `list(Secretion = c("type III secretion",
#'   "type VI secretion"), Biofilm = c("biofilm", "alginate"))`.
#'   Inside a named list, use `"preset:iron"` to request a built-in preset.
#' @param output_dir Destination. By default, completed report inputs use
#'   `07_focused_pathways`; other objects use `paannotate_focused_pathways` in
#'   the current working directory.
#' @param match How custom queries match: `"auto"` prefers an exact term ID or
#'   name and otherwise uses a literal keyword; `"exact"`, `"contains"`, and
#'   `"regex"` are also available.
#' @param sources Search exact database terms, curated themes, or both.
#' @param targets,cutoffs,directions,methods Optional result filters. `NULL`
#'   retains every available value.
#' @param databases,ontologies Optional exact, case-insensitive term filters.
#' @param evidence `"all"` retains exploratory and supported results;
#'   `"supported"` retains only results passing the original enrichment rules.
#' @param preview Return and print the complete match audit without writing a
#'   report or figures.
#' @param heatmaps,dotplots Write heatmaps and base-R dot plots.
#' @param maximum_terms,maximum_genes Display caps; complete CSV tables are
#'   never truncated.
#' @return A `pa_pathway_focus` object containing matches, filtered tables,
#'   plot status, and output paths.
#' @export
pa_focus_pathways <- function(
    x, focus, output_dir = NULL,
    match = c("auto", "exact", "contains", "regex"),
    sources = c("exact", "themes"), targets = NULL, cutoffs = NULL,
    directions = NULL, methods = NULL, databases = NULL, ontologies = NULL,
    evidence = c("all", "supported"), preview = FALSE,
    heatmaps = TRUE, dotplots = TRUE, maximum_terms = 40,
    maximum_genes = 60) {
  match <- match.arg(match)
  evidence <- match.arg(evidence)
  sources <- unique(match.arg(sources, c("exact", "themes"), several.ok = TRUE))
  if (!is.numeric(maximum_terms) || length(maximum_terms) != 1L ||
      !is.finite(maximum_terms) || maximum_terms < 1) {
    stop("maximum_terms must be one positive number.", call. = FALSE)
  }
  if (!is.numeric(maximum_genes) || length(maximum_genes) != 1L ||
      !is.finite(maximum_genes) || maximum_genes < 1) {
    stop("maximum_genes must be one positive number.", call. = FALSE)
  }
  maximum_terms <- as.integer(maximum_terms)
  maximum_genes <- as.integer(maximum_genes)
  resolved <- .focus_resolve_input(x)
  enrichment <- resolved$enrichment
  groups <- .focus_normalize(focus, match)
  terms <- .focus_available_terms(enrichment, sources)
  terms <- .focus_keep_values(terms, "database", databases)
  terms <- .focus_keep_values(terms, "ontology", ontologies)
  if (!nrow(terms)) {
    stop("No enriched terms remain after the requested source/database/ontology filters.",
         call. = FALSE)
  }
  match_audit <- .focus_match_terms(terms, groups)
  if (isTRUE(preview)) {
    result <- structure(list(
      preview = TRUE, matches = match_audit,
      matched_terms = unique(match_audit[match_audit$matched %in% TRUE,
                                         c("focus_group", "source", .focus_term_columns),
                                         drop = FALSE]),
      config = list(match = match, sources = sources, databases = databases,
                    ontologies = ontologies)
    ), class = "pa_pathway_focus")
    print(result)
    return(invisible(result))
  }
  if (is.null(output_dir)) {
    output_dir <- if (!is.null(resolved$report_directory)) {
      file.path(resolved$report_directory, "07_focused_pathways")
    } else file.path(getwd(), "paannotate_focused_pathways")
  }
  output_dir <- path.expand(output_dir)
  dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
  config <- list(
    focus = focus, match = match, sources = sources, targets = targets,
    cutoffs = cutoffs, directions = directions, methods = methods,
    databases = databases, ontologies = ontologies, evidence = evidence,
    heatmaps = heatmaps, dotplots = dotplots, maximum_terms = maximum_terms,
    maximum_genes = maximum_genes,
    original_enrichment_fdr = enrichment$config[c("term_fdr", "global_fdr")],
    fdr_recalculated_after_focus = FALSE
  )
  .scan_write_csv(match_audit, file.path(output_dir, "focus_match_audit.csv"))
  .scan_write_lines(utils::capture.output(dput(config)),
                    file.path(output_dir, "focus_config.R"))
  group_results <- list()
  all_status <- list()
  status_counter <- 0L
  used_slugs <- character()
  for (group in groups) {
    group_matches <- match_audit[match_audit$focus_group == group$name, , drop = FALSE]
    selected <- unique(group_matches[group_matches$matched %in% TRUE,
                                     c("source", .focus_term_columns), drop = FALSE])
    slug <- .scan_slug(group$name)
    if (!nzchar(slug)) slug <- "focused_pathways"
    base_slug <- slug
    suffix <- 1L
    while (slug %in% used_slugs) {
      suffix <- suffix + 1L
      slug <- paste0(base_slug, "_", suffix)
    }
    used_slugs <- c(used_slugs, slug)
    directory <- file.path(output_dir, slug)
    dir.create(directory, recursive = TRUE, showWarnings = FALSE)
    exact_terms <- selected[selected$source == "exact", , drop = FALSE]
    theme_terms <- selected[selected$source == "themes", , drop = FALSE]
    raw <- list(
      exact_summary = .focus_filter_table(
        enrichment$exact$summary, exact_terms, targets, cutoffs, directions,
        methods, evidence, summary = TRUE
      ),
      exact_ora = .focus_filter_table(
        enrichment$exact$ora, exact_terms, targets, cutoffs, directions,
        methods, evidence
      ),
      exact_ranked = .focus_filter_table(
        enrichment$exact$ranked, exact_terms, targets, cutoffs, directions,
        methods, evidence
      ),
      theme_summary = .focus_filter_table(
        enrichment$themes$summary, theme_terms, targets, cutoffs, directions,
        methods, evidence, summary = TRUE
      ),
      theme_ora = .focus_filter_table(
        enrichment$themes$ora, theme_terms, targets, cutoffs, directions,
        methods, evidence
      ),
      theme_ranked = .focus_filter_table(
        enrichment$themes$ranked, theme_terms, targets, cutoffs, directions,
        methods, evidence
      )
    )
    summary_table <- .focus_rbind(list(
      .focus_add_source(raw$exact_summary, "exact"),
      .focus_add_source(raw$theme_summary, "themes")
    ))
    ora_table <- .focus_rbind(list(
      .focus_add_source(raw$exact_ora, "exact"),
      .focus_add_source(raw$theme_ora, "themes")
    ))
    ranked_table <- .focus_rbind(list(
      .focus_add_source(raw$exact_ranked, "exact"),
      .focus_add_source(raw$theme_ranked, "themes")
    ))
    statistics <- .focus_rbind(list(ora_table, ranked_table))
    membership <- .focus_membership(enrichment, selected, raw)
    leading <- .focus_rbind(list(
      .focus_split_genes(.focus_add_source(raw$exact_ranked, "exact"),
                         "leading_edge_genes", "ranked leading edge"),
      .focus_split_genes(.focus_add_source(raw$theme_ranked, "themes"),
                         "leading_edge_genes", "ranked leading edge")
    ))
    if (nrow(leading) && is.data.frame(enrichment$gene_annotations) &&
        nrow(enrichment$gene_annotations)) {
      leading <- merge(leading, enrichment$gene_annotations, by = "gene_id",
                       all.x = TRUE, sort = FALSE)
      leading <- leading[c("gene_id", setdiff(names(leading), "gene_id"))]
    }
    tables <- c(raw, list(
      matched_terms = selected, pathway_summary = summary_table,
      pathway_statistics = statistics, pathway_membership = membership,
      leading_edge_genes = leading
    ))
    .scan_write_csv(group_matches, file.path(directory, "match_audit.csv"))
    for (table_name in names(tables)) {
      .scan_write_csv(tables[[table_name]],
                      file.path(directory, paste0(table_name, ".csv")))
    }
    .scan_write_lines(.focus_readme(group$name, resolved$scan),
                      file.path(directory, "README.txt"))
    plot_status <- list()
    plot_counter <- 0L
    record <- function(artifact, status, reason = "", files = character()) {
      plot_counter <<- plot_counter + 1L
      plot_status[[plot_counter]] <<- data.frame(
        focus_group = group$name, artifact = artifact, status = status,
        reason = reason, files = paste(basename(files), collapse = "; "),
        stringsAsFactors = FALSE
      )
    }
    render_heatmap <- function(name, matrix_value, title) {
      if (!isTRUE(heatmaps)) return(record(name, "skipped", "heatmaps=FALSE"))
      if (is.null(matrix_value) || !length(matrix_value) ||
          !nrow(matrix_value) || !ncol(matrix_value)) {
        return(record(name, "no_results", "No finite values were available"))
      }
      if (!requireNamespace("pheatmap", quietly = TRUE)) {
        return(record(name, "skipped", "Optional package 'pheatmap' is unavailable"))
      }
      tryCatch({
        made <- .scan_render_heatmap(matrix_value, file.path(directory, name), title)
        made <- made[file.exists(made)]
        if (length(made)) record(name, "created", files = made) else
          record(name, "failed", "The plotting engine did not create a file")
      }, error = function(e) record(name, "failed", conditionMessage(e)))
    }
    render_dotplot <- function(name, data, effect, size, title, x_label) {
      if (!isTRUE(dotplots)) return(record(name, "skipped", "dotplots=FALSE"))
      tryCatch({
        made <- .focus_dotplot(data, effect, size, file.path(directory, name),
                               title, x_label, maximum_terms)
        if (length(made)) record(name, "created", files = made) else
          record(name, "no_results", "No finite evaluable values were available")
      }, error = function(e) record(name, "failed", conditionMessage(e)))
    }
    render_heatmap(
      "pathway_significance_heatmap",
      .scan_summary_matrix(summary_table, maximum_terms),
      paste0(group$name, ": original pathway FDR")
    )
    render_heatmap(
      "ranked_enrichment_heatmap",
      .focus_ranked_matrix(ranked_table, maximum_terms),
      paste0(group$name, ": ranked enrichment score")
    )
    render_heatmap(
      "leading_edge_gene_heatmap",
      .focus_leading_matrix(resolved$scan, leading, maximum_genes),
      paste0(group$name, ": leading-edge gene statistics")
    )
    render_dotplot(
      "ranked_enrichment_dotplot", ranked_table, "enrichment_score",
      "overlap_count", paste0(group$name, ": ranked enrichment"),
      "Enrichment score (negative = inverse; positive = direct)"
    )
    render_dotplot(
      "ora_dotplot", ora_table, "fold_enrichment", "overlap_count",
      paste0(group$name, ": selected-gene over-representation"),
      "Fold enrichment"
    )
    status <- if (length(plot_status)) .focus_rbind(plot_status) else data.frame()
    .scan_write_csv(status, file.path(directory, "plot_status.csv"))
    status_counter <- status_counter + 1L
    all_status[[status_counter]] <- status
    group_results[[group$name]] <- list(
      directory = directory, matches = group_matches, matched_terms = selected,
      tables = tables, plot_status = status
    )
  }
  combined_status <- .focus_rbind(all_status)
  .scan_write_csv(combined_status, file.path(output_dir, "focus_status.csv"))
  result <- structure(list(
    preview = FALSE, matches = match_audit,
    matched_terms = unique(match_audit[match_audit$matched %in% TRUE,
                                       c("focus_group", "source", .focus_term_columns),
                                       drop = FALSE]),
    groups = group_results, status = combined_status, config = config,
    output_dir = normalizePath(output_dir, winslash = "/", mustWork = TRUE)
  ), class = "pa_pathway_focus")
  saveRDS(result, file.path(output_dir, "pa_pathway_focus.rds"), compress = "xz")
  if (!any(match_audit$matched %in% TRUE)) {
    warning("No enriched terms matched the requested focus. See focus_match_audit.csv for the exact search audit.",
            call. = FALSE)
  }
  result
}

#' @export
print.pa_pathway_focus <- function(x, ...) {
  cat("paannotate focused pathways\n")
  groups <- unique(as.character(x$matches$focus_group))
  cat("  focus groups:", length(groups), "\n")
  cat("  matched terms:", nrow(x$matched_terms), "\n")
  if (isTRUE(x$preview)) {
    counts <- stats::aggregate(
      matched ~ focus_group + query, x$matches,
      function(value) sum(value %in% TRUE)
    )
    if (nrow(counts)) print(counts, row.names = FALSE)
    cat("  preview only: no files written\n")
  } else {
    created <- if (is.data.frame(x$status) && nrow(x$status)) {
      sum(x$status$status == "created")
    } else 0L
    cat("  figures created:", created, "\n")
    cat("  report:", x$output_dir, "\n")
  }
  invisible(x)
}
