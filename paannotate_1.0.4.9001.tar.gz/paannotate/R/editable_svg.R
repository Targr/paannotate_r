.p2c_xml <- function(x){x<-gsub('&','&amp;',as.character(x),fixed=TRUE);x<-gsub('<','&lt;',x,fixed=TRUE);x<-gsub('>','&gt;',x,fixed=TRUE);x<-gsub('"','&quot;',x,fixed=TRUE);gsub('\n','&#10;',x,fixed=TRUE)}
.p2c_svg_text <- function(text,x,y,just='centre',rot=0,gp=grid::gpar(),edit=NULL,height){
  if(!inherits(x,'unit'))x<-grid::unit(x,'npc');if(!inherits(y,'unit'))y<-grid::unit(y,'npc')
  position<-grid::deviceLoc(x,y,valueOnly=TRUE);px<-position$x*72;py<-(height-position$y)*72
  size<-if(is.null(gp$fontsize))10 else as.numeric(gp$fontsize)
  just<-as.character(just);horizontal<-if(just[1]%in%c('left','right'))just[1] else 'center'
  vertical<-if(length(just)>1)just[2] else if(just[1]%in%c('top','bottom'))just[1] else 'center'
  lines<-strsplit(as.character(text),'\n',fixed=TRUE)[[1]];if(!length(lines))lines<-''
  offset<-if(vertical=='top')size*.85 else if(vertical=='bottom')-(length(lines)-1)*size*1.2 else -(length(lines)-1)*size*.6+size*.35
  attributes<-if(is.null(edit))'' else paste0(' data-edit-field="',.p2c_xml(edit$key),'" data-edit-id="',.p2c_xml(if(is.null(edit$id))'' else edit$id),'" data-edit-value="',.p2c_xml(if(is.null(edit$value))text else edit$value),'" tabindex="0" role="button" aria-label="Edit ',.p2c_xml(switch(edit$key,title='figure title',subtitle='subtitle',row_labels='row label',column_labels='column label',legend_title='legend title',dot_label='significance legend',missing_label='missing-value label',highlight_label='highlight legend',support_label='support heading',`_range`='color scale',edit$key)),'"')
  paste0('<text x="',px,'" y="',py+offset,'" font-family="Helvetica,Arial,sans-serif" font-size="',size,'" fill="',if(is.null(gp$col))'#000000' else .p2c_xml(gp$col),'" font-weight="',if(!is.null(gp$font)&&as.integer(gp$font)[1]%in%c(2,4))'bold' else 'normal','" text-anchor="',c(left='start',right='end',center='middle')[[horizontal]],'" transform="rotate(',-rot,' ',px,' ',py,')"',attributes,'>',paste0(vapply(seq_along(lines),function(i)paste0('<tspan x="',px,'" dy="',if(i==1)0 else size*1.2,'">',.p2c_xml(lines[i]),'</tspan>'),character(1)),collapse=''),'</text>')
}
