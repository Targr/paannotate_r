.organism_normalize <- function(x) {
  gsub("[^a-z0-9]+", "", tolower(trimws(as.character(x))))
}

.organism_read_csv <- function(x, label) {
  if (is.data.frame(x)) return(x)
  if (is.null(x) || length(x) != 1L || !file.exists(path.expand(x))) {
    stop(label, " is required and must be a readable CSV file.", call. = FALSE)
  }
  utils::read.csv(path.expand(x), check.names = FALSE, stringsAsFactors = FALSE)
}

.organism_context_check <- function(context) {
  if (!is.list(context)) {
    stop("organism_context must be a named list from an assembly-validated reference.",
         call. = FALSE)
  }
  required <- c("assembly_accession", "tax_id", "organism_name")
  missing <- required[!vapply(required, function(x) {
    !is.null(context[[x]]) && nzchar(trimws(as.character(context[[x]])))
  }, logical(1))]
  if (length(missing)) stop(
    "organism_context is missing: ", paste(missing, collapse = ", "), call. = FALSE
  )
  validation <- as.character(context$validation %||% "")
  allowed <- c(
    "exact_taxon", "species_compatible", "species_compatible_strain_difference",
    "assembly_only"
  )
  manual_override <- identical(validation, "manual_override") &&
    nzchar(trimws(as.character(context$override_reason %||% "")))
  if (!validation %in% allowed && !manual_override) {
    stop("organism_context has not passed assembly validation.", call. = FALSE)
  }
  context
}

`%||%` <- function(x, y) if (is.null(x) || !length(x)) y else x

.organism_alias_index <- function(crosswalk) {
  required <- c("gene_id", "alias", "alias_type", "evidence_type")
  missing <- setdiff(required, names(crosswalk))
  if (length(missing)) stop(
    "identifier_crosswalk is missing: ", paste(missing, collapse = ", "), call. = FALSE
  )
  crosswalk$gene_id <- toupper(trimws(as.character(crosswalk$gene_id)))
  crosswalk$alias <- toupper(trimws(as.character(crosswalk$alias)))
  crosswalk <- crosswalk[nzchar(crosswalk$gene_id) & nzchar(crosswalk$alias), , drop = FALSE]
  groups <- split(crosswalk$gene_id, crosswalk$alias)
  ambiguous <- names(groups)[vapply(groups, function(x) length(unique(x)) != 1L, logical(1))]
  direct <- vapply(groups[setdiff(names(groups), ambiguous)], function(x) unique(x)[1], character(1))
  evidence <- stats::setNames(rep("direct_identifier_crosswalk", length(direct)), names(direct))
  list(direct = direct, evidence = evidence, ambiguous = ambiguous, rows = crosswalk)
}

.organism_download <- function(url, destination, label, refresh = FALSE) {
  if (!refresh && file.exists(destination) && file.info(destination)$size > 0) return(TRUE)
  temporary <- tempfile(pattern = paste0(basename(destination), "."), tmpdir = dirname(destination))
  on.exit(unlink(temporary), add = TRUE)
  message("Downloading ", label, "...")
  worked <- tryCatch({
    old_timeout <- getOption("timeout")
    options(timeout = max(300, old_timeout))
    on.exit(options(timeout = old_timeout), add = TRUE)
    status <- suppressWarnings(utils::download.file(url, temporary, mode = "wb", quiet = TRUE))
    identical(status, 0L) && file.exists(temporary) && file.info(temporary)$size > 0
  }, error = function(e) FALSE)
  if (worked) file.copy(temporary, destination, overwrite = TRUE) else FALSE
}

.organism_resolve_kegg <- function(context, cache_dir, refresh = FALSE) {
  if (!is.null(context$kegg_code) && nzchar(context$kegg_code)) {
    return(tolower(trimws(as.character(context$kegg_code))))
  }
  known_taxa <- c(`208964` = "pae", `652611` = "pau")
  tax_id <- as.character(context$tax_id)
  if (tax_id %in% names(known_taxa)) return(unname(known_taxa[[tax_id]]))
  path <- file.path(cache_dir, "kegg_organisms.tsv")
  if (!.organism_download("https://rest.kegg.jp/list/organism", path,
                          "KEGG organism catalog", refresh)) {
    stop("KEGG organism catalog is unavailable.", call. = FALSE)
  }
  table <- utils::read.delim(path, header = FALSE, sep = "\t", quote = "",
                             comment.char = "", stringsAsFactors = FALSE)
  if (ncol(table) < 3L) stop("Invalid KEGG organism catalog.", call. = FALSE)
  names(table)[1:3] <- c("entry", "code", "name")
  organism_words <- strsplit(tolower(as.character(context$organism_name)), "[^a-z0-9]+")[[1]]
  organism_words <- organism_words[nzchar(organism_words)]
  if (length(organism_words) < 2L) stop("Cannot resolve KEGG organism from organism_name.", call. = FALSE)
  species <- paste(organism_words[1:2], collapse = " ")
  candidates <- table[grepl(species, tolower(table$name), fixed = TRUE), , drop = FALSE]
  if (!nrow(candidates)) stop(
    "No KEGG organism matches ", context$organism_name, ".", call. = FALSE
  )
  strain <- .organism_normalize(context$strain %||% paste(organism_words[-(1:2)], collapse = ""))
  if (nzchar(strain)) {
    matched <- grepl(strain, .organism_normalize(candidates$name), fixed = TRUE)
    candidates <- candidates[matched, , drop = FALSE]
  }
  if (nrow(candidates) != 1L) stop(
    "KEGG organism resolution is ambiguous for ", context$organism_name,
    if (nzchar(strain)) paste0(" (strain ", context$strain, ")") else "",
    "; set organism_context$kegg_code explicitly after review.", call. = FALSE
  )
  tolower(candidates$code[1])
}

.organism_map_alias <- function(values, index) {
  aliases <- toupper(trimws(as.character(values)))
  gene_id <- unname(index$direct[aliases])
  data.frame(
    source_identifier = aliases,
    gene_id = gene_id,
    mapping_evidence = unname(index$evidence[aliases]),
    mapping_status = ifelse(aliases %in% index$ambiguous, "ambiguous",
                            ifelse(is.na(gene_id), "unmapped", "direct")),
    stringsAsFactors = FALSE
  )
}

.organism_uniprot <- function(context, cache_dir, refresh) {
  tax_id <- as.character(context$uniprot_tax_id %||% context$tax_id)
  fields <- paste(c("accession", "organism_id", "organism_name", "xref_proteomes", "gene_names",
                    "gene_oln", "xref_refseq", "go_id", "go_p", "go_f", "go_c",
                    "protein_name"), collapse = ",")
  fetch <- function(query, destination, label) {
    url <- paste0("https://rest.uniprot.org/uniprotkb/stream?compressed=false&format=tsv&query=",
                  utils::URLencode(query, reserved = TRUE), "&fields=", fields)
    if (!.organism_download(url, destination, label, refresh)) return(NULL)
    utils::read.delim(destination, header = TRUE, sep = "\t", quote = "",
                      comment.char = "", check.names = FALSE, stringsAsFactors = FALSE)
  }
  destination <- file.path(cache_dir, paste0("uniprot_taxon_", tax_id, "_go.tsv"))
  raw <- fetch(paste0("(taxonomy_id:", tax_id, ")"), destination,
               paste0("UniProt-GOA taxon ", tax_id))
  strain <- trimws(as.character(context$strain %||% ""))
  if ((is.null(raw) || nrow(raw) < 10L) && nzchar(strain) && is.null(context$uniprot_tax_id)) {
    strain_file <- file.path(cache_dir, paste0("uniprot_strain_", .organism_normalize(strain), "_go.tsv"))
    candidate <- fetch(paste0("organism_name:\"", strain, "\""), strain_file,
                       paste0("UniProt-GOA strain ", strain))
    organism_column <- if (is.null(candidate)) NA_character_ else
      .organism_column(candidate, "^Organism$")
    id_column <- if (is.null(candidate)) NA_character_ else
      .organism_column(candidate, "Organism.*ID")
    species <- paste(strsplit(as.character(context$organism_name), "\\s+")[[1]][1:2],
                     collapse = " ")
    if (!is.null(candidate) && !is.na(organism_column)) {
      keep <- grepl(tolower(species), tolower(candidate[[organism_column]]), fixed = TRUE) &
        grepl(tolower(strain), tolower(candidate[[organism_column]]), fixed = TRUE)
      candidate <- candidate[keep, , drop = FALSE]
    }
    if (!is.null(candidate) && nrow(candidate) >= 10L && !is.na(id_column)) {
      taxon_counts <- sort(table(candidate[[id_column]]), decreasing = TRUE)
      if (length(taxon_counts) && unname(taxon_counts[1]) / nrow(candidate) >= 0.90) {
        candidate <- candidate[candidate[[id_column]] == names(taxon_counts)[1], , drop = FALSE]
      }
    }
    valid <- !is.null(candidate) && nrow(candidate) >= 10L && !is.na(organism_column) &&
      !is.na(id_column) && length(unique(candidate[[id_column]])) == 1L
    if (valid) {
      proteome_column <- .organism_column(candidate, "^Proteomes$")
      proteomes <- if (is.na(proteome_column)) character() else unique(unlist(
        regmatches(candidate[[proteome_column]], gregexpr("UP[0-9]{9}", candidate[[proteome_column]]))
      ))
      proteomes <- proteomes[nzchar(proteomes)]
      if (!length(proteomes)) {
        cached_proteomes <- list.files(
          cache_dir, pattern = "^uniprot_proteome_UP[0-9]{9}_go[.]tsv$", full.names = TRUE
        )
        if (length(cached_proteomes) == 1L) {
          cached <- utils::read.delim(
            cached_proteomes, header = TRUE, sep = "\t", quote = "", comment.char = "",
            check.names = FALSE, stringsAsFactors = FALSE
          )
          cached_organism <- .organism_column(cached, "^Organism$")
          if (!is.na(cached_organism) && nrow(cached) >= nrow(candidate) &&
              all(grepl(tolower(species), tolower(cached[[cached_organism]]), fixed = TRUE)) &&
              all(grepl(tolower(strain), tolower(cached[[cached_organism]]), fixed = TRUE))) {
            candidate <- cached
          }
        }
      }
      if (length(proteomes) == 1L) {
        proteome_file <- file.path(cache_dir, paste0("uniprot_proteome_", proteomes, "_go.tsv"))
        proteome_raw <- fetch(paste0("proteome:", proteomes), proteome_file,
                              paste0("UniProt-GOA proteome ", proteomes))
        if (!is.null(proteome_raw) && nrow(proteome_raw) >= nrow(candidate)) candidate <- proteome_raw
      }
      raw <- candidate
      tax_id <- as.character(unique(candidate[[id_column]])[1])
    }
  }
  if (is.null(raw) || nrow(raw) == 0L) {
    stop("UniProt-GOA annotations are unavailable for ", context$organism_name, ".",
         call. = FALSE)
  }
  attr(raw, "provider_tax_id") <- tax_id
  raw
}

.organism_column <- function(data, pattern) {
  hit <- grep(pattern, names(data), ignore.case = TRUE, value = TRUE)
  if (length(hit)) hit[1] else NA_character_
}

.organism_uniprot_candidates <- function(raw, i) {
  columns <- c(.organism_column(raw, "^Entry$"),
               .organism_column(raw, "ordered locus"),
               .organism_column(raw, "RefSeq"),
               .organism_column(raw, "^Gene Names$"))
  values <- character()
  for (name in columns[!is.na(columns)]) {
    values <- c(values, unlist(strsplit(as.character(raw[[name]][i]), "[ ;,]+")))
  }
  unique(toupper(values[nzchar(values)]))
}

.organism_extend_index <- function(index, raw) {
  additions <- list()
  ambiguous_bridge <- character()
  for (i in seq_len(nrow(raw))) {
    aliases <- .organism_uniprot_candidates(raw, i)
    genes <- unique(unname(index$direct[intersect(aliases, names(index$direct))]))
    genes <- genes[!is.na(genes)]
    if (length(genes) != 1L) {
      if (length(genes) > 1L) ambiguous_bridge <- c(ambiguous_bridge, aliases)
      next
    }
    additions[[length(additions) + 1L]] <- data.frame(
      alias = aliases, gene_id = genes[1], stringsAsFactors = FALSE
    )
  }
  if (length(additions)) {
    bridge <- unique(do.call(rbind, additions))
    groups <- split(bridge$gene_id, bridge$alias)
    bridge_ambiguous <- names(groups)[vapply(groups, function(x) length(unique(x)) != 1L,
                                             logical(1))]
    safe <- setdiff(names(groups), c(bridge_ambiguous, index$ambiguous, ambiguous_bridge))
    for (alias in safe) {
      gene <- unique(groups[[alias]])[1]
      existing <- unname(index$direct[alias])
      if (length(existing) && !is.na(existing) && !identical(existing, gene)) {
        index$ambiguous <- unique(c(index$ambiguous, alias))
        index$direct <- index$direct[names(index$direct) != alias]
        index$evidence <- index$evidence[names(index$evidence) != alias]
      } else if (!length(existing) || is.na(existing)) {
        index$direct[alias] <- gene
        index$evidence[alias] <- "direct_uniprot_accession_bridge"
      }
    }
  }
  index$ambiguous <- unique(c(index$ambiguous, ambiguous_bridge))
  index
}

.organism_kegg <- function(context, index, cache_dir, refresh) {
  code <- .organism_resolve_kegg(context, cache_dir, refresh)
  links_file <- file.path(cache_dir, paste0("kegg_", code, "_gene_pathway.tsv"))
  names_file <- file.path(cache_dir, paste0("kegg_", code, "_pathway_names.tsv"))
  ok <- .organism_download(paste0("https://rest.kegg.jp/link/pathway/", code),
                           links_file, paste(code, "KEGG gene-pathway annotations"), refresh) &&
    .organism_download(paste0("https://rest.kegg.jp/list/pathway/", code),
                       names_file, paste(code, "KEGG pathway names"), refresh)
  if (!ok) stop("KEGG annotations are unavailable for organism code ", code, ".",
                call. = FALSE)
  links <- utils::read.delim(links_file, header = FALSE, sep = "\t", quote = "",
                             comment.char = "", stringsAsFactors = FALSE)
  pathways <- utils::read.delim(names_file, header = FALSE, sep = "\t", quote = "",
                                comment.char = "", stringsAsFactors = FALSE)
  if (ncol(links) != 2L || ncol(pathways) != 2L) stop("Invalid KEGG response.", call. = FALSE)
  names(links) <- c("source", "pathway")
  names(pathways) <- c("pathway", "set_name")
  source_id <- sub(paste0("^", code, ":"), "", links$source, ignore.case = TRUE)
  mapped <- .organism_map_alias(source_id, index)
  links$gene_id <- mapped$gene_id
  links$mapping_status <- mapped$mapping_status
  links$source_identifier <- mapped$source_identifier
  links$set_id <- sub("^path:", "", links$pathway)
  pathways$set_id <- sub("^path:", "", pathways$pathway)
  links$set_name <- pathways$set_name[match(links$set_id, pathways$set_id)]
  links$set_name[is.na(links$set_name)] <- links$set_id[is.na(links$set_name)]
  membership <- data.frame(
    gene_id = links$gene_id, database = "KEGG", ontology = "KEGG pathway",
    set_id = links$set_id, set_name = links$set_name,
    evidence_type = mapped$mapping_evidence,
    source_identifier = links$source_identifier, provider = "KEGG",
    organism_code = code, stringsAsFactors = FALSE
  )
  membership <- unique(membership[links$mapping_status == "direct" &
                                    !is.na(membership$gene_id), , drop = FALSE])
  audit <- data.frame(
    provider = "KEGG", organism_code = code, source_rows = nrow(links),
    mapped_rows = sum(links$mapping_status == "direct"),
    unmapped_rows = sum(links$mapping_status == "unmapped"),
    ambiguous_rows = sum(links$mapping_status == "ambiguous"),
    stringsAsFactors = FALSE
  )
  list(membership = membership, audit = audit, code = code)
}

.organism_go_terms <- function(values, gene_ids, source_ids, mapping_evidence, ontology) {
  rows <- lapply(seq_along(values), function(i) {
    if (is.na(gene_ids[i]) || is.na(values[i]) || !nzchar(trimws(values[i]))) return(NULL)
    terms <- trimws(unlist(strsplit(values[i], ";", fixed = TRUE)))
    terms <- terms[grepl("\\[GO:[0-9]+\\]", terms)]
    if (!length(terms)) return(NULL)
    data.frame(
      gene_id = gene_ids[i], database = "UniProt-GOA", ontology = ontology,
      set_id = sub(".*\\[(GO:[0-9]+)\\].*", "\\1", terms),
      set_name = trimws(sub("\\s*\\[GO:[0-9]+\\].*$", "", terms)),
      evidence_type = mapping_evidence[i],
      source_identifier = source_ids[i], provider = "UniProt-GOA",
      organism_code = "", stringsAsFactors = FALSE
    )
  })
  rows <- Filter(Negate(is.null), rows)
  if (!length(rows)) return(data.frame())
  unique(do.call(rbind, rows))
}

.organism_go <- function(context, index, raw) {
  tax_id <- as.character(attr(raw, "provider_tax_id") %||% context$tax_id)
  candidates <- lapply(seq_len(nrow(raw)), function(i) {
    .organism_uniprot_candidates(raw, i)
  })
  source_ids <- vapply(candidates, function(values) {
    hit <- values[toupper(values) %in% names(index$direct)]
    if (length(hit)) hit[1] else if (length(values)) values[1] else ""
  }, character(1))
  mapped <- .organism_map_alias(source_ids, index)
  getter <- function(pattern) {
    name <- .organism_column(raw, pattern)
    if (is.na(name)) rep("", nrow(raw)) else as.character(raw[[name]])
  }
  membership_rows <- Filter(function(x) nrow(x), list(
    .organism_go_terms(getter("biological process"), mapped$gene_id,
                       mapped$source_identifier, mapped$mapping_evidence,
                       "GO biological process"),
    .organism_go_terms(getter("molecular function"), mapped$gene_id,
                       mapped$source_identifier, mapped$mapping_evidence,
                       "GO molecular function"),
    .organism_go_terms(getter("cellular component"), mapped$gene_id,
                       mapped$source_identifier, mapped$mapping_evidence,
                       "GO cellular component")
  ))
  membership <- if (length(membership_rows)) unique(do.call(rbind, membership_rows)) else data.frame()
  audit <- data.frame(
    provider = "UniProt-GOA", organism_code = tax_id, source_rows = nrow(raw),
    mapped_rows = sum(mapped$mapping_status == "direct"),
    unmapped_rows = sum(mapped$mapping_status == "unmapped"),
    ambiguous_rows = sum(mapped$mapping_status == "ambiguous"),
    stringsAsFactors = FALSE
  )
  list(membership = membership, audit = audit)
}

#' Fetch assembly-matched KEGG and GO annotations
#'
#' Resolves provider identifiers through an explicit GFF-derived crosswalk while
#' preserving the assembly's native locus tags as primary gene identifiers.
#'
#' @param organism_context Named assembly/taxon/strain context created by the
#'   reference workflow.
#' @param gene_catalog CSV path or data frame containing assembly-native genes.
#' @param identifier_crosswalk Long-form CSV path or data frame of direct aliases.
#' @param cache_dir Writable per-organism cache directory.
#' @param refresh Force fresh provider downloads.
#' @param providers Any of `"KEGG"` and `"GO"`.
#' @param evidence `"direct"` (default) rejects inferred orthology mappings.
#' @return A `pa_annotations_v4` object with membership, annotations, and audit.
#' @export
fetch_organism_annotations <- function(
    organism_context, gene_catalog, identifier_crosswalk,
    cache_dir = file.path(tools::R_user_dir("paannotate", "cache"), "organisms"),
    refresh = FALSE, providers = c("KEGG", "GO"), evidence = "direct") {
  context <- .organism_context_check(organism_context)
  if (!identical(evidence, "direct")) stop(
    "Only direct annotation/crosswalk evidence is enabled; inferred orthology requires explicit opt-in support.",
    call. = FALSE
  )
  catalog <- .organism_read_csv(gene_catalog, "gene_catalog")
  crosswalk <- .organism_read_csv(identifier_crosswalk, "identifier_crosswalk")
  if (!"gene_id" %in% names(catalog)) stop("gene_catalog is missing gene_id.", call. = FALSE)
  index <- .organism_alias_index(crosswalk)
  cache_dir <- file.path(path.expand(cache_dir),
                         paste0(context$assembly_accession, "_", context$tax_id))
  dir.create(cache_dir, recursive = TRUE, showWarnings = FALSE)
  if (file.access(cache_dir, 2) != 0) stop("Annotation cache is not writable: ", cache_dir,
                                          call. = FALSE)
  providers <- unique(toupper(providers))
  uniprot <- tryCatch(.organism_uniprot(context, cache_dir, refresh),
                      error = function(e) e)
  if (is.data.frame(uniprot)) index <- .organism_extend_index(index, uniprot)
  results <- list()
  failures <- character()
  if ("KEGG" %in% providers) results$KEGG <- tryCatch(
    .organism_kegg(context, index, cache_dir, refresh),
    error = function(e) { failures["KEGG"] <<- conditionMessage(e); NULL }
  )
  if ("GO" %in% providers) results$GO <- tryCatch(
    if (inherits(uniprot, "error")) stop(conditionMessage(uniprot), call. = FALSE)
    else .organism_go(context, index, uniprot),
    error = function(e) { failures["GO"] <<- conditionMessage(e); NULL }
  )
  memberships <- lapply(results, function(x) if (is.null(x)) NULL else x$membership)
  memberships <- Filter(function(x) is.data.frame(x) && nrow(x), memberships)
  if (!length(memberships)) stop(
    "No directly mapped organism-specific KEGG/GO membership was available. ",
    paste(names(failures), failures, sep = ": ", collapse = "; "), call. = FALSE
  )
  membership_evidence <- unique(do.call(rbind, memberships))
  membership <- unique(membership_evidence[
    c("gene_id", "database", "ontology", "set_id", "set_name")
  ])
  audits <- lapply(results, function(x) if (is.null(x)) NULL else x$audit)
  audits <- Filter(function(x) is.data.frame(x), audits)
  audit <- if (length(audits)) do.call(rbind, audits) else data.frame()
  audit$assembly_accession <- context$assembly_accession
  audit$tax_id <- context$tax_id
  audit$organism_name <- context$organism_name
  audit$evidence_policy <- evidence
  if (length(failures)) {
    failure_rows <- data.frame(
      provider = names(failures), organism_code = "", source_rows = 0L,
      mapped_rows = 0L, unmapped_rows = 0L, ambiguous_rows = 0L,
      assembly_accession = context$assembly_accession, tax_id = context$tax_id,
      organism_name = context$organism_name, evidence_policy = evidence,
      failure = unname(failures), stringsAsFactors = FALSE
    )
    audit$failure <- ""
    audit <- rbind(audit, failure_rows)
  } else audit$failure <- ""
  catalog$gene_id <- toupper(trimws(as.character(catalog$gene_id)))
  names(catalog)[names(catalog) == "gene_symbol"] <- "gene_names"
  names(catalog)[names(catalog) == "product"] <- "protein_name"
  utils::write.csv(membership_evidence, file.path(cache_dir, "membership_evidence.csv"),
                   row.names = FALSE, na = "")
  utils::write.csv(audit, file.path(cache_dir, "annotation_audit.csv"),
                   row.names = FALSE, na = "")
  structure(list(
    membership = membership, membership_evidence = membership_evidence,
    annotation_audit = audit, organism_context = context,
    uniprot_by_locus = catalog, kegg_by_locus = .collapse_kegg(
      membership[membership$database == "KEGG", , drop = FALSE]
    ), pseudocap_by_locus = NULL
  ), class = c("pa_annotations_v4", "pa_annotations_v3", "pa_annotations_v2"))
}
