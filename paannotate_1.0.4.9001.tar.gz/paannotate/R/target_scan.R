.scan_match_column <- function(data, requested, aliases, label, required = TRUE) {
  if (!identical(requested, "auto")) {
    if (!requested %in% names(data)) stop(label, " column not found: ", requested,
                                           call. = FALSE)
    return(requested)
  }
  normalized <- gsub("[^a-z0-9]", "", tolower(names(data)))
  hits <- match(gsub("[^a-z0-9]", "", tolower(aliases)), normalized, nomatch = 0L)
  hits <- hits[hits > 0L]
  if (length(hits)) return(names(data)[hits[1]])
  if (required) stop("Could not detect ", label, " column. Available columns: ",
                     paste(names(data), collapse = ", "), call. = FALSE)
  NA_character_
}

.scan_exact_pao1 <- function(x) {
  x <- toupper(trimws(as.character(x)))
  x[!grepl("^PA[0-9]{4}[A-Z]?$", x)] <- NA_character_
  x
}

.scan_extended_pao1 <- function(x) {
  x <- toupper(trimws(as.character(x)))
  x[!grepl("^PA[0-9]{4}([A-Z]|\\.[0-9]+)?$", x)] <- NA_character_
  x
}

.scan_clean_id <- function(x, policy = c("pao1_extended", "pao1_exact", "as_is")) {
  policy <- match.arg(policy)
  x <- toupper(trimws(as.character(x)))
  x[is.na(x) | !nzchar(x)] <- NA_character_
  if (policy == "pao1_exact") x <- .scan_exact_pao1(x)
  if (policy == "pao1_extended") x <- .scan_extended_pao1(x)
  x
}

.scan_identifier_audit <- function(original, cleaned, policy) {
  normalized <- toupper(trimws(as.character(original)))
  exact <- grepl("^PA[0-9]{4}[A-Z]?$", normalized)
  decimal <- grepl("^PA[0-9]{4}\\.[0-9]+$", normalized)
  extended <- exact | decimal
  anchor <- rep(NA_character_, length(normalized))
  anchor[extended] <- substr(normalized[extended], 1L, 6L)
  data.frame(
    gene_id_original = as.character(original),
    gene_id = cleaned,
    locus_anchor = anchor,
    locus_class = ifelse(
      exact, "canonical_pao1_locus",
      ifelse(decimal, "historical_decimal_sublocus", "other_or_invalid")
    ),
    relationship_type = ifelse(
      decimal, "historical_sublocus_unresolved",
      ifelse(exact, "self", "not_assigned")
    ),
    relationship_evidence = ifelse(
      decimal, "identifier syntax only; homology not inferred",
      ifelse(exact, "exact identifier", "none")
    ),
    direct_pao1_annotation_eligible = exact,
    valid_under_policy = !is.na(cleaned),
    id_policy = policy,
    stringsAsFactors = FALSE
  )
}

.scan_slug <- function(x) {
  x <- iconv(as.character(x), to = "ASCII//TRANSLIT")
  x <- tolower(gsub("[^A-Za-z0-9]+", "_", x))
  gsub("(^_+|_+$)", "", x)
}

#' Define genes or gene signatures to scan
#'
#' Creates reusable target definitions for [pa_scan_targets()]. Targets can be
#' individual genes, named gene sets, or a long table. Multi-gene targets are
#' scored independently inside each project.
#'
#' @param individual Character vector of individual genes. Names, when present,
#'   become target labels.
#' @param sets Named list of character vectors or named numeric weight vectors.
#' @param table Optional long table or file with target and gene columns.
#' @param target_col,gene_id_col,weight_col Columns in `table`, or `"auto"`.
#' @param target_sheet Excel sheet for a target table.
#' @param score_method `"mean_z"`, `"median_z"`, `"weighted_mean_z"`, or `"pc1"`.
#' @param id_policy `"pao1_extended"` preserves canonical PAO1 tags and distinct
#'   decimal-suffixed historical subloci; `"pao1_exact"` accepts canonical tags
#'   only; `"as_is"` preserves arbitrary identifiers.
#' @return A `pa_targets` object.
#' @export
pa_targets <- function(
    individual = NULL, sets = NULL, table = NULL,
    target_col = "auto", gene_id_col = "auto", weight_col = "auto",
    target_sheet = 1,
    score_method = c("mean_z", "median_z", "weighted_mean_z", "pc1"),
    id_policy = c("pao1_extended", "pao1_exact", "as_is")) {
  score_method <- match.arg(score_method)
  id_policy <- match.arg(id_policy)
  rows <- list()
  counter <- 0L
  add_rows <- function(target, genes, weights = NULL, source = "user") {
    genes <- as.character(genes)
    if (is.null(weights)) weights <- rep(1, length(genes))
    if (length(weights) != length(genes)) {
      stop("Target '", target, "' has unequal gene and weight lengths.",
           call. = FALSE)
    }
    counter <<- counter + 1L
    rows[[counter]] <<- data.frame(
      target = as.character(target), gene_id_original = genes,
      weight = suppressWarnings(as.numeric(weights)), source = source,
      stringsAsFactors = FALSE
    )
  }
  if (!is.null(individual)) {
    labels <- names(individual)
    if (is.null(labels)) labels <- as.character(individual)
    labels[is.na(labels) | !nzchar(labels)] <- as.character(individual)[is.na(labels) | !nzchar(labels)]
    for (i in seq_along(individual)) add_rows(labels[i], individual[i], 1, "individual")
  }
  if (!is.null(sets)) {
    if (!is.list(sets) || is.null(names(sets)) || any(!nzchar(names(sets)))) {
      stop("sets must be a named list.", call. = FALSE)
    }
    for (target in names(sets)) {
      value <- sets[[target]]
      weights <- if (is.numeric(value) && !is.null(names(value))) unname(value) else NULL
      genes <- if (!is.null(weights)) names(value) else as.character(value)
      add_rows(target, genes, weights, "set")
    }
  }
  if (!is.null(table)) {
    tab <- .read_raw_table(table, target_sheet)$data
    tc <- .scan_match_column(tab, target_col,
                             c("target", "target_name", "signature", "set", "group"),
                             "target")
    gc <- .scan_match_column(tab, gene_id_col,
                             c("gene_id", "gene", "locus", "locus_tag", "member"),
                             "target gene")
    wc <- .scan_match_column(tab, weight_col,
                             c("weight", "coefficient", "loading"),
                             "target weight", required = FALSE)
    weights <- if (is.na(wc)) rep(1, nrow(tab)) else tab[[wc]]
    for (target in unique(as.character(tab[[tc]]))) {
      idx <- which(as.character(tab[[tc]]) == target)
      add_rows(target, tab[[gc]][idx], weights[idx], "table")
    }
  }
  if (!length(rows)) stop("Supply individual genes, named sets, or a target table.",
                          call. = FALSE)
  membership <- do.call(rbind, rows)
  membership$gene_id <- .scan_clean_id(membership$gene_id_original, id_policy)
  invalid <- membership[is.na(membership$gene_id), , drop = FALSE]
  membership <- membership[!is.na(membership$gene_id), , drop = FALSE]
  if (!nrow(membership)) stop("No valid target genes remain.", call. = FALSE)
  membership$weight[!is.finite(membership$weight)] <- 1
  membership <- unique(membership[c("target", "gene_id", "weight", "source")])
  target_names <- unique(membership$target)
  if (any(!nzchar(target_names))) stop("Target names cannot be blank.", call. = FALSE)
  structure(
    list(
      membership = membership,
      targets = data.frame(
        target = target_names,
        target_label = target_names,
        requested_members = vapply(target_names, function(z) {
          length(unique(membership$gene_id[membership$target == z]))
        }, integer(1)),
        stringsAsFactors = FALSE
      ),
      score_method = score_method,
      id_policy = id_policy,
      audit = list(invalid_target_ids = invalid)
    ),
    class = "pa_targets"
  )
}

#' Define target-scan evidence thresholds
#'
#' @param fdr,rho,i2 Convenient aliases applying the requested FDR,
#'   absolute-rho, and I2 limits to every evidence tier that uses them.
#'   I2 is expressed as a percentage: use `i2=50` for 50%, not `i2=0.5`.
#' @param core_fdr,core_rho,core_i2 Core significance, effect, and heterogeneity
#'   rules.
#' @param core_min_projects,core_direction_agreement,core_minimum_loo_rho Core
#'   replication and stability rules.
#' @param supported_fdr,supported_rho,supported_i2 Supported significance,
#'   effect, and heterogeneity rules.
#' @param supported_min_projects,supported_direction_agreement,supported_minimum_loo_rho
#'   Supported replication and stability rules.
#' @param context_fdr,context_rho,context_min_projects Minimum context-dependent
#'   signal rules.
#' @param minimum_meta_projects Minimum projects needed for meta-analysis.
#' @param loo_screen_fdr,loo_screen_rho Permissive screen for expensive
#'   leave-one-project-out calculations.
#' @return A `pa_scan_thresholds` object.
#' @export
pa_scan_thresholds <- function(
    fdr = NULL, rho = NULL, i2 = NULL,
    core_fdr = 0.05, core_rho = 0.30, core_i2 = 75,
    core_min_projects = 5, core_direction_agreement = 0.75,
    core_minimum_loo_rho = 0.20,
    supported_fdr = 0.05, supported_rho = 0.25, supported_i2 = 85,
    supported_min_projects = 3, supported_direction_agreement = 0.70,
    supported_minimum_loo_rho = 0.10,
    context_fdr = 0.05, context_rho = 0.25, context_min_projects = 3,
    minimum_meta_projects = 3, loo_screen_fdr = 0.10,
    loo_screen_rho = 0.15) {
  if (!is.null(fdr)) core_fdr <- supported_fdr <- context_fdr <- fdr
  if (!is.null(rho)) core_rho <- supported_rho <- context_rho <- rho
  if (!is.null(i2)) {
    if (length(i2) == 1L && is.finite(i2) && i2 > 0 && i2 <= 1) {
      warning("i2 is a percentage: i2=", i2, " means ", i2,
              "%; use i2=50 for 50%.", call. = FALSE)
    }
    core_i2 <- supported_i2 <- i2
  }
  values <- as.list(environment())
  values <- values[setdiff(names(values), c("fdr", "rho", "i2"))]
  numeric_values <- unlist(values, use.names = TRUE)
  if (any(!is.finite(numeric_values))) stop("All thresholds must be finite.",
                                            call. = FALSE)
  for (nm in c("core_fdr", "supported_fdr", "context_fdr", "loo_screen_fdr")) {
    if (values[[nm]] < 0 || values[[nm]] > 1) stop(nm, " must be between 0 and 1.",
                                                   call. = FALSE)
  }
  for (nm in c("core_direction_agreement", "supported_direction_agreement")) {
    if (values[[nm]] < 0.5 || values[[nm]] > 1) stop(nm, " must be between 0.5 and 1.",
                                                     call. = FALSE)
  }
  for (nm in c("core_rho", "supported_rho", "context_rho", "loo_screen_rho")) {
    if (values[[nm]] < 0 || values[[nm]] > 1) stop(nm, " must be between 0 and 1.",
                                                   call. = FALSE)
  }
  for (nm in c("core_i2", "supported_i2")) {
    if (values[[nm]] < 0 || values[[nm]] > 100) stop(nm, " must be between 0 and 100.",
                                                     call. = FALSE)
  }
  structure(values, class = "pa_scan_thresholds")
}

.scan_read_metadata <- function(metadata, sheet = 1) {
  value <- .read_raw_table(metadata, sheet)$data
  as.data.frame(value, stringsAsFactors = FALSE, check.names = FALSE)
}

.scan_long_matrix <- function(data, gene_col, sample_col, value_col) {
  gene <- as.character(data[[gene_col]])
  sample <- as.character(data[[sample_col]])
  value <- suppressWarnings(as.numeric(data[[value_col]]))
  bad <- is.na(value) & !is.na(data[[value_col]]) & nzchar(trimws(as.character(data[[value_col]])))
  if (any(bad)) stop("Long expression value column contains nonnumeric data.",
                     call. = FALSE)
  key <- paste(gene, sample, sep = "\r")
  if (anyDuplicated(key)) stop("Long expression input has duplicate gene/sample rows.",
                               call. = FALSE)
  genes <- unique(gene)
  samples <- unique(sample)
  result <- matrix(NA_real_, length(genes), length(samples),
                   dimnames = list(genes, samples))
  result[cbind(match(gene, genes), match(sample, samples))] <- value
  result
}

.scan_prepare_expression <- function(
    expression, metadata, sample_id_col, gene_id_col = "auto",
    orientation = c("auto", "genes_in_rows", "genes_in_columns"),
    expression_format = c("auto", "wide", "long"),
    expression_sample_col = "auto", expression_value_col = "auto",
    data_type = c("auto", "raw_counts", "tpm_cpm", "normalized_log", "standardized"),
    id_policy = c("pao1_extended", "pao1_exact", "as_is"), sheet = 1) {
  orientation <- match.arg(orientation)
  expression_format <- match.arg(expression_format)
  data_type <- match.arg(data_type)
  id_policy <- match.arg(id_policy)
  sample_ids <- as.character(metadata[[sample_id_col]])
  source_label <- if (is.character(expression) && length(expression) == 1L) {
    normalizePath(path.expand(expression), winslash = "/", mustWork = TRUE)
  } else "in-memory expression"
  gene_metadata <- data.frame(stringsAsFactors = FALSE)
  if (is.matrix(expression)) {
    mat <- expression
    if (orientation == "genes_in_columns" ||
        (orientation == "auto" && !is.null(rownames(mat)) &&
           sum(rownames(mat) %in% sample_ids) > sum(colnames(mat) %in% sample_ids))) {
      mat <- t(mat)
    }
    if (is.null(rownames(mat))) stop("Expression matrices require gene names on the gene axis.",
                                     call. = FALSE)
  } else {
    raw <- if (inherits(expression, "pa_input")) expression$data else
      if (is.data.frame(expression)) expression else .read_raw_table(expression, sheet)$data
    if (expression_format == "auto") {
      long_sample <- .scan_match_column(raw, expression_sample_col,
                                        c("sample_id", "sample", "library", "run"),
                                        "expression sample", required = FALSE)
      long_value <- .scan_match_column(raw, expression_value_col,
                                       c("expression", "value", "abundance", "count", "tpm", "cpm"),
                                       "expression value", required = FALSE)
      expression_format <- if (!is.na(long_sample) && !is.na(long_value) &&
                                sum(names(raw) %in% sample_ids) < 2L) "long" else "wide"
    }
    if (expression_format == "long") {
      gc <- .scan_match_column(raw, gene_id_col,
                               c("gene_id", "gene", "locus", "locus_tag"), "gene ID")
      sc <- .scan_match_column(raw, expression_sample_col,
                               c("sample_id", "sample", "library", "run"), "expression sample")
      vc <- .scan_match_column(raw, expression_value_col,
                               c("expression", "value", "abundance", "count", "tpm", "cpm"),
                               "expression value")
      mat <- .scan_long_matrix(raw, gc, sc, vc)
    } else {
      imported <- if (inherits(expression, "pa_input")) expression else
        pa_read(raw, orientation = orientation, gene_id = gene_id_col, sheet = sheet)
      data <- imported$data
      gc <- "gene_id"
      available_samples <- intersect(sample_ids, names(data))
      if (!length(available_samples)) stop("No metadata sample IDs match expression columns.",
                                           call. = FALSE)
      numeric_data <- .coerce_numeric(data, available_samples)
      mat <- as.matrix(numeric_data[available_samples])
      rownames(mat) <- as.character(data[[gc]])
      extra <- setdiff(names(data), c(gc, available_samples))
      if (length(extra)) {
        gene_metadata <- data[c(gc, extra)]
        names(gene_metadata)[1] <- "gene_id_original"
      }
    }
  }
  storage.mode(mat) <- "numeric"
  expression_sample_ids <- colnames(mat)
  matched_samples <- intersect(sample_ids, colnames(mat))
  if (!length(matched_samples)) stop("No metadata sample IDs match the expression matrix.",
                                     call. = FALSE)
  metadata <- metadata[match(matched_samples, sample_ids), , drop = FALSE]
  mat <- mat[, matched_samples, drop = FALSE]
  original_ids <- rownames(mat)
  cleaned_ids <- .scan_clean_id(original_ids, id_policy)
  identifier_audit <- .scan_identifier_audit(original_ids, cleaned_ids, id_policy)
  invalid <- data.frame(gene_id_original = original_ids[is.na(cleaned_ids)],
                        stringsAsFactors = FALSE)
  keep <- !is.na(cleaned_ids)
  mat <- mat[keep, , drop = FALSE]
  rownames(mat) <- cleaned_ids[keep]
  if (anyDuplicated(rownames(mat))) {
    duplicate <- unique(rownames(mat)[duplicated(rownames(mat))])[1]
    stop("Expression contains duplicate normalized gene ID: ", duplicate,
         call. = FALSE)
  }
  finite_rows <- rowSums(is.finite(mat)) > 0
  mat <- mat[finite_rows, , drop = FALSE]
  inferred <- data_type
  if (data_type == "auto") {
    inferred <- if (any(mat < 0, na.rm = TRUE)) "normalized_log" else "tpm_cpm"
  }
  if (inferred == "raw_counts") {
    if (!requireNamespace("edgeR", quietly = TRUE)) {
      stop("raw_counts input requires the optional edgeR package.", call. = FALSE)
    }
    dge <- edgeR::DGEList(counts = mat)
    dge <- edgeR::calcNormFactors(dge)
    mat <- edgeR::cpm(dge, log = TRUE, prior.count = 0.5)
  } else if (inferred == "tpm_cpm") {
    if (any(mat < 0, na.rm = TRUE)) stop("tpm_cpm data cannot contain negative values.",
                                         call. = FALSE)
    mat <- log2(mat + 1)
  }
  list(
    matrix = mat, metadata = metadata, invalid_gene_ids = invalid,
    unmatched_metadata_samples = setdiff(sample_ids, matched_samples),
    unmatched_expression_samples = setdiff(expression_sample_ids, matched_samples),
    data_type_requested = data_type, data_type_used = inferred,
    source = source_label, gene_metadata = gene_metadata,
    gene_identifier_audit = identifier_audit
  )
}

.scan_prepare <- function(
    expression, metadata, targets, sample_id_col = "auto", project_id_col = "auto",
    gene_id_col = "auto", orientation = "auto", expression_format = "auto",
    expression_sample_col = "auto", expression_value_col = "auto",
    data_type = "auto", id_policy = "pao1_extended", sheet = 1,
    metadata_sheet = 1) {
  whiteley <- if (inherits(expression, "pa_whiteley")) expression else NULL
  curated_whiteley <- !is.null(whiteley) && !is.null(whiteley$profile_id)
  if (!is.null(whiteley)) {
    if (is.null(metadata)) metadata <- whiteley$metadata
    if (is.null(metadata)) {
      stop("This Whiteley object has no embedded metadata. Supply metadata explicitly.",
           call. = FALSE)
    }
    expression <- whiteley$counts
  }
  if (is.null(metadata)) stop("metadata is required for non-Whiteley inputs.",
                              call. = FALSE)
  if (!inherits(targets, "pa_targets")) {
    if (is.list(targets)) targets <- do.call(pa_targets, targets) else
      stop("targets must be created by pa_targets() or supplied as its argument list.",
           call. = FALSE)
  }
  md <- .scan_read_metadata(metadata, metadata_sheet)
  sid <- .scan_match_column(md, sample_id_col,
                            c("sample_id", "biosample_id", "sra_number", "run_accession",
                              "sample", "library_id", "run", "sample_name"),
                            "sample ID")
  pid <- .scan_match_column(md, project_id_col,
                            c("project_id", "bioproject_id", "bioproject", "study_id", "project"),
                            "project ID")
  md[[sid]] <- trimws(as.character(md[[sid]]))
  md[[pid]] <- trimws(as.character(md[[pid]]))
  if (any(!nzchar(md[[sid]]) | is.na(md[[sid]]))) stop("Metadata contains blank sample IDs.",
                                                       call. = FALSE)
  if (anyDuplicated(md[[sid]])) stop("Metadata sample IDs must be unique.", call. = FALSE)
  if (any(!nzchar(md[[pid]]) | is.na(md[[pid]]))) stop("Metadata contains blank project IDs.",
                                                       call. = FALSE)
  requested_data_type <- data_type
  preparation_type <- if (curated_whiteley && identical(whiteley$data_type, "raw_counts")) {
    "standardized"
  } else if (identical(data_type, "auto") && !is.null(whiteley$data_type)) {
    if (identical(whiteley$data_type, "tpm")) "tpm_cpm" else whiteley$data_type
  } else data_type
  preparation_id_policy <- if (curated_whiteley) "as_is" else id_policy
  prepared <- .scan_prepare_expression(
    expression, md, sid, gene_id_col, orientation, expression_format,
    expression_sample_col, expression_value_col, preparation_type,
    preparation_id_policy, sheet
  )
  names(prepared$metadata)[names(prepared$metadata) == sid] <- ".sample_id"
  names(prepared$metadata)[names(prepared$metadata) == pid] <- ".project_id"
  if (curated_whiteley && identical(whiteley$data_type, "raw_counts")) {
    normalized <- .whiteley_normalize_projects(prepared$matrix, prepared$metadata)
    prepared$matrix <- normalized$matrix
    prepared$project_data <- normalized$project_data
    cleaned_ids <- .scan_clean_id(rownames(prepared$matrix), id_policy)
    invalid <- is.na(cleaned_ids)
    if (any(invalid)) {
      prepared$invalid_gene_ids <- unique(rbind(
        prepared$invalid_gene_ids,
        data.frame(gene_id_original = rownames(prepared$matrix)[invalid],
                   stringsAsFactors = FALSE)
      ))
    }
    keep <- !invalid
    prepared$matrix <- prepared$matrix[keep, , drop = FALSE]
    rownames(prepared$matrix) <- cleaned_ids[keep]
    prepared$project_data <- lapply(prepared$project_data, function(project) {
      project$cpm <- project$cpm[keep, , drop = FALSE]
      project$log_cpm <- project$log_cpm[keep, , drop = FALSE]
      rownames(project$cpm) <- rownames(project$log_cpm) <- cleaned_ids[keep]
      project
    })
    prepared$data_type_requested <- requested_data_type
    prepared$data_type_used <- "whiteley_project_tmm_logcpm"
    prepared$source <- paste0("built-in Whiteley profile ", whiteley$profile_id,
                              " v", whiteley$profile_version)
    prepared$whiteley_profile <- list(
      profile_id = whiteley$profile_id,
      profile_version = whiteley$profile_version,
      provenance = whiteley$provenance
    )
  }
  if (!is.null(whiteley)) prepared$whiteley_cohort_audit <- whiteley$cohort_audit
  if (!is.null(whiteley)) {
    prepared$whiteley_metadata_overlay_audit <- whiteley$metadata_overlay_audit
  }
  prepared$targets <- targets
  prepared$sample_id_input_column <- sid
  prepared$project_id_input_column <- pid
  prepared
}

.scan_target_score <- function(
    mat, membership, method, minimum_members, minimum_fraction,
    detection_matrix = NULL, minimum_detection_value = 1,
    minimum_detection_fraction = 0.5, minimum_member_mad = 0,
    minimum_coherence = -Inf, minimum_score_sd = 0) {
  requested <- unique(membership$gene_id)
  matched <- intersect(requested, rownames(mat))
  x <- mat[matched, , drop = FALSE]
  detected <- rep(TRUE, length(matched))
  if (!is.null(detection_matrix) && length(matched)) {
    detection <- detection_matrix[matched, , drop = FALSE]
    detected <- rowSums(detection >= minimum_detection_value, na.rm = TRUE) >=
      ceiling(ncol(detection) * minimum_detection_fraction)
  }
  variable <- if (length(matched)) apply(x, 1, function(z) {
    value <- stats::mad(z, constant = 1, na.rm = TRUE)
    is.finite(value) && value >= minimum_member_mad && stats::sd(z, na.rm = TRUE) > 0
  }) else logical()
  keep <- detected & variable
  x <- x[keep, , drop = FALSE]
  usable <- rownames(x)
  coverage <- length(usable) / length(requested)
  if (length(usable) < minimum_members || coverage < minimum_fraction) {
    return(list(score = rep(NA_real_, ncol(mat)), matched = matched, usable = usable,
                coverage = coverage, coherence = NA_real_,
                status = "insufficient detectable, variable target members"))
  }
  z <- t(apply(x, 1, function(v) as.numeric(scale(v))))
  rownames(z) <- usable
  colnames(z) <- colnames(x)
  coherence <- if (length(usable) == 1L) 1 else {
    pairwise <- suppressWarnings(stats::cor(t(x), method = "spearman",
                                            use = "pairwise.complete.obs"))
    stats::median(pairwise[upper.tri(pairwise)], na.rm = TRUE)
  }
  if (is.finite(minimum_coherence) &&
      (!is.finite(coherence) || coherence < minimum_coherence)) {
    return(list(score = rep(NA_real_, ncol(mat)), matched = matched, usable = usable,
                coverage = coverage, coherence = coherence,
                status = "target members are not coherent enough"))
  }
  if (method == "median_z") {
    score <- apply(z, 2, stats::median, na.rm = TRUE)
  } else if (method == "pc1" && nrow(z) > 1L) {
    complete_cols <- colSums(is.finite(z)) == nrow(z)
    score <- rep(NA_real_, ncol(z))
    if (sum(complete_cols) >= 3L) {
      fit <- stats::prcomp(t(z[, complete_cols, drop = FALSE]), center = FALSE,
                           scale. = FALSE)
      pc <- fit$x[, 1]
      anchor <- colMeans(z[, complete_cols, drop = FALSE])
      if (stats::cor(pc, anchor) < 0) pc <- -pc
      score[complete_cols] <- pc
    }
  } else {
    weights <- membership$weight[match(usable, membership$gene_id)]
    if (method != "weighted_mean_z") weights <- rep(1, length(usable))
    weights[!is.finite(weights)] <- 1
    denominator <- colSums(sweep(is.finite(z), 1, abs(weights), "*"))
    numerator <- colSums(sweep(z, 1, weights, "*"), na.rm = TRUE)
    score <- numerator / denominator
    score[denominator == 0] <- NA_real_
  }
  score_sd <- stats::sd(score, na.rm = TRUE)
  list(score = as.numeric(score), matched = matched, usable = usable,
       coverage = coverage, coherence = coherence,
       status = if (is.finite(score_sd) && score_sd >= minimum_score_sd && score_sd > 0) "ok" else
         "nonvarying target score")
}

.scan_residualize <- function(y, design) {
  keep <- is.finite(y) & apply(is.finite(design), 1, all)
  answer <- rep(NA_real_, length(y))
  if (sum(keep) <= ncol(design)) return(list(values = answer, df = 0L))
  fit <- stats::lm.fit(design[keep, , drop = FALSE], y[keep])
  answer[keep] <- fit$residuals
  list(values = answer, df = sum(keep) - fit$rank)
}

.scan_correlate <- function(x, y, method, minimum_pairwise_samples) {
  keep <- is.finite(x) & is.finite(y)
  n <- sum(keep)
  if (n < max(4L, minimum_pairwise_samples)) return(c(rho = NA, pvalue = NA, n = n))
  xx <- x[keep]
  yy <- y[keep]
  if (stats::sd(xx) == 0 || stats::sd(yy) == 0) return(c(rho = NA, pvalue = NA, n = n))
  rho <- suppressWarnings(stats::cor(xx, yy, method = method))
  if (!is.finite(rho)) return(c(rho = NA, pvalue = NA, n = n))
  rho_for_test <- max(min(rho, 0.999999), -0.999999)
  statistic <- rho_for_test * sqrt((n - 2) / (1 - rho_for_test^2))
  pvalue <- 2 * stats::pt(-abs(statistic), df = n - 2)
  c(rho = rho, pvalue = pvalue, n = n)
}

.scan_correlate_rows <- function(genes, score, method, minimum_pairwise_samples) {
  genes <- as.matrix(genes)
  if (!nrow(genes)) {
    return(data.frame(rho = numeric(), pvalue = numeric(), n = integer()))
  }
  if (all(is.finite(genes)) && all(is.finite(score))) {
    n <- length(score)
    if (n < max(4L, minimum_pairwise_samples)) {
      return(data.frame(rho = rep(NA_real_, nrow(genes)),
                        pvalue = rep(NA_real_, nrow(genes)), n = rep(n, nrow(genes))))
    }
    if (method == "spearman") {
      genes <- t(vapply(seq_len(nrow(genes)), function(i) {
        rank(genes[i, ], ties.method = "average")
      }, numeric(ncol(genes))))
      score <- rank(score, ties.method = "average")
    }
    centered_genes <- genes - rowMeans(genes)
    centered_score <- score - mean(score)
    denominator <- sqrt(rowSums(centered_genes^2) * sum(centered_score^2))
    rho <- as.vector(centered_genes %*% centered_score) / denominator
    rho[!is.finite(rho)] <- NA_real_
    rho_for_test <- pmax(pmin(rho, 0.999999), -0.999999)
    statistic <- rho_for_test * sqrt((n - 2) / (1 - rho_for_test^2))
    pvalue <- 2 * stats::pt(-abs(statistic), df = n - 2)
    pvalue[!is.finite(rho)] <- NA_real_
    return(data.frame(rho = rho, pvalue = pvalue, n = rep(n, length(rho))))
  }
  values <- t(vapply(seq_len(nrow(genes)), function(i) {
    .scan_correlate(genes[i, ], score, method, minimum_pairwise_samples)
  }, numeric(3)))
  data.frame(rho = values[, "rho"], pvalue = values[, "pvalue"],
             n = values[, "n"])
}

.scan_random_effects <- function(rho, n, minimum_projects = 3L) {
  keep <- is.finite(rho) & is.finite(n) & n > 3
  rho <- rho[keep]
  n <- n[keep]
  k <- length(rho)
  if (k < minimum_projects) {
    return(c(meta_rho = NA, ci_low = NA, ci_high = NA, z_statistic = NA,
             pvalue = NA, tau2 = NA, i2_percent = NA,
             contributing_projects = k, contributing_samples = sum(n),
             same_direction_fraction = NA, positive_projects = sum(rho > 0),
             negative_projects = sum(rho < 0), fixed_rho = NA))
  }
  z <- atanh(pmax(pmin(rho, 0.999999), -0.999999))
  vi <- 1 / (n - 3)
  wi <- 1 / vi
  fixed <- sum(wi * z) / sum(wi)
  q <- sum(wi * (z - fixed)^2)
  qdf <- k - 1
  c_value <- sum(wi) - sum(wi^2) / sum(wi)
  tau2 <- if (is.finite(c_value) && c_value > 0) max(0, (q - qdf) / c_value) else 0
  wr <- 1 / (vi + tau2)
  mu <- sum(wr * z) / sum(wr)
  se <- sqrt(1 / sum(wr))
  zstat <- mu / se
  ci <- mu + c(-1, 1) * stats::qnorm(0.975) * se
  i2 <- if (q > 0) max(0, (q - qdf) / q) * 100 else 0
  sign_mu <- if (mu >= 0) 1 else -1
  c(meta_rho = tanh(mu), ci_low = tanh(ci[1]), ci_high = tanh(ci[2]),
    z_statistic = zstat, pvalue = 2 * stats::pnorm(-abs(zstat)), tau2 = tau2,
    i2_percent = i2, contributing_projects = k,
    contributing_samples = sum(n),
    same_direction_fraction = mean(sign(rho) == sign_mu),
    positive_projects = sum(rho > 0), negative_projects = sum(rho < 0),
    fixed_rho = tanh(fixed))
}

.scan_classify <- function(meta, thresholds) {
  evaluable <- is.finite(meta$meta_rho) &
    meta$contributing_projects >= thresholds$minimum_meta_projects
  core <- evaluable & meta$meta_fdr < thresholds$core_fdr &
    abs(meta$meta_rho) >= thresholds$core_rho &
    meta$contributing_projects >= thresholds$core_min_projects &
    meta$same_direction_fraction >= thresholds$core_direction_agreement &
    meta$i2_percent < thresholds$core_i2 &
    meta$leave_one_project_out_sign_stable %in% TRUE &
    meta$minimum_leave_one_out_abs_rho >= thresholds$core_minimum_loo_rho &
    meta$sensitivity_direction_stable %in% TRUE
  supported <- evaluable & meta$meta_fdr < thresholds$supported_fdr &
    abs(meta$meta_rho) >= thresholds$supported_rho &
    meta$contributing_projects >= thresholds$supported_min_projects &
    meta$same_direction_fraction >= thresholds$supported_direction_agreement &
    meta$i2_percent < thresholds$supported_i2 &
    meta$leave_one_project_out_sign_stable %in% TRUE &
    meta$minimum_leave_one_out_abs_rho >= thresholds$supported_minimum_loo_rho &
    meta$sensitivity_direction_stable %in% TRUE
  context <- evaluable & meta$meta_fdr < thresholds$context_fdr &
    abs(meta$meta_rho) >= thresholds$context_rho &
    meta$contributing_projects >= thresholds$context_min_projects
  ifelse(core, "Core tracker",
         ifelse(supported, "Supported tracker",
                ifelse(context, "Context-dependent signal",
                       ifelse(evaluable, "Not supported", "Not evaluable"))))
}

#' Check target-scan inputs before analysis
#'
#' @inheritParams pa_scan_targets
#' @return A `pa_scan_check` object with sample, project, identifier, and target
#'   coverage audits.
#' @export
pa_check_scan <- function(
    expression, metadata = NULL, targets, sample_id_col = "auto",
    project_id_col = "auto", gene_id_col = "auto", orientation = "auto",
    expression_format = "auto", expression_sample_col = "auto",
    expression_value_col = "auto", data_type = "auto",
    id_policy = "pao1_extended", sheet = 1, metadata_sheet = 1,
    min_samples_per_project = 6, minimum_target_members = 1,
    minimum_target_fraction = 0.5) {
  prepared <- .scan_prepare(
    expression, metadata, targets, sample_id_col, project_id_col,
    gene_id_col, orientation, expression_format, expression_sample_col,
    expression_value_col, data_type, id_policy, sheet, metadata_sheet
  )
  project_counts <- as.data.frame(table(prepared$metadata$.project_id),
                                  stringsAsFactors = FALSE)
  names(project_counts) <- c("project_id", "biological_samples")
  for (cutoff in sort(unique(as.integer(min_samples_per_project)))) {
    project_counts[[paste0("included_at_n", cutoff)]] <-
      project_counts$biological_samples >= cutoff
  }
  coverage <- do.call(rbind, lapply(unique(prepared$targets$membership$target), function(target) {
    members <- unique(prepared$targets$membership$gene_id[
      prepared$targets$membership$target == target])
    data.frame(
      target = target, requested_members = length(members),
      matched_members = length(intersect(members, rownames(prepared$matrix))),
      coverage_fraction = length(intersect(members, rownames(prepared$matrix))) / length(members),
      usable = length(intersect(members, rownames(prepared$matrix))) >= minimum_target_members &
        length(intersect(members, rownames(prepared$matrix))) / length(members) >= minimum_target_fraction,
      stringsAsFactors = FALSE
    )
  }))
  structure(list(
    summary = data.frame(
      item = c("expression source", "data type requested", "data type used",
               "genes", "matched samples", "projects", "targets"),
      value = c(prepared$source, prepared$data_type_requested, prepared$data_type_used,
                nrow(prepared$matrix), ncol(prepared$matrix),
                length(unique(prepared$metadata$.project_id)),
                length(unique(prepared$targets$membership$target))),
      stringsAsFactors = FALSE
    ),
    project_qc = project_counts, target_coverage = coverage,
    invalid_expression_gene_ids = prepared$invalid_gene_ids,
    invalid_target_gene_ids = prepared$targets$audit$invalid_target_ids,
    unmatched_metadata_samples = prepared$unmatched_metadata_samples,
    unmatched_expression_samples = prepared$unmatched_expression_samples,
    prepared = prepared
  ), class = "pa_scan_check")
}

#' @export
print.pa_scan_check <- function(x, ...) {
  cat("paannotate target-scan preflight\n")
  print(x$summary, row.names = FALSE)
  cat("\nProject eligibility:\n")
  print(x$project_qc, row.names = FALSE)
  cat("\nTarget coverage:\n")
  print(x$target_coverage, row.names = FALSE)
  invisible(x)
}

.scan_meta_analysis <- function(project_correlations, cutoffs, thresholds) {
  .p2c_progress('meta_analysis','Combining independent study estimates')
  modes <- unique(project_correlations$analysis_mode)
  targets <- unique(project_correlations$target)
  genes <- unique(project_correlations$gene_id)
  universe <- expand.grid(
    cutoff = cutoffs, analysis_mode = modes, target = targets, gene_id = genes,
    stringsAsFactors = FALSE
  )
  rows <- list()
  counter <- 0L
  group_data <- new.env(hash = TRUE, parent = emptyenv())
  for (cutoff in cutoffs) {
    eligible <- project_correlations[project_correlations$biological_samples >= cutoff, , drop = FALSE]
    key <- paste(eligible$analysis_mode, eligible$target, eligible$gene_id, sep = "\r")
    split_rows <- split(seq_len(nrow(eligible)), key)
    group_number <- 0L
    for (group_key in names(split_rows)) {
      group_number <- group_number + 1L
      idx <- split_rows[[group_key]]
      part <- eligible[idx, , drop = FALSE]
      counter <- counter + 1L
      stat <- .scan_random_effects(part$rho, part$pairwise_samples,
                                   thresholds$minimum_meta_projects)
      rows[[counter]] <- data.frame(
        cutoff = cutoff, analysis_mode = part$analysis_mode[1],
        target = part$target[1], gene_id = part$gene_id[1],
        as.list(stat), project_ids = paste(sort(unique(part$project_id)), collapse = "; "),
        stringsAsFactors = FALSE
      )
      if (is.finite(stat["meta_rho"])) group_data[[paste(cutoff, group_key, sep = "\r")]] <- part
      if (group_number %% 1000L == 0L || group_number == length(split_rows))
        .p2c_progress('meta_analysis',paste('Checking pooling eligibility \u00b7 sample cutoff',cutoff),
          group_number,length(split_rows),'gene\u2013target checks at this cutoff')
    }
    .p2c_progress('meta_analysis',paste('Combined estimates at sample cutoff',cutoff),
      match(cutoff,cutoffs),length(cutoffs),'sample cutoffs')
  }
  .p2c_progress('meta_sensitivity','Checking meta-analysis sensitivity')
  observed <- if (length(rows)) do.call(rbind, rows) else data.frame()
  meta <- merge(universe, observed,
                by = c("cutoff", "analysis_mode", "target", "gene_id"),
                all.x = TRUE, sort = FALSE)
  meta$evaluable_in_meta_analysis <- is.finite(meta$meta_rho) &
    meta$contributing_projects >= thresholds$minimum_meta_projects
  meta$meta_fdr <- NA_real_
  for (key in unique(paste(meta$cutoff, meta$analysis_mode, sep = "\r"))) {
    idx <- which(paste(meta$cutoff, meta$analysis_mode, sep = "\r") == key)
    family_p <- ifelse(meta$evaluable_in_meta_analysis[idx], meta$pvalue[idx], 1)
    meta$meta_fdr[idx] <- stats::p.adjust(family_p, method = "BH")
  }
  meta$sensitivity_direction_stable <- meta$evaluable_in_meta_analysis &
    is.finite(meta$fixed_rho) & sign(meta$fixed_rho) == sign(meta$meta_rho)
  meta$leave_one_project_out_sign_stable <- NA
  meta$minimum_leave_one_out_abs_rho <- NA_real_
  screened <- which(meta$evaluable_in_meta_analysis &
                      meta$meta_fdr <= thresholds$loo_screen_fdr &
                      abs(meta$meta_rho) >= thresholds$loo_screen_rho)
  for (i in screened) {
    key <- paste(meta$cutoff[i], meta$analysis_mode[i], meta$target[i],
                 meta$gene_id[i], sep = "\r")
    part <- group_data[[key]]
    if (is.null(part) || nrow(part) <= thresholds$minimum_meta_projects) next
    loo <- vapply(seq_len(nrow(part)), function(j) {
      stat <- .scan_random_effects(part$rho[-j], part$pairwise_samples[-j],
                                   thresholds$minimum_meta_projects)
      unname(stat["meta_rho"])
    }, numeric(1))
    loo <- loo[is.finite(loo)]
    meta$leave_one_project_out_sign_stable[i] <- length(loo) > 0 &&
      all(sign(loo) == sign(meta$meta_rho[i]))
    meta$minimum_leave_one_out_abs_rho[i] <- if (length(loo)) min(abs(loo)) else NA_real_
  }
  meta$direction <- ifelse(!meta$evaluable_in_meta_analysis, "Not evaluable",
                           ifelse(meta$meta_rho > 0, "Positive", "Negative"))
  meta$evidence_class <- .scan_classify(meta, thresholds)
  meta[order(meta$cutoff, meta$analysis_mode, meta$target, meta$meta_fdr,
             -abs(meta$meta_rho)), , drop = FALSE]
}

.scan_relationships <- function(meta) {
  cutoffs <- sort(unique(meta$cutoff))
  adjusted_available <- "adjusted" %in% meta$analysis_mode
  rows <- lapply(cutoffs, function(cutoff) {
    part <- meta[meta$cutoff == cutoff, , drop = FALSE]
    total <- part[part$analysis_mode == "total", , drop = FALSE]
    keep <- c("target", "gene_id", "evidence_class", "meta_rho", "meta_fdr",
              "contributing_projects", "same_direction_fraction", "i2_percent",
              "leave_one_project_out_sign_stable")
    total <- total[keep]
    names(total)[-(1:2)] <- paste0("total_", names(total)[-(1:2)])
    if (adjusted_available) {
      adjusted <- part[part$analysis_mode == "adjusted", keep, drop = FALSE]
      names(adjusted)[-(1:2)] <- paste0("adjusted_", names(adjusted)[-(1:2)])
      result <- merge(total, adjusted, by = c("target", "gene_id"), all = TRUE,
                      sort = FALSE)
      total_supported <- result$total_evidence_class %in% c("Core tracker", "Supported tracker")
      adjusted_supported <- result$adjusted_evidence_class %in% c("Core tracker", "Supported tracker")
      direction_match <- is.finite(result$total_meta_rho) & is.finite(result$adjusted_meta_rho) &
        sign(result$total_meta_rho) == sign(result$adjusted_meta_rho)
      result$persistent <- total_supported & adjusted_supported & direction_match
      result$persistent_direction <- ifelse(
        result$persistent, ifelse(result$adjusted_meta_rho > 0, "Positive", "Negative"),
        "Not persistent")
      result$persistent_class <- ifelse(
        !result$persistent, "Not persistent",
        ifelse(result$total_evidence_class == "Core tracker" |
                 result$adjusted_evidence_class == "Core tracker",
               "Core: persists after adjustment",
               "Supported: persists after adjustment"))
      result$selected_rho <- result$adjusted_meta_rho
      result$selected_fdr <- result$adjusted_meta_fdr
      result$selected_i2 <- result$adjusted_i2_percent
      result$selected_projects <- result$adjusted_contributing_projects
    } else {
      result <- total
      result$persistent <- result$total_evidence_class %in% c("Core tracker", "Supported tracker")
      result$persistent_direction <- ifelse(
        result$persistent, ifelse(result$total_meta_rho > 0, "Positive", "Negative"),
        "Not selected")
      result$persistent_class <- ifelse(
        result$persistent, paste0(result$total_evidence_class, ": unadjusted only"),
        "Not selected")
      result$selected_rho <- result$total_meta_rho
      result$selected_fdr <- result$total_meta_fdr
      result$selected_i2 <- result$total_i2_percent
      result$selected_projects <- result$total_contributing_projects
    }
    result$cutoff <- cutoff
    result$relationship_id <- paste(result$target, result$gene_id, sep = "__")
    result
  })
  do.call(rbind, rows)
}

.scan_cross_cutoff <- function(relationships) {
  cutoffs <- sort(unique(relationships$cutoff))
  keys <- c("relationship_id", "target", "gene_id")
  pieces <- lapply(cutoffs, function(cutoff) {
    x <- relationships[relationships$cutoff == cutoff,
                       c(keys, "persistent", "persistent_class", "persistent_direction",
                         "selected_rho", "selected_fdr", "selected_i2", "selected_projects"),
                       drop = FALSE]
    names(x)[-(1:3)] <- paste0("n", cutoff, "_", names(x)[-(1:3)])
    x
  })
  combined <- Reduce(function(x, y) merge(x, y, by = keys, all = TRUE, sort = FALSE),
                     pieces)
  persistent_cols <- paste0("n", cutoffs, "_persistent")
  for (column in persistent_cols) combined[[column]][is.na(combined[[column]])] <- FALSE
  pass_matrix <- as.matrix(combined[persistent_cols])
  combined$pass_count <- rowSums(pass_matrix)
  combined$passing_cutoffs <- apply(pass_matrix, 1, function(z) {
    paste(cutoffs[as.logical(z)], collapse = "; ")
  })
  direction_cols <- paste0("n", cutoffs, "_persistent_direction")
  combined$direction_stable_across_passes <- vapply(seq_len(nrow(combined)), function(i) {
    values <- unlist(combined[i, direction_cols, drop = FALSE], use.names = FALSE)
    values <- unique(values[!is.na(values) & !values %in% c("Not persistent", "Not selected")])
    length(values) <= 1L
  }, logical(1))
  rho_cols <- paste0("n", cutoffs, "_selected_rho")
  i2_cols <- paste0("n", cutoffs, "_selected_i2")
  combined$weakest_selected_abs_rho_among_passes <- vapply(seq_len(nrow(combined)), function(i) {
    keep <- as.logical(pass_matrix[i, ])
    values <- abs(as.numeric(unlist(combined[i, rho_cols, drop = FALSE],
                                    use.names = FALSE)))[keep]
    if (!length(values) || all(!is.finite(values))) NA_real_ else min(values, na.rm = TRUE)
  }, numeric(1))
  combined$worst_selected_i2_among_passes <- vapply(seq_len(nrow(combined)), function(i) {
    keep <- as.logical(pass_matrix[i, ])
    values <- as.numeric(unlist(combined[i, i2_cols, drop = FALSE],
                                use.names = FALSE))[keep]
    if (!length(values) || all(!is.finite(values))) NA_real_ else max(values, na.rm = TRUE)
  }, numeric(1))
  combined$survival_class <- ifelse(
    combined$pass_count == length(cutoffs) & combined$direction_stable_across_passes,
    "Survives all requested cutoffs",
    ifelse(combined$pass_count > 1 & !combined$direction_stable_across_passes,
           "Passes multiple cutoffs but direction changes",
           paste0("Passes cutoff(s): ", combined$passing_cutoffs)))
  combined <- combined[combined$pass_count > 0, , drop = FALSE]
  combined[order(-combined$pass_count,
                 -combined$weakest_selected_abs_rho_among_passes,
                 combined$worst_selected_i2_among_passes,
                 combined$target, combined$gene_id), , drop = FALSE]
}

.scan_gene_summary <- function(cross_cutoff, cutoffs) {
  if (!nrow(cross_cutoff)) return(data.frame())
  split_rows <- split(seq_len(nrow(cross_cutoff)), cross_cutoff$gene_id)
  rows <- lapply(names(split_rows), function(gene) {
    x <- cross_cutoff[split_rows[[gene]], , drop = FALSE]
    answer <- data.frame(
      gene_id = gene,
      relationships_passing_any_cutoff = nrow(x),
      targets_passing_any_cutoff = paste(sort(unique(x$target)), collapse = "; "),
      all_cutoff_relationships = sum(x$pass_count == length(cutoffs) &
                                       x$direction_stable_across_passes),
      survives_all_cutoffs_any_target = any(x$pass_count == length(cutoffs) &
                                              x$direction_stable_across_passes),
      strongest_weakest_abs_rho = if (all(!is.finite(
        x$weakest_selected_abs_rho_among_passes))) NA_real_ else
          max(x$weakest_selected_abs_rho_among_passes, na.rm = TRUE),
      lowest_worst_i2 = if (all(!is.finite(x$worst_selected_i2_among_passes)))
        NA_real_ else min(x$worst_selected_i2_among_passes, na.rm = TRUE),
      stringsAsFactors = FALSE
    )
    for (cutoff in cutoffs) {
      answer[[paste0("n", cutoff, "_selected_relationships")]] <-
        sum(x[[paste0("n", cutoff, "_persistent")]], na.rm = TRUE)
    }
    answer
  })
  result <- do.call(rbind, rows)
  result[!is.finite(result$strongest_weakest_abs_rho), "strongest_weakest_abs_rho"] <- NA
  result[!is.finite(result$lowest_worst_i2), "lowest_worst_i2"] <- NA
  result[order(-result$all_cutoff_relationships,
               -result$relationships_passing_any_cutoff,
               -result$strongest_weakest_abs_rho, result$gene_id), , drop = FALSE]
}

#' Scan PAO1 expression for genes associated with arbitrary target signatures
#'
#' Computes within-project target scores and correlations, optional covariate-
#' adjusted correlations, Fisher-z random-effects meta-analysis, complete-family
#' BH FDR, evidence classes, leave-one-project-out stability, and cross-cutoff
#' survival.
#'
#' @param expression Expression file, data frame, matrix, or `pa_input`.
#' @param metadata Sample metadata file or data frame.
#' @param targets A `pa_targets` object or argument list for [pa_targets()].
#' @param sample_id_col,project_id_col Metadata columns, or `"auto"`.
#' @param gene_id_col Expression gene column, or `"auto"`.
#' @param orientation Expression orientation accepted by [pa_read()].
#' @param expression_format `"auto"`, `"wide"`, or `"long"`.
#' @param expression_sample_col,expression_value_col Long-format columns.
#' @param data_type `"auto"`, `"raw_counts"`, `"tpm_cpm"`,
#'   `"normalized_log"`, or `"standardized"`.
#' @param id_policy Exact PAO1 IDs or arbitrary identifiers.
#' @param sheet,metadata_sheet Expression and metadata Excel sheets.
#' @param adjustment Optional model formula such as `~ study_arm + batch`.
#' @param min_samples_per_project One or more project sample cutoffs.
#' @param minimum_pairwise_samples Pairwise observations per correlation.
#' @param minimum_residual_df Minimum residual degrees of freedom for adjusted
#'   mode.
#' @param minimum_target_members,minimum_target_fraction Target coverage rules.
#' @param minimum_target_cpm,minimum_target_detection_fraction,minimum_target_mad
#'   Detectability and variability rules for raw-count
#'   Whiteley targets.
#' @param minimum_target_coherence,minimum_target_score_sd Target coherence and
#'   score-variation rules.
#' @param minimum_gene_cpm,minimum_gene_detection_fraction,minimum_gene_detected_samples,minimum_gene_mad
#'   Project-specific candidate
#'   gene filters for the built-in Whiteley profile.
#' @param correlation `"spearman"` or `"pearson"`.
#' @param thresholds A [pa_scan_thresholds()] object.
#' @param exclude_target_genes Exclude all target members from candidates.
#' @return A `pa_target_scan` object.
#' @export
.p2c_resume_event <- function(name,message){
  cat('P2C_EVENT ',jsonlite::toJSON(list(event=name,message=message),auto_unbox=TRUE),'\n',sep='')
  flush.console()
}
.p2c_progress <- function(phase,message,done=0,total=0,unit='steps'){
  cat('P2C_EVENT ',jsonlite::toJSON(list(event='whiteley_progress',phase=phase,
    message=message,done=done,total=total,unit=unit),auto_unbox=TRUE),'\n',sep='')
  flush.console()
}
.p2c_resume_pause <- function(stop_file){
  if(!is.null(stop_file)&&nzchar(stop_file)&&file.exists(stop_file))
    stop(structure(list(message='Paused after saving completed Whiteley work',call=NULL),class=c('p2c_pause','error','condition')))
}
.p2c_resume_read <- function(path,key){
  valid<-function(file,md5)file.exists(file)&&file.exists(md5)&&
    identical(unname(tools::md5sum(file)),trimws(readLines(md5,warn=FALSE,n=1L)))
  if(!file.exists(path)||!file.exists(paste0(path,'.md5')))return(NULL)
  source<-path
  if(!valid(path,paste0(path,'.md5'))){
    backup<-paste0(path,'.previous')
    if(!valid(backup,paste0(backup,'.md5')))stop('A saved Whiteley checkpoint failed its checksum: ',basename(path),call.=FALSE)
    source<-backup
  }
  result<-readRDS(source)
  if(!identical(result$key,key))stop('Saved Whiteley work was made with different inputs or software. Start a new analysis.',call.=FALSE)
  result
}
.p2c_resume_write <- function(path,value){
  dir.create(dirname(path),recursive=TRUE,showWarnings=FALSE)
  temporary<-paste0(path,'.',Sys.getpid(),'.tmp')
  on.exit(unlink(temporary),add=TRUE)
  saveRDS(value,temporary,compress='gzip')
  checksum<-unname(tools::md5sum(temporary))
  previous<-paste0(path,'.previous')
  if(file.exists(path)&&file.exists(paste0(path,'.md5'))){
    if(!file.copy(path,previous,overwrite=TRUE)||!file.copy(paste0(path,'.md5'),paste0(previous,'.md5'),overwrite=TRUE))
      stop('Could not protect the previous Whiteley checkpoint.',call.=FALSE)
  }
  if(!file.rename(temporary,path))stop('Could not save a Whiteley checkpoint.',call.=FALSE)
  md5_tmp<-paste0(path,'.md5.',Sys.getpid(),'.tmp')
  on.exit(unlink(md5_tmp),add=TRUE)
  writeLines(checksum,md5_tmp)
  if(!file.rename(md5_tmp,paste0(path,'.md5')))stop('Could not finalize a Whiteley checkpoint.',call.=FALSE)
  unlink(c(previous,paste0(previous,'.md5')))
}

pa_scan_targets <- function(
    expression, metadata = NULL, targets, sample_id_col = "auto",
    project_id_col = "auto", gene_id_col = "auto", orientation = "auto",
    expression_format = "auto", expression_sample_col = "auto",
    expression_value_col = "auto", data_type = "auto",
    id_policy = "pao1_extended", sheet = 1, metadata_sheet = 1, adjustment = NULL,
    min_samples_per_project = 6, minimum_pairwise_samples = 5,
    minimum_residual_df = 4, minimum_target_members = 1,
    minimum_target_fraction = 0.5,
    minimum_target_cpm = 1, minimum_target_detection_fraction = 0.5,
    minimum_target_mad = 0.05, minimum_target_coherence = -Inf,
    minimum_target_score_sd = 0,
    minimum_gene_cpm = 1, minimum_gene_detection_fraction = 0.25,
    minimum_gene_detected_samples = 3, minimum_gene_mad = 0.10,
    correlation = c("spearman", "pearson"),
    thresholds = pa_scan_thresholds(), exclude_target_genes = TRUE, pathway_membership = NULL, minimum_pathway_members = 3, minimum_pathway_fraction = .5,
    checkpoint_dir = NULL, checkpoint_key = NULL, stop_file = NULL, checkpoint_callback = NULL) {
  correlation <- match.arg(correlation)
  if (!inherits(thresholds, "pa_scan_thresholds")) {
    if (is.list(thresholds)) thresholds <- do.call(pa_scan_thresholds, thresholds) else
      stop("thresholds must come from pa_scan_thresholds().", call. = FALSE)
  }
  cutoffs <- sort(unique(as.integer(min_samples_per_project)))
  if (any(!is.finite(cutoffs) | cutoffs < 4)) stop("Sample cutoffs must be integers >= 4.",
                                                  call. = FALSE)
  fractions <- c(minimum_target_fraction, minimum_target_detection_fraction,
                 minimum_gene_detection_fraction)
  if (any(!is.finite(fractions) | fractions < 0 | fractions > 1)) {
    stop("Target and gene detection fractions must be between 0 and 1.", call. = FALSE)
  }
  nonnegative <- c(minimum_target_cpm, minimum_target_mad,
                   minimum_target_score_sd, minimum_gene_cpm, minimum_gene_mad)
  if (any(!is.finite(nonnegative) | nonnegative < 0)) {
    stop("CPM, MAD, and score-SD thresholds must be finite and nonnegative.",
         call. = FALSE)
  }
  check <- pa_check_scan(
    expression = expression, metadata = metadata, targets = targets,
    sample_id_col = sample_id_col, project_id_col = project_id_col,
    gene_id_col = gene_id_col, orientation = orientation,
    expression_format = expression_format,
    expression_sample_col = expression_sample_col,
    expression_value_col = expression_value_col, data_type = data_type,
    id_policy = id_policy, sheet = sheet, metadata_sheet = metadata_sheet,
    min_samples_per_project = cutoffs,
    minimum_target_members = minimum_target_members,
    minimum_target_fraction = minimum_target_fraction
  )
  prepared <- check$prepared
  mat <- prepared$matrix
  md <- prepared$metadata
  target_membership <- prepared$targets$membership
  target_names <- unique(target_membership$target)
  candidate_genes <- rownames(mat)
  if (exclude_target_genes) {
    candidate_genes <- setdiff(candidate_genes, unique(target_membership$gene_id))
  }
  if (!length(candidate_genes)) stop("No candidate genes remain after exclusions.",
                                     call. = FALSE)
  projects <- unique(md$.project_id)
  pathway_correlations <- list(); pathway_audits <- list()
  correlations <- list()
  score_rows <- list()
  target_qc <- list()
  project_qc <- list()
  cor_counter <- score_counter <- qc_counter <- project_counter <- 0L
  collapse_project_value <- function(data, column) {
    if (!column %in% names(data)) return("")
    values <- unique(trimws(as.character(data[[column]])))
    values <- values[!is.na(values) & nzchar(values)]
    paste(values, collapse = "; ")
  }
  for (project in projects) {
    project_index<-project_counter+1L
    checkpoint_path<-if(is.null(checkpoint_dir))NULL else file.path(checkpoint_dir,sprintf('study_%05d.rds',project_index))
    checkpoint<-if(is.null(checkpoint_path))NULL else .p2c_resume_read(checkpoint_path,checkpoint_key)
    if(!is.null(checkpoint)){
      if(!identical(checkpoint$project,project))stop('Saved Whiteley study order changed. Start a new analysis.',call.=FALSE)
      project_counter<-project_counter+1L;project_qc[[project_counter]]<-checkpoint$project_qc
      for(item in checkpoint$target_qc){qc_counter<-qc_counter+1L;target_qc[[qc_counter]]<-item}
      for(item in checkpoint$score_rows){score_counter<-score_counter+1L;score_rows[[score_counter]]<-item}
      for(item in checkpoint$correlations){cor_counter<-cor_counter+1L;correlations[[cor_counter]]<-item}
      for(item in checkpoint$pathway_correlations)pathway_correlations[[length(pathway_correlations)+1L]]<-item
      if(!is.null(checkpoint$pathway_audit))pathway_audits[[project]]<-checkpoint$pathway_audit
      .p2c_resume_event('whiteley_checkpoint',sprintf('Reused study %d of %d: %s',project_counter,length(projects),project))
      .p2c_resume_pause(stop_file)
      next
    }
    .p2c_resume_pause(stop_file)
    if(!is.null(checkpoint_dir))set.seed(as.integer(Sys.getenv('P2C_RANDOM_SEED','1729'))+project_index)
    first_cor<-cor_counter;first_score<-score_counter;first_qc<-qc_counter;first_pathway<-length(pathway_correlations)
    sample_idx <- which(md$.project_id == project)
    project_md <- md[sample_idx, , drop = FALSE]
    project_mat <- mat[, project_md$.sample_id, drop = FALSE]
    biological_samples <- ncol(project_mat)
    project_aux <- if (!is.null(prepared$project_data))
      prepared$project_data[[project]] else NULL
    project_candidates <- candidate_genes
    minimum_detected <- NA_integer_
    if (!is.null(project_aux)) {
      project_mat <- project_aux$log_cpm[, project_md$.sample_id, drop = FALSE]
      minimum_detected <- max(as.integer(minimum_gene_detected_samples),
                              ceiling(minimum_gene_detection_fraction * biological_samples))
      candidate_cpm <- project_aux$cpm[project_candidates, , drop = FALSE]
      candidate_log <- project_mat[project_candidates, , drop = FALSE]
      eligible <- rowSums(candidate_cpm >= minimum_gene_cpm, na.rm = TRUE) >= minimum_detected &
        apply(candidate_log, 1, function(z) {
          value <- stats::mad(z, constant = 1, na.rm = TRUE)
          is.finite(value) && value >= minimum_gene_mad
        })
      project_candidates <- project_candidates[eligible]
    }
    design <- NULL
    design_rank <- NA_integer_
    residual_df <- NA_integer_
    adjustment_status <- if (is.null(adjustment)) "not requested" else "unavailable"
    if (!is.null(adjustment)) {
      design_data <- project_md
      adjustment_variables <- intersect(all.vars(adjustment), names(design_data))
      for (variable in adjustment_variables) {
        values <- unique(design_data[[variable]][!is.na(design_data[[variable]])])
        if (length(values) <= 1L) design_data[[variable]] <- rep(0, nrow(design_data))
      }
      design <- tryCatch(stats::model.matrix(adjustment, data = design_data),
                         error = function(e) NULL)
      if (!is.null(design) && nrow(design) == biological_samples &&
          all(apply(is.finite(design), 1, all))) {
        design_rank <- qr(design)$rank
        residual_df <- biological_samples - design_rank
        adjustment_status <- if (residual_df >= minimum_residual_df) "available" else
          "insufficient residual degrees of freedom"
      }
    }
    project_counter <- project_counter + 1L
    project_qc[[project_counter]] <- data.frame(
      project_id = project, biological_samples = biological_samples,
      eligible_candidate_genes = length(project_candidates),
      minimum_detected_samples = minimum_detected,
      minimum_library_reads = if (is.null(project_aux)) NA_real_ else
        min(project_aux$library_sizes),
      median_library_reads = if (is.null(project_aux)) NA_real_ else
        stats::median(project_aux$library_sizes),
      maximum_library_reads = if (is.null(project_aux)) NA_real_ else
        max(project_aux$library_sizes),
      normalization = if (is.null(project_aux)) "input values" else
        project_aux$normalization,
      normalization_warning = if (is.null(project_aux) ||
          is.null(project_aux$normalization_warning)) "" else
        project_aux$normalization_warning,
      adjustment_status = adjustment_status, design_rank = design_rank,
      residual_df = residual_df,
      context = collapse_project_value(project_md, "analysis_context"),
      host = collapse_project_value(project_md, "host_scientific_name"),
      medium = collapse_project_value(project_md, "medium_full"),
      study_title = collapse_project_value(project_md, "study_title"),
      stringsAsFactors = FALSE
    )
    # Candidate-gene matrices do not depend on the target. In separate-target
    # scans, constructing and residualizing them once per project avoids
    # repeating the most expensive gene-wise operation for every target.
    project_gene_matrix <- project_mat[project_candidates, , drop = FALSE]
    pathway_matrix <- if(!is.null(pathway_membership)) .p2c_activity_matrix(project_gene_matrix,pathway_membership,unique(target_membership$gene_id),minimum_pathway_members,minimum_pathway_fraction) else NULL
    if(!is.null(pathway_matrix)){a<-attr(pathway_matrix,"audit");a$project_id<-rep(project,nrow(a));pathway_audits[[project]]<-a}
    adjusted_pathways <- NULL
    adjusted_gene_matrix <- NULL
    for (target in target_names) {
      membership <- target_membership[target_membership$target == target, , drop = FALSE]
      scored <- .scan_target_score(
        project_mat, membership, prepared$targets$score_method,
        minimum_target_members, minimum_target_fraction,
        detection_matrix = if (is.null(project_aux)) NULL else project_aux$cpm,
        minimum_detection_value = minimum_target_cpm,
        minimum_detection_fraction = minimum_target_detection_fraction,
        minimum_member_mad = if (is.null(project_aux)) 0 else minimum_target_mad,
        minimum_coherence = minimum_target_coherence,
        minimum_score_sd = minimum_target_score_sd
      )
      qc_counter <- qc_counter + 1L
      target_qc[[qc_counter]] <- data.frame(
        project_id = project, target = target,
        requested_members = length(unique(membership$gene_id)),
        matched_members = length(scored$matched),
        matched_gene_ids = paste(scored$matched, collapse = "; "),
        usable_members = length(scored$usable),
        usable_gene_ids = paste(scored$usable, collapse = "; "),
        coverage_fraction = scored$coverage, score_status = scored$status,
        median_within_target_rho = scored$coherence,
        score_sd = stats::sd(scored$score, na.rm = TRUE),
        stringsAsFactors = FALSE
      )
      for (j in seq_along(scored$score)) {
        score_counter <- score_counter + 1L
        score_rows[[score_counter]] <- data.frame(
          project_id = project, sample_id = project_md$.sample_id[j],
          target = target, target_score = scored$score[j],
          stringsAsFactors = FALSE
        )
      }
      if (scored$status != "ok") next
      # Projects below every requested cutoff can be audited, but they can never
      # contribute to a reported meta-analysis and need not generate millions
      # of disposable gene-level rows in the full release.
      if (biological_samples < min(cutoffs)) next
      if (!length(project_candidates)) next
      modes <- list(total = list(score = scored$score,
                                 genes = project_gene_matrix,
                                 residual_df = NA_integer_))
      if (!is.null(design) && identical(adjustment_status, "available")) {
        score_resid <- .scan_residualize(scored$score, design)
        if (is.null(adjusted_gene_matrix)) {
          adjusted_gene_matrix <- t(apply(
            project_gene_matrix, 1,
            function(y) .scan_residualize(y, design)$values
          ))
          if (length(project_candidates) == 1L) {
            adjusted_gene_matrix <- matrix(adjusted_gene_matrix, nrow = 1L)
          }
          rownames(adjusted_gene_matrix) <- project_candidates
          colnames(adjusted_gene_matrix) <- colnames(project_mat)
        }
        modes$adjusted <- list(score = score_resid$values,
                               genes = adjusted_gene_matrix,
                               residual_df = score_resid$df)
      }
      for (mode in names(modes)) {
        mode_data <- modes[[mode]]
        if(!is.null(pathway_matrix) && nrow(pathway_matrix)){
          pm <- pathway_matrix
          if(mode=="adjusted"){
            if(is.null(adjusted_pathways)){
              adjusted_pathways <- t(vapply(seq_len(nrow(pm)),function(i).scan_residualize(pm[i,],design)$values,numeric(ncol(pm))))
              dimnames(adjusted_pathways)<-dimnames(pm)
            }
            pm <- adjusted_pathways
          }
          ps <- .scan_correlate_rows(pm,mode_data$score,correlation,minimum_pairwise_samples)
          pathway_correlations[[length(pathway_correlations)+1L]] <- data.frame(project_id=project,biological_samples=biological_samples,target=target,gene_id=rownames(pm),analysis_mode=mode,rho=ps$rho,pvalue=ps$pvalue,pairwise_samples=ps$n,residual_df=mode_data$residual_df,target_members=paste(scored$matched,collapse="; "),stringsAsFactors=FALSE)
        }
        statistics <- .scan_correlate_rows(
          mode_data$genes[project_candidates, , drop = FALSE], mode_data$score,
          correlation, minimum_pairwise_samples
        )
        cor_counter <- cor_counter + 1L
        correlations[[cor_counter]] <- data.frame(
          project_id = project, biological_samples = biological_samples,
          target = target, gene_id = project_candidates, analysis_mode = mode,
          rho = statistics$rho, pvalue = statistics$pvalue,
          pairwise_samples = statistics$n,
          residual_df = mode_data$residual_df,
          target_members = paste(scored$matched, collapse = "; "),
          stringsAsFactors = FALSE
        )
      }
    }
    if(!is.null(checkpoint_path)){
      after<-function(items,first)if(length(items)>first)items[seq.int(first+1L,length(items))] else list()
      .p2c_resume_write(checkpoint_path,list(key=checkpoint_key,project=project,project_qc=project_qc[[project_counter]],
        target_qc=after(target_qc,first_qc),score_rows=after(score_rows,first_score),correlations=after(correlations,first_cor),
        pathway_correlations=after(pathway_correlations,first_pathway),pathway_audit=pathway_audits[[project]]))
      .p2c_resume_event('whiteley_checkpoint',sprintf('Saved study %d of %d: %s',project_counter,length(projects),project))
      if(!is.null(checkpoint_callback))checkpoint_callback(project_counter,project)
    }
    .p2c_resume_pause(stop_file)
  }
  project_correlations <- if (length(correlations)) do.call(rbind, correlations) else
    stop("No project-level correlations were evaluable.", call. = FALSE)
  meta <- .scan_meta_analysis(project_correlations, cutoffs, thresholds)
  relationships <- .scan_relationships(meta)
  cross_cutoff <- .scan_cross_cutoff(relationships)
  gene_summary <- .scan_gene_summary(cross_cutoff, cutoffs)
  project_qc <- do.call(rbind, project_qc)
  for (cutoff in cutoffs) {
    project_qc[[paste0("included_at_n", cutoff)]] <-
      project_qc$biological_samples >= cutoff
  }
  denominators <- do.call(rbind, lapply(cutoffs, function(cutoff) {
    m <- meta[meta$cutoff == cutoff, , drop = FALSE]
    r <- relationships[relationships$cutoff == cutoff, , drop = FALSE]
    data.frame(
      minimum_samples_per_project = cutoff,
      included_projects = sum(project_qc$biological_samples >= cutoff),
      total_gene_target_mode_tests = nrow(m),
      evaluable_tests = sum(m$evaluable_in_meta_analysis),
      core_mode_results = sum(m$evidence_class == "Core tracker"),
      supported_mode_results = sum(m$evidence_class == "Supported tracker"),
      context_dependent_mode_results = sum(m$evidence_class == "Context-dependent signal"),
      selected_relationships = sum(r$persistent),
      selected_unique_genes = length(unique(r$gene_id[r$persistent])),
      stringsAsFactors = FALSE
    )
  }))
  gene_input_summary <- data.frame(
    gene_id = rownames(mat), mean_expression = rowMeans(mat, na.rm = TRUE),
    detection_fraction = rowMeans(is.finite(mat)), stringsAsFactors = FALSE
  )
  result <- structure(list(
    input_audit = check[names(check) != "prepared"],
    cohort_audit = prepared$whiteley_cohort_audit,
    metadata_overlay_audit = prepared$whiteley_metadata_overlay_audit,
    targets = prepared$targets, thresholds = thresholds,
    config = list(
      expression_source = prepared$source,
      data_type_requested = prepared$data_type_requested,
      data_type_used = prepared$data_type_used,
      sample_id_input_column = prepared$sample_id_input_column,
      project_id_input_column = prepared$project_id_input_column,
      adjustment = if (is.null(adjustment)) NULL else paste(deparse(adjustment), collapse = ""),
      min_samples_per_project = cutoffs,
      minimum_pairwise_samples = minimum_pairwise_samples,
      minimum_residual_df = minimum_residual_df,
      minimum_target_members = minimum_target_members,
      minimum_target_fraction = minimum_target_fraction,
      minimum_target_cpm = minimum_target_cpm,
      minimum_target_detection_fraction = minimum_target_detection_fraction,
      minimum_target_mad = minimum_target_mad,
      minimum_target_coherence = minimum_target_coherence,
      minimum_target_score_sd = minimum_target_score_sd,
      minimum_gene_cpm = minimum_gene_cpm,
      minimum_gene_detection_fraction = minimum_gene_detection_fraction,
      minimum_gene_detected_samples = minimum_gene_detected_samples,
      minimum_gene_mad = minimum_gene_mad,
      whiteley_profile = prepared$whiteley_profile,
      correlation = correlation,
      exclude_target_genes = exclude_target_genes
    ),
    project_qc = project_qc,
    target_qc = do.call(rbind, target_qc),
    target_scores = do.call(rbind, score_rows),
    project_correlations = project_correlations,
    meta_analysis = meta,
    relationships = relationships,
    cross_cutoff = cross_cutoff,
    gene_summary = gene_summary,
    denominators = denominators,
    gene_input_summary = gene_input_summary,
    candidate_genes = candidate_genes
  ), class = "pa_target_scan")
  if(length(pathway_correlations)){
    result$pathway_project_correlations <- do.call(rbind,pathway_correlations)
    pm <- .scan_meta_analysis(result$pathway_project_correlations,cutoffs,thresholds)
    labels <- unique(.as_membership(pathway_membership)[c("database","ontology","set_id","set_name")]);labels$gene_id <- .p2c_set_key(labels)
    result$pathway_meta_analysis <- merge(pm,labels,by="gene_id",all.x=TRUE,sort=FALSE)
  }
  if(length(pathway_audits))result$pathway_activity_audit <- do.call(rbind,pathway_audits)
  if(!is.null(pathway_membership))result$pathway_activity_method <- "Mean gene z-scores within each study after expression filtering; all target members excluded. Covariate-adjusted scores use the same design as the target. Study correlations are meta-analyzed separately from gene tests; BH covers all pathway-target tests within cutoff/mode."
  result
}

#' @export
print.pa_target_scan <- function(x, ...) {
  metadata_contrast <- identical(x$config$analysis_type,
                                 "whiteley_metadata_contrast")
  cat(if (metadata_contrast) {
    "paannotate Whiteley metadata-contrast scan\n"
  } else "paannotate target-signature scan\n")
  cat(if (metadata_contrast) "  comparison:" else "  targets:",
      if (metadata_contrast) x$config$metadata_target$target_name else
        nrow(x$targets$targets), "\n")
  cat("  projects:", nrow(x$project_qc), "\n")
  cat("  candidate genes:", length(x$candidate_genes), "\n")
  cat("  project correlations:", nrow(x$project_correlations), "\n")
  cat("  meta-analysis rows:", nrow(x$meta_analysis), "\n")
  cat("  selected cross-cutoff relationships:", nrow(x$cross_cutoff), "\n")
  invisible(x)
}
