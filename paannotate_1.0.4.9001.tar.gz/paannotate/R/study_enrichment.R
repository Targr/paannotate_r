# Study-specific enrichment is an explicit fallback when pooling is unavailable.
# It uses complete saved gene ranks, never a selected-significant-gene list.
.scan_study_ranked <- function(scan, membership, methods, minimum_overlap,
                               minimum_size, maximum_size, inter_gene_cor, ...) {
  d <- scan$project_correlations
  empty <- list(ranked = data.frame(), audit = data.frame())
  if (!is.data.frame(d) || !nrow(d) || !length(setdiff(methods, 'ora'))) return(empty)
  cutoff <- min(scan$config$min_samples_per_project)
  required <- c('project_id','target','analysis_mode','gene_id','rho','pvalue',
                'biological_samples','pairwise_samples')
  if (length(setdiff(required, names(d)))) stop('Saved study correlations are incomplete.')
  d <- d[d$biological_samples >= cutoff, , drop=FALSE]
  keys <- unique(d[c('project_id','target','analysis_mode')])
  keys <- keys[do.call(order, keys), , drop=FALSE]
  rownames(keys) <- NULL
  results <- audits <- list()
  had_seed <- exists('.Random.seed', envir=.GlobalEnv, inherits=FALSE)
  if (had_seed) original_seed <- get('.Random.seed', envir=.GlobalEnv)
  on.exit(if (had_seed) assign('.Random.seed', original_seed, envir=.GlobalEnv) else
    if (exists('.Random.seed', envir=.GlobalEnv, inherits=FALSE)) rm('.Random.seed', envir=.GlobalEnv), add=TRUE)
  for (i in seq_len(nrow(keys))) {
    key <- keys[i,,drop=FALSE]
    .p2c_progress('enrichment',paste('Pathways:',key$project_id,key$target,key$analysis_mode),
                  i-1L,nrow(keys),'study\u2013target analyses')
    x <- d[d$project_id==key$project_id & d$target==key$target &
             d$analysis_mode==key$analysis_mode,,drop=FALSE]
    x <- x[is.finite(x$rho) & is.finite(x$pvalue) & x$pvalue>=0 & x$pvalue<=1,,drop=FALSE]
    x <- x[order(x$gene_id),,drop=FALSE]
    rownames(x) <- NULL
    if (anyDuplicated(x$gene_id)) stop('Duplicate genes in saved study ranks.')
    # Signed normal scores preserve the two-sided correlation-test evidence.
    # Stable gene ordering also makes tied scores reproducible.
    x$z_statistic <- sign(x$rho)*stats::qnorm(pmax(x$pvalue/2,.Machine$double.xmin),lower.tail=FALSE)
    x$cutoff <- rep.int(cutoff,nrow(x))
    seed <- as.integer((1729 + sum(utf8ToInt(paste(unlist(key),collapse='::')) *
      seq_along(utf8ToInt(paste(unlist(key),collapse='::'))))) %% 2147483646)
    set.seed(seed)
    one <- .scan_ranked(list(meta_analysis=x),membership,cutoff,key$analysis_mode,
                         methods,minimum_overlap,minimum_size,maximum_size,inter_gene_cor,...)
    if (nrow(one)) {
      one$project_id <- key$project_id
      one$analysis_mode <- key$analysis_mode
      one$ranked_genes <- nrow(x)
      one$minimum_pairwise_samples <- min(x$pairwise_samples)
      one$maximum_pairwise_samples <- max(x$pairwise_samples)
      one$evidence_scope <- 'individual study; not meta-analysis'
      results[[length(results)+1L]] <- one
    }
    audits[[i]] <- data.frame(key,ranked_genes=nrow(x),seed=seed,
      tied_rank_fraction=if(nrow(x))1-length(unique(x$z_statistic))/nrow(x) else NA_real_,
      pathway_tests=nrow(one),status=if(nrow(one))'tested' else 'no evaluable pathway ranks',
      stringsAsFactors=FALSE)
  }
  answer <- if(length(results)) do.call(rbind,results) else data.frame()
  if(nrow(answer)) {
    # One family per study, mode and method across ALL targets and pathways.
    # The global family additionally covers all eligible studies and modes.
    answer <- .scan_group_bh(answer,'pvalue',c('project_id','analysis_mode','method'))
    answer$strict_support <- answer$evaluable %in% TRUE &
      answer$family_fdr<=.05 & answer$global_fdr<=.05 &
      (is.na(answer$overlap_count) | answer$overlap_count>=minimum_overlap)
  }
  .p2c_progress('enrichment','Study-specific pathways tested',nrow(keys),nrow(keys),'study\u2013target analyses')
  list(ranked=answer,audit=if(length(audits))do.call(rbind,audits) else data.frame())
}

.p2c_study_pathway_heatmaps <- function(enrichment,directory,maximum_terms) {
  d <- enrichment$studies$ranked
  if(!is.data.frame(d)||!nrow(d))return(character())
  files <- character()
  for(mode in unique(d$analysis_mode))for(method in unique(d$method)) {
    x <- d[d$analysis_mode==mode & d$method==method,,drop=FALSE]
    x$row_id <- paste(x$database,x$ontology,x$set_id,sep='::')
    x$row_label <- paste0(x$set_name,' [',x$database,']')
    x$column_id <- paste(x$project_id,x$target,sep='::')
    x$column_label <- paste0(x$target,' (',x$project_id,')')
    x$q <- x$global_fdr
    x$value <- if(method=='fgsea')x$enrichment_score else
      sign(x$enrichment_score)*pmin(12,-log10(pmax(x$global_fdr,1e-12)))
    invalid <- !x$evaluable | !is.finite(x$pvalue) | !is.finite(x$q)
    x$value[invalid] <- x$q[invalid] <- x$pvalue[invalid] <- NA_real_
    x$k <- 1
    files <- c(files,.p2c_table_heatmap(x,directory,
      paste0('study_pathway_enrichment_',method,'_',mode),
      paste0('Pathway enrichment \u00b7 individual studies \u00b7 ',mode,' \u00b7 ',method),
      if(method=='fgsea')'Normalized enrichment score (NES)' else 'CAMERA direction \u00d7 \u2212log10 adjusted P',
      'pathways',
      'Original study-enrichment global BH FDR across all tested pathways, targets, studies and modes in this enrichment run, separately from pooled tests. Family FDR spans all targets and pathways within study/mode/method. Display selection never recalculates P values. Individual-study evidence is not a pooled estimate.',
      maximum_terms))
  }
  files
}
