# A separate pathway-activity correlation family. Target genes never contribute to activity.
.p2c_set_key <- function(x)paste(x$database,x$ontology,x$set_id,sep='::')
.p2c_activity_matrix <- function(expression,membership,exclude=character(),minimum_members=3,minimum_fraction=.5){
  if(length(minimum_members)!=1L || !is.finite(minimum_members) || minimum_members<2 || minimum_members!=as.integer(minimum_members))stop('Minimum pathway members must be an integer of at least two.')
  if(length(minimum_fraction)!=1L || !is.finite(minimum_fraction) || minimum_fraction<0 || minimum_fraction>1)stop('Pathway coverage must be between zero and one.')
  membership <- .as_membership(membership)
  sets <- split(membership,.p2c_set_key(membership));rows <- list();audit <- list()
  genes <- rownames(expression);sds <- apply(expression,1,stats::sd,na.rm=TRUE)
  usable <- genes[is.finite(sds)&sds>0]
  for(key in names(sets)){
    term <- sets[[key]];requested <- unique(term$gene_id)
    effective <- setdiff(requested,exclude);matched <- intersect(effective,usable)
    fraction <- if(length(effective))length(matched)/length(effective) else 0
    status <- if(length(matched)<minimum_members)'too_few_usable_members' else if(fraction<minimum_fraction)'insufficient_member_coverage' else 'ok'
    audit[[key]] <- data.frame(pathway_id=key,set_name=term$set_name[1],requested_members=length(requested),target_members_excluded=length(intersect(requested,exclude)),usable_members=length(matched),coverage_fraction=fraction,status=status,usable_gene_ids=paste(matched,collapse=';'),stringsAsFactors=FALSE)
    if(status!='ok')next
    z <- expression[matched,,drop=FALSE];z <- (z-rowMeans(z,na.rm=TRUE))/sds[matched]
    score <- colMeans(z,na.rm=TRUE)
    score[colSums(is.finite(z))<max(minimum_members,ceiling(minimum_fraction*length(matched)))] <- NA_real_
    rows[[key]] <- score
  }
  answer <- if(length(rows))do.call(rbind,rows) else matrix(numeric(),0,ncol(expression))
  colnames(answer) <- colnames(expression)
  attr(answer,'audit') <- if(length(audit))do.call(rbind,audit) else data.frame()
  answer
}

.p2c_custom_activity <- function(analysis,membership,minimum_members=3,minimum_fraction=.5){
  if(analysis$mode!='correlation' || is.null(analysis$normalized_expression))return(analysis)
  exclude <- unique(trimws(unlist(strsplit(paste(analysis$target_qc$usable_gene_ids,collapse=';'),';'))))
  scores <- .p2c_activity_matrix(analysis$normalized_expression,membership,exclude,minimum_members,minimum_fraction)
  analysis$pathway_activity_audit <- attr(scores,'audit')
  analysis$pathway_activity_method <- 'Mean within-study gene z-scores after expression filtering; all target members excluded. At least the requested member count and coverage are required for each score.'
  if(!nrow(scores))return(analysis)
  covariates <- .custom_covariate_design(analysis$metadata,analysis$config$adjust_for)
  if(!is.null(covariates$design)){
    scores <- t(vapply(seq_len(nrow(scores)),function(i).scan_residualize(scores[i,],covariates$design)$values,numeric(ncol(scores))))
    rownames(scores) <- analysis$pathway_activity_audit$pathway_id[analysis$pathway_activity_audit$status=='ok']
  }
  results <- list()
  for(target in unique(analysis$target_scores$target)){
    t <- analysis$target_scores[analysis$target_scores$target==target,,drop=FALSE]
    t <- t[match(colnames(analysis$normalized_expression),t$sample_id),,drop=FALSE]
    fit <- .scan_correlate_rows(scores,t$analyzed_score,analysis$config$correlation,analysis$config$min_samples)
    results[[target]] <- data.frame(target=target,gene_id=rownames(scores),rho=fit$rho,pvalue=fit$pvalue,pairwise_samples=fit$n,stringsAsFactors=FALSE)
  }
  d <- do.call(rbind,results);d$fdr <- NA_real_;valid <- is.finite(d$pvalue)
  d$fdr[valid] <- stats::p.adjust(d$pvalue[valid],'BH')
  labels <- unique(membership[c('database','ontology','set_id','set_name')]);labels$gene_id <- .p2c_set_key(labels)
  analysis$pathway_results <- merge(d,labels,by='gene_id',all.x=TRUE,sort=FALSE)
  analysis
}

.p2c_combine_pathways <- function(base,custom=NULL,mode='append',universe=NULL){
  if(!mode%in%c('append','custom'))stop('Choose built-in plus custom pathways or custom only.')
  primary <- if(mode=='custom') .empty_membership() else .as_membership(base)
  if(!is.null(custom)){
    extra <- .as_membership(.scan_read_membership(custom))
    primary <- unique(rbind(primary,extra))
  }
  if(!nrow(primary))stop('No pathway membership was supplied.')
  if(is.list(base)&&!is.data.frame(base)&&mode=='append'){
    base$membership <- primary;return(base)
  }
  primary
}

.p2c_membership_audit <- function(membership,universe,minimum_size=5){
  membership <- .as_membership(membership)
  rows <- lapply(split(membership,.p2c_set_key(membership)),function(term){
    submitted <- unique(term$gene_id);matched <- intersect(submitted,universe)
    data.frame(pathway_id=.p2c_set_key(term)[1],set_name=term$set_name[1],
      submitted_members=length(submitted),measured_members=length(matched),
      status=if(length(matched)<minimum_size)'below_minimum_measured_size' else 'size_eligible',
      unmatched_gene_ids=paste(setdiff(submitted,universe),collapse=';'),stringsAsFactors=FALSE)
  })
  if(length(rows))do.call(rbind,rows) else data.frame()
}

.p2c_write_activity_audit <- function(analysis,directory){
  if(is.data.frame(analysis$pathway_membership_audit)) .scan_write_csv(analysis$pathway_membership_audit,file.path(directory,'pathway_enrichment_membership_audit.csv'))
  if(is.data.frame(analysis$pathway_activity_audit)) .scan_write_csv(analysis$pathway_activity_audit,file.path(directory,'pathway_activity_membership_audit.csv'))
  if(is.data.frame(analysis$pathway_results)) .scan_write_csv(analysis$pathway_results,file.path(directory,'pathway_activity_correlations.csv'))
  if(is.data.frame(analysis$pathway_meta_analysis)) .scan_write_csv(analysis$pathway_meta_analysis,file.path(directory,'pathway_activity_meta_analysis.csv'))
  if(is.data.frame(analysis$pathway_project_correlations)) .scan_write_csv(analysis$pathway_project_correlations,file.path(directory,'pathway_activity_project_correlations.csv.gz'))
  if(!is.null(analysis$pathway_activity_method))writeLines(analysis$pathway_activity_method,file.path(directory,'pathway_activity_method.txt'))
}
