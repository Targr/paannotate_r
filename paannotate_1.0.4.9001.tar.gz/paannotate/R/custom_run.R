.custom_source <- function(x) {
  if (is.character(x) && length(x) == 1L) {
    return(normalizePath(path.expand(x), winslash = "/", mustWork = TRUE))
  }
  if (is.matrix(x)) "in-memory matrix" else "in-memory table"
}

.custom_numeric_samples <- function(data, sample_columns = NULL) {
  if (!is.null(sample_columns)) {
    sample_columns <- unique(as.character(sample_columns))
    missing <- setdiff(sample_columns, names(data))
    if (length(missing)) stop("Sample columns were not found: ",
                              paste(missing, collapse = ", "), call. = FALSE)
    return(sample_columns)
  }
  normalized <- gsub("[^a-z0-9]", "", tolower(names(data)))
  reserved <- c(
    "geneid", "gene", "locus", "locustag", "genename", "symbol",
    "description", "product", "proteinname", "length", "genelength",
    "log2foldchange", "log2fc", "logfc", "foldchange", "pvalue", "pval",
    "padj", "fdr", "qvalue", "stat", "score", "waldstatistic", "basemean"
  )
  candidates <- names(data)[!normalized %in% reserved]
  candidates[vapply(candidates, function(column) {
    original <- data[[column]]
    converted <- suppressWarnings(as.numeric(original))
    nonblank <- !is.na(original) & nzchar(trimws(as.character(original)))
    !any(nonblank & !is.finite(converted)) && sum(is.finite(converted)) >= 2L
  }, logical(1))]
}

.custom_import_expression <- function(
    data, metadata = NULL, sample_id_col = "auto", sample_columns = NULL,
    gene_id_col = "auto", orientation = "auto", expression_format = "auto",
    expression_sample_col = "auto", expression_value_col = "auto",
    sheet = 1, metadata_sheet = 1, id_policy = "pao1_exact") {
  source <- .custom_source(data)
  imported <- data
  if (!is.matrix(data)) {
    imported <- if (inherits(data, "pa_input")) data else
      pa_read(data, orientation = orientation, gene_id = gene_id_col, sheet = sheet)
  }
  if (is.null(metadata)) {
    if (is.matrix(imported)) {
      matrix_value <- imported
      if (identical(orientation, "genes_in_columns") ||
          (identical(orientation, "auto") &&
             sum(.looks_like_locus(colnames(matrix_value))) >
             sum(.looks_like_locus(rownames(matrix_value))))) {
        matrix_value <- t(matrix_value)
      }
      samples <- colnames(matrix_value)
      if (is.null(samples) || !length(samples)) {
        stop("An expression matrix needs sample names on its columns.", call. = FALSE)
      }
      imported <- matrix_value
    } else {
      samples <- .custom_numeric_samples(imported$data, sample_columns)
      if (length(samples) < 2L) {
        stop("Could not safely identify expression sample columns; supply metadata or sample_columns.",
             call. = FALSE)
      }
    }
    metadata_table <- data.frame(.custom_sample_id = samples,
                                 stringsAsFactors = FALSE)
    sid <- ".custom_sample_id"
  } else {
    metadata_table <- .scan_read_metadata(metadata, metadata_sheet)
    sid <- .scan_match_column(
      metadata_table, sample_id_col,
      c("sample_id", "biosample_id", "sample", "sample_name", "library_id", "run"),
      "sample ID"
    )
    metadata_table[[sid]] <- trimws(as.character(metadata_table[[sid]]))
    if (anyNA(metadata_table[[sid]]) || any(!nzchar(metadata_table[[sid]]))) {
      stop("Metadata contains blank sample IDs.", call. = FALSE)
    }
    if (anyDuplicated(metadata_table[[sid]])) {
      stop("Metadata sample IDs must be unique.", call. = FALSE)
    }
    if (!is.null(sample_columns)) {
      metadata_table <- metadata_table[metadata_table[[sid]] %in% sample_columns,
                                       , drop = FALSE]
    }
  }
  prepared <- .scan_prepare_expression(
    imported, metadata_table, sid, gene_id_col = gene_id_col,
    orientation = orientation, expression_format = expression_format,
    expression_sample_col = expression_sample_col,
    expression_value_col = expression_value_col, data_type = "standardized",
    id_policy = id_policy, sheet = sheet
  )
  list(
    matrix = prepared$matrix, metadata = prepared$metadata,
    sample_id_col = sid, source = source,
    invalid_gene_ids = prepared$invalid_gene_ids,
    unmatched_metadata_samples = prepared$unmatched_metadata_samples,
    unmatched_expression_samples = prepared$unmatched_expression_samples,
    gene_metadata = prepared$gene_metadata,
    gene_identifier_audit = prepared$gene_identifier_audit
  )
}

.custom_infer_data_type <- function(matrix_value, requested) {
  requested <- match.arg(requested, c(
    "auto", "raw_counts", "tpm_cpm", "normalized_log", "standardized"
  ))
  if (requested != "auto") {
    return(list(value = requested, confidence = "user supplied",
                reason = "data_type was set explicitly"))
  }
  finite <- matrix_value[is.finite(matrix_value)]
  if (!length(finite)) stop("Expression contains no finite values.", call. = FALSE)
  if (any(finite < 0)) {
    return(list(value = "normalized_log", confidence = "high",
                reason = "negative values rule out raw counts, TPM, and CPM"))
  }
  integer_fraction <- mean(abs(finite - round(finite)) < 1e-8)
  library_sizes <- colSums(matrix_value, na.rm = TRUE)
  if (integer_fraction >= 0.98 && max(finite) >= 20 &&
      stats::median(library_sizes) >= 1000) {
    return(list(value = "raw_counts", confidence = "medium",
                reason = "values are nonnegative integers with count-sized library totals"))
  }
  list(value = "tpm_cpm", confidence = "low",
       reason = paste0(
         "nonnegative non-count values were treated as TPM/CPM; set data_type=", 
         "'normalized_log' if the file is already log transformed"
       ))
}

.custom_normalize <- function(matrix_value, data_type, minimum_cpm = 1) {
  if (any(!is.finite(matrix_value))) {
    if (data_type == "raw_counts") {
      stop("Raw counts cannot contain missing or infinite values.", call. = FALSE)
    }
  }
  if (data_type == "raw_counts") {
    if (!requireNamespace("edgeR", quietly = TRUE)) {
      stop("Raw-count analysis requires edgeR; install it with BiocManager::install('edgeR').",
           call. = FALSE)
    }
    if (any(matrix_value < 0, na.rm = TRUE) ||
        any(abs(matrix_value - round(matrix_value)) > 1e-8, na.rm = TRUE)) {
      stop("raw_counts must contain nonnegative whole numbers.", call. = FALSE)
    }
    dge <- edgeR::DGEList(counts = matrix_value)
    dge <- edgeR::calcNormFactors(dge, method = "TMM")
    cpm <- edgeR::cpm(dge, log = FALSE)
    normalized <- edgeR::cpm(dge, log = TRUE, prior.count = 2)
    minimum_detected <- max(2L, ceiling(ncol(matrix_value) * 0.20))
    keep <- rowSums(cpm >= minimum_cpm, na.rm = TRUE) >= minimum_detected
    method <- "edgeR TMM normalization followed by log2 CPM"
  } else if (data_type == "tpm_cpm") {
    if (any(matrix_value < 0, na.rm = TRUE)) {
      stop("TPM/CPM values cannot be negative.", call. = FALSE)
    }
    normalized <- log2(matrix_value + 1)
    keep <- rowSums(is.finite(normalized)) >= 2L
    method <- "log2(value + 1)"
  } else {
    normalized <- matrix_value
    keep <- rowSums(is.finite(normalized)) >= 2L
    method <- if (data_type == "standardized") "input standardized values" else
      "input normalized log-expression values"
  }
  variable <- apply(normalized, 1, function(value) {
    observed <- stats::sd(value, na.rm = TRUE)
    is.finite(observed) && observed > 0
  })
  keep <- keep & variable
  if (!any(keep)) stop("No expressed, variable genes remain after input checks.",
                       call. = FALSE)
  list(matrix = normalized[keep, , drop = FALSE], keep = keep,
       method = method)
}

.custom_targets <- function(targets, id_policy) {
  if (inherits(targets, "pa_targets")) return(targets)
  if (is.list(targets)) {
    return(pa_targets(sets = targets, score_method = "mean_z",
                      id_policy = id_policy))
  }
  if (!is.character(targets) || !length(targets)) {
    stop("targets must contain a gene, a vector of genes, or a named list defining a signature.",
         call. = FALSE)
  }
  pa_targets(individual = targets, score_method = "mean_z", id_policy = id_policy)
}

.custom_match_columns <- function(data, columns, label) {
  if (is.null(columns) || !length(columns)) return(character())
  requested <- unique(as.character(columns))
  matched <- vapply(requested, function(column) {
    hit <- which(tolower(names(data)) == tolower(column))
    if (length(hit) != 1L) stop(label, " column not found: ", column,
                                call. = FALSE)
    names(data)[hit]
  }, character(1))
  unname(matched)
}

.custom_covariate_design <- function(metadata, adjust_for) {
  if (is.null(adjust_for) || !length(adjust_for)) {
    return(list(design = NULL, keep = rep(TRUE, nrow(metadata)), columns = character()))
  }
  columns <- .custom_match_columns(metadata, adjust_for, "Adjustment")
  keep <- stats::complete.cases(metadata[columns])
  if (sum(keep) < 4L) stop("Too few samples have complete adjustment metadata.",
                           call. = FALSE)
  design_data <- metadata[keep, columns, drop = FALSE]
  variable <- vapply(design_data, function(value) length(unique(value)) > 1L,
                     logical(1))
  columns <- columns[variable]
  if (!length(columns)) {
    return(list(design = NULL, keep = keep, columns = character()))
  }
  design <- stats::model.matrix(stats::reformulate(columns), data = design_data)
  if (qr(design)$rank < ncol(design)) {
    stop("The adjustment columns are redundant or perfectly confounded.", call. = FALSE)
  }
  list(design = design, keep = keep, columns = columns)
}

.custom_gene_metadata <- function(prepared, genes, id_policy) {
  value <- prepared$gene_metadata
  if (!is.data.frame(value) || !nrow(value)) return(data.frame(gene_id = genes))
  id <- .scan_clean_id(value$gene_id_original, id_policy)
  value$gene_id <- id
  value <- value[!is.na(value$gene_id) & !duplicated(value$gene_id), , drop = FALSE]
  merge(data.frame(gene_id = genes), value, by = "gene_id", all.x = TRUE,
        sort = FALSE)
}

.custom_correlation_analysis <- function(
    prepared, type_info, targets, min_samples, fdr, rho, adjust_for,
    correlation, id_policy, minimum_cpm) {
  normalized <- .custom_normalize(prepared$matrix, type_info$value, minimum_cpm)
  matrix_value <- normalized$matrix
  metadata <- prepared$metadata
  sid <- prepared$sample_id_col
  covariates <- .custom_covariate_design(metadata, adjust_for)
  metadata <- metadata[covariates$keep, , drop = FALSE]
  matrix_value <- matrix_value[, metadata[[sid]], drop = FALSE]
  design <- covariates$design
  if (ncol(matrix_value) < min_samples) {
    stop("Only ", ncol(matrix_value), " usable samples remain; min_samples is ",
         min_samples, ".", call. = FALSE)
  }
  target_object <- .custom_targets(targets, id_policy)
  target_membership <- target_object$membership
  target_names <- unique(target_membership$target)
  missing <- setdiff(unique(target_membership$gene_id), rownames(matrix_value))
  target_qc <- list(); scores <- list(); results <- list()
  all_target_genes <- unique(target_membership$gene_id)
  candidates <- setdiff(rownames(matrix_value), all_target_genes)
  if (!length(candidates)) stop("No non-target genes remain to test.", call. = FALSE)
  gene_matrix <- matrix_value[candidates, , drop = FALSE]
  adjusted_genes <- NULL
  if (!is.null(design)) {
    adjusted_genes <- t(vapply(seq_len(nrow(gene_matrix)), function(i) {
      .scan_residualize(gene_matrix[i, ], design)$values
    }, numeric(ncol(gene_matrix))))
    dimnames(adjusted_genes) <- dimnames(gene_matrix)
  }
  for (i in seq_along(target_names)) {
    target <- target_names[i]
    membership <- target_membership[target_membership$target == target, , drop = FALSE]
    scored <- .scan_target_score(
      matrix_value, membership, target_object$score_method,
      minimum_members = 1, minimum_fraction = 0.5,
      minimum_coherence = -Inf, minimum_score_sd = 0
    )
    target_qc[[i]] <- data.frame(
      target = target, requested_members = length(unique(membership$gene_id)),
      matched_members = length(scored$matched), usable_members = length(scored$usable),
      matched_gene_ids = paste(scored$matched, collapse = "; "),
      usable_gene_ids = paste(scored$usable, collapse = "; "),
      coverage_fraction = scored$coverage, status = scored$status,
      stringsAsFactors = FALSE
    )
    if (scored$status != "ok") next
    score <- scored$score
    tested_genes <- gene_matrix
    if (!is.null(design)) {
      score <- .scan_residualize(score, design)$values
      tested_genes <- adjusted_genes
    }
    statistics <- .scan_correlate_rows(
      tested_genes, score, correlation, min_samples
    )
    statistic <- statistics$rho * sqrt(
      pmax(0, statistics$n - 2) / pmax(1e-12, 1 - statistics$rho^2)
    )
    adjusted <- rep(NA_real_, length(statistics$pvalue))
    valid <- is.finite(statistics$pvalue)
    if (any(valid)) adjusted[valid] <- stats::p.adjust(statistics$pvalue[valid], "BH")
    selected <- is.finite(adjusted) & adjusted <= fdr &
      is.finite(statistics$rho) & abs(statistics$rho) >= rho
    results[[i]] <- data.frame(
      target = target, gene_id = candidates, effect_type = "correlation_rho",
      effect = statistics$rho, rho = statistics$rho,
      log2FoldChange = NA_real_, statistic = statistic,
      pvalue = statistics$pvalue, fdr = adjusted,
      pairwise_samples = statistics$n, selected = selected,
      direction = ifelse(statistics$rho >= 0, "Positive", "Negative"),
      stringsAsFactors = FALSE
    )
    scores[[i]] <- data.frame(
      sample_id = metadata[[sid]], target = target, target_score = scored$score,
      analyzed_score = score, stringsAsFactors = FALSE
    )
  }
  target_qc <- do.call(rbind, target_qc)
  if (!length(results)) {
    stop("No target could be analyzed: ",
         paste(paste0(target_qc$target, " (", target_qc$status, ")"), collapse = "; "),
         call. = FALSE)
  }
  gene_results <- do.call(rbind, results)
  rownames(gene_results) <- NULL
  sample_audit <- data.frame(
    sample_id = prepared$metadata[[sid]],
    included = prepared$metadata[[sid]] %in% metadata[[sid]],
    reason = ifelse(prepared$metadata[[sid]] %in% metadata[[sid]], "included",
                    "missing adjustment metadata"), stringsAsFactors = FALSE
  )
  structure(list(
    mode = "correlation", gene_results = gene_results,
    selected_genes = gene_results[gene_results$selected %in% TRUE, , drop = FALSE],
    normalized_expression = matrix_value, metadata = metadata,
    sample_audit = sample_audit, target_qc = target_qc,
    target_scores = if (length(scores)) do.call(rbind, scores) else data.frame(),
    sample_count = ncol(matrix_value), candidate_genes = candidates,
    gene_metadata = .custom_gene_metadata(
      prepared, unique(gene_results$gene_id), id_policy
    ),
    config = list(
      source = prepared$source, data_type = type_info$value,
      data_type_confidence = type_info$confidence,
      data_type_reason = type_info$reason, normalization = normalized$method,
      question = "genes associated with target expression",
      correlation = correlation, fdr = fdr, rho = rho,
      adjust_for = covariates$columns, min_samples = min_samples,
      id_policy = id_policy
    ),
    input_audit = prepared[c(
      "invalid_gene_ids", "unmatched_metadata_samples",
      "unmatched_expression_samples", "gene_identifier_audit"
    )]
  ), class = "pa_custom_analysis")
}

.custom_comparison_design <- function(metadata, condition, comparison,
                                      adjust_for, min_samples) {
  condition_column <- .custom_match_columns(metadata, condition, "Condition")
  if (length(condition_column) != 1L) stop("condition must name one metadata column.",
                                           call. = FALSE)
  if (!is.character(comparison) || length(comparison) != 2L || anyNA(comparison) ||
      any(!nzchar(trimws(comparison)))) {
    stop("comparison must contain two values: c(positive, reference).",
         call. = FALSE)
  }
  comparison <- trimws(comparison)
  if (tolower(comparison[1]) == tolower(comparison[2])) {
    stop("The positive and reference comparison values must differ.", call. = FALSE)
  }
  raw <- trimws(as.character(metadata[[condition_column]]))
  role <- ifelse(
    tolower(raw) == tolower(comparison[1]), "positive",
    ifelse(tolower(raw) == tolower(comparison[2]), "reference", "excluded")
  )
  covariate_columns <- .custom_match_columns(metadata, adjust_for, "Adjustment")
  complete <- if (length(covariate_columns)) stats::complete.cases(
    metadata[covariate_columns]
  ) else rep(TRUE, nrow(metadata))
  keep <- role %in% c("positive", "reference") & complete
  group_counts <- table(factor(role[keep], levels = c("positive", "reference")))
  if (sum(keep) < min_samples || any(group_counts < 2L)) {
    stop("The comparison has ", group_counts[["positive"]], " positive and ",
         group_counts[["reference"]], " reference samples after exclusions; ",
         "at least two per group and ", min_samples, " total are required.",
         call. = FALSE)
  }
  design_data <- metadata[keep, , drop = FALSE]
  design_data$.condition <- factor(role[keep], levels = c("reference", "positive"))
  variable <- if (length(covariate_columns)) vapply(
    design_data[covariate_columns], function(value) length(unique(value)) > 1L,
    logical(1)
  ) else logical()
  covariate_columns <- covariate_columns[variable]
  design <- stats::model.matrix(
    stats::reformulate(c(covariate_columns, ".condition")), data = design_data
  )
  if (qr(design)$rank < ncol(design)) {
    stop("The condition is perfectly confounded with an adjustment column.",
         call. = FALSE)
  }
  list(
    keep = keep, role = role, design = design,
    coefficient = match(".conditionpositive", colnames(design)),
    condition = condition_column, positive = comparison[1], reference = comparison[2],
    adjust_for = covariate_columns, group_counts = group_counts,
    complete = complete
  )
}

.custom_comparison_analysis <- function(
    prepared, type_info, condition, comparison, min_samples, fdr, log2fc,
    adjust_for, minimum_cpm, id_policy) {
  metadata <- prepared$metadata
  sid <- prepared$sample_id_col
  design_info <- .custom_comparison_design(
    metadata, condition, comparison, adjust_for, min_samples
  )
  metadata_used <- metadata[design_info$keep, , drop = FALSE]
  raw <- prepared$matrix[, metadata_used[[sid]], drop = FALSE]
  normalized <- .custom_normalize(raw, type_info$value, minimum_cpm)
  coefficient <- design_info$coefficient
  if (!is.finite(coefficient)) stop("Could not construct the requested comparison.",
                                    call. = FALSE)
  if (type_info$value == "raw_counts") {
    dge <- edgeR::DGEList(counts = raw)
    keep_genes <- edgeR::filterByExpr(dge, design = design_info$design,
                                      min.count = minimum_cpm)
    if (!any(keep_genes)) stop("No genes passed the raw-count expression filter.",
                               call. = FALSE)
    dge <- dge[keep_genes, , keep.lib.sizes = FALSE]
    dge <- edgeR::calcNormFactors(dge, method = "TMM")
    dge <- edgeR::estimateDisp(dge, design_info$design)
    fit <- edgeR::glmQLFit(dge, design_info$design, robust = TRUE)
    test <- edgeR::glmQLFTest(fit, coef = coefficient)
    table <- edgeR::topTags(test, n = Inf, sort.by = "none")$table
    genes <- rownames(table)
    effect <- table$logFC
    pvalue <- table$PValue
    statistic <- sign(effect) * sqrt(pmax(0, table$F))
    average <- table$logCPM
    normalized_matrix <- edgeR::cpm(dge, log = TRUE, prior.count = 2)
    method <- "edgeR quasi-likelihood differential expression"
  } else {
    if (!requireNamespace("limma", quietly = TRUE)) {
      stop("Normalized-expression comparison requires limma; install it with BiocManager::install('limma').",
           call. = FALSE)
    }
    normalized_matrix <- normalized$matrix
    fit <- limma::lmFit(normalized_matrix, design_info$design)
    fit <- limma::eBayes(fit, robust = TRUE)
    table <- limma::topTable(fit, coef = coefficient, number = Inf,
                             sort.by = "none")
    genes <- rownames(table)
    effect <- table$logFC
    pvalue <- table$P.Value
    statistic <- table$t
    average <- table$AveExpr
    method <- "limma moderated differential expression"
  }
  adjusted <- stats::p.adjust(pvalue, method = "BH")
  roles <- design_info$role[design_info$keep]
  mean_positive <- rowMeans(normalized_matrix[, roles == "positive", drop = FALSE],
                            na.rm = TRUE)
  mean_reference <- rowMeans(normalized_matrix[, roles == "reference", drop = FALSE],
                             na.rm = TRUE)
  gene_results <- data.frame(
    target = paste0(design_info$positive, "_vs_", design_info$reference),
    gene_id = genes, effect_type = "log2_fold_change",
    effect = effect, rho = NA_real_, log2FoldChange = effect,
    statistic = statistic, pvalue = pvalue, fdr = adjusted,
    mean_positive = mean_positive[genes], mean_reference = mean_reference[genes],
    pairwise_samples = ncol(raw),
    selected = is.finite(adjusted) & adjusted <= fdr &
      is.finite(effect) & abs(effect) >= log2fc,
    direction = ifelse(effect >= 0, "Positive", "Negative"),
    stringsAsFactors = FALSE
  )
  gene_results <- gene_results[order(gene_results$fdr, -abs(gene_results$effect)),
                               , drop = FALSE]
  sample_audit <- data.frame(
    sample_id = metadata[[sid]], metadata_value = metadata[[design_info$condition]],
    comparison_role = design_info$role,
    included = design_info$keep,
    reason = ifelse(
      design_info$keep, "included",
      ifelse(!design_info$complete, "missing adjustment metadata",
             "outside requested comparison")
    ), stringsAsFactors = FALSE
  )
  structure(list(
    mode = "comparison", gene_results = gene_results,
    selected_genes = gene_results[gene_results$selected %in% TRUE, , drop = FALSE],
    normalized_expression = normalized_matrix[genes, , drop = FALSE],
    metadata = metadata_used, sample_audit = sample_audit,
    target_qc = data.frame(), target_scores = data.frame(),
    sample_count = ncol(raw), candidate_genes = genes,
    gene_metadata = .custom_gene_metadata(prepared, genes, id_policy),
    config = list(
      source = prepared$source, data_type = type_info$value,
      data_type_confidence = type_info$confidence,
      data_type_reason = type_info$reason, normalization = normalized$method,
      question = paste0(design_info$positive, " versus ", design_info$reference),
      condition = design_info$condition, positive = design_info$positive,
      reference = design_info$reference, method = method,
      fdr = fdr, log2fc = log2fc, adjust_for = design_info$adjust_for,
      min_samples = min_samples, id_policy = id_policy
    ),
    input_audit = prepared[c(
      "invalid_gene_ids", "unmatched_metadata_samples",
      "unmatched_expression_samples", "gene_identifier_audit"
    )]
  ), class = "pa_custom_analysis")
}

.custom_precomputed_analysis <- function(data, sheet, orientation, gene_id_col,
                                         id_policy, fdr, log2fc) {
  imported <- if (inherits(data, "pa_input")) data else
    pa_read(data, orientation = orientation, gene_id = gene_id_col, sheet = sheet)
  table <- imported$data
  original_ids <- table$gene_id
  ids <- .scan_clean_id(original_ids, id_policy)
  identifier_audit <- .scan_identifier_audit(original_ids, ids, id_policy)
  valid_ids <- !is.na(ids)
  if (any(!valid_ids)) {
    table <- table[valid_ids, , drop = FALSE]
    ids <- ids[valid_ids]
  }
  if (!length(ids)) stop("No valid gene identifiers remain.", call. = FALSE)
  if (anyDuplicated(ids)) stop("Precomputed results contain duplicate gene IDs.",
                               call. = FALSE)
  table$gene_id <- ids
  numeric_column <- function(candidates) {
    hit <- candidates[candidates %in% names(table)][1]
    if (!length(hit) || is.na(hit)) return(rep(NA_real_, nrow(table)))
    suppressWarnings(as.numeric(table[[hit]]))
  }
  effect <- numeric_column(c("log2FoldChange", "effect", "estimate", "rho", "stat", "t", "score"))
  pvalue <- numeric_column(c("pvalue", "PValue", "P.Value", "pval"))
  supplied_fdr <- numeric_column(c("padj", "fdr", "FDR", "qvalue"))
  statistic <- numeric_column(c("stat", "t", "WaldStatistic", "score"))
  if (!any(is.finite(effect)) && any(is.finite(statistic))) effect <- statistic
  if (!any(is.finite(statistic))) {
    statistic <- sign(effect) * -log10(pmax(pvalue, .Machine$double.xmin))
  }
  if (!any(is.finite(statistic))) {
    stop("Precomputed results need a statistic, or an effect plus P-value.",
         call. = FALSE)
  }
  adjusted <- supplied_fdr
  if (!any(is.finite(adjusted)) && any(is.finite(pvalue))) {
    adjusted <- rep(NA_real_, length(pvalue))
    valid <- is.finite(pvalue)
    adjusted[valid] <- stats::p.adjust(pvalue[valid], "BH")
  }
  target <- if ("target" %in% names(table)) as.character(table$target) else
    rep("precomputed_results", nrow(table))
  has_logfc <- "log2FoldChange" %in% names(table)
  selected <- is.finite(adjusted) & adjusted <= fdr &
    (!has_logfc | (is.finite(effect) & abs(effect) >= log2fc))
  gene_results <- data.frame(
    target = target, gene_id = ids,
    effect_type = if (has_logfc) "log2_fold_change" else "supplied_effect",
    effect = effect, rho = if ("rho" %in% names(table)) effect else NA_real_,
    log2FoldChange = if (has_logfc) effect else NA_real_,
    statistic = statistic, pvalue = pvalue, fdr = adjusted,
    pairwise_samples = NA_integer_, selected = selected,
    direction = ifelse(statistic >= 0, "Positive", "Negative"),
    stringsAsFactors = FALSE
  )
  structure(list(
    mode = "results", gene_results = gene_results,
    selected_genes = gene_results[gene_results$selected %in% TRUE, , drop = FALSE],
    normalized_expression = NULL, metadata = NULL, sample_audit = data.frame(),
    target_qc = data.frame(), target_scores = data.frame(),
    sample_count = 1L, candidate_genes = ids,
    gene_metadata = table[c("gene_id", setdiff(names(table), "gene_id"))],
    config = list(
      source = .custom_source(data), data_type = "precomputed_results",
      data_type_confidence = "high",
      data_type_reason = "recognized statistical result columns",
      normalization = "already performed by the source analysis",
      question = "enrichment of supplied gene-level results",
      method = "precomputed", fdr = fdr, log2fc = log2fc,
      id_policy = id_policy
    ),
    input_audit = list(
      invalid_gene_ids = identifier_audit[
        !identifier_audit$valid_under_policy,
        c("gene_id_original", "locus_class", "id_policy"), drop = FALSE
      ],
      unmatched_metadata_samples = character(),
      unmatched_expression_samples = character(),
      gene_identifier_audit = identifier_audit
    )
  ), class = "pa_custom_analysis")
}

.custom_ranked_table <- function(analysis, membership, method,
                                 minimum_size, maximum_size) {
  rows <- list(); failures <- character(); counter <- 0L
  for (target in unique(analysis$gene_results$target)) {
    genes <- analysis$gene_results[
      analysis$gene_results$target == target &
        is.finite(analysis$gene_results$statistic),
      c("gene_id", "statistic"), drop = FALSE
    ]
    if (nrow(genes) < 2L) next
    fit <- tryCatch(
      suppressWarnings(pa_enrich_ranked(
        genes, membership, method = method, gene_id_col = "gene_id",
        statistic_col = "statistic", minimum_size = minimum_size,
        maximum_size = maximum_size
      )),
      error = function(error) {
        failures <<- c(failures, paste0(target, ": ", conditionMessage(error)))
        NULL
      }
    )
    if (is.null(fit) || !nrow(fit$results)) next
    value <- fit$results
    pvalue <- suppressWarnings(as.numeric(
      if ("pval" %in% names(value)) value$pval else value$PValue
    ))
    method_fdr <- suppressWarnings(as.numeric(
      if ("padj" %in% names(value)) value$padj else value$FDR
    ))
    effect <- suppressWarnings(as.numeric(if ("NES" %in% names(value)) value$NES else
      ifelse(tolower(as.character(value$Direction)) == "up", 1, -1)))
    leading <- if ("leadingEdge" %in% names(value)) {
      vapply(value$leadingEdge, function(x) paste(x, collapse = "; "), character(1))
    } else rep("", nrow(value))
    overlap <- if ("leadingEdge" %in% names(value)) lengths(value$leadingEdge) else
      if ("NGenes" %in% names(value)) as.integer(value$NGenes) else NA_integer_
    evaluable <- is.finite(pvalue) & is.finite(method_fdr) & is.finite(effect)
    counter <- counter + 1L
    rows[[counter]] <- data.frame(
      cutoff = analysis$sample_count, target = target,
      direction = ifelse(effect >= 0, "Positive", "Negative"),
      database = value$database, ontology = value$ontology,
      set_id = value$set_id, set_name = value$set_name, method = method,
      rank_mode = "single_dataset", pvalue = pvalue,
      method_fdr = method_fdr, enrichment_score = effect,
      evaluable = evaluable,
      exclusion_reason = ifelse(evaluable, "", "ranked method returned a non-finite result"),
      set_size = if ("size" %in% names(value)) as.integer(value$size) else overlap,
      overlap_count = overlap, leading_edge_genes = leading,
      stringsAsFactors = FALSE
    )
  }
  result <- if (length(rows)) do.call(rbind, rows) else .scan_empty_enrichment()
  if (nrow(result)) result <- .scan_group_bh(
    result, "pvalue", c("cutoff", "target", "method", "database", "ontology")
  )
  list(results = result, failures = failures)
}

.custom_enrich_membership <- function(
    analysis, membership, methods, term_fdr, global_fdr,
    minimum_overlap, minimum_size, maximum_size) {
  selection <- analysis$gene_results[analysis$gene_results$selected %in% TRUE,
                                     , drop = FALSE]
  selection <- data.frame(
    target = selection$target, gene_id = selection$gene_id,
    direction = selection$direction, effect = selection$effect,
    fdr = selection$fdr,
    evidence_class = rep("Selected in this dataset", nrow(selection)),
    stringsAsFactors = FALSE
  )
  ora <- if ("ora" %in% methods) .scan_ora(
    selection, membership, unique(analysis$candidate_genes), analysis$sample_count,
    minimum_overlap, minimum_size, maximum_size
  ) else .scan_empty_enrichment()
  ranked_methods <- setdiff(methods, "ora")
  ranked_pieces <- lapply(ranked_methods, function(method) {
    .custom_ranked_table(analysis, membership, method, minimum_size, maximum_size)
  })
  failures <- unlist(lapply(ranked_pieces, `[[`, "failures"), use.names = FALSE)
  ranked_tables <- lapply(ranked_pieces, `[[`, "results")
  ranked_tables <- Filter(function(x) is.data.frame(x) && nrow(x), ranked_tables)
  ranked <- if (length(ranked_tables)) .focus_rbind(ranked_tables) else
    .scan_empty_enrichment()
  if (nrow(ranked)) {
    ranked <- .scan_group_bh(
      ranked, "pvalue", c("cutoff", "target", "method", "database", "ontology")
    )
    ranked$strict_support <- ranked$evaluable %in% TRUE &
      ranked$family_fdr <= term_fdr & ranked$global_fdr <= global_fdr &
      (is.na(ranked$overlap_count) | ranked$overlap_count >= minimum_overlap)
  }
  if (nrow(ora)) {
    ora$strict_support <- ora$family_fdr <= term_fdr &
      ora$global_fdr <= global_fdr & ora$overlap_count >= minimum_overlap
  }
  list(ora = ora, ranked = ranked, summary = .scan_term_summary(ora, ranked),
       failures = failures)
}

.custom_enrich <- function(
    analysis, annotation_source, methods, curated, themes,
    term_fdr, global_fdr, minimum_overlap, minimum_size, maximum_size) {
  membership <- .as_membership(annotation_source)
  exact <- .custom_enrich_membership(
    analysis, membership, methods, term_fdr, global_fdr,
    minimum_overlap, minimum_size, maximum_size
  )
  if (isTRUE(curated)) {
    theme <- .scan_theme_membership(membership, .scan_read_themes(themes))
    theme_result <- .custom_enrich_membership(
      analysis, theme$membership, methods, term_fdr, global_fdr,
      minimum_overlap, minimum_size, maximum_size
    )
    themes_result <- list(
      dictionary = theme$themes, term_mapping = theme$mapping,
      membership = theme$membership, ora = theme_result$ora,
      ranked = theme_result$ranked, summary = theme_result$summary
    )
    iron <- list(
      exact_terms = .scan_iron_subset(exact$summary),
      themes = if (nrow(theme_result$summary)) {
        focus_lookup <- unique(theme$mapping[c("curated_theme", "focus")])
        value <- merge(theme_result$summary, focus_lookup,
                       by.x = "set_name", by.y = "curated_theme",
                       all.x = TRUE, sort = FALSE)
        value[grepl("^iron", value$focus), , drop = FALSE]
      } else data.frame()
    )
  } else {
    themes_result <- list(
      dictionary = data.frame(), term_mapping = data.frame(),
      membership = .empty_membership(), ora = .scan_empty_enrichment(),
      ranked = .scan_empty_enrichment(), summary = data.frame()
    )
    iron <- list(exact_terms = data.frame(), themes = data.frame())
    theme_result <- list(failures = character())
  }
  annotation_audit <- if (is.list(annotation_source) &&
                          is.data.frame(annotation_source$annotation_audit)) {
    annotation_source$annotation_audit
  } else data.frame()
  membership_evidence <- if (is.list(annotation_source) &&
                             is.data.frame(annotation_source$membership_evidence)) {
    annotation_source$membership_evidence
  } else membership
  structure(list(
    selection = analysis$gene_results[analysis$gene_results$selected %in% TRUE,
                                      , drop = FALSE],
    gene_annotations = .scan_gene_annotations(annotation_source),
    exact = list(membership = membership, membership_evidence = membership_evidence,
                 ora = exact$ora,
                 ranked = exact$ranked, summary = exact$summary),
    themes = themes_result, iron = iron,
    config = list(
      methods = methods, cutoff = analysis$sample_count,
      view = "single_dataset", term_fdr = term_fdr,
      global_fdr = global_fdr, minimum_overlap = minimum_overlap,
      minimum_size = minimum_size, maximum_size = maximum_size,
      curated = isTRUE(curated), annotation_audit = annotation_audit,
      ranked_failures = c(exact$failures, theme_result$failures)
    )
  ), class = "pa_scan_enrichment")
}

.custom_start_here <- function(analysis, enrichment) {
  curated <- !is.null(enrichment) && isTRUE(enrichment$config$curated)
  rows <- list(
    c("Question", analysis$config$question),
    c("Analysis type", switch(
      analysis$mode, correlation = "single-dataset gene correlation",
      comparison = "single-dataset condition comparison",
      results = "precomputed gene results"
    )),
    c("No meta-analysis", "This report analyzes one dataset; it does not calculate I2, cross-project persistence, or cross-cutoff evidence."),
    c("Positive direction", if (analysis$mode == "comparison") {
      paste0("Positive values mean higher in ", analysis$config$positive,
             "; negative values mean higher in ", analysis$config$reference, ".")
    } else "Positive values move with the target or supplied positive statistic; negative values move oppositely."),
    c("Gene selection", paste0("selected=TRUE requires FDR <= ", analysis$config$fdr,
                               if (analysis$mode == "correlation") paste0(" and |rho| >= ", analysis$config$rho) else
                                 if (!is.null(analysis$config$log2fc)) paste0(" and |log2 fold change| >= ", analysis$config$log2fc) else "", ".")),
    c("Canonical pathways", if (is.null(enrichment)) "Not run." else
      "GO, KEGG, PseudoCAP, and supplied database terms are reported exactly as defined by their sources."),
    c("Ranked enrichment", if (is.null(enrichment)) "Not run." else
      "Uses every tested gene, so it can detect coordinated pathways even when few individual genes pass FDR."),
    c("Curated pathways", if (curated) "Explicitly requested and written separately." else
      "Not requested; only canonical terms are shown."),
    c("Missing cells", "Blank heatmap cells mean that no finite result was available for that target and pathway; they are not zeros.")
  )
  data.frame(section = vapply(rows, `[[`, character(1), 1),
             explanation = vapply(rows, `[[`, character(1), 2),
             stringsAsFactors = FALSE)
}

.custom_term_key <- function(data) {
  if (!is.data.frame(data) || !nrow(data)) return(character())
  required <- c("database", "ontology", "set_id", "set_name")
  if (length(setdiff(required, names(data)))) return(character())
  do.call(paste, c(data[required], sep = "\r"))
}

.custom_term_subset <- function(enrichment, data, custom = FALSE) {
  if (!is.data.frame(data) || !nrow(data)) return(data)
  keys <- enrichment$config$custom_pathway_keys
  is_custom <- if (length(keys)) .custom_term_key(data) %in% keys else
    rep(FALSE, nrow(data))
  data[if (isTRUE(custom)) is_custom else !is_custom, , drop = FALSE]
}

.custom_gene_matrix <- function(analysis, maximum_genes) {
  data <- analysis$gene_results
  valid <- is.finite(data$effect)
  data <- data[valid, , drop = FALSE]
  if (!nrow(data)) return(NULL)
  best <- tapply(abs(data$statistic), data$gene_id, max, na.rm = TRUE)
  genes <- names(sort(best, decreasing = TRUE))[seq_len(min(maximum_genes, length(best)))]
  targets <- unique(data$target)
  result <- matrix(NA_real_, length(genes), length(targets),
                   dimnames = list(genes, targets))
  for (i in seq_len(nrow(data))) {
    if (data$gene_id[i] %in% genes) result[data$gene_id[i], data$target[i]] <- data$effect[i]
  }
  attr(result,"statistic") <- if(analysis$mode=="correlation")"Correlation (rho)" else "Comparison effect (log2 scale)"
  result
}

.custom_write_workbook <- function(analysis, enrichment, path, maximum_rows) {
  if (!requireNamespace("openxlsx", quietly = TRUE)) return(NULL)
  workbook <- openxlsx::createWorkbook(creator = "paannotate")
  used <- character()
  add <- function(name, value) {
    info <- .scan_add_sheet(workbook, name, value, used, maximum_rows)
    used <<- c(used, info$name)
  }
  add("START_HERE", .custom_start_here(analysis, enrichment))
  add("Selected_genes", analysis$selected_genes)
  add("All_gene_results", analysis$gene_results)
  add("Sample_audit", analysis$sample_audit)
  if (nrow(analysis$target_qc)) add("Target_QC", analysis$target_qc)
  if (!is.null(enrichment)) {
    add("Canonical_summary", .custom_term_subset(
      enrichment, enrichment$exact$summary
    ))
    add("Canonical_ranked", .custom_term_subset(
      enrichment, enrichment$exact$ranked
    ))
    add("Canonical_ORA", .custom_term_subset(
      enrichment, enrichment$exact$ora
    ))
    if (length(enrichment$config$custom_pathway_keys)) {
      add("Custom_summary", .custom_term_subset(
        enrichment, enrichment$exact$summary, custom = TRUE
      ))
      add("Custom_ranked", .custom_term_subset(
        enrichment, enrichment$exact$ranked, custom = TRUE
      ))
      add("Custom_ORA", .custom_term_subset(
        enrichment, enrichment$exact$ora, custom = TRUE
      ))
    }
    if (.scan_has_curated(enrichment)) add("Curated_themes", enrichment$themes$summary)
  }
  openxlsx::saveWorkbook(workbook, path, overwrite = TRUE)
  path
}

.custom_base_plot <- function(analysis, base_path) {
  data <- analysis$gene_results
  keep <- is.finite(data$effect) & is.finite(data$pvalue) & data$pvalue >= 0
  data <- data[keep, , drop = FALSE]
  if (!nrow(data)) return(character())
  files <- paste0(base_path, c(".png", ".pdf"))
  for (file in files) {
    if (grepl("[.]png$", file)) grDevices::png(file, width = 1800, height = 1200,
                                               res = 180) else
      grDevices::pdf(file, width = 10, height = 7)
    tryCatch({
      color <- ifelse(data$selected %in% TRUE, "#B2182B", "#BDBDBD")
      graphics::plot(
        data$effect, -log10(pmax(data$pvalue, .Machine$double.xmin)),
        pch = 16, col = color, cex = 0.65,
        xlab = if (analysis$mode == "correlation") "Correlation (rho)" else
          "Effect (positive versus reference)",
        ylab = "-log10(P-value)", main = "Single-dataset gene results"
      )
      graphics::abline(v = 0, col = "#666666", lty = 2)
    }, finally = grDevices::dev.off())
  }
  files[file.exists(files)]
}

.custom_write_figures <- function(analysis, enrichment, directory,
                                  maximum_genes, maximum_terms) {
  dir.create(directory, recursive = TRUE, showWarnings = FALSE)
  rows <- list(); counter <- 0L; files <- character()
  record <- function(artifact, status, reason = "", made = character()) {
    counter <<- counter + 1L
    rows[[counter]] <<- data.frame(
      artifact = artifact, status = status, reason = reason,
      files = paste(basename(made), collapse = "; "), stringsAsFactors = FALSE
    )
  }
  plot_files <- .custom_base_plot(analysis, file.path(directory, "gene_results"))
  files <- c(files, plot_files)
  record("gene_results_plot", if (length(plot_files)) "created" else "no_results",
         made = plot_files)
  render <- function(name, matrix_value, title, limit = NULL) {
    if (is.null(matrix_value) || !length(matrix_value) || !nrow(matrix_value) ||
        !ncol(matrix_value)) return(record(name, "no_results", "No finite values"))
    made <- tryCatch(
      .scan_render_heatmap(matrix_value, file.path(directory, name), title, limit),
      error = function(error) {
        record(name, "failed", conditionMessage(error)); character()
      }
    )
    if (length(made)) {
      files <<- c(files, made); record(name, "created", made = made)
    } else if (!any(vapply(rows, function(x) x$artifact == name, logical(1)))) {
      record(name, "skipped", "pheatmap is unavailable")
    }
  }
  files <- c(files, .p2c_result_heatmaps(analysis, enrichment, directory, maximum_genes, maximum_terms))
  limit <- if (analysis$mode == "correlation") 1 else NULL
  render("gene_effect_heatmap", .custom_gene_matrix(analysis, maximum_genes),
         "Strongest single-dataset gene effects", limit)
  if (!is.null(enrichment)) {
    canonical_summary <- .custom_term_subset(
      enrichment, enrichment$exact$summary
    )
    canonical_ranked <- .custom_term_subset(
      enrichment, enrichment$exact$ranked
    )
    render("canonical_pathway_heatmap",
           .scan_summary_matrix(canonical_summary, maximum_terms),
           "Canonical GO, KEGG, and database pathways")
    ranked_files <- tryCatch(.focus_dotplot(
      canonical_ranked, "enrichment_score", "overlap_count",
      file.path(directory, "canonical_ranked_dotplot"),
      "Canonical ranked enrichment",
      "Enrichment score (negative = inverse; positive = direct)", maximum_terms
    ), error = function(error) character())
    files <- c(files, ranked_files)
    record("canonical_ranked_dotplot",
           if (length(ranked_files)) "created" else "no_results", made = ranked_files)
    if (length(enrichment$config$custom_pathway_keys)) {
      render("custom_pathway_heatmap", .scan_summary_matrix(
        .custom_term_subset(enrichment, enrichment$exact$summary, custom = TRUE),
        maximum_terms
      ), "User-supplied custom pathways")
    }
    if (.scan_has_curated(enrichment)) {
      render("curated_pathway_heatmap",
             .scan_summary_matrix(enrichment$themes$summary, maximum_terms),
             "Optional paannotate curated umbrella pathways")
    }
  }
  status <- if (length(rows)) do.call(rbind, rows) else data.frame()
  .scan_write_csv(status, file.path(directory, "figure_status.csv"))
  unique(files[file.exists(files)])
}

.custom_write_report <- function(
    analysis, enrichment, output_dir, workbook, heatmaps,
    maximum_excel_rows, maximum_heatmap_genes, maximum_heatmap_terms) {
  output_dir <- path.expand(output_dir)
  dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
  input_dir <- file.path(output_dir, "01_input_and_qc")
  gene_dir <- file.path(output_dir, "02_gene_results")
  canonical_dir <- file.path(output_dir, "03_canonical_enrichment")
  figure_dir <- file.path(output_dir, "04_figures")
  for (directory in c(input_dir, gene_dir)) {
    dir.create(directory, recursive = TRUE, showWarnings = FALSE)
  }
  start <- .custom_start_here(analysis, enrichment)
  .scan_write_csv(start, file.path(output_dir, "START_HERE.csv"))
  .scan_write_lines(c(
    "paannotate single-dataset report", "",
    paste(start$section, start$explanation, sep = ": ")
  ), file.path(output_dir, "README.txt"))
  .scan_write_csv(analysis$sample_audit, file.path(input_dir, "sample_audit.csv"))
  .scan_write_csv(analysis$target_qc, file.path(input_dir, "target_qc.csv"))
  .scan_write_csv(analysis$input_audit$invalid_gene_ids,
                  file.path(input_dir, "invalid_gene_ids.csv"))
  .scan_write_csv(analysis$input_audit$gene_identifier_audit,
                  file.path(input_dir, "gene_identifier_audit.csv"))
  .scan_write_lines(utils::capture.output(dput(analysis$config)),
                    file.path(input_dir, "analysis_config.R"))
  .scan_write_csv(analysis$gene_results,
                  file.path(gene_dir, "all_gene_results.csv.gz"))
  .scan_write_csv(analysis$selected_genes,
                  file.path(gene_dir, "selected_genes.csv"))
  if (nrow(analysis$target_scores)) {
    .scan_write_csv(analysis$target_scores,
                    file.path(gene_dir, "target_scores.csv.gz"))
  }
  .p2c_write_activity_audit(analysis,output_dir)
  saveRDS(analysis, file.path(output_dir, "analysis_checkpoint.rds"), compress = "xz")
  if (!is.null(enrichment)) {
    dir.create(canonical_dir, recursive = TRUE, showWarnings = FALSE)
    .scan_write_csv(.custom_term_subset(enrichment, enrichment$exact$summary),
                    file.path(canonical_dir, "canonical_summary.csv"))
    .scan_write_csv(.custom_term_subset(enrichment, enrichment$exact$ranked),
                    file.path(canonical_dir, "canonical_ranked.csv.gz"))
    .scan_write_csv(.custom_term_subset(enrichment, enrichment$exact$ora),
                    file.path(canonical_dir, "canonical_ora.csv"))
    .scan_write_csv(enrichment$gene_annotations,
                    file.path(canonical_dir, "gene_annotations.csv.gz"))
    .scan_write_csv(enrichment$exact$membership_evidence,
                    file.path(canonical_dir, "membership_evidence.csv.gz"))
    .scan_write_csv(enrichment$config$annotation_audit,
                    file.path(input_dir, "annotation_provider_audit.csv"))
    if (.scan_has_curated(enrichment)) {
      curated_dir <- file.path(output_dir, "06_curated_pathways")
      dir.create(curated_dir, recursive = TRUE, showWarnings = FALSE)
      .scan_write_csv(enrichment$themes$summary,
                      file.path(curated_dir, "curated_summary.csv"))
      .scan_write_csv(enrichment$themes$ranked,
                      file.path(curated_dir, "curated_ranked.csv.gz"))
      .scan_write_csv(enrichment$themes$ora,
                      file.path(curated_dir, "curated_ora.csv"))
      .scan_write_csv(enrichment$themes$term_mapping,
                      file.path(curated_dir, "canonical_to_curated_mapping.csv.gz"))
    }
    custom_keys <- enrichment$config$custom_pathway_keys
    if (length(custom_keys)) {
      custom_dir <- file.path(output_dir, "05_custom_pathways")
      dir.create(custom_dir, recursive = TRUE, showWarnings = FALSE)
      .scan_write_csv(
        .custom_term_subset(enrichment, enrichment$exact$summary, custom = TRUE),
        file.path(custom_dir, "custom_summary.csv")
      )
      .scan_write_csv(
        .custom_term_subset(enrichment, enrichment$exact$ranked, custom = TRUE),
        file.path(custom_dir, "custom_ranked.csv.gz")
      )
      .scan_write_csv(
        .custom_term_subset(enrichment, enrichment$exact$ora, custom = TRUE),
        file.path(custom_dir, "custom_ora.csv")
      )
    }
    saveRDS(enrichment, file.path(output_dir, "enrichment_checkpoint.rds"),
            compress = "xz")
  }
  files <- c(report_directory = normalizePath(output_dir, winslash = "/"))
  if (isTRUE(workbook)) {
    made <- .custom_write_workbook(
      analysis, enrichment, file.path(output_dir, "paannotate_custom_report.xlsx"),
      maximum_excel_rows
    )
    if (!is.null(made)) files <- c(files, workbook = made)
  }
  if (isTRUE(heatmaps)) {
    made <- .custom_write_figures(
      analysis, enrichment, figure_dir, maximum_heatmap_genes,
      maximum_heatmap_terms
    )
    if (length(made)) files <- c(files, figures = made)
  }
  files
}

.custom_attach_annotations <- function(analysis, enrichment) {
  if (is.null(enrichment) || !nrow(enrichment$gene_annotations)) return(analysis)
  order_key <- seq_len(nrow(analysis$gene_results))
  analysis$gene_results$.custom_order <- order_key
  analysis$gene_results <- merge(
    analysis$gene_results, enrichment$gene_annotations,
    by = "gene_id", all.x = TRUE, sort = FALSE
  )
  analysis$gene_results <- analysis$gene_results[
    order(analysis$gene_results$.custom_order), , drop = FALSE
  ]
  analysis$gene_results$.custom_order <- NULL
  analysis$selected_genes <- analysis$gene_results[
    analysis$gene_results$selected %in% TRUE, , drop = FALSE
  ]
  analysis
}

#' Run a streamlined analysis of one custom PAO1 dataset
#'
#' One entry point for a target-correlation analysis, a two-condition
#' comparison, or enrichment of precomputed gene-level results. Unlike the
#' Whiteley workflow, this is a single-dataset analysis and contains no
#' cross-project meta-analysis, I2, persistence, or cutoff-survival machinery.
#' Canonical database pathways are reported by default; paannotate's manually
#' curated umbrella terms appear only when `curated=TRUE`.
#'
#' @param data Expression matrix/table or precomputed result table, supplied as
#'   a data frame, matrix, CSV/TSV/TXT file, or Excel workbook.
#' @param output_dir Report destination.
#' @param metadata Optional sample metadata table/file. It is required for a
#'   condition comparison but optional for target correlations.
#' @param targets Gene(s) to analyze separately, a named list defining one or
#'   more multi-gene signatures, or a [pa_targets()] object.
#' @param condition Metadata column used for a two-condition comparison.
#' @param comparison Two values in `c(positive, reference)` order.
#' @param mode Usually `"auto"`; explicit choices are `"correlation"`,
#'   `"comparison"`, and `"results"`.
#' @param data_type `"auto"`, `"raw_counts"`, `"tpm_cpm"`,
#'   `"normalized_log"`, or `"standardized"`.
#' @param sample_id_col,gene_id_col Input identifier columns, or `"auto"`.
#' @param sample_columns Optional expression-column names when metadata is not
#'   supplied and automatic detection is ambiguous.
#' @param orientation,expression_format,expression_sample_col,expression_value_col
#'   Advanced layout controls inherited from the general importer.
#' @param sheet,metadata_sheet Excel sheets for expression/results and metadata.
#' @param id_policy `"pao1_extended"` preserves canonical PAO1 tags and distinct
#'   decimal-suffixed historical subloci; `"pao1_exact"` accepts canonical tags
#'   only; `"as_is"` preserves arbitrary identifiers. Decimal suffixes are never
#'   stripped or treated as evidence of homology.
#' @param min_samples Minimum usable samples for expression analysis.
#' @param fdr,rho,log2fc Gene-selection thresholds; ranked enrichment still uses
#'   every tested gene.
#' @param adjust_for Optional metadata-column names to adjust for.
#' @param correlation Correlation used for gene targets.
#' @param minimum_cpm Low-expression threshold for raw counts.
#' @param enrich Run pathway enrichment.
#' @param membership Optional annotation object or membership file/table. When
#'   `NULL`, assembly-matched annotations are fetched if `organism_context`,
#'   `gene_catalog`, and `identifier_crosswalk` are supplied; otherwise the
#'   legacy PAO1 annotations are used.
#' @param organism_context Named assembly/taxon/strain context.
#' @param gene_catalog Assembly-native gene catalog CSV/data frame.
#' @param identifier_crosswalk Long-form direct identifier crosswalk.
#' @param annotation_evidence Currently `"direct"`; inferred orthology is never
#'   enabled implicitly.
#' @param custom_pathways Optional additional five-column membership table/file.
#' @param curated Include paannotate's manually curated umbrella pathways.
#' @param focus Optional pathway focus passed to [pa_focus_pathways()] after the
#'   main report is written, for example `"iron"`.
#' @param ranked_method `"auto"`, `"fgsea"`, or `"camera_pr"`.
#' @param term_fdr,global_fdr,minimum_overlap,minimum_size,maximum_size
#'   Pathway evidence and size settings.
#' @param themes Optional curated-theme dictionary used when `curated=TRUE`.
#' @param cache_dir,refresh_annotations,pseudocap_file,pseudocap_url Annotation
#'   retrieval controls.
#' @param preview Analyze and print the detected setup without enrichment or
#'   writing files.
#' @param workbook,heatmaps Write the reader workbook and figures.
#' @param maximum_excel_rows,maximum_heatmap_genes,maximum_heatmap_terms Display
#'   limits; complete CSV files are never truncated.
#' @return A `pa_custom_pipeline`, or a `pa_custom_analysis` when `preview=TRUE`.
#' @export
pa_run_custom <- function(
    data, output_dir = "paannotate_custom_report", metadata = NULL,
    targets = NULL, condition = NULL, comparison = NULL,
    mode = c("auto", "correlation", "comparison", "results"),
    data_type = c("auto", "raw_counts", "tpm_cpm", "normalized_log", "standardized"),
    sample_id_col = "auto", gene_id_col = "auto", sample_columns = NULL,
    orientation = "auto", expression_format = "auto",
    expression_sample_col = "auto", expression_value_col = "auto",
    sheet = 1, metadata_sheet = 1, id_policy = "pao1_extended",
    min_samples = 6, fdr = 0.05, rho = 0.30, log2fc = 1,
    adjust_for = NULL, correlation = c("spearman", "pearson"),
    minimum_cpm = 1, enrich = TRUE, membership = NULL,
    organism_context = NULL, gene_catalog = NULL, identifier_crosswalk = NULL,
    annotation_evidence = "direct",
    custom_pathways = NULL, curated = FALSE, focus = NULL,
    pathway_library_mode = "append", pathway_activity = FALSE, minimum_pathway_members = 3, minimum_pathway_fraction = .5,
    ranked_method = c("auto", "fgsea", "camera_pr"),
    term_fdr = 0.05, global_fdr = 0.05, minimum_overlap = 3,
    minimum_size = 5, maximum_size = 500, themes = NULL,
    cache_dir = file.path(tools::R_user_dir("paannotate", "cache"), "PAO1"),
    refresh_annotations = FALSE, pseudocap_file = NULL, pseudocap_url = NULL,
    preview = FALSE, workbook = TRUE, heatmaps = TRUE,
    maximum_excel_rows = 200000, maximum_heatmap_genes = 60,
    maximum_heatmap_terms = 40) {
  mode <- match.arg(mode)
  data_type <- match.arg(data_type)
  correlation <- match.arg(correlation)
  ranked_method <- match.arg(ranked_method)
  id_policy <- match.arg(id_policy, c("pao1_extended", "pao1_exact", "as_is"))
  if (!is.numeric(min_samples) || length(min_samples) != 1L ||
      !is.finite(min_samples) || min_samples < 4) {
    stop("min_samples must be one integer of at least 4.", call. = FALSE)
  }
  min_samples <- as.integer(min_samples)
  if (!is.numeric(fdr) || length(fdr) != 1L || !is.finite(fdr) ||
      fdr <= 0 || fdr > 1) stop("fdr must be between 0 and 1.", call. = FALSE)
  if (mode == "auto") {
    mode <- if (!is.null(targets)) "correlation" else
      if (!is.null(condition) || !is.null(comparison)) "comparison" else "results"
  }
  if (mode == "correlation" && is.null(targets)) {
    stop("Correlation mode requires targets=.", call. = FALSE)
  }
  if (mode == "comparison" && (is.null(condition) || is.null(comparison))) {
    stop("Comparison mode requires condition= and comparison=c(positive, reference).",
         call. = FALSE)
  }
  if (mode == "results") {
    analysis <- .custom_precomputed_analysis(
      data, sheet, orientation, gene_id_col, id_policy, fdr, log2fc
    )
  } else {
    prepared <- .custom_import_expression(
      data, metadata, sample_id_col, sample_columns, gene_id_col,
      orientation, expression_format, expression_sample_col,
      expression_value_col, sheet, metadata_sheet, id_policy
    )
    type_info <- .custom_infer_data_type(prepared$matrix, data_type)
    if (identical(type_info$confidence, "low")) warning(
      "The expression data type was inferred with low confidence as '",
      type_info$value, "'. Use preview=TRUE to inspect this decision, or set ",
      "data_type explicitly if it is incorrect.", call. = FALSE
    )
    analysis <- if (mode == "correlation") .custom_correlation_analysis(
      prepared, type_info, targets, min_samples, fdr, rho, adjust_for,
      correlation, id_policy, minimum_cpm
    ) else .custom_comparison_analysis(
      prepared, type_info, condition, comparison, min_samples, fdr, log2fc,
      adjust_for, minimum_cpm, id_policy
    )
  }
  resolve_annotations <- function() {
    if (!is.null(membership)) {
      frozen_membership <- .scan_read_membership(membership)
      if (is.null(gene_catalog)) return(frozen_membership)
      catalog <- .organism_read_csv(gene_catalog, "gene_catalog")
      if (!"gene_id" %in% names(catalog)) {
        stop("gene_catalog is missing gene_id.", call. = FALSE)
      }
      if ("gene_symbol" %in% names(catalog) && !"gene_names" %in% names(catalog)) {
        names(catalog)[names(catalog) == "gene_symbol"] <- "gene_names"
      }
      if ("product" %in% names(catalog) && !"protein_name" %in% names(catalog)) {
        names(catalog)[names(catalog) == "product"] <- "protein_name"
      }
      return(structure(list(
        membership = frozen_membership,
        membership_evidence = frozen_membership,
        annotation_audit = data.frame(
          provider = "frozen_membership",
          source_rows = nrow(frozen_membership),
          mapped_rows = nrow(frozen_membership),
          stringsAsFactors = FALSE
        ),
        uniprot_by_locus = catalog,
        kegg_by_locus = NULL,
        pseudocap_by_locus = NULL
      ), class = c("pa_annotations_v4", "pa_annotations_v3", "pa_annotations_v2")))
    }
    if (!is.null(organism_context)) return(fetch_organism_annotations(
      organism_context = organism_context, gene_catalog = gene_catalog,
      identifier_crosswalk = identifier_crosswalk, cache_dir = cache_dir,
      refresh = refresh_annotations, evidence = annotation_evidence
    ))
    fetch_pa_annotations(
      cache_dir = cache_dir, refresh = refresh_annotations,
      pseudocap_file = pseudocap_file, pseudocap_url = pseudocap_url
    )
  }
  if (isTRUE(preview)) {
    if (isTRUE(enrich)) {
      preview_annotations <- .p2c_combine_pathways(if(pathway_library_mode=='custom') .empty_membership() else resolve_annotations(),custom_pathways,pathway_library_mode)
      preview_membership <- .as_membership(preview_annotations)
      analysis$annotation_audit <- if (is.list(preview_annotations)) {
        preview_annotations$annotation_audit
      } else data.frame()
      analysis$config$annotation_membership_rows <- nrow(preview_membership)
      analysis$config$annotation_genes <- length(unique(preview_membership$gene_id))
    }
    print(analysis)
    return(invisible(analysis))
  }
  enrichment <- NULL
  if (isTRUE(enrich)) {
    annotation_source <- if(pathway_library_mode=="custom") .empty_membership() else resolve_annotations()
    custom_keys <- character()
    if(!is.null(custom_pathways))custom_keys <- unique(.custom_term_key(.as_membership(.scan_read_membership(custom_pathways))))
    annotation_source <- .p2c_combine_pathways(annotation_source,custom_pathways,pathway_library_mode)
    analysis$pathway_membership_audit <- .p2c_membership_audit(annotation_source,analysis$gene_results$gene_id,minimum_size)
    if(isTRUE(pathway_activity))analysis <- .p2c_custom_activity(analysis,.as_membership(annotation_source),minimum_pathway_members,minimum_pathway_fraction)
    method <- ranked_method
    if (method == "auto") method <- if (requireNamespace("fgsea", quietly = TRUE)) {
      "fgsea"
    } else if (requireNamespace("limma", quietly = TRUE)) "camera_pr" else NA_character_
    methods <- "ora"
    if (!is.na(method)) methods <- c(methods, method)
    if (is.na(method)) warning(
      "Ranked enrichment was skipped because neither fgsea nor limma is installed; ORA will still run.",
      call. = FALSE
    )
    enrichment <- .custom_enrich(
      analysis, annotation_source, methods, curated, themes,
      term_fdr, global_fdr, minimum_overlap, minimum_size, maximum_size
    )
    enrichment$config$custom_pathway_keys <- custom_keys
    analysis <- .custom_attach_annotations(analysis, enrichment)
  }
  files <- .custom_write_report(
    analysis, enrichment, output_dir, workbook, heatmaps,
    maximum_excel_rows, maximum_heatmap_genes, maximum_heatmap_terms
  )
  result <- structure(list(
    analysis = analysis, enrichment = enrichment, files = files, focus = NULL
  ), class = "pa_custom_pipeline")
  if (!is.null(focus) && !is.null(enrichment)) {
    result$focus <- tryCatch(pa_focus_pathways(
      result, focus = focus,
      output_dir = file.path(path.expand(output_dir), "07_focused_pathways"),
      sources = if (isTRUE(curated)) c("exact", "themes") else "exact"
    ), error = function(error) {
      warning("Focused pathway report was not created: ", conditionMessage(error),
              call. = FALSE)
      NULL
    })
  }
  print(result)
  invisible(result)
}

#' @export
print.pa_custom_analysis <- function(x, ...) {
  cat("paannotate single-dataset analysis\n")
  cat("  question:", x$config$question, "\n")
  cat("  analysis:", x$mode, "\n")
  cat("  input type:", x$config$data_type, "(", x$config$data_type_confidence,
      "confidence)\n")
  cat("  samples:", if (x$mode == "results") "precomputed" else x$sample_count,
      "\n")
  cat("  genes tested:", nrow(x$gene_results), "\n")
  cat("  genes selected:", nrow(x$selected_genes), "\n")
  invisible(x)
}

#' @export
print.pa_custom_pipeline <- function(x, ...) {
  print(x$analysis)
  if (!is.null(x$enrichment)) {
    cat("  canonical pathway terms:", nrow(.custom_term_subset(
      x$enrichment, x$enrichment$exact$summary
    )), "\n")
    if (length(x$enrichment$config$custom_pathway_keys)) cat(
      "  custom pathway terms:", nrow(.custom_term_subset(
        x$enrichment, x$enrichment$exact$summary, custom = TRUE
      )), "\n"
    )
    cat("  curated pathways:", if (.scan_has_curated(x$enrichment))
      nrow(x$enrichment$themes$summary) else "not requested", "\n")
  }
  cat("  report:", unname(x$files["report_directory"]), "\n")
  invisible(x)
}
