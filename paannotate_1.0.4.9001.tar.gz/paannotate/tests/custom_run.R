library(paannotate)

set.seed(73)
genes <- sprintf("PA%04d", seq_len(80))
samples <- paste0("sample_", seq_len(12))
latent <- as.numeric(scale(stats::rnorm(length(samples))))
expression <- matrix(
  stats::rnorm(length(genes) * length(samples)), nrow = length(genes),
  dimnames = list(genes, samples)
)
expression[1, ] <- latent
for (i in 2:10) expression[i, ] <- latent + stats::rnorm(length(latent), sd = 0.15)
for (i in 11:19) expression[i, ] <- -latent + stats::rnorm(length(latent), sd = 0.15)

membership <- rbind(
  data.frame(
    gene_id = genes[2:10], database = "GO", ontology = "BP",
    set_id = "GO:IRON", set_name = "siderophore-mediated iron acquisition"
  ),
  data.frame(
    gene_id = genes[11:19], database = "KEGG", ontology = "pathway",
    set_id = "pae02030", set_name = "Bacterial chemotaxis"
  ),
  data.frame(
    gene_id = genes[20:40], database = "GO", ontology = "BP",
    set_id = "GO:OTHER", set_name = "cellular process"
  )
)
annotation_object <- structure(list(membership = membership),
                               class = "pa_annotations_v2")
custom_membership <- data.frame(
  gene_id = genes[2:10], database = "CUSTOM", ontology = "user_defined",
  set_id = "CUSTOM:TARGET_POSITIVE", set_name = "My positive target module"
)
ranked_method <- if (requireNamespace("limma", quietly = TRUE)) "camera_pr" else "auto"

correlation_dir <- tempfile("paannotate_custom_correlation_")
correlation_result <- pa_run_custom(
  expression, correlation_dir, targets = "PA0001",
  data_type = "normalized_log", min_samples = 8,
  fdr = 0.10, rho = 0.50, membership = annotation_object,
  custom_pathways = custom_membership,
  ranked_method = ranked_method, minimum_size = 3, minimum_overlap = 2,
  curated = FALSE, workbook = requireNamespace("openxlsx", quietly = TRUE),
  heatmaps = requireNamespace("pheatmap", quietly = TRUE)
)
stopifnot(
  inherits(correlation_result, "pa_custom_pipeline"),
  inherits(correlation_result$analysis, "pa_custom_analysis"),
  correlation_result$analysis$mode == "correlation",
  !any(c("i2", "meta_rho", "cross_cutoff") %in%
       names(correlation_result$analysis$gene_results)),
  nrow(correlation_result$analysis$selected_genes) >= 10L,
  file.exists(file.path(correlation_dir, "START_HERE.csv")),
  file.exists(file.path(correlation_dir, "02_gene_results",
                        "all_gene_results.csv.gz")),
  file.exists(file.path(correlation_dir, "03_canonical_enrichment",
                        "canonical_summary.csv")),
  dir.exists(file.path(correlation_dir, "05_custom_pathways")),
  !dir.exists(file.path(correlation_dir, "06_curated_pathways")),
  !isTRUE(correlation_result$enrichment$config$curated)
)
canonical_output <- utils::read.csv(file.path(
  correlation_dir, "03_canonical_enrichment", "canonical_summary.csv"
))
custom_output <- utils::read.csv(file.path(
  correlation_dir, "05_custom_pathways", "custom_summary.csv"
))
stopifnot(
  !any(canonical_output$database == "CUSTOM"),
  any(custom_output$database == "CUSTOM")
)

focus <- pa_focus_pathways(
  correlation_result, focus = "GO:IRON", sources = "exact",
  output_dir = tempfile("paannotate_custom_focus_"),
  heatmaps = requireNamespace("pheatmap", quietly = TRUE)
)
stopifnot(inherits(focus, "pa_pathway_focus"), nrow(focus$matched_terms) == 1L)

if (requireNamespace("limma", quietly = TRUE)) {
  metadata <- data.frame(
    sample_id = samples,
    treatment = rep(c("control", "treated"), each = 6),
    batch = rep(c("one", "two"), times = 6),
    stringsAsFactors = FALSE
  )
  comparison_expression <- expression
  comparison_expression[2:10, metadata$treatment == "treated"] <-
    comparison_expression[2:10, metadata$treatment == "treated"] + 2
  comparison_dir <- tempfile("paannotate_custom_comparison_")
  comparison_result <- pa_run_custom(
    comparison_expression, comparison_dir, metadata = metadata,
    condition = "treatment", comparison = c("treated", "control"),
    data_type = "normalized_log", min_samples = 6,
    adjust_for = "batch", enrich = FALSE, workbook = FALSE, heatmaps = FALSE
  )
  stopifnot(
    comparison_result$analysis$mode == "comparison",
    all(c("log2FoldChange", "fdr") %in%
        names(comparison_result$analysis$gene_results)),
    comparison_result$analysis$config$positive == "treated",
    !dir.exists(file.path(comparison_dir, "03_canonical_enrichment"))
  )
}

if (requireNamespace("edgeR", quietly = TRUE)) {
  set.seed(74)
  count_metadata <- data.frame(
    sample_id = samples,
    treatment = rep(c("control", "treated"), each = 6),
    stringsAsFactors = FALSE
  )
  counts <- matrix(
    stats::rnbinom(length(genes) * length(samples), mu = 50, size = 10),
    nrow = length(genes), dimnames = list(genes, samples)
  )
  counts <- rbind(
    counts,
    "PA0195.1" = stats::rnbinom(length(samples), mu = 50, size = 10),
    "PA4280.1" = stats::rnbinom(length(samples), mu = 50, size = 10)
  )
  counts[2:8, count_metadata$treatment == "treated"] <-
    counts[2:8, count_metadata$treatment == "treated"] * 4L
  count_result <- pa_run_custom(
    counts, tempfile("paannotate_custom_counts_"), metadata = count_metadata,
    condition = "treatment", comparison = c("treated", "control"),
    data_type = "raw_counts", enrich = FALSE, workbook = FALSE,
    heatmaps = FALSE
  )
  stopifnot(
    count_result$analysis$mode == "comparison",
    grepl("edgeR", count_result$analysis$config$method),
    nrow(count_result$analysis$gene_results) > 0L,
    nrow(count_result$analysis$input_audit$gene_identifier_audit) == 82L,
    all(c("PA0195.1", "PA4280.1") %in%
        count_result$analysis$input_audit$gene_identifier_audit$gene_id)
  )
}

precomputed <- data.frame(
  gene_id = genes,
  log2FoldChange = c(rep(2, 10), stats::rnorm(70)),
  pvalue = c(rep(0.001, 10), stats::runif(70)),
  padj = c(rep(0.01, 10), stats::runif(70)),
  stringsAsFactors = FALSE
)
precomputed_dir <- tempfile("paannotate_custom_results_")
precomputed_result <- pa_run_custom(
  precomputed, precomputed_dir, enrich = FALSE,
  workbook = FALSE, heatmaps = FALSE
)
stopifnot(
  precomputed_result$analysis$mode == "results",
  nrow(precomputed_result$analysis$gene_results) == length(genes),
  file.exists(file.path(precomputed_dir, "analysis_checkpoint.rds"))
)

frozen_membership_file <- tempfile(fileext = ".csv")
utils::write.csv(membership, frozen_membership_file, row.names = FALSE)
frozen_catalog <- data.frame(
  gene_id = genes,
  locus_tag = genes,
  gene_symbol = paste0("symbol_", seq_along(genes)),
  product = paste("protein", seq_along(genes)),
  stringsAsFactors = FALSE
)
frozen_catalog_file <- tempfile(fileext = ".csv")
utils::write.csv(frozen_catalog, frozen_catalog_file, row.names = FALSE)
frozen_result <- pa_run_custom(
  precomputed, tempfile("paannotate_frozen_annotations_"),
  membership = frozen_membership_file, gene_catalog = frozen_catalog_file,
  ranked_method = ranked_method, minimum_size = 3, minimum_overlap = 2,
  workbook = FALSE, heatmaps = FALSE
)
stopifnot(
  "gene_names" %in% names(frozen_result$analysis$gene_results),
  frozen_result$analysis$gene_results$gene_names[1] == "symbol_1",
  "protein_name" %in% names(frozen_result$analysis$gene_results)
)

extended_loci <- data.frame(
  gene_id = c("PA0195", "PA0195.1", "PA4280", "PA4280.1", "PA4280.5"),
  log2FoldChange = c(1, 2, -1, -2, 1.5),
  pvalue = rep(0.001, 5), padj = rep(0.01, 5),
  stringsAsFactors = FALSE
)
extended_dir <- tempfile("paannotate_extended_loci_")
extended_result <- pa_run_custom(
  extended_loci, extended_dir, id_policy = "pao1_extended",
  enrich = FALSE, workbook = FALSE, heatmaps = FALSE
)
extended_audit <- extended_result$analysis$input_audit$gene_identifier_audit
stopifnot(
  nrow(extended_result$analysis$gene_results) == 5L,
  any(extended_result$analysis$gene_results$gene_id == "PA0195.1"),
  any(extended_result$analysis$gene_results$gene_id == "PA4280.1"),
  !anyDuplicated(extended_result$analysis$gene_results$gene_id),
  sum(extended_audit$locus_class == "historical_decimal_sublocus") == 3L,
  all(extended_audit$relationship_type[extended_audit$locus_class ==
    "historical_decimal_sublocus"] == "historical_sublocus_unresolved"),
  file.exists(file.path(extended_dir, "01_input_and_qc",
                        "gene_identifier_audit.csv"))
)

preview <- pa_run_custom(
  expression, targets = "PA0001", data_type = "normalized_log",
  min_samples = 8, enrich = FALSE, preview = TRUE
)
stopifnot(inherits(preview, "pa_custom_analysis"))

fixture_themes <- data.frame(
  priority = 1:3,
  curated_theme = c("Siderophore and iron acquisition", "Fixture chemotaxis", "Fixture general"),
  keyword_rule = c("siderophore", "chemotaxis", "cellular process"),
  focus = c("iron_core", "general", "general")
)

if (requireNamespace("limma", quietly = TRUE)) {
  curated_dir <- tempfile("paannotate_custom_curated_")
  curated_result <- pa_run_custom(
    expression, curated_dir, targets = "PA0001",
    data_type = "normalized_log", min_samples = 8,
    membership = annotation_object, ranked_method = "camera_pr",
    minimum_size = 3, minimum_overlap = 2, curated = TRUE, themes = fixture_themes,
    workbook = FALSE, heatmaps = FALSE
  )
  stopifnot(
    isTRUE(curated_result$enrichment$config$curated),
    dir.exists(file.path(curated_dir, "06_curated_pathways"))
  )
}
