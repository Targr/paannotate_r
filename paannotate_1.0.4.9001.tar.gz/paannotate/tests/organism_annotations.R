library(paannotate)

context <- list(
  assembly_accession = "GCF_060446305.1", tax_id = 652611,
  organism_name = "Pseudomonas aeruginosa PA14", strain = "PA14",
  validation = "exact_taxon", uniprot_tax_id = 652611
)
catalog <- data.frame(
  gene_id = c("AC7F68_RS07240", "AC7F68_RS07245"),
  locus_tag = c("AC7F68_RS07240", "AC7F68_RS07245"),
  gene_symbol = c("exampleA", "exampleB"),
  protein_id = c("WP_003109717.1", "WP_000000002.1"), product = c("A", "B")
)
crosswalk <- data.frame(
  gene_id = c("AC7F68_RS07240", "AC7F68_RS07240", "AC7F68_RS07245"),
  alias = c("AC7F68_RS07240", "WP_003109717.1", "AC7F68_RS07245"),
  alias_type = c("locus_tag", "protein_id", "locus_tag"),
  evidence_type = "direct_annotation", source = "NCBI GFF3"
)
cache <- tempfile("paannotate_organism_cache_")
provider_cache <- file.path(cache, "GCF_060446305.1_652611")
dir.create(provider_cache, recursive = TRUE)
writeLines("pau:PA14_10190\tpath:pau00010",
           file.path(provider_cache, "kegg_pau_gene_pathway.tsv"))
writeLines("path:pau00010\tGlycolysis / Gluconeogenesis",
           file.path(provider_cache, "kegg_pau_pathway_names.tsv"))
writeLines(c(
  paste(c("Entry", "Gene Names", "Gene Names (ordered locus)", "RefSeq",
          "Gene Ontology IDs", "Gene Ontology (biological process)",
          "Gene Ontology (molecular function)", "Gene Ontology (cellular component)",
          "Protein names"), collapse = "\t"),
  paste(c("Q00001", "exampleA", "PA14_10190", "WP_003109717.1;", "GO:0006096",
          "glycolytic process [GO:0006096]", "", "", "Example A"), collapse = "\t")
), file.path(provider_cache, "uniprot_taxon_652611_go.tsv"))

annotations <- fetch_organism_annotations(
  context, catalog, crosswalk, cache_dir = cache, providers = "KEGG"
)
stopifnot(
  inherits(annotations, "pa_annotations_v4"),
  nrow(annotations$membership) == 1L,
  annotations$membership$gene_id == "AC7F68_RS07240",
  annotations$membership$set_id == "pau00010",
  annotations$membership_evidence$source_identifier == "PA14_10190",
  annotations$membership_evidence$evidence_type == "direct_uniprot_accession_bridge",
  annotations$annotation_audit$mapped_rows == 1L,
  file.exists(file.path(provider_cache, "membership_evidence.csv")),
  !any(annotations$membership$gene_id == "PA14_10190")
)
