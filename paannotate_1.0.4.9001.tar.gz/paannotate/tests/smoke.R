library(paannotate)

cache_dir <- tempfile()
dir.create(cache_dir)
membership <- data.frame(
  gene_id = c("PA0001", "PA0002", "PA0003"),
  database = "KEGG", ontology = "KEGG pathway",
  set_id = "pae99999", set_name = "Synthetic pathway",
  stringsAsFactors = FALSE
)
kegg_by_locus <- data.frame(
  gene_id = c("PA0001", "PA0002", "PA0003"),
  kegg_pathway_ids = "pae99999",
  kegg_pathway_names = "Synthetic pathway",
  stringsAsFactors = FALSE
)
uniprot <- data.frame(
  gene_id = c("PA0001", "PA0002"),
  uniprot_accession = c("P1", "P2"),
  uniprot_gene_names = c("one", "two"),
  uniprot_protein_name = c("Protein one", "Protein two"),
  go_ids = c("", ""),
  go_biological_process = "", go_molecular_function = "",
  go_cellular_component = "", uniprot_function = "", ec_numbers = "",
  uniprot_pathway = "", stringsAsFactors = FALSE
)
annotations <- structure(
  list(
    membership = membership,
    kegg_by_locus = kegg_by_locus,
    uniprot_by_locus = uniprot
  ),
  class = "pa_annotations_v2"
)
saveRDS(annotations, file.path(cache_dir, "pa_annotations.rds"))

pseudocap <- data.frame(
  `Locus Tag` = c("PA0001", "PA0002", "PA0003"),
  `Gene Name` = c("dnaA", "two", "three"),
  Product = c("Initiator", "Protein two", "Protein three"),
  Start = c(1, 101, 301), End = c(100, 300, 600),
  `Database Source` = "PseudoCAP",
  `Pathway Name` = c("Replication", "Synthetic metabolism", "Synthetic metabolism"),
  `Functional Class` = c("Replication", "Metabolism", "Metabolism"),
  check.names = FALSE, stringsAsFactors = FALSE
)
pseudocap_file <- tempfile(fileext = ".csv")
utils::write.csv(pseudocap, pseudocap_file, row.names = FALSE)

whiteley_file <- tempfile(pattern = "whiteley_TPM_", fileext = ".csv")
utils::write.csv(data.frame(
  gene_id = c("PA0001", "PA0002", "PA0003"),
  study_1 = c(5, 10, 0), study_2 = c(7, 12, 1)
), whiteley_file, row.names = FALSE)
whiteley <- import_whiteley(whiteley_file, data_type = "tpm")
stopifnot(inherits(whiteley, "pa_whiteley"))
stopifnot(whiteley$data_type == "tpm")

input <- data.frame(
  gene_id = c("PA0001", "PA0002", "PA0003", "PA0714_1"),
  gene_name = c("one", "two", "three", "ambiguous"),
  gene_description = "",
  a1 = c(100, 50, 10, 10), a2 = c(110, 55, 11, 10),
  b1 = c(10, 50, 100, 10), b2 = c(11, 55, 110, 10),
  log2FoldChange = c(-3.3, 0, 3.3, 0),
  pvalue = c(0.001, 1, 0.001, 1),
  padj = c(0.003, 1, 0.003, 1)
)

csv <- tempfile(fileext = ".csv")
tsv <- tempfile(fileext = ".tsv")
utils::write.csv(input, csv, row.names = FALSE)
utils::write.table(input, tsv, sep = "\t", quote = FALSE, row.names = FALSE)

for (path in c(csv, tsv)) {
  output <- tempfile()
  result <- analyze_pa_csv(
    path, c("a1", "a2"), c("b1", "b2"), "A", "B",
    output_dir = output, cache_dir = cache_dir,
    pseudocap_file = pseudocap_file, whiteley_reference = whiteley
  )
  stopifnot(nrow(result$all_genes) == nrow(input))
  stopifnot(nrow(result$significant_genes) == 2)
  stopifnot(result$comparison_summary$positive_log2fc_means == "B")
  stopifnot(is.na(result$all_genes$pao1_locus[4]))
  stopifnot(result$all_genes$gene_length[1] == 100)
  stopifnot(result$all_genes$whiteley_data_type[1] == "tpm")
  stopifnot(any(result$annotation_membership$database == "PseudoCAP"))
  stopifnot(file.exists(
    file.path(output, "summary", "comparison_summary.csv")
  ))
}

# Separate files are joined by locus tag, not row position.
expression_only <- input[c("gene_id", "gene_name", "gene_description",
                           "a1", "a2", "b1", "b2")]
statistics_only <- input[rev(seq_len(nrow(input))),
                         c("gene_id", "log2FoldChange", "pvalue", "padj")]
combined <- pa_combine(expression_only, statistics_only, minimum_match = 1)
stopifnot(inherits(combined, "pa_input"))
stopifnot(combined$data$log2FoldChange[combined$data$gene_id == "PA0001"] == -3.3)

# A table with genes across columns is transposed and common aliases normalize.
transposed <- data.frame(
  field = c("a1", "b1", "logFC", "pval", "FDR"),
  PA0001 = c(100, 10, -3.3, 0.001, 0.003),
  PA0002 = c(50, 50, 0, 1, 1),
  check.names = FALSE, stringsAsFactors = FALSE
)
odd <- pa_read(transposed, orientation = "genes_in_columns")
stopifnot(nrow(odd$data) == 2)
stopifnot(all(c("gene_id", "log2FoldChange", "pvalue", "padj") %in%
              names(odd$data)))

guide <- utils::capture.output(pa_help())
stopifnot(any(grepl("pa_combine", guide, fixed = TRUE)))

# Execute optional statistical engines when they are installed.
set.seed(42)
advanced_ids <- sprintf("PA%04d", seq_len(100))
advanced_data <- data.frame(
  gene_id = advanced_ids,
  log2FoldChange = c(rep(2, 15), stats::rnorm(85)),
  pvalue = c(rep(0.001, 15), stats::runif(85)),
  padj = c(rep(0.01, 15), stats::runif(85)),
  gene_length = sample(300:2000, 100),
  stringsAsFactors = FALSE
)
advanced_membership <- do.call(rbind, lapply(seq_len(5), function(set) {
  data.frame(
    gene_id = advanced_ids[((set - 1) * 20 + 1):(set * 20)],
    database = "test", ontology = "path", set_id = paste0("set", set),
    set_name = paste("Set", set), stringsAsFactors = FALSE
  )
}))
if (requireNamespace("limma", quietly = TRUE)) {
  ranked <- pa_enrich_ranked(
    advanced_data, advanced_membership, method = "camera_pr"
  )
  stopifnot(nrow(ranked$results) == 5, nrow(ranked$ranked_genes) == 100)
  log_expression <- matrix(
    stats::rnorm(600), nrow = 100,
    dimnames = list(advanced_ids, paste0("sample", seq_len(6)))
  )
  log_expression[1:15, 4:6] <- log_expression[1:15, 4:6] + 1
  design <- cbind(Intercept = 1, Group = c(0, 0, 0, 1, 1, 1))
  full_camera <- pa_enrich_ranked(
    advanced_data, advanced_membership, method = "camera",
    expression = log_expression, design = design, contrast = 2,
    inter_gene_cor = NA
  )
  stopifnot(nrow(full_camera$results) == 5)
}
if (requireNamespace("goseq", quietly = TRUE)) {
  biased <- pa_enrich_bias(
    advanced_data, advanced_membership, bias = "gene_length"
  )
  stopifnot(nrow(biased$results) == 5)
}
if (requireNamespace("fgsea", quietly = TRUE)) {
  ranked_fgsea <- suppressWarnings(pa_enrich_ranked(
    advanced_data, advanced_membership, method = "fgsea"
  ))
  stopifnot(nrow(ranked_fgsea$results) == 5)
}
