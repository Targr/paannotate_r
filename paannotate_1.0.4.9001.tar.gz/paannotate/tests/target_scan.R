library(paannotate)

set.seed(17)
projects <- 6L
samples_per_project <- 16L
sample_count <- projects * samples_per_project
metadata <- data.frame(
  sample_id = paste0("S", seq_len(sample_count)),
  project_id = rep(paste0("P", seq_len(projects)), each = samples_per_project),
  study_arm = rep(rep(c("A", "B"), each = samples_per_project / 2), projects),
  stringsAsFactors = FALSE
)
latent <- unlist(lapply(seq_len(projects), function(i) {
  as.numeric(scale(stats::rnorm(samples_per_project)))
}))
genes <- sprintf("PA%04d", seq_len(61))
expression <- matrix(
  stats::rnorm(length(genes) * sample_count), length(genes), sample_count,
  dimnames = list(genes, metadata$sample_id)
)
expression[1, ] <- latent + stats::rnorm(sample_count, sd = 0.10)
expression[61, ] <- latent + stats::rnorm(sample_count, sd = 0.12)
for (gene in 2:11) {
  expression[gene, ] <- 0.75 * latent + stats::rnorm(sample_count, sd = 0.35)
}
for (gene in 12:21) {
  expression[gene, ] <- -0.75 * latent + stats::rnorm(sample_count, sd = 0.35)
}

targets <- pa_targets(
  individual = c(Pf_gene = "PA0001", invalid_example = "PA0195_1"),
  sets = list(Pf_block = c("PA0001", "PA0061"))
)
stopifnot(nrow(targets$audit$invalid_target_ids) == 1L)
extended_targets <- pa_targets(individual = c(decimal_sublocus = "PA0195.1"))
stopifnot(any(extended_targets$membership$gene_id == "PA0195.1"))

preflight <- pa_check_scan(
  expression, metadata, targets, data_type = "normalized_log",
  min_samples_per_project = c(12, 16)
)
stopifnot(inherits(preflight, "pa_scan_check"), all(preflight$target_coverage$usable))

# Matrix orientation auto-detection and long-format import use the same samples.
transposed_check <- pa_check_scan(
  t(expression), metadata, targets, data_type = "normalized_log",
  min_samples_per_project = 16
)
stopifnot(transposed_check$summary$value[transposed_check$summary$item == "genes"] == 61)
long_expression <- data.frame(
  gene_id = rep(rownames(expression), times = ncol(expression)),
  sample_id = rep(colnames(expression), each = nrow(expression)),
  expression = as.vector(expression), stringsAsFactors = FALSE
)
long_check <- pa_check_scan(
  long_expression, metadata, targets, expression_format = "long",
  data_type = "normalized_log", min_samples_per_project = 16
)
stopifnot(long_check$summary$value[long_check$summary$item == "matched samples"] == sample_count)

thresholds <- pa_scan_thresholds(i2 = 100)
scan <- pa_scan_targets(
  expression, metadata, targets, adjustment = ~ study_arm,
  min_samples_per_project = c(12, 16), data_type = "normalized_log",
  thresholds = thresholds
)
stopifnot(inherits(scan, "pa_target_scan"))
stopifnot(all(c("total", "adjusted") %in% scan$meta_analysis$analysis_mode))
stopifnot(nrow(scan$meta_analysis) == 2L * 2L * 2L * 59L)
stopifnot(any(scan$cross_cutoff$gene_id == "PA0002"))
stopifnot(any(scan$cross_cutoff$gene_id == "PA0012"))
stopifnot(all(scan$project_qc$included_at_n16))

simple_meta <- paannotate:::.scan_random_effects(rep(0.5, 4), rep(20, 4), 3)
stopifnot(abs(simple_meta[["meta_rho"]] - 0.5) < 1e-10)
stopifnot(simple_meta[["i2_percent"]] == 0)

membership <- rbind(
  data.frame(
    gene_id = genes[2:11], database = "GO", ontology = "BP",
    set_id = "GO:IRON", set_name = "siderophore-mediated iron acquisition"
  ),
  data.frame(
    gene_id = genes[12:21], database = "KEGG", ontology = "pathway",
    set_id = "pae02030", set_name = "Bacterial chemotaxis"
  ),
  data.frame(
    gene_id = genes[22:41], database = "GO", ontology = "BP",
    set_id = "GO:OTHER", set_name = "cellular process"
  )
)
methods <- if (requireNamespace("fgsea", quietly = TRUE)) c("ora", "fgsea") else "ora"
annotation_object <- structure(list(
  membership = membership,
  uniprot_by_locus = data.frame(
    gene_id = genes,
    uniprot_gene_names = paste0("gene", seq_along(genes)),
    uniprot_protein_name = paste("Protein", seq_along(genes)),
    stringsAsFactors = FALSE
  )
), class = "pa_annotations_v2")
fixture_themes <- data.frame(
  priority = 1:3,
  curated_theme = c("Siderophore and iron acquisition", "Fixture chemotaxis", "Fixture general"),
  keyword_rule = c("siderophore", "chemotaxis", "cellular process"),
  focus = c("iron_core", "general", "general")
)

enrichment <- suppressWarnings(pa_enrich_scan(
  scan, annotation_object, methods = methods, cutoff = 16,
  minimum_overlap = 3, minimum_size = 3, curated = TRUE, themes = fixture_themes
))
stopifnot(inherits(enrichment, "pa_scan_enrichment"))
stopifnot(nrow(enrichment$gene_annotations) == length(genes))
stopifnot(nrow(enrichment$exact$ora) > 0)
stopifnot(any(enrichment$iron$exact_terms$set_id == "GO:IRON"))
stopifnot(any(enrichment$themes$summary$set_name == "Siderophore and iron acquisition"))

# Empty selected-gene lists skip ORA without blocking independent ranked
# enrichment. This is a valid result when no individual relationship satisfies
# every persistence rule but pathway members move together in the full ranking.
empty_selection_scan <- scan
empty_selection_scan$relationships$persistent[] <- FALSE
empty_selection_enrichment <- suppressWarnings(pa_enrich_scan(
  empty_selection_scan, annotation_object, methods = methods, cutoff = 16,
  minimum_overlap = 3, minimum_size = 3, curated = TRUE, themes = fixture_themes
))
stopifnot(inherits(empty_selection_enrichment, "pa_scan_enrichment"))
stopifnot(nrow(empty_selection_enrichment$selection) == 0L)
stopifnot(nrow(empty_selection_enrichment$exact$ora) == 0L)
stopifnot(nrow(empty_selection_enrichment$themes$ora) == 0L)
if ("fgsea" %in% methods) {
  stopifnot(nrow(empty_selection_enrichment$exact$ranked) > 0L)
  stopifnot(nrow(empty_selection_enrichment$themes$ranked) > 0L)
  stopifnot(nrow(empty_selection_enrichment$exact$summary) > 0L)
  stopifnot(all(!empty_selection_enrichment$exact$summary$ora_strict))
  stopifnot(any(empty_selection_enrichment$exact$summary$ranked_strict))
  stopifnot(any(empty_selection_enrichment$exact$summary$evidence_tier ==
                  "Ranked supported"))
}

# Multiple requested cutoffs may contain selected genes at one cutoff and none
# at another. The empty cutoff remains valid and does not discard the populated
# cutoff's ORA results.
mixed_selection_scan <- scan
mixed_selection_scan$relationships$persistent[
  mixed_selection_scan$relationships$cutoff == 16
] <- FALSE
mixed_selection_enrichment <- suppressWarnings(pa_enrich_scan(
  mixed_selection_scan, annotation_object, methods = "ora", cutoff = c(12, 16),
  minimum_overlap = 3, minimum_size = 3
))
stopifnot(nrow(mixed_selection_enrichment$selection) > 0L)
stopifnot(all(mixed_selection_enrichment$selection$cutoff == 12L))
stopifnot(nrow(mixed_selection_enrichment$exact$ora) > 0L)
stopifnot(all(mixed_selection_enrichment$exact$ora$cutoff == 12L))

# A non-evaluable ranked pathway can share a heatmap cell with a valid result.
# It remains auditable but must not make the finite matrix value fail.
nonfinite_summary <- data.frame(
  cutoff = c(16L, 16L), target = c("Pf_gene", "Pf_gene"),
  direction = c("Positive", NA_character_), database = c("GO", "GO"),
  ontology = c("BP", "BP"), set_id = c("GO:IRON", "GO:IRON_FAILED"),
  set_name = c("iron acquisition", "iron acquisition"),
  ora_best_fdr = c(0.01, NA_real_), ranked_best_fdr = c(NA_real_, 0.02),
  stringsAsFactors = FALSE
)
nonfinite_matrix <- paannotate:::.scan_summary_matrix(nonfinite_summary)
stopifnot(is.matrix(nonfinite_matrix), all(is.finite(nonfinite_matrix)))

# Invalid P-values do not enter BH correction or alter valid adjusted values.
bh_input <- data.frame(
  family = "one", pvalue = c(0.01, NA_real_, 0.02), stringsAsFactors = FALSE
)
bh_output <- paannotate:::.scan_group_bh(bh_input, "pvalue", "family")
stopifnot(is.na(bh_output$family_fdr[2]), is.na(bh_output$global_fdr[2]))
stopifnot(all(abs(bh_output$family_fdr[c(1, 3)] - c(0.02, 0.02)) < 1e-12))

# Non-evaluable ranked rows remain in the audit input but are omitted from the
# reader-facing term summary.
ranked_audit <- data.frame(
  cutoff = c(16L, 16L), target = c("Pf_gene", "Pf_gene"),
  direction = c("Positive", NA_character_), database = c("GO", "GO"),
  ontology = c("BP", "BP"), set_id = c("GO:IRON", "GO:FAILED"),
  set_name = c("iron acquisition", "failed pathway"),
  method = "fgsea", global_fdr = c(0.02, NA_real_),
  strict_support = c(TRUE, FALSE), enrichment_score = c(2.1, NA_real_),
  pvalue = c(0.01, NA_real_), evaluable = c(TRUE, FALSE),
  stringsAsFactors = FALSE
)
ranked_summary <- paannotate:::.scan_term_summary(data.frame(), ranked_audit)
stopifnot(nrow(ranked_summary) == 1L, ranked_summary$set_id == "GO:IRON")

report_dir <- tempfile("paannotate_target_scan_")
files <- pa_write_scan(
  scan, enrichment, report_dir,
  workbook = requireNamespace("openxlsx", quietly = TRUE),
  heatmaps = requireNamespace("pheatmap", quietly = TRUE)
)
stopifnot(file.exists(file.path(report_dir, "04_relationships", "cross_cutoff.csv")))
stopifnot(file.exists(file.path(report_dir, "05_enrichment", "iron_exact_terms.csv")))
if (requireNamespace("openxlsx", quietly = TRUE)) {
  stopifnot(file.exists(file.path(report_dir, "paannotate_target_scan_report.xlsx")))
}
if (requireNamespace("pheatmap", quietly = TRUE)) {
  stopifnot(file.exists(file.path(report_dir, "06_heatmaps", "iron_focused_pathways.png")))
  stopifnot(file.exists(file.path(report_dir, "06_heatmaps", "heatmap_status.csv")))
  heatmap_status <- utils::read.csv(
    file.path(report_dir, "06_heatmaps", "heatmap_status.csv"),
    stringsAsFactors = FALSE
  )
  stopifnot(any(heatmap_status$scope == "combined"))
  stopifnot(any(heatmap_status$scope == "individual" &
                  heatmap_status$target == "Pf_gene"))
}

# Focused pathway reports reuse saved enrichment rather than rerunning it.
focus_preview <- pa_focus_pathways(
  enrichment, focus = "GO:IRON", sources = "exact", preview = TRUE
)
stopifnot(inherits(focus_preview, "pa_pathway_focus"))
stopifnot(nrow(focus_preview$matched_terms) == 1L)
stopifnot(focus_preview$matched_terms$set_id == "GO:IRON")

# Presets search biological pathway names, not internal THEME_ prefixes or
# substrings such as the "iron" letters inside "environment".
preset_terms <- data.frame(
  source = c("exact", "themes", "themes"), database = c("KEGG", "CURATED", "CURATED"),
  ontology = c("pathway", "umbrella_theme", "umbrella_theme"),
  set_id = c("pae01120", "THEME_protein_secretion", "THEME_iron_biology"),
  set_name = c("Microbial metabolism in diverse environments",
               "Protein secretion and export", "Iron acquisition"),
  stringsAsFactors = FALSE
)
preset_match <- paannotate:::.focus_match_terms(
  preset_terms, paannotate:::.focus_normalize("iron", "auto")
)
stopifnot(sum(preset_match$matched) == 1L)
stopifnot(preset_match$set_name[preset_match$matched] == "Iron acquisition")

wide_canvas <- paannotate:::.focus_canvas_dimensions(
  paste(rep("a very long ontology pathway label", 8), collapse = " "), rows = 10
)
stopifnot(wide_canvas$width > 18, wide_canvas$left_margin > 16)

if (requireNamespace("pheatmap", quietly = TRUE)) {
  sparse_heatmap_base <- tempfile("paannotate_sparse_heatmap_")
  sparse_matrix <- matrix(
    c(2, NA, NA, -2), nrow = 2,
    dimnames = list(c("pathway A", "pathway B"), c("target A", "target B"))
  )
  sparse_files <- paannotate:::.scan_render_heatmap(
    sparse_matrix, sparse_heatmap_base, "Sparse but valid heatmap"
  )
  stopifnot(setequal(tools::file_ext(sparse_files), c("svg", "pdf", "png")), all(file.exists(sparse_files)))
}

focus_dir <- tempfile("paannotate_focus_")
pipeline_for_focus <- structure(
  list(scan = scan, enrichment = enrichment,
       files = c(report_directory = report_dir)),
  class = "pa_scan_pipeline"
)
focused <- pa_focus_pathways(
  pipeline_for_focus,
  focus = list(Iron_system = "GO:IRON", Chemotaxis = "pae02030"),
  output_dir = focus_dir, sources = "exact",
  heatmaps = requireNamespace("pheatmap", quietly = TRUE), maximum_terms = 10
)
stopifnot(inherits(focused, "pa_pathway_focus"))
stopifnot(file.exists(file.path(focus_dir, "focus_match_audit.csv")))
stopifnot(file.exists(file.path(focus_dir, "iron_system", "pathway_statistics.csv")))
stopifnot(file.exists(file.path(focus_dir, "iron_system", "README.txt")))
stopifnot(file.exists(file.path(focus_dir, "pa_pathway_focus.rds")))
stopifnot(!any(focused$status$status == "failed"))

# Focusing is a view operation: original adjusted P-values remain byte-for-byte
# unchanged rather than being corrected again after terms are selected.
focused_ora <- focused$groups$Iron_system$tables$exact_ora
original_ora <- enrichment$exact$ora[
  enrichment$exact$ora$set_id == "GO:IRON", , drop = FALSE
]
stopifnot(identical(focused_ora$global_fdr, original_ora$global_fdr))
stopifnot(identical(focused_ora$family_fdr, original_ora$family_fdr))
stopifnot(nrow(focused$groups$Iron_system$tables$pathway_membership) == 10L)

# Older enrichment checkpoints did not retain complete exact membership. They
# still yield overlap/leading-edge membership instead of crashing.
legacy_enrichment <- enrichment
legacy_enrichment$exact$membership <- NULL
legacy_dir <- tempfile("paannotate_legacy_focus_")
legacy_focus <- pa_focus_pathways(
  legacy_enrichment, focus = "GO:IRON", output_dir = legacy_dir,
  sources = "exact", methods = "ora", heatmaps = FALSE, dotplots = FALSE
)
stopifnot(inherits(legacy_focus, "pa_pathway_focus"))
stopifnot(nrow(legacy_focus$groups[[1]]$tables$pathway_membership) > 0L)
stopifnot(all(grepl("legacy report",
                    legacy_focus$groups[[1]]$tables$pathway_membership$membership_basis)))

if (requireNamespace("yaml", quietly = TRUE)) {
  config_dir <- tempfile("paannotate_config_")
  dir.create(config_dir)
  expression_file <- file.path(config_dir, "expression.csv")
  metadata_file <- file.path(config_dir, "metadata.csv")
  utils::write.csv(data.frame(gene_id = rownames(expression), expression,
                              check.names = FALSE), expression_file, row.names = FALSE)
  utils::write.csv(metadata, metadata_file, row.names = FALSE)
  config <- list(
    expression = list(path = "expression.csv", data_type = "normalized_log"),
    metadata = list(path = "metadata.csv"),
    targets = list(individual = list(Pf_gene = "PA0001")),
    scan = list(adjustment = "~ study_arm", min_samples_per_project = 16,
                thresholds = list(i2 = 100)),
    enrichment = list(enabled = FALSE),
    report = list(output_dir = "yaml_report", workbook = FALSE, heatmaps = FALSE)
  )
  config_file <- file.path(config_dir, "scan.yml")
  yaml::write_yaml(config, config_file)
  pipeline <- pa_run_scan_config(config_file)
  stopifnot(inherits(pipeline, "pa_scan_pipeline"))
  stopifnot(file.exists(file.path(config_dir, "yaml_report", "00_audit", "scan_config.R")))
}
