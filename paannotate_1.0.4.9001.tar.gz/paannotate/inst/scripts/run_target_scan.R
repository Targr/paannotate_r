#!/usr/bin/env Rscript

arguments <- commandArgs(trailingOnly = TRUE)
if (length(arguments) != 1L || arguments %in% c("-h", "--help")) {
  cat("Usage: Rscript run_target_scan.R target_scan_config.yml\n")
  quit(save = "no", status = if (length(arguments) == 1L) 0L else 2L)
}

result <- paannotate::pa_run_scan_config(arguments[[1]])
print(result)
