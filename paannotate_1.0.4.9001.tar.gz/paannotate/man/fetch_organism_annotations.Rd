\name{fetch_organism_annotations}
\alias{fetch_organism_annotations}
\title{Fetch assembly-matched KEGG and GO annotations}
\usage{
fetch_organism_annotations(
  organism_context,
  gene_catalog,
  identifier_crosswalk,
  cache_dir = file.path(tools::R_user_dir("paannotate", "cache"), "organisms"),
  refresh = FALSE,
  providers = c("KEGG", "GO"),
  evidence = "direct"
)
}
\arguments{
\item{organism_context}{Named assembly/taxon/strain context from a validated reference.}
\item{gene_catalog}{Assembly-native gene catalog CSV path or data frame.}
\item{identifier_crosswalk}{Long-form direct alias crosswalk CSV path or data frame.}
\item{cache_dir}{Writable per-organism annotation cache.}
\item{refresh}{Force fresh provider downloads.}
\item{providers}{Any of \code{"KEGG"} and \code{"GO"}.}
\item{evidence}{\code{"direct"}; inferred orthology is not enabled implicitly.}
}
\value{A \code{pa_annotations_v4} object with membership, gene annotations, and a provider audit.}
\description{Resolves provider identifiers through an explicit GFF-derived crosswalk while preserving assembly-native locus tags as primary identifiers.}
