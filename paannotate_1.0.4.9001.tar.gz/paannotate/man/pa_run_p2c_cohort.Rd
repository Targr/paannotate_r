\name{pa_run_p2c_cohort}
\alias{pa_run_p2c_cohort}
\title{Run a Whiteley-style target scan of a custom Paper2Counts cohort}
\usage{
pa_run_p2c_cohort(
  manifest,
  targets,
  output_dir,
  min_samples_per_project = 6,
  heatmaps = FALSE,
  workbook = FALSE,
  scan_args = list(),
  membership = NULL,
  custom_pathways = NULL,
  enrich = FALSE,
  pathway_library_mode = "append",
  pathway_activity = FALSE,
  minimum_size = 5,
  minimum_pathway_members = 3,
  minimum_pathway_fraction = 0.5
)
}
\arguments{
\item{membership}{Optional pathway membership table or annotation object.}
\item{custom_pathways}{Optional user-supplied pathway sets.}
\item{enrich}{Whether to test pathway enrichment.}
\item{minimum_size}{Minimum term size for enrichment.}
\item{pathway_library_mode}{How custom sets combine with the provider library.}
\item{pathway_activity}{Whether to calculate sample-level pathway scores.}
\item{minimum_pathway_members}{Minimum measured members for a pathway score.}
\item{minimum_pathway_fraction}{Minimum measured fraction for a pathway score.}

\item{manifest}{P2C cohort scan manifest accepted by \code{pa_load_p2c_cohort()}.}
\item{targets}{Gene IDs or unambiguous gene symbols to scan separately.}
\item{output_dir}{Organized report destination.}
\item{min_samples_per_project}{Minimum samples per contributing study.}
\item{heatmaps}{Write heatmaps when the optional plotting package is available.}
\item{workbook}{Write an Excel workbook when openxlsx is available.}
\item{scan_args}{Additional named arguments passed to \code{pa_scan_targets()}.}
}
\value{
A \code{pa_scan_pipeline} object containing the target scan and output paths.
}
\description{
Normalizes each study independently, calculates target-gene correlations within studies, and combines those correlations across studies. Decimal locus IDs such as PA0714.1 remain distinct from PA0714. Targets may use symbols resolved through supplied gene catalogs. The report includes study gene coverage and target resolution audits.
}
