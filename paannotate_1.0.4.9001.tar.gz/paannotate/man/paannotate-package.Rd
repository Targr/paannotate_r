\name{paannotate-package}
\alias{paannotate}
\alias{paannotate-package}
\title{Reusable PAO1 annotation and enrichment}
\description{
Downloads and caches KEGG and UniProt-GOA annotations for PAO1, annotates
differential-expression tables, and performs KEGG and GO enrichment.
}
\docType{package}
