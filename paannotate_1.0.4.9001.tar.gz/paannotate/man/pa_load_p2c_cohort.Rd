\name{pa_load_p2c_cohort}
\alias{pa_load_p2c_cohort}
\title{Load a Paper2Counts cohort for a Whiteley-style target scan}
\usage{
pa_load_p2c_cohort(manifest)
}
\arguments{
\item{manifest}{Path to a P2C cohort scan manifest CSV or a data frame.}
}
\value{
A list with a \code{pa_whiteley}-compatible count object, study gene and sample audit, and gene alias table.
}
\description{
Reads independent Paper2Counts raw-count matrices and their sample metadata. Only exact gene identifiers shared across every selected study are included. Missing genes are never filled with zero counts. Optional gene catalogs supply aliases such as PhrD.
}
